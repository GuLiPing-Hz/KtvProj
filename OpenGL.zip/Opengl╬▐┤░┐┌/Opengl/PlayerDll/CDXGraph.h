//
// CDXGraph.h
//

#ifndef __H_CDXGraph__
#define __H_CDXGraph__

// Filter graph notification to the specified window
#define WM_GRAPHNOTIFY  (WM_USER+20)

class CDXGraph
{
private:

	IMediaControl *		mMediaControl;
	IMediaEventEx *		mEvent;
	IBasicVideo *		mBasicVideo;

	IVideoWindow  *		mVideoWindow;


	DWORD				mObjectTableEntry; 

public:	
	IGraphBuilder *     mGraph;  
	IBasicAudio *		mBasicAudio;
	IMediaSeeking *		mSeeking;
	CDXGraph();
	virtual ~CDXGraph();

public:
	virtual bool Create(void);
	virtual void Release(void);
	virtual bool Attach(IGraphBuilder * inGraphBuilder);

	IGraphBuilder * GetGraph(void); // Not outstanding reference count
	IMediaEventEx * GetEventHandle(void);

	bool ConnectFilters(IPin * inOutputPin, IPin * inInputPin, const AM_MEDIA_TYPE * inMediaType = 0);
	void DisconnectFilters(IPin * inOutputPin);

	bool SetDisplayWindow(HWND inWindow);
	bool SetNotifyWindow(HWND inWindow);
	bool ResizeVideoWindow(long inLeft, long inTop, long inWidth, long inHeight);
	void HandleEvent(WPARAM inWParam, LPARAM inLParam);

	bool Run(void);        // Control filter graph
	bool Stop(void);
	bool Pause(void);
	bool IsRunning(void);  // Filter graph status
	bool IsStopped(void);
	bool IsPaused(void);

	bool SetFullScreen(BOOL inEnabled);
	bool GetFullScreen(void);

	// IMediaSeeking
	bool GetCurrentPosition(double * outPosition);
	bool GetStopPosition(double * outPosition);
	bool SetCurrentPosition(double inPosition);
	bool SetStartStopPosition(double inStart, double inStop);
	bool GetDuration(double * outDuration);
	bool SetPlaybackRate(double inRate);

	// Attention: range from -10000 to 0, and 0 is FULL_VOLUME.
	bool SetAudioVolume(long inVolume);
	long GetAudioVolume(void);
	// Attention: range from -10000(left) to 10000(right), and 0 is both.
	bool SetAudioBalance(long inBalance);
	long GetAudioBalance(void);

	bool RenderFile(const char * inFile);
	bool RenderFileTCHAR(const TCHAR * inFile);
	bool RenderPin(IPin *pin);
	int   GetStatus(void) ;
//	bool SnapshotBitmap(const char * outFile);
	HRESULT FindFilterByInterface(REFIID   riid,   IBaseFilter**   ppFilter);
	HRESULT   FindFilterByName(LPCWSTR    strName,   IBaseFilter**   ppFilter) ; 
	IPin   *   GetPin(IBaseFilter   *pFilter,PIN_DIRECTION   dirRequest);
	IPin   *   InputPinOf(IBaseFilter   *pFilter);
	IPin   *   OutputPinOf(IBaseFilter   *pFilter);
	HRESULT NextUpstream(IBaseFilter* pFilter, IBaseFilter** ppNext);
	HRESULT ConnectUpstreamOf(IBaseFilter* pFilter, IBaseFilter* pTransform);
	HRESULT ConnectUpstreamOf2(IBaseFilter* pFilter, IBaseFilter* pTransform);
	HRESULT ConnectUpstreamOf3(IBaseFilter* pFilter, IBaseFilter* pTransform);
	HRESULT AddFilter(IBaseFilter *pFilter, LPCWSTR pName);
	HRESULT DelFilter(IBaseFilter *pFilter);	


	HRESULT AddFilterByCLSID(
		IGraphBuilder *pGraph,  // Pointer to the Filter Graph Manager.
		const GUID& clsid,      // CLSID of the filter to create.
		LPCWSTR wszName,        // A name for the filter.
		IBaseFilter **ppF) ;     // Receives a pointer to the filter.
	HRESULT GetUnconnectedPin(
		IBaseFilter *pFilter,   // Pointer to the filter.
		PIN_DIRECTION PinDir,   // Direction of the pin to find.
    IPin **ppPin);           // Receives a pointer to the pin.
	HRESULT ConnectFilters(
		IGraphBuilder *pGraph, // Filter Graph Manager.
		IPin *pOut,            // Output pin on the upstream filter.
    IBaseFilter *pDest);    // Downstream filter.
	
	HRESULT ConnectFilters(
		IGraphBuilder *pGraph, 
		IBaseFilter *pSrc, 
    IBaseFilter *pDest);
	HRESULT FindFilterInterface(
		IGraphBuilder *pGraph, // Pointer to the Filter Graph Manager.
		REFGUID iid,           // IID of the interface to retrieve.
    void **ppUnk) ;         // Receives the interface pointer.
	HRESULT FindPinInterface(
		IBaseFilter *pFilter,  // Pointer to the filter to search.
		REFGUID iid,           // IID of the interface.
    void **ppUnk) ;         // Receives the interface pointer.
	
	HRESULT FindInterfaceAnywhere(
    IGraphBuilder *pGraph, 
    REFGUID iid, 
    void **ppUnk);
	HRESULT GetNextFilter(
		IBaseFilter *pFilter, // Pointer to the starting filter
		PIN_DIRECTION Dir,    // Direction to search (upstream or downstream)
    IBaseFilter **ppNext) ;// Receives a pointer to the next filter.
private:
	void AddToObjectTable(void) ;
	void RemoveFromObjectTable(void);
	
	bool QueryInterfaces(void);


};

#endif // __H_CDXGraph__