
#include "stdafx.h"
#include <string>
#include <Wininet.h>
#include <stdio.h>
#include  <io.h>
#include <fcntl.h>
#include "Player.h"
#include "KtvDownloadSong.h"
#define DND_BUFF_SIZE 20480

//extern HANDLE hRequestExitEvent;

extern KTVDOWNPARAM	*g_pCurrentKtvDownload;

DWORD WINAPI KtvDownloadSongThread(LPVOID pParam)
{
	if(pParam == NULL)
	{
		return -1;
	}
	CString strUrl( ((KTVDOWNPARAM*)pParam)->strUrl );
	HWND hwnd = ((KTVDOWNPARAM*)pParam)->hwnd;
	
	CString FilePath(((KTVDOWNPARAM*)pParam)->filePath);
	CString FileCfg(FilePath + _T(".cfg"));

	DWORD			totalByte			 = 0;
	DWORD			HeadInfoLenth	= sizeof(DWORD);
	DWORD           dwStatusCode;
	DWORD           dwSizeOfStatusCode  = sizeof(DWORD);
	DWORD			getByte				 = 0;
	DWORD		    downloadByte    = 0;
	DWORD			percent              = 0;
	HINTERNET		InetHandle				= NULL;
	HINTERNET 		DownloadHandle	   = NULL;
	int						fhandle = -1;
	FILE			*fpcfg	   = NULL;
	BYTE			DBuff[DND_BUFF_SIZE];

	ULONGLONG	OldFileLength = 0; //�ϵ�������
	
	if((InetHandle = InternetOpen(_T("9158VirtualCamera"), INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, NULL)) == NULL)
	{
		//��ʼ��Internetʧ��
//		GenericLog(Error, "KtvDownloadSongThread InternetOpen error." );
		PostMessage(hwnd,WM_KTVDOWNLOADSONG_FAILED, (unsigned int)pParam, 0);
		return -1;
	}
////////////////////////////����SongFile////////////////////////
		try
		{
			CString Referer(_T("Accept: */*\nUser-Agent: NSPlayer/11.0.5721.5251 WMFSDK/11.0\nUA-CPU: x86\nAccept-Encoding: gzip, deflate\nConnection: Keep-Alive"));

			//��ȡ�������ļ����ȣ����ڶϵ�����
			CFileFind ff;   
			if(ff.FindFile(FilePath))
			{
				ff.FindNextFile();
				OldFileLength = ff.GetLength();
			}
			ff.Close();

			fpcfg = _wfopen(FileCfg, _T("rb"));
			if(fpcfg != NULL)
			{
				fread(&OldFileLength, sizeof(DWORD), 1, fpcfg);
				fclose(fpcfg);
				fpcfg = NULL;
			}
			
			if(OldFileLength >0) //�ϵ�����
			{
				CString Range=_T("");
				Range.Format(_T("\nRange: bytes=%d-"), (int)OldFileLength);
				Referer += Range;
				downloadByte = OldFileLength;
			}
			DownloadHandle = InternetOpenUrl(InetHandle,strUrl.GetBuffer(0), Referer, -1,0,0);
			strUrl.ReleaseBuffer();
			if(DownloadHandle != NULL)
			{
				
				//��վ�����ļ������ж� begin--hongjin 2009-10-21
				BOOL bRet = HttpQueryInfo(DownloadHandle, HTTP_QUERY_STATUS_CODE|HTTP_QUERY_FLAG_NUMBER, &dwStatusCode, &dwSizeOfStatusCode, NULL);
				if(!bRet)
				{
					return 0;
				}
				
				//ȷ��Ҫ���ʵ��ļ��Ƿ����
				if(404 == dwStatusCode)
				{
				InternetCloseHandle(DownloadHandle) ;
				InternetCloseHandle(InetHandle);
				return 0;
				}
            	//��վ�����ļ������ж� end--hongjin 2009-10-21
		    	HttpQueryInfo(DownloadHandle, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER, &totalByte, &HeadInfoLenth, NULL);
				if(0 == totalByte)//�������꣬�������cfg�ļ�����
				{
					DeleteFile(FileCfg);
//					if ( pNotifyWnd!=NULL && pNotifyWnd->GetSafeHwnd() )
//						pNotifyWnd->PostMessage( WM_KTVDOWNLOADSONG_COMPLETE, (unsigned int)pParam, 0 );
					PostMessage(hwnd,WM_KTVDOWNLOADSONG_COMPLETE, (unsigned int)pParam, 0);
					InternetCloseHandle(DownloadHandle);
					InternetCloseHandle(InetHandle);
					return 0;
				}
				totalByte += OldFileLength;
			}
			else
			{
				//����ʧ�ܣ�֪ͨ�û�URL��Ч
// 				int nSize = WideCharToMultiByte( CP_ACP, 0, strUrl, -1, NULL, 0, NULL, NULL);
// 				char *pszUrl = new char[nSize];
// 				memset(pszUrl,0,nSize);
// 				WideCharToMultiByte( CP_ACP, 0, strUrl, -1, pszUrl, nSize, NULL, NULL);
// //				GenericLog(Error, "KtvDownloadSongThread InternetOpenUrl error.URL:%s", pszUrl);
// 				delete []pszUrl;
				PostMessage(hwnd,WM_KTVDOWNLOADSONG_FAILED, (unsigned int)pParam, 0);
				InternetCloseHandle(InetHandle);
				return -1;
			}
			if(OldFileLength == 0)
			{
				FILE *fp = _wfopen(FilePath, _T("wb"));
				fclose(fp);
				//fhandle   =   _wopen(FilePath.GetBuffer(0), _O_BINARY|_O_CREAT|_S_IREAD | _S_IWRITE);
			}


			fhandle   =   _wopen(FilePath.GetBuffer(0), 0x8000|0x0002);
			FilePath.ReleaseBuffer();
			if(fhandle != -1)
			{
				if(OldFileLength !=0)
				{
					_lseek( fhandle, OldFileLength, SEEK_SET );
				}
				
				fpcfg = _wfopen(FileCfg, _T("wb"));
				while(TRUE)
				{
					if(g_pCurrentKtvDownload != (KTVDOWNPARAM*)pParam)//WaitForSingleObject(hRequestExitEvent, 0) != WAIT_TIMEOUT)
					{//�������µ������̣߳����߳��˳����������ص��ļ�ɾ����
						WriteLog("g_pCurrentKtvDownload != (KTVDOWNPARAM*)pParam\n");
						if(fhandle != -1)
						{
							_close(fhandle);
							fhandle = -1;
						}
						if(fpcfg != NULL)
						{
							fclose(fpcfg);
							fpcfg = NULL;
						}
						InternetCloseHandle(DownloadHandle);
						InternetCloseHandle(InetHandle);
						DeleteFile(FileCfg);
						DeleteFile(FilePath);
						return (-1);
					}
					//����ʡȥ����,��Ϊд���ļ�ʱ�ϸ��ս��յ����ֽ���д.
					//memset(DBuff, 0, BUFF_SIZE);
					if(InternetReadFile(DownloadHandle, DBuff, DND_BUFF_SIZE, &getByte))
					{
						if(getByte == 0)
						{
							//�������					
							InternetCloseHandle(DownloadHandle);
							if(fhandle != -1)
							{
								_close(fhandle);
								fhandle = -1;
							}
							if(fpcfg != NULL)
							{
								fclose(fpcfg);
								fpcfg = NULL;
							}
							DeleteFile(FileCfg);
//							if ( pNotifyWnd!=NULL && pNotifyWnd->GetSafeHwnd() )
//								pNotifyWnd->PostMessage( WM_KTVDOWNLOADSONG_COMPLETE, (unsigned int)pParam, 0 );
							PostMessage(hwnd,WM_KTVDOWNLOADSONG_COMPLETE, (unsigned int)pParam, 0 );
							break;
						}
						else
						{
							//д���ļ�
							_write(fhandle, DBuff, getByte);
							downloadByte += getByte;
							if(totalByte != 0)
							{
								percent = downloadByte * 100 / totalByte;
							}
							else
							{
								percent = downloadByte;
							}
//							CString alexTmp=_T("");
//							alexTmp.Format(_T("OldFileLength=%d, totalByte=%d, downloadByte=%d\n"), (int)OldFileLength, totalByte, downloadByte);
//							OutputDebugString(alexTmp);
							
							//д����
							if(fpcfg != NULL)
							{
								fseek( fpcfg, 0L, SEEK_SET);								
								fwrite(&downloadByte, sizeof(DWORD), 1, fpcfg);
							}
//							if ( pNotifyWnd!=NULL && pNotifyWnd->GetSafeHwnd() )
//								pNotifyWnd->PostMessage( WM_KTVDOWNLOADSONG_PROGRESS, (unsigned int)pParam, percent );
// 							WriteLog("Percent:");
// 							
// 							FILE *fp;
// 							fp=fopen("d:\\log.txt","at");
// 							fprintf(fp,"PlayerDll: %d \n",percent);
							//fprintf(fp,szLog);
							//fclose(fp);
							PostMessage(hwnd,WM_KTVDOWNLOADSONG_PROGRESS, (unsigned int)pParam, percent);
						}
					}
				}//end while
			}
			else // fp == NULL
			{
// 				int nSize = WideCharToMultiByte( CP_ACP, 0, FilePath, -1, NULL, 0, NULL, NULL);
// 				char *pszFilePath = new char[nSize];
// 				memset(pszFilePath,0,nSize);
// 				WideCharToMultiByte( CP_ACP, 0, FilePath, -1, pszFilePath, nSize, NULL, NULL);
// //				GenericLog(Error, "KtvDownloadSongThread _wfopen_s error. FilePath:%s", pszFilePath);
// 				delete []pszFilePath;
				PostMessage(hwnd,WM_KTVDOWNLOADSONG_FAILED, (unsigned int)pParam, 0);
				return -1;
			}
		}
		catch(...)
		{
			if(fhandle != -1)
			{
				_close(fhandle);
				fhandle = -1;
			}
			if(fpcfg != NULL)
			{
				fclose(fpcfg);
				fpcfg = NULL;
			}
			InternetCloseHandle(DownloadHandle);
			InternetCloseHandle(InetHandle);
			return -1;
		}
	InternetCloseHandle(InetHandle);
	return 0;
}
