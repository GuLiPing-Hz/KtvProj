// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__F328B6D7_BCD4_4672_B16A_9CA3A5B6237A__INCLUDED_)
#define AFX_STDAFX_H__F328B6D7_BCD4_4672_B16A_9CA3A5B6237A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define _WIN32_WINNT 0x0500
#define _WIN32_DCOM
//#include <windows.h>
//#ifdef _DEBUG
#include <afx.h>
//#endif
//#pragma comment(lib, "NetWorkV6U.lib")
#pragma comment(lib, "wininet.lib")
#include <atlbase.h>
#include <streams.h>

//��ֹqedit.h	�ڵ�ͷ�ļ�û�С�dxtrans.h�����µĴ���
#define __IDxtCompositor_INTERFACE_DEFINED__  
#define __IDxtAlphaSetter_INTERFACE_DEFINED__  
#define __IDxtJpeg_INTERFACE_DEFINED__  
#define __IDxtKey_INTERFACE_DEFINED__  

#include <qedit.h>
// TODO: reference additional headers your program requires here
//EXTERN_C const CLSID CLSID_TrackSwitch;
//#define   INITGUID  
//DEFINE_GUID(CLSID_TrackSwitch, 
//			0xa4b11047, 0x79c1, 0x44c5, 0xb6, 0xf2, 0x8a, 0x86, 0x87, 0x55, 0xab, 0xe5);
static   const   GUID   CLSID_TrackSwitch = {0xa4b11047, 0x79c1, 0x44c5,   {0xb6, 0xf2, 0x8a, 0x86, 0x87, 0x55, 0xab, 0xe5}   }; 
//DEFINE_GUID(IID_ITrackSwitch, 
//			0x6a720cc9, 0xff10, 0x4e1b, 0xac, 0xc4, 0xd2, 0x2a, 0xcb, 0xc, 0x2c, 0x7f);
static   const   GUID   IID_ITrackSwitch = {0x6a720cc9, 0xff10, 0x4e1b,   {0xac, 0xc4, 0xd2, 0x2a, 0xcb, 0xc, 0x2c, 0x7f}   }; 

// {5258CD7B-E36F-4A87-81B9-783829E63AE6}
static   const   GUID   CLSID_ASFSource = {0x5258cd7b, 0xe36f, 0x4a87,   {0x81, 0xb9, 0x78, 0x38, 0x29, 0xe6, 0x3a, 0xe6}   }; 

// {2BED3867-F9AE-4D9C-B94E-DB93ECED98A2}
static   const   GUID   IID_IASFSource = {0x859188f6, 0x8285, 0x4146,  {0xb7, 0x8, 0x50, 0x4e, 0x78, 0xf6, 0xfa, 0xd4}   }; 

static   const   GUID   CLSID_DCBassSource = {0xabe7b1d9, 0x4b3e, 0x4acd,  {0xa0, 0xd1, 0x92, 0x61, 0x1d, 0x3a, 0x44, 0x92}   }; 

// {5258CD7B-E36F-4A87-81B9-783829E63AE6}
static   const   GUID   CLSID_ASFURLSource = {0x218be93c, 0x2ef9, 0x4a9c,   {0x96, 0xb7, 0x3c, 0x36, 0x13, 0xf5, 0x6a, 0xc8}   }; 

// {2BED3867-F9AE-4D9C-B94E-DB93ECED98A2}
static   const   GUID   IID_IASFURLSource = {0xd5cbdb5d, 0x7d26, 0x4b52,  {0x96, 0xe2, 0x74, 0x70, 0x86, 0x76, 0x35, 0xbf}   }; 


static   const   GUID   CLSID_FFDshow = {0x04fe9017, 0xf873, 0x410e,  {0x87, 0x1e, 0xab, 0x91, 0x66, 0x1a, 0x4e, 0xf7}   }; 
//0xda5e4ec4, 0x61ab, 0x458b, 0xb8, 0x36, 0xb8, 0x74, 0x4b, 0x6b, 0xd3, 0xa7)
//------------------------------------------------------------------------------
//
// Desc: ITrackSwitch �Ľӿڶ���
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------
#define WM_PLAYER_MESSAGE						(WM_USER+1021)
#define WM_PLAYER_INIT							WM_PLAYER_MESSAGE+0
#define WM_PLAYER_CREATE						WM_PLAYER_MESSAGE+1
#define WM_PLAYER_PLAY							WM_PLAYER_MESSAGE+2
#define WM_PLAYER_STOP							WM_PLAYER_MESSAGE+3
#define WM_PLAYER_PAUSE							WM_PLAYER_MESSAGE+4
#define WM_PLAYER_RUSUME						WM_PLAYER_MESSAGE+5
#define WM_PLAYER_MUTE							WM_PLAYER_MESSAGE+6
#define WM_PLAYER_SETFILENAME					WM_PLAYER_MESSAGE+7
#define WM_PLAYER_UNINIT						WM_PLAYER_MESSAGE+8
#define WM_PLAYER_DESTORY						WM_PLAYER_MESSAGE+9
#define WM_KTVDOWNLOADSONG_COMPLETE				WM_PLAYER_MESSAGE+10
#define WM_KTVDOWNLOADSONG_PROGRESS				WM_PLAYER_MESSAGE+11
#define WM_KTVDOWNLOADSONG_FAILED				WM_PLAYER_MESSAGE+12

#define STATUS_COLSING							0
#define STATUS_OPENING							1
#define STATUS_OPENED							2
#define STATUS_OPEN_FAILED						3
#define STATUS_PLAYING							4
#define STATUS_STOPED							5
#define STATUS_PAUSED							6
#define STATUS_CLOSED							7
#define STATUS_BUFFERINGDATA					8
#define STATUS_READY							9
#define STATUS_MISSING_DECODE					10

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(x) \
	if (x != NULL)       \
{                    \
	x->Release();     \
	x = NULL;         \
}
#endif

#ifndef SAFE_DELETE
#define SAFE_DELETE(x) \
	if (x != NULL)      \
{                   \
	delete x;        \
	x = NULL;        \
}
#endif

#ifndef SAFE_ARRAY_DELETE
#define SAFE_ARRAY_DELETE(x) \
	if (x != NULL)            \
{                         \
	delete[] x;            \
	x = NULL;              \
}
#endif

#ifndef SAFE_FREE
#define SAFE_FREE(x) \
	if (x != NULL)            \
{                         \
	free(x);            \
	x = NULL;              \
}
#endif

#ifndef SAFE_CLOSEHANDLE
#define SAFE_CLOSEHANDLE(h)         \
    if (h != NULL)                  \
{                               \
	CloseHandle(h);             \
	h = NULL;                   \
}
#endif

#ifndef SAFE_CLOSEFILEHANDLE
#define SAFE_CLOSEFILEHANDLE(h)     \
    if (h != INVALID_HANDLE_VALUE)  \
{                               \
	CloseHandle(h);             \
	h = INVALID_HANDLE_VALUE;   \
}
#endif 



#ifndef GOTO_EXIT_IF_FAILED
#define GOTO_EXIT_IF_FAILED(hr) if(FAILED(hr)) goto Exit;
#endif

#ifndef BREAK_IF_FAILED
#define BREAK_IF_FAILED(hr)			\
	if(FAILED(hr))						\
{									\
	break;							\
}

#endif

#ifndef RETURN_IF_FAILED
#define RETURN_IF_FAILED(hr) if(FAILED(hr)) return hr;
#endif
#ifndef __INULLIP__
#define __INULLIP__

#ifdef __cplusplus
extern "C" {
#endif
	
	//----------------------------------------------------------------------------
	// ITrackSwitch
	//----------------------------------------------------------------------------
	DECLARE_INTERFACE_(ITrackSwitch, IUnknown)
	{
		
		STDMETHOD(put_MediaType) (THIS_
			CMediaType *pmt       /* [in] */	// the media type selected
			) PURE;
		
		STDMETHOD(get_MediaType) (THIS_
			CMediaType **pmt      /* [out] */	// the media type selected
			) PURE;
		
		STDMETHOD(get_IPin) (THIS_
			IPin **pPin          /* [out] */	// the source pin
			) PURE;
		
		
		STDMETHOD(get_State) (THIS_
			FILTER_STATE *state  /* [out] */	// the filter state
			) PURE;
		
		STDMETHOD (set_ch)  (THIS_
			int   num			/* [in] */	// ���õ�����
			) PURE;  
	};

//IASFSource�Ľӿ�
	DECLARE_INTERFACE_(IASFSource, IUnknown)
	{
		STDMETHOD(CanChangeSource) (THIS) PURE;
		STDMETHOD(IsMultStream)  (THIS_
			BOOL	&bMultStream			/* [out] */	// 
				) PURE; 
	//	STDMETHOD(ReleaseResource) (THIS_) PURE;
		STDMETHOD(Set_Stream)  (THIS_
			int   num			/* [in] */	// ���õ�����
			) PURE;  
		STDMETHOD(Get_LanguageLen)  (THIS_
			int   &nLanguageLen			/* [out] */	// 
				) PURE;  
		STDMETHOD(Get_LanguageString)  (THIS_
			char   * pszLanguageString		/* [in, out] */	// 
				) PURE; 
	};
	//IASFURLSource�Ľӿ�
	DECLARE_INTERFACE_(IASFURLSource, IUnknown)
	{
		STDMETHOD(CanChangeSource) (THIS) PURE;
		STDMETHOD(IsMultStream)  (THIS_
			BOOL	&bMultStream			/* [out] */	// 
			) PURE; 
		//	STDMETHOD(ReleaseResource) (THIS_) PURE;
		STDMETHOD(Set_Stream)  (THIS_
			int   num			/* [in] */	// ���õ�����
			) PURE;  
		STDMETHOD(Get_LanguageLen)  (THIS_
			int   &nLanguageLen			/* [out] */	// 
			) PURE;  
		STDMETHOD(Get_LanguageString)  (THIS_
			char   * pszLanguageString		/* [in, out] */	// 
			) PURE; 
	};
	//----------------------------------------------------------------------------
	
#ifdef __cplusplus
}
#endif

#endif // __INULLIP__
// #ifdef __cplusplus
// 
// class DECLSPEC_UUID("A4B11047-79C1-44C5-B6F2-8A868755ABE5")
// TrackSwitch;
// #endif
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__F328B6D7_BCD4_4672_B16A_9CA3A5B6237A__INCLUDED_)
