#pragma once
#include "timerex.h"

class DrawListener :
	public ITimerListener
{
public:
	DrawListener(void);
	~DrawListener(void);
	void onTimer( unsigned int elapsed_tm );
};
