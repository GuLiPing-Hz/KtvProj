#include "stdafx.h"
#include "TimerEx.h"

#pragma comment(lib,"winmm.lib")

//-----------------------------------------------------------------------------
// ���캯��
CTimerEx::CTimerEx(DWORD dwFps/* = 60*/, bool bFrameSkip/* = true*/)
: m_pListener( NULL )
, m_dwLastFlipped( 0 )
, m_dwLastMinitues( 0 )
, m_dwPrevFrameMinitues( 0 )
, m_dwFrameRate( 0 )
, m_dwSkipRate( 0 )
, m_fFrameTime( 0 )
, m_bDrawFlag( false )
, m_bFrameSkip( bFrameSkip )
, m_bInit( true )
, m_dwFrameCount( 0 )
, m_dwSkipCount( 0 )
{
	setFPS(dwFps);
	timeBeginPeriod(1);
}

//-----------------------------------------------------------------------------
// ��������
CTimerEx::~CTimerEx()
{
	timeEndPeriod( 1 );
}

//-----------------------------------------------------------------------------
// ���ü�����
void CTimerEx::setListener( ITimerListener * listener )
{
	m_pListener = listener;
}

//-----------------------------------------------------------------------------
// ������ʱ��
void CTimerEx::processTimer()
{
	DWORD elapsed_tm = 0;

	++m_dwFrameCount;

	if ( m_bInit )
	{
		m_dwLastMinitues = timeGetTime();
		m_dwPrevFrameMinitues = 0;
		m_bInit = false;
		m_bDrawFlag = true;
	}
	else
	{
		DWORD dwTime = (DWORD)( m_dwFrameCount * m_fFrameTime + m_dwLastMinitues );
		if ( m_bFrameSkip && timeGetTime()  > dwTime/*(DWORD)( (m_dwFrameCount + 1) * m_fFrameTime + m_dwLastMinitues )*/ )
		{
			m_bDrawFlag = false;
			++m_dwSkipCount;
		}
		else
		{
			while ( timeGetTime() < dwTime )
			{
				Sleep( 1 );
			}

			DWORD dwCurTime = timeGetTime();
			elapsed_tm = dwCurTime - m_dwLastMinitues - m_dwPrevFrameMinitues;
			m_dwPrevFrameMinitues = dwCurTime - m_dwLastMinitues;

			m_bDrawFlag = true;
		}

		if ( timeGetTime() - m_dwLastMinitues >= 1000 )
		{
			m_dwLastMinitues = timeGetTime();
			m_dwPrevFrameMinitues = 0;
			m_dwFrameRate = m_dwFrameCount;
			m_dwFrameCount = 0;
			m_dwSkipRate = m_dwSkipCount;
			m_dwSkipCount = 0;
		}
	}


	if ( m_bDrawFlag )
	{
		if ( m_pListener ) m_pListener->onTimer( elapsed_tm );
	}
}

//-----------------------------------------------------------------------------
// 
void CTimerEx::measure()
{
	++m_dwFrameCount;
	m_bDrawFlag = true;
	if(timeGetTime() - m_dwLastMinitues >= 1000)
	{
		m_dwLastMinitues = timeGetTime();
		m_dwPrevFrameMinitues = 0;
		m_dwFrameRate = m_dwFrameCount;
		m_dwFrameCount = 0;
		m_dwSkipRate = m_dwSkipCount;
		m_dwSkipCount = 0;
	}
}

//-----------------------------------------------------------------------------
//
void CTimerEx::onFrameSkip(bool bFrameSkip)
{
	m_bFrameSkip = bFrameSkip;
}

//-----------------------------------------------------------------------------
// ����֡��
void CTimerEx::setFPS(DWORD fps)
{
	m_fFrameTime = 1000.0f / fps;
}

//-----------------------------------------------------------------------------
// ��ȡ֡��
DWORD CTimerEx::getFrameRate()
{
	return m_dwFrameRate;
}

//-----------------------------------------------------------------------------
// ��ȡ����֡��
DWORD CTimerEx::getSkipRate()
{
	return m_dwSkipRate;
}

//-----------------------------------------------------------------------------
// ��ȡ�Ƿ������滭
bool CTimerEx::getDrawFlag()
{
	return m_bDrawFlag;
}
