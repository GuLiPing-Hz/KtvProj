// Opengl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Opengl.h"

// The one and only application object

//CWinApp theApp;



#include <string>
#include <string.h>
#include <stdio.h>
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include "TimerEx.h"
#include "DrawListener.h"


void DisplayVideo()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_TRIANGLES);//��ͼ��ģʽGL_POINTS��GL_LINES��GL_QUADS,GL_QUAD_STRIP
	//����GL_LINE_STRIP��GL_LINE_LOOP��GL_TRIANGLES��GL_TRIANGLE_STRIP��GL_TRIANGLE_FAN
	glEnd();
	glFlush();
}

//bool openFile(string sfileName)
//{
//	m_SourceFile = dlgOpen.GetPathName();
//	// Rebuild the file playback filter graph
//
//	//		m_SourceFile = "http://www.ma-friends.com/mp3/����.mp3";
//
//	//		m_SourceFile.GetBuffer(0);
//	WCHAR   szwFile[MAX_PATH];
//	MultiByteToWideChar(CP_ACP, 0, m_SourceFile.GetBuffer(0), -1, szwFile, MAX_PATH);
//	SetFileName(szwFile);
//	m_SliderTimer = SetTimer(SLIDER_TIMER, 100, NULL);//�趨��ʱ�����¼�ID�����ʱ�䣬�ص�����������OnTimer()
//	m_GetFrameTimer = SetTimer(GETFRAME_TIMER, 67, NULL);
//	//		m_GetAudioTimer = SetTimer(GETAUDIO_TIMER, 10, NULL);
//
//
//
//	if(CreateGraph()==-1)
//	{
//		// 			FILE *fp;
//		// 			fp=fopen("d:\\log.txt","at");
//		// 			fprintf(fp,"CreateGraph Failed.\n");
//		// 			fclose(fp);	
//		return;
//	}//����������·
//	BOOL bIsMultStream = FALSE;
//	int  nLanguageLen = 0;
//	IsMultStream(bIsMultStream);//���ж��Ƿ��ж�����
//	Get_LanguageLen(nLanguageLen);//ȡ�������ַ�������
//	WriteLog("Get_LanguageLen\n");
//	if(m_Language != NULL)
//	{
//		delete m_Language;
//	}
//	m_Language = new WCHAR[nLanguageLen+1];//Ϊ�����ַ�������ռ�
//	Get_LanguageString(m_Language);//ȡ�������ַ���,���������л�
//	// 
//	// 		FILE *fp;
//	// 		fp=fopen("d:\\log.txt","at");
//	// 		fprintf(fp,"nLanguageLen = %d \nm_Language = %s\n",nLanguageLen, m_Language);
//	// 		fclose(fp);
//
//	GetMideaType(m_bVideo, m_bAudio);//�õ�ý���Ƿ�����Ƶ/��Ƶ
//	if (NULL != m_pFrameData)
//	{
//		free(m_pFrameData);
//		m_pFrameData=NULL;
//	}
//	if (m_bVideo)
//	{
//		GetFrameSize(m_nWidth,m_nHeight);//�õ���Ƶ��С��������ռ�
//
//		m_pFrameData = (BYTE *) malloc(m_nWidth*m_nHeight*3);
//
//	}
//	if (NULL != g_pAudioData)
//	{
//		free(g_pAudioData);
//		g_pAudioData = NULL;
//	}
//	if (m_bAudio)
//	{
//		WriteLog("bAudio = TRUE.\n\n");
//
//		g_pAudioData = (BYTE *)malloc(FILEBUFFER);//������Ƶ����
//		GetAudioMideaType(m_mtAudioType);//�õ���Ƶ��ʽ
//	}
//
//	g_bOpenFile = TRUE;		
//	return true;
//}

//int main(int argc , char *argv[])

/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing The Base Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */


HDC			g_hDC=NULL;		// Private GDI Device Context
HGLRC		g_hRC=NULL;		// Permanent Rendering Context
HWND		g_hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	g_hInstance;		// Holds The Instance Of The Application
CTimerEx g_cTimeEx;
DrawListener g_drawListener;

bool	g_keys[256];			// Array Used For The Keyboard Routine
bool	g_active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	g_fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

GLuint	g_texture[1];			// Storage For One Texture

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

AUX_RGBImageRec *LoadBMP(char *Filename)				//����ͼƬ
{
	FILE *File=NULL;									// File Handle

	if (!Filename)										// Make Sure A Filename Was Given
	{
		return NULL;									// If Not Return NULL
	}

	File=fopen(Filename,"r");							// Check To See If The File Exists

	if (File)											// Does The File Exist?
	{
		fclose(File);									// Close The Handle
		return auxDIBImageLoad(Filename);				// Load The Bitmap And Return A Pointer
	}

	return NULL;										// If Load Failed Return NULL
}

BOOL LoadGLTextures()									// Load Bitmaps And Convert To Textures
{
	BOOL Status=FALSE;									// Status Indicator

	AUX_RGBImageRec *TextureImage[1];					// Create Storage Space For The Texture

	memset(TextureImage,0,sizeof(void *)*1);           	// Set The Pointer To NULL

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if (TextureImage[0]=LoadBMP("Data/NeHe.bmp"))
	{
		Status=TRUE;									// Set The Status To TRUE

		glGenTextures(1, &g_texture[0]);					// ����1������id

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, g_texture[0]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);
		// ��������
		//glTexSubImage2D (GL_TEXTURE_2D, 0, 0, 0, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, data);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}

	if (TextureImage[0])									// If Texture Exists
	{
		if (TextureImage[0]->data)							// If Texture Image Exists
		{
			free(TextureImage[0]->data);					// Free The Texture Image Memory
		}

		free(TextureImage[0]);								// Free The Image Structure
	}

	return Status;										// Return The Status
}

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The ��ǰ�ӿ�

	glMatrixMode(GL_PROJECTION);						
	//Select The ͶӰ����Ϊ͸��ͼ������Ļ����ζ��ԽԶ�Ķ���������ԽС (45��)
	glLoadIdentity();									// Reset The Projection Matrix
	//glOrthof(-backingHeight/2.0, backingHeight/2.0, -backingWidth/2.0, backingHeight/2.0, -1.0f, 1.0f);
	// Calculate The Aspect Ratio Of The Window
	//gluPerspective(90.0f,(GLfloat)width/(GLfloat)height,1.0f,1.0f);//�˴�͸�Ӱ��ջ��ڴ��ڿ��Ⱥ͸߶ȵĵ�һ���������ӽ�������
	//��һ���������۾������ĽǶȡ�
	//1.0f,100.0f�������ڳ��������ܻ�����ȵĽ�ƽ���Զƽ��
	//�ü����ڵĸ߶� h �� 2 * tan��fovy/2�� * zNear.
	//�����ɿ��߱Ⱦ�����
	gluOrtho2D(0.0,width/1.0,-height/1.0,0.0);
	glMatrixMode(GL_MODELVIEW);//Select The ģ�͹۲�������д�������ǵ�����ѶϢ
	glLoadIdentity();									// Reset The Modelview Matrix
}

BOOL InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	if (!LoadGLTextures())								// Jump To Texture Loading Routine ( NEW )
	{
		return FALSE;									// If Texture Didn't Load Return FALSE
	}
	//glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping
	glShadeModel(GL_SMOOTH);							//  ������Ӱƽ�� 
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// Black Background
	glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);    // ����Դ����alphaͨ��ֵ�İ�͸����Ϻ���
	glEnable(GL_BLEND);//������ɫ���
	//glClearDepth(1.0f);									// ������Ȼ���
	//glEnable(GL_DEPTH_TEST);							// ������Ȳ���
	//glDepthFunc(GL_LEQUAL);								// ������Ȳ��Ե�����
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);	// ����ϵͳ��͸�ӽ�������
	return TRUE;										// Initialization Went OK
}

BOOL DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{

	//�����ɫ//����Ȼ�����
	glClear(GL_COLOR_BUFFER_BIT);// | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();									// Reset The Current Modelview Matrix
	//glTranslatef(-0.5f,-0.0f,-1.0f);// ���� 1.5 ��λ����������Ļ 6.0 //�ƶ����ĵ㡣
	//glBegin(GL_TRIANGLES);								// Drawing Using ������+������+5
	//	glColor4f(1.0f,0.0f,0.0f,1.0f);
	//	glVertex3f( 100.0+2.0f, -50.0f, 0.0f);					// Top
	//	glColor4f(0.0f,1.0f,0.0f,1.0f);
	//	glVertex3f(50.0f,-100.0f, 0.0f);					// Bottom Left
	//	glColor4f(0.0f,0.0f,1.0f,1.0f);
	//	glVertex3f( 150.0+5.0f,-100.0f, 0.0f);					// Bottom Right
	//glEnd();											// Finished Drawing The Triangle
	//glTranslatef(1.0f,0.0f,0.0f);						// Move Right 3 Units�ƶ����ĵ�
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, g_texture[0]);//������,֮ǰҪ����2D����
	glBegin(GL_QUADS);									// Draw A �ı��Σ�������+3
	//˳ʱ����Ƶ��Ƕ���ĺ���档�����˵�������������������εı��档��ʱ�뻭�����������β������泯������
		
		//glColor4f(0.0f,1.0f,0.0f,1.0f);
		glTexCoord2f(0.0f, 0.0f);//ָ��uv����
		glVertex3f(-0.0f,-100.0f, 0.0f);					// Bottom Left ��

		glTexCoord2f(1.0f, 0.0f);//ָ��uv����
		glVertex3f( 100.0f+3.0f,-100.0f, 0.0f);					// Bottom Right ��

		//glColor4f(0.0f,0.0f,1.0f,1.0f);
		glTexCoord2f(1.0f, 1.0f);//ָ��uv����
		glVertex3f( 100.0f+3.0f, 0.0f, 0.0f);					// Top Right ��

		//glColor4f(1.0f,0.0f,0.0f,1.0f);
		glTexCoord2f(0.0f, 1.0f);//ָ��uv����
		glVertex3f(0.0f, 0.0f, 0.0f);					// Top Left ��
		
	glEnd();	
	glDisable(GL_TEXTURE_2D);
		///////////////////////////////////////////////////////////
	glBegin(GL_QUADS);	
		glColor4f(0.0f,0.0f,1.0f,1.0f);
		glVertex3f(400.0f,-100.0f, 0.0f);					// Bottom Left 

		glVertex3f( 500.0f+3.0f,-100.0f, 0.0f);					// Bottom Right 

		glColor4f(0.0f,1.0f,0.0f,1.0f);
		glVertex3f( 500.0f+3.0f, 0.0f, 0.0f);					// Top Right ��

		glColor4f(1.0f,0.0f,0.0f,1.0f);
		glVertex3f(400.0f, 0.0f, 0.0f);					// Top Left 
////////////////////////////
		glColor4f(0.0f,1.0f,1.0f,1.0f);
		glVertex3f(600.0f,-100.0f, 0.0f);					// Bottom Left 

		glVertex3f( 700.0f+3.0f,-100.0f, 0.0f);					// Bottom Right 

		glColor4f(1.0f,1.0f,0.0f,1.0f);
		glVertex3f( 700.0f+3.0f, 0.0f, 0.0f);					// Top Right ��

		glColor4f(1.0f,0.0f,1.0f,1.0f);
		glVertex3f(600.0f, 0.0f, 0.0f);					// Top Left 

		glColor4f(1.0f,1.0f,1.0f,1.0f);//��ԭ��ɫ
	glEnd();											// Done Drawing The Quad
	return TRUE;										// Keep Going
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (g_fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (g_hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(g_hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		g_hRC=NULL;										// Set RC To NULL
	}

	if (g_hDC && !ReleaseDC(g_hWnd,g_hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		g_hDC=NULL;										// Set DC To NULL
	}

	if (g_hWnd && !DestroyWindow(g_hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		g_hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",g_hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		g_hInstance=NULL;									// Set hInstance To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	g_fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	g_hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= g_hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (g_fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					//ÿ������ѡ��ɫ�����
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				g_fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (g_fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW|WS_EX_TOPMOST;	// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_TOOLWINDOW|WS_EX_TOPMOST;//�ö�
		// | WS_EX_WINDOWEDGE;			// Window Extended Style
		//���ô�����ʽ��popup�ޱ߿��ޱ��⣬�޲˵�
		dwStyle=WS_POPUPWINDOW;//WS_POPUP;//WS_OVERLAPPEDWINDOW;
		// Windows Style  WS_SIZEBOX;//
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(g_hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 450,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								g_hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	//��͸��
	SetWindowLong(g_hWnd, GWL_EXSTYLE,GetWindowLong(g_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
	SetLayeredWindowAttributes(g_hWnd, 0,255*60/100, LWA_ALPHA);

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(g_hDC=GetDC(g_hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(g_hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(g_hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(g_hRC=wglCreateContext(g_hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(g_hDC,g_hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(g_hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(g_hWnd);						// Slightly Higher Priority
	SetFocus(g_hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				g_active=TRUE;						// Program Is Active
			}
			else
			{
				g_active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			}
			break;
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			g_keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			g_keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}
		
		case WM_LBUTTONDOWN://�����϶����ڣ�(���ͷǿͻ����������)
		{
			SendMessage(g_hWnd, WM_NCLBUTTONDOWN, HTCAPTION, lParam);
			break;
		}
			

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

void MessageWhile()
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			if (g_keys[VK_ESCAPE])
			{
				done=TRUE;
			}
			g_cTimeEx.processTimer();
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			//if ((g_active && !DrawGLScene()) || g_keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			//{
			//	done=TRUE;							// ESC or DrawGLScene Signalled A Quit
			//}
			//else									// Not Time To Quit, Update Screen
			//{
			//	SwapBuffers(g_hDC);					// Swap Buffers (Double Buffering)
			//}

			//if (g_keys[VK_F1])						// Is F1 Being Pressed?
			//{
			//	g_keys[VK_F1]=FALSE;					// If So Make Key FALSE
			//	KillGLWindow();						// Kill Our Current Window
			//	g_fullscreen=!g_fullscreen;				// Toggle Fullscreen / Windowed Mode
			//	// Recreate Our OpenGL Window
			//	if (!CreateGLWindow("Viedo Open",640,480,16,g_fullscreen))
			//	{
			//		return ;						// Quit If Window Was Not Created
			//	}
			//}
		}
	}
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{

	// Ask The User Which Screen Mode They Prefer
	//if (MessageBox(NULL,"Would You Like To Run In Fullscreen Mode?", "Start FullScreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
	//{
	//	fullscreen=FALSE;							// Windowed Mode
	//}
	g_cTimeEx.setListener(&g_drawListener);

	//���ô��ڵĴ�С
	int win_width;
	int win_height;
	HDC hDesktop= GetDC(0);//��ȡ��Ļ���
	win_width=GetDeviceCaps(hDesktop,HORZRES);
	win_height=GetDeviceCaps(hDesktop,VERTRES);
	// Create Our OpenGL Window
	if (!CreateGLWindow("Video Open",win_width,win_height,32,FALSE))//���⣬���ߣ���ɫ��ʾλ
	{
		return 0;									// Quit If Window Was Not Created
	}
	MessageWhile();
	// Shutdown
	KillGLWindow();									// Kill The Window
	return (0);//msg.wParam							// Exit The Program
}
