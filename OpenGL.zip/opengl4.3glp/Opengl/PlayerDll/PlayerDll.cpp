// PlayerDll.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#define	 PLAYER_DLLAPI extern "C" __declspec(dllexport)
#include "PlayerDll.h"
#include "Player.h"
#include "KtvDownloadSong.h"
#include <stdio.h>
CPlayer * g_pPlayer = NULL;
CPlayer * g_pURLPlayer = NULL;
TCHAR   * g_pszLanguageString = TEXT("���� (�й�);");
//HANDLE  g_hEvent;
//BOOL		g_bSendBuffStatus=FALSE;
GETAUDIOSAMPLE	g_lpGetAudioSample;
GETAUDIOSAMPLE2	g_lpGetAudioSample2;
ISEOF			g_lpIsEOF;
SENDSTATUS		g_lpSendStatus;

extern			CDXGraph *		g_FilterGraph;     // Filter Graph��װ
//////////////////////////////////////////////////////////////////////////video
extern			VideoBufferNode*	g_pVideoNodeHeader;
extern			VideoBufferNode*	g_pVideoWrite;
extern			VideoBufferNode*	g_pVideoRead;
extern			volatile LONG			g_nVideoNodeUsed;
int				g_nVolume		= 65535;
int				g_bMute			= FALSE;
BOOL			g_bIsURL		= FALSE;
HWND			g_hwnd;
int				g_status;

DWORD			g_nThreadID = 0;
HANDLE			g_hThread=NULL;
HANDLE			g_hEvent = INVALID_HANDLE_VALUE;										// event handle
volatile int	g_bOpened= FALSE;
BOOL			g_bPlayCommand = FALSE;
char*			g_pszURL = NULL;

char*			g_pszCurrentPath=NULL;//��ǰ·��
CString			CurrentPath;
CString			PrevFilePath;// (_T(""));
CString			PrevFileCfg;// (_T(""));
KTVDOWNPARAM	*g_pCurrentKtvDownload = NULL;
BOOL			g_bDownloadComplete = FALSE;
long			g_StartTime, g_CurrentTime;
//HANDLE			g_hRequestExitEvent = NULL;//�������������߳��˳���EVENT

int			g_nStreamNumber=0;//add by glp

BOOL IsURL(TCHAR * strFileName);
BOOL IsMP3(TCHAR * strFileName);
BOOL InitMessageOnlyWindow();




int Initialize(GETAUDIOSAMPLE lpGetAudioSample,GETAUDIOSAMPLE2 lpGetAudioSample2, ISEOF lpIsEOF, SENDSTATUS lpSendStatus)//, GETMESSAGE lpGetMessage)
{
// 	g_hThread = CreateThread(NULL, 0, PlayerProc, NULL, NULL, &g_nThreadID);
// 	Sleep(500);

// 	TCHAR	strModuleName[MAX_PATH];
// 	memset(strModuleName, 0, MAX_PATH);
//     GetModuleFileName( 0, strModuleName, MAX_PATH );
// 	if(_tcsstr (strModuleName, _T("9158VirtualCamera.exe")) == NULL&&_tcsstr (strModuleName, _T("PlayerTest.exe")) == NULL)
// 		return -1;
	WriteLog("Initialize enter\n");
	InitMessageOnlyWindow();
	g_pPlayer = new CPlayer();
	g_lpGetAudioSample = lpGetAudioSample;
	g_lpGetAudioSample2 = lpGetAudioSample2;
	g_lpIsEOF = lpIsEOF;
	g_lpSendStatus = lpSendStatus;

	PrevFilePath = _T("");
	PrevFileCfg = _T("");

	// ȡ��ǰӦ�ó���·���� g_pszCurrentPath
	DWORD nPathLen = 260;
	char pszCurrentPath[260] = {0};
	GetModuleFileNameA(GetModuleHandle(NULL),pszCurrentPath,nPathLen);
	CurrentPath = pszCurrentPath;
	int pos = CurrentPath.ReverseFind('\\');
	CurrentPath = CurrentPath.Left(pos);
	int nSize = WideCharToMultiByte( CP_ACP, 0, CurrentPath, -1, NULL, 0, NULL, NULL);
// 	g_pszCurrentPath = new char[nSize];
// 	memset(g_pszCurrentPath,0,nSize);
// 	WideCharToMultiByte( CP_ACP, 0, CurrentPath, -1, g_pszCurrentPath, nSize, NULL, NULL);
// 	WriteLog(g_pszCurrentPath);
// 	delete []pszCurrentPath;

	//g_hRequestExitEvent = CreateEvent(NULL, TRUE, FALSE, NULL);//�������������߳��˳���EVENT
	g_bDownloadComplete = FALSE;
	return 0;
}
int UnInitialize()
{
	WriteLog("UnInitialize enter");
	SAFE_ARRAY_DELETE(g_pszCurrentPath);
	SAFE_DELETE(g_pCurrentKtvDownload);

	if (g_pPlayer)
	{
		g_pPlayer->DestroyGraph();
		g_pPlayer->UnInitialize();

		delete g_pPlayer;
		g_pPlayer = NULL;
		return 0;
	}
//	CloseHandle(g_hRequestExitEvent);

	return -1;

}
int SetNeedGetAudioData(BOOL bNeedGetAudio)
{
	if (g_pPlayer!=NULL)
	{
		g_pPlayer->SetNeedGetAudioData(bNeedGetAudio);
		return 0;
	}
	return -1;
}

int SetFileName(TCHAR * pszFileName)
{
	WriteLog("SetFileName enter\n");
	g_bDownloadComplete = FALSE;
	//WriteLog("SetFileName: ");
	DestroyGraph();

//	SetEvent(g_hRequestExitEvent); //�ȷ��ж���Ϣ,ͣ��ǰһ�������߳�
	if (g_pPlayer!=NULL)
	{
		g_bOpened = FALSE;
		g_bIsURL = IsURL(pszFileName);
		if (g_bIsURL)//�����ַ
		{
			CString strUrl = pszFileName;
			CString	FilePath (_T(""));
		
			FilePath.Format( _T("%s\\%s"), _T("\\DownLoad\\Songs"),  strUrl.Mid(strUrl.ReverseFind(_T('/')) + 1));
			FilePath = CurrentPath+FilePath;

			CString FileCfg(FilePath + _T(".cfg"));

			PrevFileCfg = FileCfg;
			PrevFilePath = FilePath;

			KTVDOWNPARAM *pKtvDownload = new KTVDOWNPARAM(strUrl, FilePath, g_hwnd);
			if(_waccess(FileCfg, 0) == 0 || _waccess(FilePath, 0) != 0)
			{
				unsigned long dwthreadID = 0;
				if (g_pCurrentKtvDownload)//add by glp
				{
					SAFE_DELETE(g_pCurrentKtvDownload);
				}
				g_pCurrentKtvDownload = pKtvDownload;//���������߳��ж��Ƿ�Ҫ�˳���ȫ�ֱ���
				g_status=STATUS_BUFFERINGDATA;
				g_lpSendStatus(STATUS_BUFFERINGDATA);
			
				//GetLocalTime(&g_StartTime);
				g_StartTime = GetTickCount();
				CreateThread( 0, 0, (LPTHREAD_START_ROUTINE)KtvDownloadSongThread, (void*)pKtvDownload, 0, &dwthreadID );
			}
			else
			{
				//�������
				PostMessage(g_hwnd,WM_KTVDOWNLOADSONG_COMPLETE, (unsigned int)pKtvDownload, 0);
			}
// 			int nSize = WideCharToMultiByte( CP_ACP, 0, FilePath, -1, NULL, 0, NULL, NULL);
// 			char *pszFilePath = new char[nSize];
// 			memset(pszFilePath,0,nSize);
// 			WideCharToMultiByte( CP_ACP, 0, FilePath, -1, pszFilePath, nSize, NULL, NULL);
//			GenericLog(Error, "KtvDownloadSongThread _wfopen_s error. FilePath:%s", pszFilePath);
			_tcscpy(g_pPlayer->m_pszSourceFile,FilePath);
// 			WriteLog(pszFilePath);
// 			delete []pszFilePath;

			FilePath.ReleaseBuffer();
			//delete pKtvDownload;
		}	
		else
		{
			_tcscpy(g_pPlayer->m_pszSourceFile , pszFileName);
		}

		return 0;
	}
	return -1;

}

int CreateGraph(void)        // ����Filter Graph
{
	WriteLog("CreateGraph.\n");
//	g_bSendBuffStatus = FALSE;
	g_bOpened=FALSE;
	if (!g_bIsURL)//���ص�ַ
	{
		if (g_pPlayer!=NULL)
		{
			g_pPlayer->Stop();
			if (!g_pPlayer->CreateGraph())
			{
				
				return -1;
			}

			g_lpSendStatus(STATUS_OPENED);
			g_lpSendStatus(STATUS_PLAYING);
			WriteLog("CreateGraph:g_lpSendStatus(STATUS_PLAYING);\n");
			g_bOpened = TRUE;
			SetVolume(g_nVolume);
			return 0;
		}
		return -1;
	}
	else//�����ַ
	{
		return 0;
	}

}

int CreateGraph2(void)        // ����Filter Graph
{
	WriteLog("CreateGraph2.\n");
	//	g_bSendBuffStatus = FALSE;
	g_bOpened=FALSE;
	if (!g_bIsURL)//���ص�ַ
	{
		if (g_pPlayer!=NULL)
		{
			if (!g_pPlayer->CreateGraph2())
			{

				return -1;
			}

			//g_lpSendStatus(STATUS_OPENED);
			//g_lpSendStatus(STATUS_PLAYING);
			WriteLog("CreateGraph2:g_lpSendStatus(STATUS_PLAYING);\n");
			g_bOpened = TRUE;
			//SetVolume(g_nVolume);
			return 0;
		}
		return -1;
	}
	else//�����ַ
	{
		return 0;
	}

}

int DestroyGraph(void)       // ����Filter Graph
{
	WriteLog("DestroyGraph.\n");
	g_bOpened=FALSE;
// 	if (!g_bIsURL)
// 	{
		if (g_pPlayer!=NULL)
		{
			g_pPlayer->DestroyGraph();
			if(!(_waccess(PrevFileCfg, 0) == 0 || _waccess(PrevFilePath, 0) != 0))
			{
				DeleteFile(PrevFileCfg);
				DeleteFile(PrevFilePath);
			}
			return 0;
		}
		return -1;
// 	}
// 	else
// 	{
// 		PostThreadMessage(g_nThreadID,WM_PLAYER_DESTORY,0,0);
// 		return 0;		
// 	}
}

int Start()
{

// 	if ()
// 	{
// 	}
	WriteLog("Call Start.\n");
	if (g_pPlayer!=NULL && g_bOpened == TRUE &&g_status !=STATUS_BUFFERINGDATA)
	{
		
		WriteLog("Start.\n");
		g_pPlayer->Start();
		g_lpSendStatus(STATUS_PLAYING);
		return 0;
	}

	return -1;
}
int Stop()
{
	WriteLog("Stop.\n");
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->Stop();
		return 0;
	}

	return -1;
}
int Pause()
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->Pause();	
		return 0;
	}

	return -1;
}
int Resume()
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->Resume();
		return 0;
	}

	return -1;
}
int Mute(BOOL bMute)
{
	g_bMute = bMute;

	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (bMute)
		{
			g_pPlayer->SetVolume(-10000);
		}
		else
		{
			float fVolume = g_nVolume;
			fVolume = fVolume *10/65535 - 10;
			fVolume = -fVolume *fVolume * fVolume * fVolume;
			g_pPlayer->SetVolume(fVolume);
		}		
		return 0;
	}

	return -1;
}
int GetMute(BOOL &bMute)
{
	bMute = g_bMute;
	return 0;
}
int SetVolume(int nVolume)//ȡֵ��0��65535,
{

	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (nVolume > 65535)//��ֹ���볬����Χ
		{
			nVolume = 65535;
		}
		if (nVolume <0)
		{
			nVolume = 0;
		}

		float fVolume = nVolume;
		g_nVolume = nVolume;
		if (!g_bMute)
		{
// 			SYSTEMTIME st;
// 			GetLocalTime(&st);
// 			FILE *fp;
// 			fp=fopen("d:\\log.txt","at");
// 			fprintf(fp,"PlayerDll: %d:%d:%d:%d ",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
// 			fprintf(fp,"SetVolume: nVolume = %d\n",nVolume);
// 			fclose(fp);
			fVolume = fVolume *10/65535 - 10;
			fVolume = -fVolume *fVolume* fVolume * fVolume;
			g_pPlayer->SetVolume(fVolume);
		}
		return 0;
	}


	return -1;
}
int GetVolume(int &nVolume)//ȡֵ��0��65535,
{
	nVolume = g_nVolume;
	return 0;
}
int IsMultStream(BOOL &bIsMultStream)//�Ƿ��Ƕ�����
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		bIsMultStream = g_pPlayer->m_bIsMultStream;
		return 0;
	}

	return -1;
}
int Get_LanguageLen(int   &nLanguageLen)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_bIsMultStream)
		{

			nLanguageLen = g_pPlayer->m_nLanguageLen;
		}
		else
		{
			nLanguageLen = 12;
		}
// 		FILE *fp;
// 		fp=fopen("d:\\log.txt","at");
// 		fprintf(fp,"nLanguageLen = %d\n", nLanguageLen);
// 		fclose(fp);	
		return 0;
	}

	return -1;

}
int Get_LanguageString(TCHAR   * pszLanguageString)
{
	if (pszLanguageString==NULL)
	{
		return -1;
	}
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_bIsMultStream)
		{
			if(g_pPlayer->m_pszLanguage == NULL)
			{
				_tcscpy(pszLanguageString, g_pszLanguageString);	
				WriteLog("g_pPlayer->m_pszLanguage == NULL\n");
			}
			_tcscpy(pszLanguageString,g_pPlayer->m_pszLanguage);
		}
		else
		{
			_tcscpy(pszLanguageString, g_pszLanguageString);
		}	
// 		FILE *fp;
// 		fp=fopen("d:\\log.txt","at");
// 		fprintf(fp,"pszLanguageString = %s\n", pszLanguageString);
// 		fclose(fp);
		return 0;
	}


	return -1;
}

void ChangeStreamsNumber()
{
	if (g_nStreamNumber == 0)
	{
		g_nStreamNumber = 1;
	}
	else
	{
		g_nStreamNumber = 0;
	}
}
int SelectStreams(int nLanguageNumber)
{
// 	FILE *fp;
// 	fp=fopen("d:\\log.txt","at");
// 	fprintf(fp,"nLanguageNumber = %d\n", nLanguageNumber);
// 	fclose(fp);
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		nLanguageNumber +=1;//�������Ǵ�0��ʼ�������1��ʼ

// 		FILE *fp;
// 		fp=fopen("d:\\log.txt","at");
// 		fprintf(fp,"nLanguageNumber + 1 = %d\n", nLanguageNumber);
// 		fclose(fp);
		if (g_pPlayer->m_bIsMultStream)
		{
// 			FILE *fp;
// 			fp=fopen("d:\\log.txt","at");
// 			fprintf(fp,"g_pPlayer->m_bIsMultStream\n");
// 			fclose(fp);
			g_pPlayer->SelectStreams(nLanguageNumber);			

			if (g_pPlayer->m_FilterGraph!= NULL && !(g_pPlayer->m_bSeekable)&&g_bDownloadComplete)
			{
				
				double duration = 1.;
				double pos = 1.;
				
				//g_pPlayer->m_FilterGraph->GetDuration(&duration);
				g_pPlayer->m_FilterGraph->GetCurrentPosition(&pos);
				//pos = pos - duration * FastSpeed;
				if (!g_pPlayer->CreateGraph())
				{
					g_lpSendStatus(STATUS_OPEN_FAILED);
					//	break;
				}
				g_bOpened = TRUE;
				SetVolume(g_nVolume);
				g_pPlayer->SelectStreams(nLanguageNumber);
				Start();
				if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
				{
					g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);
					g_pPlayer->ClearSempleBuffer();
 				}
				return 0;
			}
		}	
		return 0;
	}


	return -1;
}
int GetTime(QWORD &cnsCurrentTime)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->GetTime(cnsCurrentTime);
		return 0;
	}

	return -1;
}

int  GetDuration(double * outDuration)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL)
		{
			double Duration=0;
			
			g_pPlayer->m_FilterGraph->GetDuration(&Duration);
			*outDuration = Duration;
			return 0;
		}
		return -1;
		
	}


	return -1;
}
int SetCurrentPosition(double inPosition)
{
	if (g_pPlayer!=NULL  &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
		{
			double Duration;
			
			g_pPlayer->m_FilterGraph->GetDuration(&Duration);
			g_pPlayer->m_FilterGraph->SetCurrentPosition(inPosition);	
			return 0;
		}
		if (g_pPlayer->m_FilterGraph!= NULL && !(g_pPlayer->m_bSeekable)&&g_bDownloadComplete)
		{
			if (!g_pPlayer->CreateGraph())
			{
				g_lpSendStatus(STATUS_OPEN_FAILED);
			//	break;
			}
			
// 			g_lpSendStatus(STATUS_OPENED);
// 			g_lpSendStatus(STATUS_PLAYING);
// 			WriteLog("WM_KTVDOWNLOADSONG_PROGRESS g_lpSendStatus(STATUS_PLAYING);\n");
			g_bOpened = TRUE;
			SetVolume(g_nVolume);
			Start();
			if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
			{
				g_pPlayer->m_FilterGraph->SetCurrentPosition(inPosition);	
			}
			return 0;
		}
		return -1;
	
	}


	return -1;
}

int GetCurrentPosition(double * outPosition)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL)
		{
			double Position=0;
			g_pPlayer->m_FilterGraph->GetCurrentPosition(&Position);
			*outPosition = Position;
			return 0;
		}
		return -1;
	
	}

	return -1;
}
int FastBack(float FastSpeed)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
		{

			double duration = 1.;
			double pos = 1.;			
			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			g_pPlayer->m_FilterGraph->GetCurrentPosition(&pos);
			pos = pos - duration * FastSpeed;
			
			g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);
			
			g_pPlayer->ClearSempleBuffer();
			return 0;
		}
		if (g_pPlayer->m_FilterGraph!= NULL && !(g_pPlayer->m_bSeekable)&&g_bDownloadComplete)
		{

			double duration = 1.;
			double pos = 1.;

			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			g_pPlayer->m_FilterGraph->GetCurrentPosition(&pos);
			pos = pos - duration * FastSpeed;
			if (!g_pPlayer->CreateGraph())
			{
				g_lpSendStatus(STATUS_OPEN_FAILED);
				//	break;
			}
			g_bOpened = TRUE;
			SetVolume(g_nVolume);
			Start();
			if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
			{
				g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);
				g_pPlayer->ClearSempleBuffer();
			}
			return 0;
		}
		return -1;
		
	}

	return -1;
}
int FastForward(float FastSpeed)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
		{
			double duration = 1.;
			double pos = 1.;
			
			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			g_pPlayer->m_FilterGraph->GetCurrentPosition(&pos);
			pos = pos + duration * FastSpeed;
			g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);
			
			g_pPlayer->ClearSempleBuffer();	
			return 0;
		}
		if (g_pPlayer->m_FilterGraph!= NULL && !(g_pPlayer->m_bSeekable)&&g_bDownloadComplete)
		{
			
			double duration = 1.;
			double pos = 1.;
			
			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			g_pPlayer->m_FilterGraph->GetCurrentPosition(&pos);
			pos = pos + duration * FastSpeed;
			if (!g_pPlayer->CreateGraph())
			{
				g_lpSendStatus(STATUS_OPEN_FAILED);
				//	break;
			}
			g_bOpened = TRUE;
			SetVolume(g_nVolume);
			Start();
			if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
			{
				g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);
				g_pPlayer->ClearSempleBuffer();
			}
			return 0;
		}
		return -1;
		
	}

	return -1;
}
int SetPos(float fPos)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
		{
			double duration = 1.;
			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			double pos = duration * fPos;
			g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);

			g_pPlayer->ClearSempleBuffer();
			
			return 0;

		}
		if (g_pPlayer->m_FilterGraph!= NULL && !(g_pPlayer->m_bSeekable)&&g_bDownloadComplete)
		{
			double duration = 1.;
			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			double pos = duration * fPos;
			if (!g_pPlayer->CreateGraph())
			{
				g_lpSendStatus(STATUS_OPEN_FAILED);
				//	break;
			}
			g_bOpened = TRUE;
			SetVolume(g_nVolume);
			Start();
			if (g_pPlayer->m_FilterGraph!= NULL && g_pPlayer->m_bSeekable)
			{
				g_pPlayer->m_FilterGraph->SetCurrentPosition(pos);
				g_pPlayer->ClearSempleBuffer();
			}
			return 0;
		}
		return -1;
		
	}

	return -1;
}
int GetPos(float & fOutPos)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		if (g_pPlayer->m_FilterGraph!= NULL)
		{
			double pos = 0, duration = 1. , stoppos = 0;
			
			g_pPlayer->m_FilterGraph->GetCurrentPosition(&pos);
			g_pPlayer->m_FilterGraph->GetStopPosition(&stoppos);
			g_pPlayer->m_FilterGraph->GetDuration(&duration);
			
			fOutPos = pos/duration;	
			return 0;	
		}
		return -1;
		

	}

	return -1;
}

int GetFrameSize(int &nWidth, int &nHeight)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		nWidth = g_pPlayer->m_nWidth;
		nHeight = g_pPlayer->m_nHeight;
		return 0;
	}

	return -1;
}
int GetFrame(BYTE *pFrame, int nWidth, int nHeight)
{
	if (g_pPlayer!=NULL &&pFrame!=NULL  &&g_bOpened == TRUE)
	{
		if (g_nVideoNodeUsed>0)
		{
			memcpy(pFrame,g_pVideoRead->pBuffer,nWidth*nHeight*3);
			g_pVideoRead = g_pVideoRead->pNext;
			g_nVideoNodeUsed --;
			return 0;
		}
		return -1;
	}

	return -1;
}
int GetAudio(double &SampleTime, BYTE * pBuffer, long &BufferSize)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->GetAudio(SampleTime, pBuffer, BufferSize);	
		return 0;
	}
		
	return -1;
}
int GetAudio2(double &SampleTime, BYTE * pBuffer, long &BufferSize)//add by glp
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->GetAudio2(SampleTime, pBuffer, BufferSize);	
		return 0;
	}

	return -1;
}
int GetMideaType(BOOL &m_bVideo, BOOL &m_bAudio)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		m_bVideo = g_pPlayer->m_bVideo;
		m_bAudio = g_pPlayer->m_bAudio;
		return 0;
	}

	return -1;
}

int GetAudioMideaType(AM_MEDIA_TYPE &AudioMideaType)
{
	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->GetAudioMideaType(AudioMideaType);	
		return 0;
	}

	return -1;
}
int SetAudioFormat(WAVEFORMATEX wfx)
{
	if (g_pPlayer!=NULL)
	{
		g_pPlayer->SetAudioMideaType(wfx);	
		return 0;
	}

	return -1;
}
int IsSetTrack(BOOL &bIsSetTrack)//�л�����Filter�Ƿ���سɹ�
{

	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		bIsSetTrack = g_pPlayer->m_bIsSetTrack;
		return 0;
	}

	return -1;
}
int SetTrackLeft()
{

	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->SetTrackLeft();	
		return 0;
	}

	return -1;	
}
int SetTrackRight()
{

	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->SetTrackRight();
		return 0;
	}

	return -1;
}
int SetStereo()
{

	if (g_pPlayer!=NULL &&g_bOpened == TRUE)
	{
		g_pPlayer->SetStereo();
		return 0;
	}

	return -1;
}
BOOL   IsFilterRegistered(CLSID   inFilterId)   
{   
	IBaseFilter   *pFilter   =   NULL;   
	if(SUCCEEDED(CoCreateInstance(inFilterId,NULL,CLSCTX_INPROC_SERVER,IID_IBaseFilter,(void**)&pFilter)))   
	{   
		//pFilter->Release(); 
		SAFE_RELEASE(pFilter);
		return   TRUE;   
	}   
	return   FALSE;   
} 
// BOOL RegisterFilter(const char * inFilterAx)
// {
// 	typedef (WINAPI * REGISTER_FUNC) (void);
// 	REGISTER_FUNC MyFunc = NULL;
// 	HMODULE hModule = ::LoadLibrary(inFilterAx);
// 	if (hModule)
// 	{
// 		MyFunc = (REGISTER_FUNC)GetProcAddress(hModule,"DllRegisterServer");
// 		BOOL pass = (MyFunc != NULL);
// 		if (pass)
// 		{
// 			MyFunc();
// 		}
// 		::FreeLibrary(hModule);
// 		return pass;
// 	}
// 	return FALSE;
// }
LRESULT CALLBACK MessageOnlyWinProc(
									HWND hwnd,      // handle to window
									UINT uMsg,      // message identifier
									WPARAM wParam,  // first message parameter
									LPARAM lParam   // second message parameter
									)//���ڴ�����Ϣ���ڽ��յ�����Ϣ�����ղ��Ž����źš�
{
	//	FILE *fp;
//	WriteLog("MessageOnlyWinProc.\n");
	int nStatus=0 ;
	switch(uMsg)
	{
	case WM_CLOSE:
		
		// 		fp=fopen("d:\\log.txt","at");
		// 		fprintf(fp,"WM_CLOSE\n");
		// 	   	fclose(fp);
		DestroyWindow(hwnd);
		break;	
	case WM_GRAPHNOTIFY:
		
		// 		fp=fopen("d:\\log.txt","at");
		// 		fprintf(fp,"WM_GRAPHNOTIFY\n");
		// 	   	fclose(fp);
//		WriteLog("MessageOnlyWinProc GetStatus()\n");
		if (g_FilterGraph)
		{
			nStatus = g_FilterGraph->GetStatus();
		}
		
//		WriteLog("MessageOnlyWinProc GetStatus() Success.\n");
		if (nStatus==1)//����
		{
			g_lpIsEOF();
			WriteLog("if (nStatus==1)//���� EOF\n");
		}
		if (nStatus==2)//��������
		{
// 			if (g_bSendBuffStatus)
// 			{
				g_lpSendStatus(STATUS_PLAYING);
				WriteLog("/��������g_lpSendStatus(STATUS_PLAYING);\n");
//			}
//				g_bSendBuffStatus = TRUE;
		
			g_status=STATUS_PLAYING;
		}
		if (nStatus==3)//��ʼ����
		{
			g_status=STATUS_BUFFERINGDATA;
			g_lpSendStatus(STATUS_BUFFERINGDATA);
		}
		if (nStatus==EC_OPENING_FILE)
		{
			g_lpSendStatus(STATUS_OPENING);
		}
		//		g_FilterGraph->HandleEvent(0,0);
		break;
	case WM_KTVDOWNLOADSONG_COMPLETE:
	//	WriteLog("WM_KTVDOWNLOADSONG_COMPLETE\n");
		if (g_bOpened ==FALSE&& g_pCurrentKtvDownload == (KTVDOWNPARAM	*)wParam)
		{
			WriteLog("WM_KTVDOWNLOADSONG_COMPLETE CreateGraph()\n");
			if (!g_pPlayer->CreateGraph())
			{
				g_lpSendStatus(STATUS_OPEN_FAILED);
				break;
			}

			g_lpSendStatus(STATUS_OPENED);
			g_lpSendStatus(STATUS_PLAYING);
			WriteLog("WM_KTVDOWNLOADSONG_COMPLETE g_lpSendStatus(STATUS_PLAYING);\n");
			g_bOpened = TRUE;
			SetVolume(g_nVolume);

		}
		if (g_pCurrentKtvDownload == (KTVDOWNPARAM	*)wParam &&g_bIsURL)
		{
			g_bDownloadComplete = TRUE;
		}
		break;
	case WM_KTVDOWNLOADSONG_PROGRESS:
	//	WriteLog("WM_KTVDOWNLOADSONG_PROGRESS\n");
		g_CurrentTime = GetTickCount();

		if ((lParam>10||(g_CurrentTime - g_StartTime>10000 && lParam>5)) && g_bOpened ==FALSE && g_pCurrentKtvDownload == (KTVDOWNPARAM	*)wParam)
		{
			WriteLog("WM_KTVDOWNLOADSONG_PROGRESS 20% , CreateGraph()\n");
			g_bDownloadComplete = FALSE;
			if (!g_pPlayer->CreateGraph())
			{
				g_lpSendStatus(STATUS_OPEN_FAILED);
				break;
			}

			g_lpSendStatus(STATUS_OPENED);
			g_lpSendStatus(STATUS_PLAYING);
			WriteLog("WM_KTVDOWNLOADSONG_PROGRESS g_lpSendStatus(STATUS_PLAYING);\n");
			g_bOpened = TRUE;
			SetVolume(g_nVolume);
		}

		break;
	case WM_KTVDOWNLOADSONG_FAILED:
		WriteLog("WM_KTVDOWNLOADSONG_FAILED\n");
		g_lpIsEOF();
		WriteLog("EOF\n");
		break;
	case WM_DESTROY:
		//PostQuitMessage(0);
		DestroyWindow(hwnd);
		break;
		
		
	default:
		return DefWindowProc(hwnd,uMsg,wParam,lParam);
	}
	return 0;
}
BOOL InitMessageOnlyWindow()
{
	WriteLog("InitMessageOnlyWindow enter\n");
	HINSTANCE hInstance = NULL;
	hInstance = GetModuleHandle(NULL);
	if (hInstance == NULL)
	{
		return FALSE;
	}
	
	WNDCLASS wndcls;
	wndcls.cbClsExtra=0;
	wndcls.cbWndExtra=0;
	wndcls.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	wndcls.hCursor=LoadCursor(NULL,IDC_CROSS);
	wndcls.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	wndcls.hInstance=hInstance;
	wndcls.lpfnWndProc=MessageOnlyWinProc;
	wndcls.lpszClassName=_T("Message-Only Window");
	wndcls.lpszMenuName=NULL;
	wndcls.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&wndcls);
	
	g_hwnd = CreateWindowEx(0,_T("Message-Only Window"),_T("Message-Only Window"),0,0,0,0,0,HWND_MESSAGE,0,hInstance,0);
	if (g_hwnd == NULL)
	{
		return FALSE;	
	}
	return TRUE;
}
int Open()
{
	return 0;
}
int Close()
{
	return 0;
}
int DownloadCompleted(BOOL bDownloadCompleted)
{
	g_bDownloadComplete = bDownloadCompleted;
	return 0;
}
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}
