// Opengl.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <math.h>
#include <windows.h>

#include "Opengl.h"
#include "PlayerDll/PlayerDll.h"

#include "CWavePlayer.h"

#define WM_PLAYER_MESSAGE (WM_USER+1000)

extern			HWND				g_hWnd;
extern			CWavePlayer	g_Player;
extern			bool					g_bGLThread;//���ƻ滭�̺߳���

CGPoint CGPointMake(float x,float y)
{
	CGPoint point;
	point.x = x;
	point.y = y;
	return point;
}

CGSize CGSizeMake(int x,int y)
{
	CGSize cgSize;
	cgSize.width = x;
	cgSize.height = y;
	return cgSize;
}

CGRect CGRectMake(float x,float y,int w,int h)
{
	CGRect rect;
	rect.origin.x = x;
	rect.origin.y = y;
	rect.size.width = w;
	rect.size.height = h;
	return rect;
}

CGRect CGRectMake(const CGPoint& point,const CGSize& size)
{
	CGRect rect;
	rect.origin = point;
	rect.size = size;
	return rect;
}



CGRect CGRectIntersection(const CGRect& a,const CGRect& b)
{
	//writeLog("CGRectIntersection enter");
	float Lmax = max(a.origin.x,b.origin.x);
	float Rmin = min(a.origin.x+a.size.width,b.origin.x+b.size.width);
	float Tmax = max(a.origin.y,b.origin.y);
	float Bmin = min(a.origin.y+a.size.height,b.origin.y+b.size.height);

	if (Lmax>=Rmin||Tmax>=Bmin)
	{
		return CGRectMake(0.0f,0.0f,0,0);
	}
	int w = (int)(Rmin-Lmax);
	int h = (int)(Bmin-Tmax);
	return CGRectMake(Lmax,Tmax,w,h);
}

void writeLog(const wchar_t *msg)
{
	if (msg == NULL)
	{
		return;
	}
	char buf[1024] = {0};
	WideCharToMultiByte(CP_ACP,0,msg,-1,buf,1023,NULL,NULL);

	SYSTEMTIME st;
	GetLocalTime(&st);

	FILE * fp = fopen(LOGPATH,"a");
	if (fp == NULL)
	{
		return;
	}
	fprintf(fp,"[%02d:%02d:%02d.%05d],%s\n",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds,buf);
	fclose(fp);
}

void writeLog(const char *msg,...)
{

	if (msg == NULL)
	{
		return;
	}
	SYSTEMTIME st;
	GetLocalTime(&st);

	FILE * fp = fopen(LOGPATH,"a");
	if (fp == NULL)
	{
		return;
	}
	fprintf(fp,"[%02d:%02d:%02d.%05d]:",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	va_list arg_ptr;
	const char* str = msg;
	va_start(arg_ptr, msg);
	do
	{
		if(*str != '%')
			fputc(*str++,fp);
		else
		{
			switch(*(++str))
			{
			case('d')://int/ long 
				{
					int a = va_arg(arg_ptr,int);
					fprintf(fp,"%d",a);
					break;
				}
			case ('f')://float,double
				{
					float b = va_arg(arg_ptr,double);
					fprintf(fp,"%f",b);
					break;
				}
			case('s')://str
				{
					char* s = va_arg(arg_ptr,char*);
					fprintf(fp,"%s",s);
					break;
				}
			}
			str++;
		}
	}while(*str != '\0');
	fprintf(fp,"\n");
	va_end(arg_ptr);
	fclose(fp);
}

bool OpenVideoFile(const char * fileName)
{
	if (fileName == NULL)
	{
		return false;
	}
	// Rebuild the file playback filter graph

//	m_SourceFile = "http://www.ma-friends.com/mp3/����.mp3";

//	m_SourceFile.GetBuffer(0);
	WCHAR   szwFile[MAX_PATH];
	MultiByteToWideChar(CP_ACP, 0, fileName, -1, szwFile, MAX_PATH);
	//SetFileName(m_SourceFile.GetBuffer(0));//���������ļ���
	//SetFileName(szwFile);//���������ļ���
	SetFileName(szwFile);
		
	if(CreateGraph()==-1)
	{
		return FALSE;
	}//����������·
	//BOOL bIsMultStream = FALSE;
		//int  nLanguageLen = 0;
		//IsMultStream(bIsMultStream);//���ж��Ƿ��ж�����
		//Get_LanguageLen(nLanguageLen);//ȡ�������ַ�������
		//if(m_Language != NULL)
		//{
		//	delete m_Language;
		//}
 	//	m_Language = new WCHAR[nLanguageLen+1];//Ϊ�����ַ�������ռ�
  //		Get_LanguageString(m_Language);//ȡ�������ַ���,���������л�
// 
// 		FILE *fp;
// 		fp=fopen("d:\\log.txt","at");
// 		fprintf(fp,"nLanguageLen = %d \nm_Language = %s\n",nLanguageLen, m_Language);
// 		fclose(fp);

		//GetMideaType(m_bVideo, m_bAudio);//�õ�ý���Ƿ�����Ƶ/��Ƶ
		//if (NULL != m_pFrameData)
		//{
		//	free(m_pFrameData);
		//	m_pFrameData=NULL;
		//}
		//if (m_bVideo)
		//{
		//	GetFrameSize(m_nWidth,m_nHeight);//�õ���Ƶ��С��������ռ�

		//	m_pFrameData = (BYTE *) malloc(m_nWidth*m_nHeight*3);
		//	
		//}
		/*if (NULL != g_pAudioData)
		{
			free(g_pAudioData);
			g_pAudioData = NULL;
		}*/
		//if (m_bAudio)
		//{
		//	WriteLog("bAudio = TRUE.\n\n");
		//	if (NULL == g_pAudioData)
		//	{
		//		g_pAudioData = (BYTE *)malloc(FILEBUFFER);//������Ƶ����
		//	}
		//	GetAudioMideaType(m_mtAudioType);//�õ���Ƶ��ʽ
		//	
		//}
		//
		//g_bOpenFile = TRUE;		
	return true;
}

int StartPlayer()
{
	if (Start())
	{
		return -1;
	}
	return 0;
}

int StopPlayer()
{
	if (Stop())
	{
		return -1;
	}
	return 0;
}

int PausePlayer()
{
	if (Pause())
	{
		return -1;
	}
	return 0;
}

int ResumePlayer()
{
	if (Resume())
	{
		return -1;
	}
	return 0;
}

void CALLBACK GetAudioSample()//���ڵ���Ƶ����׼����ʱȡ��Ƶ���ݵĻص�������
{
	//GetAudio(g_fSampleTime, g_pAudioData, g_nBufferSize);
}

void CALLBACK GetAudioSample2()//��һ���ص�������
{

}

void CALLBACK IsEOF()//���ڽ��ս����źŵĻص�����
{

	g_Player.Close();
	g_bGLThread = false;//�����߳�
	UnInitialize();
	//PostMessage(g_hWnd,WM_PLAYER_MESSAGE,nStatus,0);

	//if (g_pMp3File != NULL)
	//{
	//	ULONG uWrited = 0;
	//	ULONG uUnWrited = g_uMp3BufferWrited;
	//	PBYTE ptmpMP3 = g_pMP3Buffer;
	//	do 
	//	{

	//		ptmpMP3 += uWrited;
	//		uUnWrited -= uWrited;
	//		uWrited = fwrite(ptmpMP3,1,uUnWrited,g_pMp3File);

	//	} while (uWrited<uUnWrited);

	//	g_uMp3BufferWrited = 0;
	//	g_writedToFile ++;
	//	//if (g_writedToFile == g_writeToFile)
	//	{
	//		// Deinit the stream
	//		BE_ERR err = beDeinitStream(g_hbeStream, g_pMP3Buffer, &g_dwWrite);

	//		// Check result
	//		if(err != BE_ERR_SUCCESSFUL)
	//		{

	//			beCloseStream(g_hbeStream);
	//			WriteLog("beExitStream failed");
	//			return ;
	//		}

	//		// Are there any bytes returned from the DeInit call?
	//		// If so, write them to disk
	//		if( g_dwWrite )
	//		{
	//			if( fwrite( g_pMP3Buffer, 1, g_dwWrite, g_pMp3File ) != g_dwWrite )
	//			{
	//				WriteLog("last Output file write error");
	//				return ;
	//			}
	//		}
	//		fflush(g_pMp3File);
	//		fclose(g_pMp3File);
	//		// close the MP3 Stream
	//		beCloseStream( g_hbeStream );

	//		// Delete MP3 Buffer
	//		if (g_writedToFile == g_writeToFile)
	//		{
	//			delete [] g_pMP3Buffer;
	//			g_pMP3Buffer = NULL;
	//		}
	//		g_uMp3BufferWrited = 0;

	//		if ( beWriteInfoTag )
	//		{
	//			// Write the INFO Tag
	//			beWriteInfoTag( g_hbeStream, g_strFileOut );//��Ҫ��mp3ͷ����д��
	//		}
	//		else
	//		{
	//			beWriteVBRHeader( g_strFileOut );
	//		}
	//	}
	//	g_pMp3File = NULL;
	//	g_bTransformed = TRUE;
	//	g_strFileOut = "";

	//}
}

void CALLBACK SendStatus(int nStatus)//����ת��״̬��Ϣ�Ļص�����
{
	PostMessage(g_hWnd,WM_PLAYER_MESSAGE,nStatus,0);
}



 







