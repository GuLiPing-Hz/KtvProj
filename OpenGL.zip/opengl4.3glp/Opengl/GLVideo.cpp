#include "StdAfx.h"
#include "GLVideo.h"

#include "Opengl.h"
#include "PlayerDll/PlayerDll.h"

bool   g_bPboSupported = false;
int		g_pboMode = 0;			//PBO model

// function pointers for PBO Extension
// Windows needs to get function pointers from ICD OpenGL drivers,
// because opengl32.dll does not support extensions higher than v1.1.
PFNGLGENBUFFERSARBPROC pglGenBuffersARB = 0;                     // VBO Name Generation Procedure
PFNGLBINDBUFFERARBPROC pglBindBufferARB = 0;                     // VBO Bind Procedure
PFNGLBUFFERDATAARBPROC pglBufferDataARB = 0;                     // VBO Data Loading Procedure
PFNGLBUFFERSUBDATAARBPROC pglBufferSubDataARB = 0;               // VBO Sub Data Loading Procedure
PFNGLDELETEBUFFERSARBPROC pglDeleteBuffersARB = 0;               // VBO Deletion Procedure
PFNGLGETBUFFERPARAMETERIVARBPROC pglGetBufferParameterivARB = 0; // return various parameters of VBO
PFNGLMAPBUFFERARBPROC pglMapBufferARB = 0;                       // map VBO procedure
PFNGLUNMAPBUFFERARBPROC pglUnmapBufferARB = 0;                   // unmap VBO procedure
#define glGenBuffersARB           pglGenBuffersARB
#define glBindBufferARB           pglBindBufferARB
#define glBufferDataARB           pglBufferDataARB
#define glBufferSubDataARB        pglBufferSubDataARB
#define glDeleteBuffersARB        pglDeleteBuffersARB
#define glGetBufferParameterivARB pglGetBufferParameterivARB
#define glMapBufferARB            pglMapBufferARB
#define glUnmapBufferARB          pglUnmapBufferARB

CGLVideo::CGLVideo(int textureX,int textureY):m_pvideoTextureData(NULL),
										m_videoHeight(0),
										m_videoWidth(0),
										m_textureX(textureX),
										m_textureY(textureY),
										m_pvideoData(NULL),
										m_uMax(0),
										m_uMin(0),
										m_vMin(0),
										m_vMax(0),
										m_bInit(false),
										m_switchTextureID(1),
										m_DATA_SIZE(0)
{
	m_texture[0] = 0;
	m_texture[1] = 0;
	m_pboIds[0] = 0;
	m_pboIds[1] = 0;
}

bool CGLVideo::GetTextureIDInit()
{
	return m_bInit;
}

int CGLVideo::getTextureSwitch()
{
	return m_switchTextureID;
}

void CGLVideo::bindTexture()
{
	glBindTexture(GL_TEXTURE_2D,m_texture[0]);
}

CGLVideo::~CGLVideo(void)
{
	m_texture[0] = 0;
	m_texture[1] = 0;
	m_pboIds[0] = 0;
	m_pboIds[1] = 0;
	if (m_pvideoTextureData)
	{
		delete [] m_pvideoTextureData;
		m_pvideoTextureData = NULL;
	}
	if (m_pvideoData)
	{
		delete [] m_pvideoData;
		m_pvideoData = NULL;
	}
}

BOOL CGLVideo::Video2TextureMem(BYTE* pVideo,BYTE* pTexture,int format)
{
	if (!pVideo || !pTexture)
	{
		return FALSE;
	}
	BYTE *tmpVideo = pVideo;
	BYTE *tmpTexture = pTexture;
	if ((m_videoWidth > m_textureX) || (m_videoHeight > m_textureY))
	{
		return FALSE;
	}
	for (int i=0;i<m_videoHeight;i++)
	{
		memcpy(tmpTexture,tmpVideo,m_videoWidth*format);
		tmpTexture = tmpTexture + m_textureX*format;
		tmpVideo = tmpVideo + m_videoWidth*format;
	}
	return TRUE;
}

BOOL CGLVideo::LoadGLTexturesVideo()
{
	BOOL Status=FALSE;									// Status Indicator					

	glInfo struct_glInfo;
	struct_glInfo.getInfo();//��ȡ�Կ���Ϣ
	struct_glInfo.printSelf2Log();//��ӡ����־

	GetFrameSize(m_videoWidth,m_videoHeight);
	//m_videoHeight = 512;
	//m_videoWidth = 512;
	//makeTextureXY(m_videoWidth,m_videoHeight);
	m_DATA_SIZE = m_videoHeight*m_videoWidth*3;

	if (!m_pvideoData)
	{
		m_pvideoData= new BYTE[m_videoWidth*m_videoHeight*3];
	}
	//m_pvideoTextureData = new BYTE[m_textureX*m_textureY*3];
	if ( !m_pvideoData )
	{
		return Status;
	}

	//memset(m_pvideoData,0xFF,m_videoWidth*m_videoHeight*3);
	//int result = GetFrame(m_pvideoData,m_videoWidth,m_videoHeight);
	//if (result == 0)
	{
		//Video2TextureMem(m_pvideoData,m_pvideoTextureData);
		Status=TRUE;									// Set The Status To TRUE
		glGenTextures(1, &m_texture[0]);					// ����1������id
		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, m_texture[0]);
//		glTexImage2D(GL_TEXTURE_2D, 0, 3, m_textureX, m_textureY, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_videoWidth, m_videoHeight, 0, GL_BGR, GL_UNSIGNED_BYTE, m_pvideoData);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		//pbo
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		/*glBindTexture(GL_TEXTURE_2D,m_texture[1]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_videoWidth, m_videoHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoData);

		//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE );
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);*/

		if(struct_glInfo.isExtensionSupported("GL_ARB_pixel_buffer_object"))
		{
			// get pointers to GL functions
			glGenBuffersARB = (PFNGLGENBUFFERSARBPROC)wglGetProcAddress("glGenBuffersARB");
			glBindBufferARB = (PFNGLBINDBUFFERARBPROC)wglGetProcAddress("glBindBufferARB");
			glBufferDataARB = (PFNGLBUFFERDATAARBPROC)wglGetProcAddress("glBufferDataARB");
			glBufferSubDataARB = (PFNGLBUFFERSUBDATAARBPROC)wglGetProcAddress("glBufferSubDataARB");
			glDeleteBuffersARB = (PFNGLDELETEBUFFERSARBPROC)wglGetProcAddress("glDeleteBuffersARB");
			glGetBufferParameterivARB = (PFNGLGETBUFFERPARAMETERIVARBPROC)wglGetProcAddress("glGetBufferParameterivARB");
			glMapBufferARB = (PFNGLMAPBUFFERARBPROC)wglGetProcAddress("glMapBufferARB");
			glUnmapBufferARB = (PFNGLUNMAPBUFFERARBPROC)wglGetProcAddress("glUnmapBufferARB");

			// check once again PBO extension
			if(glGenBuffersARB && glBindBufferARB && glBufferDataARB && glBufferSubDataARB &&
				glMapBufferARB && glUnmapBufferARB && glDeleteBuffersARB && glGetBufferParameterivARB)
			{
				g_bPboSupported = true;
				g_pboMode = 2;    // using 2 PBOs
				writeLog("Video card supports GL_ARB_pixel_buffer_object.");
			}
			else
			{
				g_bPboSupported = false;
				g_pboMode = 0;    // without PBO
				writeLog("Video card does NOT support GL_ARB_pixel_buffer_object.");
			}
		}

		if(g_bPboSupported)
		{
			// create 2 pixel buffer objects, you need to delete them when program exits.
			// glBufferDataARB with NULL pointer reserves only memory space.
			glGenBuffersARB(2, m_pboIds);
			//char bufLog[256] = {0};
			//sprintf(bufLog,"m_pboIDS[0] = %d,m_pboIDS[1] = %d",m_pboIds[0],m_pboIds[1]);
			//writeLog(bufLog);
			glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_pboIds[0]);
			glBufferDataARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_DATA_SIZE, 0, GL_STREAM_DRAW_ARB);
			glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_pboIds[1]);
			glBufferDataARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_DATA_SIZE, 0, GL_STREAM_DRAW_ARB);
			glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, 0);
		}
/*
		m_uMax = (float)m_videoWidth/m_textureX;
		m_uMin = (float)0.0/m_textureX;
		m_vMax = (float)m_videoHeight/m_textureY;
		m_vMin = (float)0.0/m_textureY;
*/
		m_uMax = 1.0f;
		m_uMin = 0.0f;
		m_vMax = 1.0f;
		m_vMin = 0.0f;

		m_bInit = true;
	}
	return Status;										// Return The Status
}

BOOL CGLVideo::UpdateGLTextures()//��������
{
	BOOL status = FALSE;
	if (!m_bInit)
	{
		status = FALSE;
	}
	if (!m_pvideoData)
	{
		status = FALSE;
	}
	
	int result = GetFrame(m_pvideoData,m_videoWidth,m_videoHeight);
	if (result == 0)
	{
		glBindTexture(GL_TEXTURE_2D, m_texture[0]);
		/*if (m_switchTextureID == 1)//����1������1
		{
			glBindTexture(GL_TEXTURE_2D, m_texture[1]);//������,֮ǰҪ����2D����
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, m_texture[0]);//������,֮ǰҪ����2D����
		}*/
		//ExchangeRedBlue(m_pvideoData);
		/*if (*tmpVideoData == *m_pvideoData)
		{
			return TRUE;
		}*/
		//Video2TextureMem(m_pvideoData,m_pvideoTextureData);
		// ��������
		//glTexImage2D(GL_TEXTURE_2D, 0, 3, m_textureX, m_textureY, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
		//glTexSubImage2D (GL_TEXTURE_2D, 0, 0, 0, m_videoWidth, m_videoHeight, GL_BGR, GL_UNSIGNED_BYTE, m_pvideoData);
		//glTexSubImage2D (GL_TEXTURE_2D, 0, 0, 0, m_textureX, m_textureY, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
		//////////////////////////////////////////////////////////////////////////
		static int index = 0;
		int nextIndex = 0;                  // pbo index used for next frame
		
		if(g_pboMode&0x3)
		{
			// "index" is used to copy pixels from a PBO to a texture object
			// "nextIndex" is used to update pixels in a PBO
			if(g_pboMode &0x1)
			{
				// In single PBO mode, the index and nextIndex are set to 0
				//writeLog("g_pboMode is 1");
				index = nextIndex = 0;
			}
			else if(g_pboMode&0x2)
			{
				// In dual PBO mode, increment current index first then get the next index
				//writeLog("g_pboMode is 2");
				index = (index + 1) % 2;
				nextIndex = (index + 1) % 2;
			}

			// start to copy from PBO to texture object ///////
			//t1.start();

			// bind the texture and PBO
			glBindTexture(GL_TEXTURE_2D, m_texture[0]);
			glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_pboIds[index]);

			// copy pixels from PBO to texture object
			// Use offset instead of ponter.
			glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, m_videoWidth, m_videoHeight, GL_BGR, GL_UNSIGNED_BYTE, NULL);

			// measure the time copying data from PBO to texture object
			//t1.stop();
			//copyTime = t1.getElapsedTimeInMilliSec();
			///////////////////////////////////////////////////


			// start to modify pixel values ///////////////////
			//t1.start();

			// bind PBO to update pixel values
			glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_pboIds[nextIndex]);

			// map the buffer object into client's memory
			// Note that glMapBufferARB() causes sync issue.
			// If GPU is working with this buffer, glMapBufferARB() will wait(stall)
			// for GPU to finish its job. To avoid waiting (stall), you can call
			// first glBufferDataARB() with NULL pointer before glMapBufferARB().
			// If you do that, the previous data in PBO will be discarded and
			// glMapBufferARB() returns a new allocated pointer immediately
			// even if GPU is still working with the previous data.
			glBufferDataARB(GL_PIXEL_UNPACK_BUFFER_ARB, m_DATA_SIZE, NULL, GL_STREAM_DRAW_ARB);
			GLubyte* ptr = (GLubyte*)glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, GL_WRITE_ONLY_ARB);
			if(ptr)
			{
				// update data directly on the mapped buffer
				//updatePixels(ptr, DATA_SIZE);
				//writeLog("glMapBufferARB ptr enter");
				memcpy(ptr,m_pvideoData,m_DATA_SIZE);
				glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB); // release pointer to mapping buffer
			}

			// measure the time modifying the mapped buffer
			//t1.stop();
			//updateTime = t1.getElapsedTimeInMilliSec();
			///////////////////////////////////////////////////

			// it is good idea to release PBOs with ID 0 after use.
			// Once bound with 0, all pixel operations behave normal ways.
			glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_ARB, 0);
		}
		else
		{
			///////////////////////////////////////////////////
			// start to copy pixels from system memory to textrure object
			//t1.start();
			glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, m_videoWidth, m_videoHeight, GL_BGR, GL_UNSIGNED_BYTE, m_pvideoData);

			//t1.stop();
			//copyTime = t1.getElapsedTimeInMilliSec();
			
			// start to modify pixels /////////////////////////
			//t1.start();
			//updatePixels(imageData, DATA_SIZE);
			//t1.stop();
			//updateTime = t1.getElapsedTimeInMilliSec();
			
		}
		//////////////////////////////////////////////////////////////////////////
		status = TRUE;
	}
	/*if (m_switchTextureID == 1)//����1�����ڻ�0
	{
		glBindTexture(GL_TEXTURE_2D, m_texture[0]);
		m_switchTextureID = 0;
	}
	else
	{
		glBindTexture(GL_TEXTURE_2D, m_texture[1]);
		m_switchTextureID = 1;
	}*/
	return status;
	//OutputDebugStringA("result==-1\n");
	//writeLog("result==-1");
	//status = FALSE;
}

void CGLVideo::DrawVideo(float ScreenX,float ScreenY)
{
	glTexCoord2f(m_uMin, m_vMin);//ָ��uv����
	glVertex3f(0.0f,-ScreenY, 0.0f);					// Bottom Left 

	glTexCoord2f(m_uMax, m_vMin);//ָ��uv����
	glVertex3f( ScreenX,-ScreenY, 0.0f);					// Bottom Right 

	glTexCoord2f(m_uMax, m_vMax);//ָ��uv����
	glVertex3f( ScreenX, -0.0f, 0.0f);					// Top Right 

	glTexCoord2f(m_uMin, m_vMax);//ָ��uv����
	glVertex3f(0.0f, 0.0f, 0.0f);					// Top Left 
}

void CGLVideo::makeTextureXY(int x,int y)
{
	int tx = 1;
	int ty = 1;
	while (tx<x)
	{
		tx = tx*2;
	}
	
	while(ty<y)
	{
		ty = ty*2;
	}
	//int txy = tx>ty?tx:ty;
	m_textureX = tx;
	m_textureY = ty;
}

void CGLVideo::ExchangeRedBlueC(BYTE* buffer)
{
	if (buffer == NULL)
	{
		return;
	}
	BYTE * tmpP = buffer;
	int sum = m_videoWidth*m_videoHeight*3;
	for (int i =0;i<sum;i+=3)
	{
		BYTE tmpB = tmpP[i];
		tmpP[i] = tmpP[i+2];
		tmpP[i+2] = tmpB;
	}
}

void CGLVideo::ExchangeRedBlue(void* buffer)										// Flips The Red And Blue Bytes (256x256)
{
	void* b = buffer;											// Pointer To The Buffer
	int s = m_videoHeight*m_videoWidth;
	__asm														// Assembler Code To Follow
	{
		mov ecx, s										// Counter Set To Dimensions Of Our Memory Block
		mov ebx, b												// Points ebx To Our Data (b)
		label:													// Label Used For Looping
				mov al,[ebx+0]										// Loads Value At ebx Into al
				mov ah,[ebx+2]										// Loads Value At ebx+2 Into ah
				mov [ebx+2],al										// Stores Value In al At ebx+2
				mov [ebx+0],ah										// Stores Value In ah At ebx

				add ebx,3											// Moves Through The Data By 3 Bytes
				dec ecx												// Decreases Our Loop Counter
				jnz label											// If Not Zero Jump Back To Label
	}
}
