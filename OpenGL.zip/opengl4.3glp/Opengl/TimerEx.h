#ifndef __TIMEREX_H__
#define __TIMEREX_H__

#include "Opengl.h"
#include <windows.h>
#include "Timer.h"

class SceneMgr;
//--------------------------------------------------------------------------
class ITimerListener
{
public:
	// ��������
	virtual ~ITimerListener() {}

	virtual void onTimer( unsigned int elapsed_tm ) = 0;
	virtual SceneMgr* GetSceneMgr() = 0;
	virtual void setStarTime(unsigned int elapsed_tm)=0;
	virtual void setStopTime(unsigned int elapsed_tm)=0;
};

class CTimerEx:public Timer
{
public:
	// ���캯��
	CTimerEx(DWORD dwFps = 60, bool bFrameSkip = true);

	// ��������
	~CTimerEx();

public:
	// ���ü�����
	void setListener( ITimerListener * listener );
	//��ü�����
	ITimerListener* getListener();

	// ������ʱ��
	void processTimer();

	void startTimer();
	void stopTimer();

	void measure();
	void setFPS(DWORD time);
	void onFrameSkip(bool bFrameSkip);
	bool getDrawFlag();
	DWORD getSkipRate();
	DWORD getFrameRate();

private:
	ITimerListener * m_pListener;
	DWORD m_dwLastFlipped;
	DWORD m_dwLastMinitues;
	DWORD m_dwPrevFrameMinitues;
	DWORD m_dwFrameRate;
	DWORD m_dwSkipRate;
	float m_fFrameTime;
	bool m_bDrawFlag;
	bool m_bFrameSkip;

	bool m_bInit;
	DWORD m_dwFrameCount;
	DWORD m_dwSkipCount;
};

#endif // __TIMEREX_H__