#include "StdAfx.h"
#include "OpenGLWindow.h"

#include "Opengl.h"
#include "CWavePlayer.h"
#include "staff/SceneMgr.h"
#include "staff/SceneObjectEx.h"
#include "PlayerDll/PlayerDll.h"

#define WM_PLAYER_MESSAGE (WM_USER+1000)
#define FILEBUFFER	(1024*1024)

CWavePlayer g_Player;
HWND		g_hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	g_hInstance;		// Holds The Instance Of The Application
HDC						g_hDC;		// Private GDI Device Context
HGLRC					g_hRC;		// Permanent Rendering Context
BYTE * g_pAudioData=NULL;

bool	g_keys[256];			// Array Used For The Keyboard Routine
bool	g_active=TRUE;		// Window Active Flag Set To TRUE By Default
bool g_bGLThread = true;//���ƻ滭�̺߳���

extern bool		g_bPboSupported;
extern int		g_pboMode;	

DWORD WINAPI GLThreadProc(LPVOID pParam)
{
	COpenGLWindow * pcopenGLWindow = (COpenGLWindow*) pParam;
	if (!pcopenGLWindow->InitGL())									// Initialize Our Newly Created GL Window
	{
		pcopenGLWindow->KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	pcopenGLWindow->ReSizeGLScene(1280, 720);					// Set Up Our Perspective GL Screen
	CTimerEx * ptimeEx = pcopenGLWindow->GetTimerEx();
	if (!ptimeEx)
	{
		return -1;
	}
	while(g_bGLThread)
	{
		ptimeEx->processTimer();
	}
	ITimerListener* timerListener = pcopenGLWindow->GetTimerListener();
	SceneMgr* sceneMgr = timerListener->GetSceneMgr();
	sceneMgr->endModel();//����
	return 0;
}


int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
				   HINSTANCE	hPrevInstance,		// Previous Instance
				   LPSTR		lpCmdLine,			// Command Line Parameters
				   int			nCmdShow)			// Window Show State
{

	writeLog("main enter");
	Initialize(GetAudioSample,GetAudioSample2,IsEOF,SendStatus);//��ʼ��
	SetNeedGetAudioData(FALSE);//����ΪTUREʱ��GetAudioSample������е���GetAudioȡ��Ƶ���ݳ��������򲥷Ż���ͣ;

	//////////////////////////////////////////////////////////////////////////
	int win_width;
	int win_height;
	HDC hDesktop= GetDC(0);//��ȡ��Ļ���
	win_width=GetDeviceCaps(hDesktop,HORZRES);
	win_height=GetDeviceCaps(hDesktop,VERTRES);

	
	COpenGLWindow				openGLWindow;

	if (!openGLWindow.CreateGLWindow("Video Open"))//���⣬���ߣ���ɫ��ʾλ
	{
		return 0;									// Quit If Window Was Not Created
	}

	CGLVideo*							pglVideo = new CGLVideo;
	//CGLFlorid	*							pglFlorid = new CGLFlorid;
	//pglFlorid->LoadGLTextures("Data/NeHe.bmp");��������
	

	CGSize winsize = CGSizeMake(1280,720);//D:\\���Ƽ�\\Video\\Opengl\\Data
	SceneObjectEx *					psceneObjectEx = new SceneObjectEx("C:\\Users\\Administrator\\Documents\\Visual Studio 2005\\Projects\\DXdemoTestSM\\debug","960139=��=����=��=������",winsize);
	SceneMgr *							psceneMgr = new SceneMgr;//D:\\���Ƽ�\\Video\\Opengl\\Data
	if (!psceneMgr->addObjectToAdd((SceneObject*)psceneObjectEx))
	{
		return -1;
	}
	DrawListener*						pdrawListener = new DrawListener(pglVideo,NULL,psceneMgr);
	//DrawListener*						pdrawListener = new DrawListener(pglVideo);

	openGLWindow.SetTimerListener(pdrawListener);//���û滭����
	//���ô��ڵĴ�С
	/*if(!OpenVideoFile("D:\\work\\video\\Data\\mpg\\1304=��=022951=��=���к�=��=�����ֵ�.mpg"))
	{
		writeLog("video open error");
		return false;
	}
	StartPlayer();*/
	// Create Our OpenGL Window

	openGLWindow.MessageWhile();//��Ϣѭ��
	// Shutdown
	openGLWindow.KillGLWindow();//��������
	//g_pcOpenGLWindow = NULL;
	return 0;//msg.wParam							// Exit The Program
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
						 UINT	uMsg,			// Message For This Window
						 WPARAM	wParam,			// Additional Message Information
						 LPARAM	lParam)			// Additional Message Information
{
	static COpenGLWindow * pcOpenGLWindow= NULL;
	switch (uMsg)									// Check For Windows Messages
	{
	case WM_CREATE:
		{
			CREATESTRUCT *tmpCreate = reinterpret_cast< CREATESTRUCT*>(lParam);
			pcOpenGLWindow = static_cast<COpenGLWindow*>(tmpCreate->lpCreateParams);
		}
		break;
	case WM_PLAYER_MESSAGE:
		{
			if (pcOpenGLWindow)
			{
				pcOpenGLWindow->OnPlayerMessage(wParam, lParam);
				return 0;
			}
			break;
		}
	case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				g_active=TRUE;						// Program Is Active
			}
			else
			{
				g_active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

	case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
			case SC_SCREENSAVE:
			case SC_MONITORPOWER:
				return 0;
			}
			break;
		}

	case WM_CLOSE:								// Did We Receive A Close Message?
		{
			g_bGLThread = false;//�����߳�
			ITimerListener* timerListener = pcOpenGLWindow->GetTimerListener();
			SceneMgr* sceneMgr = timerListener->GetSceneMgr();
			sceneMgr->endModel();//����
			UnInitialize();
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

	case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			g_keys[wParam] = TRUE;					// If So, Mark It As TRUE
			switch(wParam)
			{
			case VK_SPACE:
				{
					if(g_bPboSupported)
					{
						bool bbreak = false;
						if (g_pboMode&0x4)
						{
							g_pboMode = 1;
							bbreak = true;
						}
						if (!bbreak)
						{
							g_pboMode <<= 1;
						}
						char bufLog[256] = {0};
						sprintf(bufLog,"g_pboMode is %d",g_pboMode);
						writeLog(bufLog);
					}
					break;
				}
			case 'S':
				{
					if (pcOpenGLWindow)
					{
						if (pcOpenGLWindow->getTimeRunning())
						{
							pcOpenGLWindow->setTimerRunning(false);
							CTimerEx * timer = pcOpenGLWindow->GetTimerEx();
							if (timer)
							{
								timer->stopTimer();//1
								PausePlayer();//2
								//¼��ֹͣ3
							}	
						}
						else
						{
							pcOpenGLWindow->setTimerRunning(true);
							CTimerEx * timer = pcOpenGLWindow->GetTimerEx();
							if (timer)
							{
								//¼����ʼ1
								StartPlayer();//2
								timer->startTimer();//3								
							}	
						}
					}	
					break;
				}
			}
			return 0;								// Jump Back
		}

	case WM_KEYUP:								// Has A Key Been Released?
		{
			g_keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

	case WM_LBUTTONDOWN://�����϶����ڣ�(���ͷǿͻ����������)
		{
			//SendMessage(g_hWnd, WM_NCLBUTTONDOWN, HTCAPTION, lParam);
			break;
		}


		//case WM_SIZE:								// Resize The OpenGL Window
		//	{
		//		ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
		//		return 0;								// Jump Back
		//	}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

//////////////////////////////////////////////////////////////////////
COpenGLWindow::COpenGLWindow(ITimerListener* pTimerListener):
																	m_fullscreen(true),
																	//g_hRC(NULL),
																	m_pcTimeEx(NULL),
																	//m_pFrameData(NULL),
																	m_Language(NULL),
																	m_bTimerRunning(false),
																	m_bTimerStart(false)
{
	m_pcTimeEx = new CTimerEx(60);
	m_pcTimeEx->setListener(pTimerListener);
}

COpenGLWindow::~COpenGLWindow(void)
{
	SAFE_DELETE(m_pcTimeEx);
}

void COpenGLWindow::setTimerRunning(bool bTimerRunning)
{
	m_bTimerRunning = bTimerRunning;
}

bool COpenGLWindow::getTimeRunning()
{
	return m_bTimerRunning;
}

BOOL COpenGLWindow::CreateGLThread()
{
	DWORD threadID;
	HANDLE hThread = CreateThread(NULL,0,GLThreadProc,(LPVOID)this,0,&threadID);
	if (hThread == NULL)
	{
		return FALSE;
	}
	CloseHandle(hThread);
	return TRUE;
}

CTimerEx* COpenGLWindow::GetTimerEx()
{
	return m_pcTimeEx;
}

void COpenGLWindow::SetTimerListener(ITimerListener* pTimerListerne)
{
	m_pcTimeEx->setListener(pTimerListerne);
}

ITimerListener* COpenGLWindow::GetTimerListener()
{
	return m_pcTimeEx->getListener();
}

void COpenGLWindow::MessageWhile()
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop
	//if (!CreateGLThread())
	//{
		//MessageBox(NULL,"CreateGLThread error","OpenGL",MB_OK);
		//return;
	//}
	
	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			
			if (g_keys[VK_ESCAPE])
			{
				done=TRUE;
				g_bGLThread = false;
				if (m_pcTimeEx)
				{
					m_pcTimeEx->stopTimer();
				}
				ITimerListener* timerListener = GetTimerListener();
				if (timerListener)
				{
					SceneMgr* sceneMgr = timerListener->GetSceneMgr();
					if (sceneMgr)
					{
						sceneMgr->endModel();//����
					}
				}	
			}
			if (g_bGLThread)
			{
				if (m_pcTimeEx)
				{
					if (!m_bTimerStart)
					{
						m_pcTimeEx->startTimer();
						m_bTimerStart = true;
						m_bTimerRunning = true;
					}
					if (m_bTimerRunning)
					{
						//writeLog("COpenGLWindow::MessageWhile m_bTimerRunning");
						m_pcTimeEx->processTimer();
					}
				}	
			}
		}
	}
	writeLog("out while");
}


GLvoid COpenGLWindow::ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The ��ǰ�ӿ�

	glMatrixMode(GL_PROJECTION);						
	//Select The ͶӰ����Ϊ͸��ͼ������Ļ����ζ��ԽԶ�Ķ���������ԽС (45��)
	glLoadIdentity();									
	// Reset The Projection Matrix
	//glOrthof(-backingHeight/2.0, backingHeight/2.0, -backingWidth/2.0, backingHeight/2.0, -1.0f, 1.0f);ios
	// Calculate The Aspect Ratio Of The Window
	//gluPerspective(90.0f,(GLfloat)width/(GLfloat)height,1.0f,1.0f);//�˴�͸�Ӱ��ջ��ڴ��ڿ��Ⱥ͸߶ȵĵ�һ���������ӽ�������
	//��һ���������۾������ĽǶȡ�
	//1.0f,100.0f�������ڳ��������ܻ�����ȵĽ�ƽ���Զƽ��
	//�ü����ڵĸ߶� h �� 2 * tan��fovy/2�� * zNear.
	//�����ɿ��߱Ⱦ�����
	gluOrtho2D(0.0,width,-height,0.0);
	glMatrixMode(GL_MODELVIEW);//Select The ģ�͹۲�������д�������ǵ�����ѶϢ
	glLoadIdentity();									// Reset The Modelview Matrix
}

BOOL COpenGLWindow::InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	//glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping
	glShadeModel(GL_SMOOTH);							//  ������Ӱƽ�� 
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// Black Background
	glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);    // ����Դ����alphaͨ��ֵ�İ�͸����Ϻ���
	glEnable(GL_BLEND);//������ɫ���
	//glClearDepth(1.0f);									// ������Ȼ���
	//glEnable(GL_DEPTH_TEST);							// ������Ȳ���
	//glDepthFunc(GL_LEQUAL);								// ������Ȳ��Ե�����
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);	// ����ϵͳ��͸�ӽ�������
	return TRUE;										// Initialization Went OK
}

GLvoid COpenGLWindow::KillGLWindow(GLvoid)
{
	if (m_fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (g_hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(g_hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		g_hRC=NULL;										// Set RC To NULL
	}

	if (g_hDC && !ReleaseDC(g_hWnd,g_hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		g_hDC=NULL;										// Set DC To NULL
	}

	if (g_hWnd && !DestroyWindow(g_hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		g_hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",g_hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		g_hInstance=NULL;									// Set hInstance To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
BOOL COpenGLWindow::CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	writeLog("COpenGLWindow::CreateGLWindow enter");
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	m_fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	g_hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= g_hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}

	if (m_fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					//ÿ������ѡ��ɫ�����
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				m_fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (m_fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;//|WS_EX_TOPMOST;	// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW;//|WS_EX_TOPMOST;//�ö�
		// | WS_EX_WINDOWEDGE;			// Window Extended Style
		//���ô�����ʽ��popup�ޱ߿��ޱ��⣬�޲˵�
		dwStyle=WS_POPUPWINDOW;//WS_OVERLAPPEDWINDOW;////WS_POPUP;//WS_OVERLAPPEDWINDOW;
		// Windows Style  WS_SIZEBOX;//
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(g_hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
		"OpenGL",							// Class Name
		title,								// Window Title
		dwStyle |							// Defined Window Style
		WS_CLIPSIBLINGS |					// Required Window Style
		WS_CLIPCHILDREN,					// Required Window Style
		0, 0,								// Window Position
		WindowRect.right-WindowRect.left,	// Calculate Window Width
		WindowRect.bottom-WindowRect.top,	// Calculate Window Height
		NULL,								// No Parent Window
		NULL,								// No Menu
		g_hInstance,							// Instance
		this)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	//��͸��
	//SetWindowLong(g_hWnd, GWL_EXSTYLE,GetWindowLong(g_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
	//SetLayeredWindowAttributes(g_hWnd, 0,255*60/100, LWA_ALPHA);

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};

	if (!(g_hDC=GetDC(g_hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(g_hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(g_hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(g_hRC=wglCreateContext(g_hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(g_hDC,g_hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

//////////////////////////////////////////////////////////////////////////
	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	ReSizeGLScene(1280, 720);
	//////////////////////////////////////////////////////////////////////////

	ShowWindow(g_hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(g_hWnd);						// Slightly Higher Priority
	SetFocus(g_hWnd);									// Sets Keyboard Focus To The Window

	return TRUE;									// Success
}

LRESULT COpenGLWindow::OnPlayerMessage(WPARAM wParam, LPARAM lParam) 
{ 
	// TODO: �����û��Զ�����Ϣ 
	BOOL bIsMultStream = FALSE;
	int  nLanguageLen = 0;
	switch(wParam)
	{
	case STATUS_OPENED://�õ��������ųɹ���Ϣ�󣬽������²���

		IsMultStream(bIsMultStream);//���ж��Ƿ��ж�����
		Get_LanguageLen(nLanguageLen);//ȡ�������ַ�������
		if(m_Language != NULL)
		{
			delete m_Language;
		}
		m_Language = new WCHAR[nLanguageLen+1];//Ϊ�����ַ�������ռ�
		Get_LanguageString(m_Language);//ȡ�������ַ���,���������л�
		
		GetMideaType(m_bVideo, m_bAudio);//�õ�ý���Ƿ�����Ƶ/��Ƶ
		if (m_bVideo)
		{
			//GetFrameSize(m_nWidth,m_nHeight);//�õ���Ƶ��С��������ռ�
			/*if (m_pFrameData == NULL)
			{
				m_pFrameData = (BYTE *) malloc(m_nWidth*m_nHeight*3);
			}*/
		}
		if (m_bAudio)
		{
			//if (NULL == g_pAudioData)
			//{
			//	g_pAudioData = (BYTE *)malloc(FILEBUFFER);//������Ƶ����
			//}
			//GetAudioMideaType(m_mtAudioType);//�õ���Ƶ��ʽ
		}
		
		//g_bOpenFile = TRUE;		
		
		//	SetProcessWorkingSetSize(::GetCurrentProcess(),-1,-1);  
		
		//OnButtonPlay();
		//m_SliderTimer = SetTimer(SLIDER_TIMER, 100, NULL);
		//m_GetFrameTimer = SetTimer(GETFRAME_TIMER, 67, NULL);
		//SetDlgItemText(IDC_STATUS,"OPENED.");
		break;
	case STATUS_OPENING:
		//SetDlgItemText(IDC_STATUS,"OPENING...");
		break;
	case STATUS_BUFFERINGDATA:
		//SetDlgItemText(IDC_STATUS,"BUFFERINGDATA...");
	    break;
	case STATUS_PLAYING:
		//SetDlgItemText(IDC_STATUS,"PLAYING...");
		break;
	case 5:
		break;
	case 6:
	    break;
	case 7:
	    break;
	default:
	    break;
	}
	return 0; 
}
