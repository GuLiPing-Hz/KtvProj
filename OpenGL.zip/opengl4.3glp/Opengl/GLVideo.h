#pragma once

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include "glext.h"
#include "glInfo.h"

class CGLVideo
{
public:
	CGLVideo(int textureX = 0,int textureY = 0);
	~CGLVideo(void);

	int getTextureSwitch();
	void bindTexture();
	bool GetTextureIDInit();
	//BOOL Init(char *fileName);//
	BOOL LoadGLTexturesVideo();
	BOOL UpdateGLTextures();//��������
	void DrawVideo(float ScreenX,float ScreenY);
private:
	//��Ƶ����תΪ������ʽ������
	void ExchangeRedBlueC(BYTE* buffer);
	void ExchangeRedBlue(void* buffer)	;
	BOOL Video2TextureMem(BYTE* pVideo,BYTE* pTexture,int format=3);
	void makeTextureXY(int x,int y);

private:
	BYTE*	m_pvideoData;//��Ƶ����
	BYTE * m_pvideoTextureData;//��������
	GLuint	m_texture[2];			//  Texture id
	GLuint m_pboIds[2];			//PBO id
	
	float		m_uMax;
	float		m_uMin;
	float		m_vMax;
	float		m_vMin;
	int		m_switchTextureID;

public:
	INT		m_videoWidth;//��Ƶ��
	INT		m_videoHeight;//��Ƶ��
	int		m_DATA_SIZE;
	int		m_textureX;
	int		m_textureY;
	bool		m_bInit;
};
