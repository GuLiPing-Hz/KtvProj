#include "StdAfx.h"
#include "GLFlorid.h"

CGLFlorid::CGLFlorid(int textureX ,int textureY):
																	m_textureX(textureX),
																	m_textureY(textureY)
{
	m_texture[0] = 0;
}

CGLFlorid::~CGLFlorid(void)
{
}

void CGLFlorid::bindTexture()
{
	glBindTexture(GL_TEXTURE_2D,m_texture[0]);
}

GLuint CGLFlorid::GetTextureID()
{
	return m_texture[0];
}

AUX_RGBImageRec * CGLFlorid::LoadBMP(const char *fileName)				//����ͼƬ
{
	FILE *File=NULL;									// File Handle

	if (!fileName)										// Make Sure A Filename Was Given
	{
		return NULL;									// If Not Return NULL
	}

	File=fopen(fileName,"r");							// Check To See If The File Exists

	if (File)											// Does The File Exist?
	{
		fclose(File);									// Close The Handle
		return auxDIBImageLoad(fileName);				// Load The Bitmap And Return A Pointer
	}

	return NULL;										// If Load Failed Return NULL
}


BOOL CGLFlorid::LoadGLTextures(const char *fileName)
{
	BOOL Status=FALSE;									// Status Indicator
	if (!fileName)										// Make Sure A Filename Was Given
	{
		return Status;									// If Not Return NULL
	}
	AUX_RGBImageRec *TextureImage[1];					// Create Storage Space For The Texture

	memset(TextureImage,0,sizeof(void *)*1);           	// Set The Pointer To NULL

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if (TextureImage[0]=LoadBMP(fileName))
	{
		Status=TRUE;									// Set The Status To TRUE

		glGenTextures(1, &m_texture[0]);					// ����1������id

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, m_texture[0]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);
		// ��������
		//glTexSubImage2D (GL_TEXTURE_2D, 0, 0, 0, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, data);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}

	if (TextureImage[0])									// If Texture Exists
	{
		if (TextureImage[0]->data)							// If Texture Image Exists
		{
			free(TextureImage[0]->data);					// Free The Texture Image Memory
		}

		free(TextureImage[0]);								// Free The Image Structure
	}

	return Status;										// Return The Status
}

void CGLFlorid::DrawFlorid()
{
	return;
	//static float uv[] = {0.0f,0.0f,	1.0f,0.0f,	1.0f,1.0f,	1.0f,0.0f,	1.0f,1.0f	,0.0f,1.0f};
	static float vs[] = {0.0f,-500.0f,500.0f,-500.0f,	0.0f,-0.0f,		500.0f,-500.0f,	0.0f,-0.0f, 500.0f, -0.0f};
	static float cs[] = {0.0f,1.0f,0.0f,0.5f,    1.0f,0.0f,0.0f,0.5f,    0.0f,0.0f,1.0f,0.5f,    1.0f,0.0f,0.0f,0.5f,    0.0f,0.0f,1.0f,0.5f,    1.0f,0.0f,0.0f,0.5f};
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(2, GL_FLOAT, 0, vs);

	glEnableClientState(GL_COLOR_ARRAY);
	glColorPointer(4, GL_FLOAT, 0, cs);

	//glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	//glTexCoordPointer(2, GL_FLOAT, 0, uv);

	glDrawArrays(GL_TRIANGLES, 0, 6 );
	glColor4f(1.0f,1.0f,1.0f,1.0f);
	return;
	glColor4f(1.0f,0.0f,0.0f,1.0f);
	glVertex3f(-0.0f,-100.0f, 0.0f);					// Bottom Left ��

	glColor4f(0.0f,1.0f,0.0f,1.0f);
	glVertex3f( 100.0f,-100.0f, 0.0f);					// Bottom Right ��

	//glColor4f(0.0f,0.0f,1.0f,1.0f);
	glColor4f(0.0f,0.0f,1.0f,1.0f);
	glVertex3f( 100.0f, 0.0f, 0.0f);					// Top Right ��

	//glColor4f(1.0f,0.0f,0.0f,1.0f);
	glColor4f(1.0f,0.0f,0.0f,1.0f);
	glVertex3f(0.0f, 0.0f, 0.0f);					// Top Left ��
	glColor4f(1.0f,1.0f,1.0f,1.0f);
}

void CGLFlorid::makeTextureXY(int x,int y)
{
	int tx = 1;
	int ty = 1;
	while (tx<x)
	{
		tx = tx*2;
	}
	m_textureX = tx;
	while(ty<y)
	{
		ty = ty*2;
	}
	m_textureY = ty;
}
