#pragma once

#include <string>
#include <string.h>
#include <stdio.h>

#include "GLVideo.h"
#include "GLFlorid.h"
#include "TimerEx.h"
#include "DrawListener.h"

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

class COpenGLWindow
{
public:
	COpenGLWindow(ITimerListener* pTimerListener=NULL);
	~COpenGLWindow(void);
	
	void setTimerRunning(bool bTimerRunning);
	bool getTimeRunning();

	BOOL CreateGLThread();//����GL�߳�
	CTimerEx* GetTimerEx();//��ȡ��ʱ��
	void SetTimerListener(ITimerListener* pTimerListerne);//���ü�����
	ITimerListener* GetTimerListener();//��ȡ������
	LRESULT OnPlayerMessage(WPARAM wParam, LPARAM lParam);//������������Ϣ
	BOOL CreateGLWindow(char* title, int width=1280, int height=720, int bits=32, bool fullscreenflag=false);//���⣬���ߣ���ɫ��ʾλ
	void MessageWhile();//��Ϣѭ��
	GLvoid KillGLWindow(GLvoid);//����
	BOOL InitGL(GLvoid);										// All Setup For OpenGL Goes Here
	GLvoid ReSizeGLScene(GLsizei width, GLsizei height);		// Resize And Initialize The GL Window
private:
	
	
private:
	bool					m_fullscreen;	// Fullscreen Flag Set To Fullscreen Mode By Default
	WCHAR *		m_Language;
	//BYTE *			m_pFrameData;
	BOOL				m_bVideo;//�Ƿ�����Ƶ
	//int					m_nWidth;
	//int					m_nHeight;
	BOOL				m_bAudio;//�Ƿ�����Ƶ
	//AM_MEDIA_TYPE	m_mtAudioType;
	bool					m_bTimerStart;
	bool					m_bTimerRunning;

	CTimerEx	*		m_pcTimeEx;
};
