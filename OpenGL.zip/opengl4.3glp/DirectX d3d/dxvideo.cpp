#include "stdafx.h"
 #include "dxvideo.h"
 
#ifdef _DEBUG
 #undef THIS_FILE
 static char THIS_FILE[]=__FILE__;
 #define new DEBUG_NEW
 #endif
 
//////////////////////////////////////////////////////////////////////
 // Construction/Destruction
 //////////////////////////////////////////////////////////////////////
 #define SAFE_DELETE(p) { if(p) { delete (p); (p)=NULL; } }
 #define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }
 #define SAFE_CLOSEHANDLE(h) { if(h) { CloseHandle(h); (h)=NULL; } }
 
struct CUSTOMVERTEX
 {     
 float x,y,z,rhw; //�������� 
    DWORD color;  //������ɫ 
 float tu,tv;  //�������� 
};
 #define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)
 
CD3DDraw::CD3DDraw()
 {
  m_pd3d9 = NULL;
  m_pd3dDevice = NULL;
  m_pd3dTextureRGB32 = NULL;
  m_pd3dTextureY = NULL;
  m_pd3dTextureU = NULL;
  m_pd3dTextureV = NULL;
  m_pd3dVertexBuffer = NULL;
 
 m_pPixelShader = NULL;
  g_pConstantTable_PS = NULL;
   
  m_nWidth = 0;
  m_nHeight = 0;
  m_pd3dxFont = NULL;
  m_pd3dxSprite = NULL;
 
 m_pYBuf = NULL;
  m_pUBuf = NULL;
  m_pVBuf = NULL;
  m_pRGB32Buf = NULL;
 }
 
CD3DDraw::~CD3DDraw()
 {
  ReleaseD3D();
  if (m_pYBuf)
  {
   delete[] m_pYBuf;
   m_pYBuf = NULL;
  }
  if (m_pUBuf)
  {
   delete[] m_pUBuf;
   m_pUBuf = NULL;
  }
  if (m_pVBuf)
  {
   delete[] m_pVBuf;
   m_pVBuf = NULL;
  }
  if (m_pRGB32Buf)
  {
   delete[] m_pRGB32Buf;
   m_pRGB32Buf = NULL;
  }
 }
 
void CD3DDraw::ReleaseD3D()
 {
  SAFE_RELEASE(m_pd3dxFont);
  SAFE_RELEASE(m_pd3dxSprite);
  SAFE_RELEASE(m_pd3dVertexBuffer);
  SAFE_RELEASE(m_pd3dTextureRGB32);
  SAFE_RELEASE(m_pd3dTextureY);
  SAFE_RELEASE(m_pd3dTextureU);
  SAFE_RELEASE(m_pd3dTextureV);
  SAFE_RELEASE(m_pPixelShader);
  SAFE_RELEASE(m_pd3dDevice);
  SAFE_RELEASE(m_pd3d9);
 }
 
BOOL CD3DDraw::InitD3D(HWND hwnd, UINT nWidth, UINT nHeight, int nPixelFormat)
 {
  int nConvertType = CONVERT_PIXEL_FORMAT_NONE;
  if (nPixelFormat == DISP_VIDEO_I420 || nPixelFormat == DISP_VIDEO_YV12)
   nConvertType = CONVERT_PIXEL_FORMAT_GPU;
 
 m_pd3d9 = Direct3DCreate9(D3D_SDK_VERSION);
  if (m_pd3d9 == NULL)
   return FALSE;
 
 D3DCAPS9 caps;
  m_pd3d9->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &caps);
 
 if(nConvertType == CONVERT_PIXEL_FORMAT_GPU && caps.PixelShaderVersion < D3DPS_VERSION(1,1))
  {
   nConvertType = CONVERT_PIXEL_FORMAT_CPU;
  }
 
 int vp = 0;
  if(caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT)
  {
   // yes, save in 'vp' the fact that hardware vertex processing is supported.
   vp = D3DCREATE_HARDWARE_VERTEXPROCESSING;
  }
  else
  {
   // no, save in 'vp' the fact that we must use software vertex processing.
   vp = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
  }
  
  HRESULT hr;
 
 /*
  D3DDISPLAYMODE d3dDisplayMode;
  hr = m_pd3d9->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3dDisplayMode);
  if (FAILED(hr))
   return FALSE;
  */
 
 D3DPRESENT_PARAMETERS d3dpp;
  memset(&d3dpp, 0, sizeof(D3DPRESENT_PARAMETERS));
  d3dpp.BackBufferWidth = nWidth;
  d3dpp.BackBufferHeight = nHeight;
  d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
  d3dpp.BackBufferCount = 1;
  d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
  d3dpp.MultiSampleQuality = 0;
  d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
  d3dpp.hDeviceWindow = hwnd;
  d3dpp.Windowed = TRUE;
  d3dpp.EnableAutoDepthStencil = TRUE;
  d3dpp.AutoDepthStencilFormat = D3DFMT_D16; // depth format
 
 hr = m_pd3d9->CreateDevice(
   D3DADAPTER_DEFAULT, // primary adapter
   D3DDEVTYPE_HAL, // device type
   hwnd, // window associated with device
   vp, // vertex processing type
   &d3dpp, // present parameters
   &m_pd3dDevice); // returned created device
  if(FAILED(hr))
   return FALSE;
 
 //because of sprite only draw rgb32 texture, not support yuv texture
  nConvertType = CONVERT_PIXEL_FORMAT_CPU;
 
 do 
 {
   if (nConvertType == CONVERT_PIXEL_FORMAT_GPU)
   {
    LPD3DXBUFFER pCode;                  // buffer with the assembled shader code
    LPD3DXBUFFER pErrorMsgs;             // buffer with error messages
    CString strPixelShaderCode;
    strPixelShaderCode = 
    "sampler2D YTextue;"\\
     "sampler2D UTextue;"\\
     "sampler2D VTextue;"\\
     "float4 main( float2 texCoord : TEXCOORD0 ) : COLOR0"\\
     "{"\\
     "float3 yuvColor;"\\
     "float3 delYuv = float3(-16.0/255.0 , -128.0/255.0 , -128.0/255.0);"\\
     "yuvColor.x = tex2D( YTextue, texCoord ).x;"\\
     "yuvColor.y = tex2D( UTextue, texCoord ).x;"\\
     "yuvColor.z = tex2D( VTextue, texCoord ).x;"\\
     "yuvColor += delYuv;"\\
     "float3 matYUVRGB1 = float3(1.164,  2.018 ,   0.0   );"\\
     "float3 matYUVRGB2 = float3(1.164, -0.391 , -0.813  );"\\
     "float3 matYUVRGB3 = float3(1.164,    0.0 ,  1.596  );"\\
     "float4 rgbColor;"\\
     "rgbColor.x = dot(yuvColor,matYUVRGB1);"\\
     "rgbColor.y = dot(yuvColor,matYUVRGB2);"\\
     "rgbColor.z = dot(yuvColor,matYUVRGB3);"\\
     "rgbColor.w = 1.0f;"\\
     "return rgbColor;"\\
     "}";
    
    DWORD dwShaderFlags = D3DXSHADER_SKIPOPTIMIZATION|D3DXSHADER_DEBUG;
    hr = D3DXCompileShader( strPixelShaderCode, strPixelShaderCode.GetLength(), NULL, NULL, "main", "ps_2_0", dwShaderFlags, &pCode, &pErrorMsgs, &g_pConstantTable_PS);
    if (FAILED(hr))
    {
     nConvertType = CONVERT_PIXEL_FORMAT_CPU;
     break;
    }
    if (pCode)
    {
     hr = m_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &m_pPixelShader );
     if (FAILED(hr))
     {
      nConvertType = CONVERT_PIXEL_FORMAT_CPU;
      break;
     }
    }
   }
 
 } while(0);
 
 // ����Ѱַģʽ:D3DTADDRESS_WRAP, D3DTADDRESS_CLAMP, D3DTADDRESS_MIRROR, D3DTADDRESS_BORDER, D3DTADDRESS_MIRRORONCE
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_WRAP );
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_WRAP );
 
 if (nConvertType == CONVERT_PIXEL_FORMAT_GPU)
  {
   m_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU,  D3DTADDRESS_WRAP );
   m_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV,  D3DTADDRESS_WRAP );  
   m_pd3dDevice->SetSamplerState( 2, D3DSAMP_ADDRESSU,  D3DTADDRESS_WRAP );
   m_pd3dDevice->SetSamplerState( 2, D3DSAMP_ADDRESSV,  D3DTADDRESS_WRAP );
  }
  
  // �������ˣ�����ͼ��Ŵ���Сʱͼ���ƽ����ʾ
  // D3DTEXF_POINT->�ٽ���ȡ��, D3DTEXF_LINEAR->���Թ���
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
  m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_POINT );
 
 if (nConvertType == CONVERT_PIXEL_FORMAT_GPU)
  {
   m_pd3dDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
   m_pd3dDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
   m_pd3dDevice->SetSamplerState( 1, D3DSAMP_MIPFILTER, D3DTEXF_POINT );
   m_pd3dDevice->SetSamplerState( 2, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
   m_pd3dDevice->SetSamplerState( 2, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
   m_pd3dDevice->SetSamplerState( 2, D3DSAMP_MIPFILTER, D3DTEXF_POINT );
  }
  
  // ������������ģʽ�� D3DCULL_NONE->�����涼����, D3DCULL_CW->����˳ʱ��������, D3DCULL_CCW->������ʱ��������
  m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
  
  // Turn off the zbuffer
  m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
  m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, FALSE );
  
  // �Ƿ�������
  m_pd3dDevice->SetRenderState(D3DRS_LIGHTING,FALSE);
  
  // �Ƿ�������
  m_pd3dDevice->SetRenderState(D3DRS_DITHERENABLE, FALSE);
  
  // �Ƿ�����ģ�建��
  m_pd3dDevice->SetRenderState(D3DRS_STENCILENABLE, FALSE);
  
  // alpha���
  m_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
  m_pd3dDevice->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
  
  // ��ɫ���:D3DTOP_MODULATE->���, D3DTOP_ADD->���, D3DTOP_SELECTARG1->ʹ�õ�ǰ��ɫ
  //m_pDirect3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE ); //D3DTOP_ADD, D3DTOP_SELECTARG1
  // ��ɫ��Դ:D3DTA_TEXTURE->����,D3DTA_CURRENT->ǰһ��texture stage,D3DTA_DIFFUSE->������
  //m_pDirect3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
  //m_pDirect3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
  
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
  m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
 
 if (nConvertType == CONVERT_PIXEL_FORMAT_GPU)
  {
   m_pd3dDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 0 );
   m_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
   m_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT);
   m_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLOROP, D3DTOP_ADD );
   m_pd3dDevice->SetTextureStageState( 2, D3DTSS_TEXCOORDINDEX, 0 );
   m_pd3dDevice->SetTextureStageState( 2, D3DTSS_COLORARG1, D3DTA_TEXTURE );
   m_pd3dDevice->SetTextureStageState( 2, D3DTSS_COLORARG2, D3DTA_CURRENT);
   m_pd3dDevice->SetTextureStageState( 2, D3DTSS_COLOROP, D3DTOP_ADD );
  }
 
 if (nConvertType != CONVERT_PIXEL_FORMAT_GPU)
  {
   hr = m_pd3dDevice->CreateTexture( nWidth, nHeight, 1, 0, D3DFMT_X8R8G8B8, D3DPOOL_MANAGED, &m_pd3dTextureRGB32, NULL);
  }
  else
  {
   if (nPixelFormat  == DISP_VIDEO_I420 || nPixelFormat == DISP_VIDEO_YV12)
   {
    hr = m_pd3dDevice->CreateTexture( nWidth, nHeight, 1, 0, D3DFMT_L8, D3DPOOL_MANAGED, &m_pd3dTextureY, NULL);
    hr = m_pd3dDevice->CreateTexture( nWidth/2, nHeight/2, 1, 0, D3DFMT_L8, D3DPOOL_MANAGED, &m_pd3dTextureU, NULL);
    hr = m_pd3dDevice->CreateTexture( nWidth/2, nHeight/2, 1, 0, D3DFMT_L8, D3DPOOL_MANAGED, &m_pd3dTextureV, NULL);
   }
  }
 
 if( FAILED(hr))
  {
   return FALSE;
  }
 
 /*
  CUSTOMVERTEX* pVertices = NULL;
     RECT rect; 
  //������Ƶ����
  rect.top = 0;   
  rect.left = 0;
  rect.right = nWidth;
  rect.bottom = nHeight;
  
  CUSTOMVERTEX vertices[4] =
  {
   { (float)rect.left, (float)rect.top, 
  0.0f, 1.0f, D3DCOLOR_XRGB(255,255,255), 0.0f, 0.0f }, 
  { (float)rect.right, (float)rect.top, 
  0.0f, 1.0f, D3DCOLOR_XRGB(255,255,255), 1.0f, 0.0f }, 
  { (float)rect.left, (float)rect.bottom, 
  0.0f, 1.0f, D3DCOLOR_XRGB(255,255,255), 0.0f, 1.0f }, 
  { (float)rect.right, (float)rect.bottom, 
  0.0f, 1.0f, D3DCOLOR_XRGB(255,255,255), 1.0f, 1.0f }
  };
 
 m_pd3dDevice->CreateVertexBuffer(4*sizeof(vertices), 
  0, 
  D3DFVF_CUSTOMVERTEX, 
  D3DPOOL_DEFAULT, 
  &m_pd3dVertexBuffer, NULL ); 
 
  m_pd3dVertexBuffer->Lock(0, sizeof(vertices), (void**)&pVertices, 0); 
 memcpy(pVertices, vertices, sizeof(vertices)); 
 m_pd3dVertexBuffer->Unlock();  
  */
 
 D3DXCreateSprite(m_pd3dDevice, &m_pd3dxSprite);
 
 m_hWnd = hwnd;
  m_nWidth = nWidth;
  m_nHeight = nHeight;
  m_nPixelFormat = nPixelFormat;
  m_nConvertPixelFormatType = nConvertType;
 
 return TRUE;
 }
 
BOOL CD3DDraw::DrawImageBuffer(BYTE* pBuffer, INT nWidth, INT nHeight, int nRotation, CString szLogo)
 {
  if (m_nWidth != nWidth || m_nHeight != nHeight)
  {
   ReleaseD3D();
   InitD3D(m_hWnd, nWidth, nHeight, m_nPixelFormat);
   return FALSE;
  }
 
 RECT rct = {0};
  GetClientRect(m_hWnd, &rct);
  if (!m_pd3dxFont || rct.right != m_nShowWidth || rct.bottom != m_nShowHeight)
  {
   SAFE_RELEASE(m_pd3dxFont);
   if (!InitFont(nWidth, nHeight))
    return FALSE;
  }
 
 LPBYTE lpY = NULL;
  LPBYTE lpU = NULL;
  LPBYTE lpV = NULL;
 
 if (m_nConvertPixelFormatType == CONVERT_PIXEL_FORMAT_GPU)
  {
   if (m_nPixelFormat == DISP_VIDEO_I420)
   {
    lpY = pBuffer;
    lpU = pBuffer + nWidth * nHeight;
    lpV = pBuffer + nWidth * nHeight * 5 / 4;
   }
   else if (m_nPixelFormat == DISP_VIDEO_YV12)
   {
    lpY = pBuffer;
    lpV = pBuffer + nWidth * nHeight;
    lpU = pBuffer + nWidth * nHeight * 5 / 4;
   }
   else
    return FALSE;
 
  if (nRotation == 1)
   {
    if (!m_pYBuf)
     m_pYBuf = new BYTE[nWidth * nHeight];
    if (!m_pUBuf)
     m_pUBuf = new BYTE[nWidth * nHeight/4];
    if (!m_pVBuf)
     m_pVBuf = new BYTE[nWidth * nHeight/4];
    
    YUV420p_RotateXY(nWidth, nHeight, lpY, lpU, lpV, m_pYBuf, m_pUBuf, m_pVBuf);
   }
  }
  else
  {
   if (nRotation == 1)
   {
    if (!m_pRGB32Buf)
     m_pRGB32Buf = new BYTE[nWidth * nHeight * 4];
    RGB32_RotateXY(nWidth, nHeight, pBuffer, m_pRGB32Buf);
   }
  }
 
 HRESULT hr;
  
  if (!m_pd3dTextureRGB32 && (!m_pd3dTextureY || !m_pd3dTextureU || !m_pd3dTextureV))
   return FALSE;
 
 if (m_nConvertPixelFormatType != CONVERT_PIXEL_FORMAT_GPU)
  {
   D3DLOCKED_RECT d3dlr;
   hr = m_pd3dTextureRGB32->LockRect( 0, &d3dlr, 0, 0 );
   if( FAILED(hr))
   {
    return FALSE;
   }
   if (nRotation == 1)
    memcpy(d3dlr.pBits, m_pRGB32Buf, nWidth * nHeight * 4);
   else
    memcpy(d3dlr.pBits, pBuffer, nWidth * nHeight * 4);
   hr = m_pd3dTextureRGB32->UnlockRect(0);
   if( FAILED(hr))
   {
    return FALSE;
   }
  }
  else
  {
   D3DLOCKED_RECT d3dlrY, d3dlrU, d3dlrV;
   //Y plain
   hr = m_pd3dTextureY->LockRect( 0, &d3dlrY, 0, 0 );
   if( FAILED(hr))
   {
    return FALSE;
   }
   if (nRotation == 1)
    memcpy(d3dlrY.pBits, m_pYBuf, nWidth*nHeight);
   else
    memcpy(d3dlrY.pBits, lpY, nWidth*nHeight);
   hr = m_pd3dTextureY->UnlockRect(0);
   if( FAILED(hr))
   {
    return FALSE;
   }
   //U plain
   hr = m_pd3dTextureU->LockRect( 0, &d3dlrU, 0, 0 );
   if( FAILED(hr))
   {
    return FALSE;
   }
   if (nRotation == 1)
    memcpy(d3dlrU.pBits, m_pUBuf, nWidth*nHeight/4);
   else
    memcpy(d3dlrU.pBits, lpU, nWidth*nHeight/4);
   hr = m_pd3dTextureU->UnlockRect(0);
   if( FAILED(hr))
   {
    return FALSE;
   }
   //V Plain
   hr = m_pd3dTextureV->LockRect( 0, &d3dlrV, 0, 0 );
   if( FAILED(hr))
   {
    return FALSE;
   }
   if (nRotation == 1)
    memcpy(d3dlrV.pBits, m_pVBuf, nWidth*nHeight/4);
   else
    memcpy(d3dlrV.pBits, lpV, nWidth*nHeight/4);
   hr = m_pd3dTextureV->UnlockRect(0);
   if( FAILED(hr))
   {
    return FALSE;
   }
  }
 
 //Clear
  hr = m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0 );
  if( FAILED(hr))
  {
   return FALSE;
  }
  
  hr = m_pd3dDevice->BeginScene();
  if( FAILED(hr))
  {
   return FALSE;
  }
 
 //��ʾ��Ƶ
 // m_pd3dDevice->SetStreamSource( 0, m_pd3dVertexBuffer, 0, sizeof(CUSTOMVERTEX) );
 // hr = m_pd3dDevice->SetVertexShader( NULL );
 // m_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );
  if (m_nConvertPixelFormatType == CONVERT_PIXEL_FORMAT_GPU)
  {
   hr = m_pd3dDevice->SetPixelShader(m_pPixelShader);
  }
 
//  if (m_nConvertPixelFormatType != CONVERT_PIXEL_FORMAT_GPU)
 //  {
 //   hr = m_pd3dDevice->SetTexture( 0, m_pd3dTextureRGB32 );
 //  }
 //  else
 //  {
 //   hr = m_pd3dDevice->SetTexture( 0, m_pd3dTextureY );
 //   hr = m_pd3dDevice->SetTexture( 1, m_pd3dTextureV );
 //   hr = m_pd3dDevice->SetTexture( 2, m_pd3dTextureU );
 //   hr = m_pd3dDevice->SetPixelShader( m_pPixelShader );
 //  }
 // 
//  m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );
 
// m_pd3dDevice->SetTexture( 0, NULL );
 // if (m_nConvertPixelFormatType == CONVERT_PIXEL_FORMAT_GPU)
 // {
 //  m_pd3dDevice->SetTexture( 1, NULL );
 //  m_pd3dDevice->SetTexture( 2, NULL );  
 // }
  
  if (SUCCEEDED(m_pd3dxSprite->Begin(D3DXSPRITE_ALPHABLEND)))
  {
   if (m_nConvertPixelFormatType != CONVERT_PIXEL_FORMAT_GPU)
   {
    m_pd3dxSprite->Draw(m_pd3dTextureRGB32, NULL, NULL, NULL, 0xffffffff);
   }
   else
   {
    m_pd3dxSprite->Draw(m_pd3dTextureY, NULL, NULL, NULL, 0xffffffff);
    m_pd3dxSprite->Draw(m_pd3dTextureV, NULL, NULL, NULL, 0xffffffff);
    m_pd3dxSprite->Draw(m_pd3dTextureU, NULL, NULL, NULL, 0xffffffff);
   }
 
  szLogo.TrimLeft();
   szLogo.TrimRight();
   int nCount = szLogo.GetLength();
  // float fTotalFontWidth = 0.0f;
   int nShowCount = nCount;
   /*
   for (int i=0; i<nCount; i++)
   {
    TCHAR c = szLogo.GetAt(i);
    if (c&0x80)
    {
     fTotalFontWidth += m_lFontWidth*2;
     i++;
    }
    else
    {
     if (c>='A' && c<='Z')
      fTotalFontWidth += (float)m_lFontWidth*7/6;
     else
      fTotalFontWidth += m_lFontWidth;
    }
 
   if ((int)fTotalFontWidth > m_nShowWidth)
    {
     if (szLogo.GetAt(i-1)&0x80)
      i--;
     nShowCount = i;
     break;
    }
   }
 
  if (nShowCount == 0)
   {
    nShowCount = nCount;
   }
   */
   RECT rct111 = {0};
   rct111.bottom = m_nHeight;
   rct111.right = m_nWidth;
   DWORD format = DT_SINGLELINE | DT_LEFT | DT_BOTTOM | DT_NOCLIP;
   m_pd3dxFont->DrawText(m_pd3dxSprite, szLogo, nShowCount, &rct111, format, D3DCOLOR_XRGB(0,0,255));
 
  m_pd3dxSprite->End();
  }
 
 m_pd3dDevice->EndScene();
  // Present the backbuffer contents to the display
  m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
 
 return TRUE;
 }
 
INT CD3DDraw::GetPixelFormatConvertType()
 {
  return m_nConvertPixelFormatType;
 }
 
BOOL CD3DDraw::YUV420p_RotateXY(int nWidth, int nHeight, BYTE *lpInY, BYTE *lpInU, BYTE *lpInV, BYTE *lpOutY, BYTE *lpOutU, BYTE *lpOutV)
 {
  int j;
  BYTE* destY = lpOutY;
  for (j = nHeight-1; j >= 0; j--)
  {
   BYTE* from = lpInY+j*nWidth+nWidth-1;
   BYTE* to = from-nWidth;
   while(from > to)
   {
    *destY++ = *from--;
   }
  }
  BYTE* destU = lpOutU;
  for (j = (nHeight)/2-1; j >= 0; j--)
  {
   BYTE* from = lpInU+j*nWidth/2+nWidth/2-1;
   BYTE* to = from-nWidth/2;
   while(from > to)
   {
    *destU++ = *from--;
   }
  }
  BYTE* destV = lpOutV;
  for (j = (nHeight)/2-1; j >= 0; j--)
  {
   BYTE* from = lpInV+j*nWidth/2+nWidth/2-1;
   BYTE* to = from-nWidth/2;
   while(from > to)
   {
    *destV++ = *from--;
   }
  }
  
  return TRUE;
 }
 
BOOL CD3DDraw::RGB32_RotateXY(int nWidth, int nHeight, BYTE* lpInBuf, BYTE* lpOutBuf)
 {
  int i,j;
  BYTE* dest = lpOutBuf;
 
 for (i=nHeight-1; i>=0; i--)
  {
   for (j=nWidth-1; j>=0; j--)
   {
    *dest++ = *(lpInBuf+(i*nWidth+j)*4);
    *dest++ = *(lpInBuf+(i*nWidth+j)*4 + 1);
    *dest++ = *(lpInBuf+(i*nWidth+j)*4 + 2);
    *dest++ = *(lpInBuf+(i*nWidth+j)*4 + 3);
   }
  }
  
  return TRUE;
 }
 
BOOL CD3DDraw::InitFont(INT nWidth, INT nHeight)
 {
 ... 
  return TRUE;
 }
