#pragma once
 
#include "d3dx9.h"
 #pragma comment(lib, "d3d9.lib")
 #pragma comment(lib, "d3dx9.lib")
 
#include "../../../ufc/Include/UniCommon.h"
 
#define CONVERT_PIXEL_FORMAT_NONE 0
 #define CONVERT_PIXEL_FORMAT_GPU 1
 #define CONVERT_PIXEL_FORMAT_CPU 2
 
class CD3DDraw  
{
 public:
  CD3DDraw();
  virtual ~CD3DDraw();
 
 BOOL InitD3D(HWND hwnd, UINT nWidth, UINT nHeight, int nPixelFormat);
  BOOL InitFont(INT nWidth, INT nHeight);
  void ReleaseD3D();
  BOOL DrawImageBuffer(BYTE* pBuffer, INT nWidth, INT nHeight, int nRotation, CString szLogo);
  INT GetPixelFormatConvertType();
 
 BOOL YUV420p_RotateXY(int nWidth, int nHeight, BYTE* lpInY, BYTE* lpInU, BYTE* lpInV, BYTE* lpOutY, BYTE* lpOutU, BYTE* lpOutV);
  BOOL RGB32_RotateXY(int nWidth, int nHeight, BYTE* lpInBuf, BYTE* lpOutBuf);
 
private:
  LPDIRECT3D9 m_pd3d9;
  LPDIRECT3DDEVICE9 m_pd3dDevice;
  LPDIRECT3DTEXTURE9 m_pd3dTextureY;
  LPDIRECT3DTEXTURE9 m_pd3dTextureU;
  LPDIRECT3DTEXTURE9 m_pd3dTextureV;
  LPDIRECT3DTEXTURE9 m_pd3dTextureRGB32;
  LPDIRECT3DVERTEXBUFFER9 m_pd3dVertexBuffer;
 
 LPDIRECT3DPIXELSHADER9 m_pPixelShader;
  LPD3DXCONSTANTTABLE g_pConstantTable_PS;  //������Ⱦ��������
  
 
 LPD3DXSPRITE m_pd3dxSprite;
  LPD3DXFONT m_pd3dxFont;
 
 INT m_nWidth;
  INT m_nHeight;
  INT m_nPixelFormat;
  HWND m_hWnd;
  INT m_nConvertPixelFormatType;
 
 BYTE* m_pYBuf;
  BYTE* m_pUBuf;
  BYTE* m_pVBuf;
  BYTE* m_pRGB32Buf;
 
// LONG m_lFontWidth;
  INT m_nShowWidth;
  INT m_nShowHeight;
 };
