//
//  LyricRender.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "LyricRender.h"
#import "FreeTypeFont.h"
#import "ImgsetMgr.h"

@implementation LyricRender

//-----------------------------------------------------------------------------

- (void)dealloc
{
    [mVecLyric release];
	[mVecLittleLyric release];
	[mSongName release];
	[mSongPlayedTime release];
    [mFreeTypeFont release];
    
    [super dealloc];
}

// 初始化
- (id) init
{
    self = [super init];
    mbKtvMode = true;
    mbFirstSentence = true;
    mfMovieImagePos = 0.0f;
    mfTipImageTrans = 0.0f;
    mfTextPos = 0.0f;
    mfTextLittlePos = 0.0f;
    mfTextWidth = 0.0f;
    mfNextTextWidth = 0.0f;
    mfSongNameWidth = 0.0f;
    
	if ( mbKtvMode )
	{
		mfStartPos = 0.0f;
		mfNextStartPos = 0.0f;
	}
	else
	{
		mfStartPos = 170.0f / 720.0f;
	}
    
    mbInvalidate = false;
    
    mFreeTypeFont = [[FreeTypeFont alloc] init];
    
    return self;
}

- (void) invalidate
{
    mbInvalidate = true;
}

// 加载歌词字体
- (void) loadFont: (NSString *) strLyric
{
    [mFreeTypeFont load: nil LyricString: strLyric];
}

//-----------------------------------------------------------------------------
// 设置曲谱模式是否为KTV模式(曲谱模式:KTV模式,游戏模式)
- (void) setMode:(bool)ktv_mode
{
	mbKtvMode = ktv_mode;
	if ( mbKtvMode )
	{
		mfStartPos = 0.0f;
		mfNextStartPos = 0.0f;
	}
	else
	{
		mfStartPos = 170.0f / 720.0f;
	}
}

//-----------------------------------------------------------------------------
// 设置歌词框演唱起点
- (void) setFirstLyricStartPos:(float)start_pos
{
	mfStartPos = start_pos;
	mfNextStartPos = 0.0f;
	[self invalidate];
}

//-----------------------------------------------------------------------------
// 设置歌词框演唱起点
- (void) setNextLyricStartPos:(float)start_pos
{
	mfStartPos = 0.0f;
	mfNextStartPos = start_pos;
	[self invalidate];
}

//-----------------------------------------------------------------------------
/// 歌曲播放时间
- (void) setSongTime:(NSString *)curtime
{
	mSongPlayedTime = curtime;
	[self invalidate];
}

//-----------------------------------------------------------------------------
// 歌曲名称
- (void) setSongName:(NSString *)curname
{
    /*
	CEGUI::Font * songInfoFnt = &CEGUI::FontManager::getSingleton().get("simhei10");
	CEGUI::String & ch = Ci::CUtility::mbc2CeguiString( curname );
	mfSongNameWidth = songInfoFnt->getTextExtent( ch );

	mSongName = curname;
	[self invalidate];
    */
}

//-----------------------------------------------------------------------------
// 显示歌词(返回歌词长度)
- (float) showFirstLyric:(NSMutableArray *)lyric_list Refresh:(bool)refresh
{
	if ( !mFreeTypeFont )
	{
		//LOG_GAME_ERR( "Get font simhei24 error." );
		//LOG_GAME_ERR( "Get font simhei16 error." );
		return 0.0f;
	}
	//CGSize sz = window_size;//getPixelSize();
	mfTextWidth = 0;
	NSMutableString * ceguiStrTemp = [[NSMutableString alloc] initWithCapacity:8];
	float offset = 0.0f;
	for( _tGuiLyricInfo * i in lyric_list )
	{
		i.width = ([mFreeTypeFont getTextExtent: i.lyric]) * SCALE;
		[ceguiStrTemp appendString: i.lyric];
        if ( mbKtvMode )
		{
			i.pos = ( int )offset;
			offset += i.width + FONT24_SPACE;
		}
	}
	
	float fRealTextWidth = ([mFreeTypeFont getTextExtent: ceguiStrTemp]) * SCALE;		//20.0f / 16.0f
    [ceguiStrTemp release];//////////////////glp
	mfTextWidth = fRealTextWidth + FONT24_SPACE * ( [lyric_list count] - 1 );
	mfTextPos = LEFT_INDENT;

	mVecLyric = lyric_list;

	if ( refresh )
	{
		[self invalidate];
	}

	return fRealTextWidth;
}

//-----------------------------------------------------------------------------
// 显示小歌词
- (float) showSecondLyric:(NSMutableArray *)lyric_list Refresh:(bool)refresh
{
	mfNextTextWidth = 0.0f;
	
	CGSize sz = window_size;//getPixelSize();
	NSMutableString * ceguiStrTemp = [NSMutableString alloc];
	float offset = 0.0f;
	for( _tGuiLyricInfo * i in lyric_list )
	{
		i.pos = ( int )offset;
		i.width = ([mFreeTypeFont getTextExtent: i.lyric]) * SCALE;
		[ceguiStrTemp appendString: i.lyric];
		offset += i.width + FONT24_SPACE;
	}

	float fRealTextWidth = ( [mFreeTypeFont getTextExtent: ceguiStrTemp] ) * SCALE;		//20.0f / 16.0f
    [ceguiStrTemp release];////////////glp
	mfNextTextWidth = fRealTextWidth + FONT24_SPACE * ( [lyric_list count] - 1 );
	mfTextLittlePos = sz.width - mfNextTextWidth - RIGHT_INDENT;

	mVecLittleLyric = lyric_list;

	if ( refresh )
	{
		[self invalidate];
	}

	return fRealTextWidth;
}

//-----------------------------------------------------------------------------
// 设置滑动图标位置
- (void) setLyricMovePos:(float)position
{
	mfMovieImagePos = position;
}

//-----------------------------------------------------------------------------
// 设置提示图标透明度
- (void) setLyricTipImageTrans:(float)trans
{
	mfTipImageTrans = trans;
}

//-----------------------------------------------------------------------------
// 设置当前句是否为第一句
- (void) switchSentence:(bool)bFirstSentence
{
	mbFirstSentence = bFirstSentence;
}

//-----------------------------------------------------------------------------
// 重置所有标志位
- (void) reset
{
	[mVecLyric removeAllObjects];
	[mVecLittleLyric removeAllObjects];

	mbFirstSentence = true;
	mfMovieImagePos = 0.0f;
	mfTipImageTrans = 0.0f;

	mfTextPos = 0.0f;
	mfTextLittlePos = 0.0f;
	mfTextWidth = 0.0f;
	mfNextTextWidth = 0.0f;

	//GeometryBuffer & geo = getGeometryBuffer();
	//geo.reset();
    
    [[[ImgsetMgr getSingleton] getImageset:@"FreeTypeFont"] clear];
}

//-----------------------------------------------------------------------------
- (void) populateGeometryBuffer
{
	static KKColorRect color_rect0( 0xFF65CCF4, 0xFF2366DF, 0xFF65CCF4, 0xFF2366DF );
	static KKColorRect color_rect1( 0xFFDDDDDD, 0xFFDDDDDD, 0xFFDDDDDD, 0xFFDDDDDD );
    
	//GeometryBuffer & geo = getGeometryBuffer();
	//geo.reset();
    [[[ImgsetMgr getSingleton] getImageset:@"FreeTypeFont"] clear];
    
    if ( !mbInvalidate )
    {
        return;
    }
    
    /*
	if ( mbKtvMode )
	{
		//static CEGUI::Font * fnt = &CEGUI::FontManager::getSingleton().get( "simhei24" );
		static CEGUI::Font * fnt = &CEGUI::FontManager::getSingleton().get( "simhei16" );
		CEGUI::Size sz = getPixelSize();
		if ( fnt )
		{
			CEGUI::Point pt( 0, 3 ); 
			CEGUI::Rect rt( pt, sz );

			CEGUI::Rect clip_rect1	= rt;
			clip_rect1.d_right		= mfTextPos + mfTextWidth * mfStartPos;//clip_rect1.d_left + ( clip_rect1.d_right - clip_rect1.d_left ) * mfStartPos;
			CEGUI::Rect clip_rect2	= rt;
			clip_rect2.d_left		= clip_rect1.d_right;

			BOOST_FOREACH( _tGuiLyricInfo & i, mVecLyric )
			{
				pt.d_x = i.pos + mfTextPos;//( float )i.pos * sz.d_width;

				CEGUI::String & ch = i.lyric;
				// 101,204,244 下面是 35,102,223
				fnt->drawText( geo, ch, pt, &clip_rect1, colour_rect, 0.0, SCALE, SCALE );
				fnt->drawText( geo, ch, pt, &clip_rect2, colour( 0xFFDDDDDD ), 0.0, SCALE, SCALE );
			}
		}
		if ( fnt )
		{
			CEGUI::Point pt( 0, FONT_HEIGHT + 6 ); 
			CEGUI::Rect rt( pt, sz );

			CEGUI::Rect clip_rect1	= rt;
			clip_rect1.d_right		= mfTextLittlePos + mfNextTextWidth * mfNextStartPos;//clip_rect1.d_left + ( clip_rect1.d_right - clip_rect1.d_left ) * mfStartPos;
			CEGUI::Rect clip_rect2	= rt;
			clip_rect2.d_left		= clip_rect1.d_right;

			BOOST_FOREACH( _tGuiLyricInfo & i, mVecLittleLyric )
			{
				pt.d_x = i.pos + mfTextLittlePos;//( float )i.pos * sz.d_width;

				CEGUI::String & ch = i.lyric;
				// 101,204,244 下面是 35,102,223
				fnt->drawText( geo, ch, pt, &clip_rect1, colour_rect, 0.0, SCALE, SCALE );
				fnt->drawText( geo, ch, pt, &clip_rect2, colour( 0xFFDDDDDD ), 0.0, SCALE, SCALE );
			}
		}

		static CEGUI::Image * move_image = (CEGUI::Image*)&CEGUI::ImagesetManager::getSingleton().get( "Skin2" ).getImage( "ImageLyricCursor");
		if ( move_image )
		{
			// 2.画滑动光标
			//if ( mfStartPos <= 0.0f && mfNextStartPos <= 0.0f )		// 字上不画光标
			if ( mfStartPos < 1.0f && mfNextStartPos <= 1.0f )			// 字上画光标，1.0或大于1.0后隐藏
			{
				CEGUI::Point	clip_pt;
				CEGUI::Vector2	move_pos;

				if ( mbFirstSentence )
				{
					if ( mfStartPos <= 0.0f )
						move_pos.d_x = mfTextPos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX + MOVE_IMAGE_SPACE * mfMovieImagePos - move_image->getWidth();
					else
						move_pos.d_x = mfTextPos + mfTextWidth * mfStartPos - move_image->getWidth();

					move_pos.d_y = MOVE_IMAGE_Y1;

					clip_pt.d_x = mfTextPos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX;
					clip_pt.d_y = MOVE_IMAGE_Y1;
				}
				else
				{
					if ( mfNextStartPos <= 0.0f )
						move_pos.d_x = mfTextLittlePos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX + MOVE_IMAGE_SPACE * mfMovieImagePos - move_image->getWidth();
					else
						move_pos.d_x = mfTextLittlePos + mfNextTextWidth * mfNextStartPos - move_image->getWidth();

					move_pos.d_y = MOVE_IMAGE_Y2;

					clip_pt.d_x = mfTextLittlePos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX;
					clip_pt.d_y = MOVE_IMAGE_Y2;
				}
				
				CEGUI::Size clip_sz( MOVE_IMAGE_SPACE + MAX_LYRIC_WIDTH, move_image->getHeight() );
				CEGUI::Rect clip_rect( clip_pt, clip_sz );
				CEGUI::colour c( 0xFFFFFFFF );
				CEGUI::ColourRect colour_rect( c );
				move_image->draw( geo, move_pos, &clip_rect, colour_rect );
			}
		}

	}
	else
    */
	{
        if ( nil == mVecLyric )
        {
            return;
        }
        
        CGSize sz = CGSizeMake( window_size.width, 40.0f );//getPixelSize();
        CGPoint pt = CGPointMake( 0.0f, 90.0f );
        CGRect rt = CGRectMake(pt.x, pt.y, sz.width, sz.height);

        CGRect clip_rect0	= rt;
        clip_rect0.size.width		= (int)( clip_rect0.size.width * mfStartPos );
        CGRect clip_rect1	= rt;
        clip_rect1.size.width		-= clip_rect0.size.width;
        clip_rect1.origin.x         += clip_rect0.size.width;
        
        for( _tGuiLyricInfo * i in mVecLyric )
        {
            if ( i.pos > -20 && i.pos < sz.width )
            {
                NSString * ch = i.lyric;
                pt.x = ( float )i.pos;
                [mFreeTypeFont drawText: ch OffsetPoint: pt ClipRect: &clip_rect0 ColorRect: color_rect0];
                [mFreeTypeFont drawText: ch OffsetPoint: pt ClipRect: &clip_rect1 ColorRect: color_rect1];
            }
        }
    }
}

@end //LyricRender