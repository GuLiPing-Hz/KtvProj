//
//  LyricInfo.cpp
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "LyricInfo.h"

@implementation _tGuiLyricInfo
@synthesize lyric, width, pos;

- (id) init
{
    self = [super init];
    lyric = nil;
    width = 0.0f;
    pos = 0;
    return self;
}

- (void)dealloc
{
    [lyric release];
    
    [super dealloc];
}

@end