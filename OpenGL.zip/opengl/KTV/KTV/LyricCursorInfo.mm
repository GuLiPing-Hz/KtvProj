//
//  LyricCursorInfo.mm
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#include "LyricCursorInfo.h"

@implementation _tGuiLyricCursorInfo

@synthesize x, y, b, r;

- (id) init
{
    self = [super init];
    x = 0;
    y = 0;
    b = false;
    r = RANK_NONE;
    return self;
}

- (id) initWithParams:
     (int) _x
     YValue: (int) _y
     BValue: (bool) _b
     RValue:(int)_r
{
    self = [super init];
    x = _x;
    y = _y;
    b = _b;
    r = _r;
    return self;    
}

@end
