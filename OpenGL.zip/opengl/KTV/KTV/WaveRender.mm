//
//  WaveRender.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "WaveRender.h"
#import "ImgsetMgr.h"
#import "KKType.h"

@implementation WaveRender
//-----------------------------------------------------------------------------


- (void) dealloc
{
    [mVecWave release];           // 谱线(_tGuiWaveInfo)
	[mVecCursors release];        // 游标数组(_tGuiLyricCursorInfo)
	[mVecCursorsPos release];
    [mSentenceLineList release];
    [mImageWaveLeft0 release];
	[mImageWaveMiddle0 release];
	[mImageWaveRight0 release];
    
	// 谱线光环
	[mImageWaveLeft1 release];
	[mImageWaveMiddle1 release];
	[mImageWaveRight1 release];
    
	// 歌唱的靠谱的谱线
	[mImageWaveLeft2 release];
	[mImageWaveMiddle2 release];
	[mImageWaveRight2 release];
    
	// 标准的不靠谱的谱线
	[mImageWaveLeft3 release];
	[mImageWaveMiddle3 release];
	[mImageWaveRight3 release];
    
	[mImageWave release];
    [mImageWaveTrans release];
    
    [super dealloc];
}

// 构造函数
- (id) init
{
    self = [super init];
    mfStartPos = 0.0f;
    mLyricCursorPos = { 149.8125f, 1.0f };
    mLyricLastCursorPos = mLyricLastCursorPos;
    int r = (int)RANK_GREEN;
    mLyricCursorInfo = [[_tGuiLyricCursorInfo alloc] initWithParams:mfStartPos YValue:-1.0f BValue:false RValue:r];
    mbKtvMode = true;
    mImageWaveLeft0 = NULL;
    mImageWaveMiddle0 = NULL;
    mImageWaveRight0 = NULL;
    mImageWaveLeft1 = NULL;
    mImageWaveMiddle1 = NULL;
    mImageWaveRight1 = NULL;
    mImageWaveLeft2 = NULL;
    mImageWaveMiddle2 = NULL;
    mImageWaveRight2 = NULL;
    mImageWaveLeft3 = NULL;
    mImageWaveMiddle3 = NULL;
    mImageWaveRight3 = NULL;
    mImageWave = NULL;
    mbEnableWaveEffect = false;
    mImageWaveTrans = [[TransParams alloc] initByParams:YES TransType:TRANS_ALPHA AlphaBegin:0.0f FadeinTm:1.0f DelayTm:0.0f FadeoutTm:1.0f RotateTm:0.6f];
    mbEnableMoveImage = false;
    mfKtvErr = 0.0f;
    mfGameErr = 0.0f;
    mStandard_y = 0;

	// 标准的谱线
    ImgsetMgr * imgsetMgr = [ImgsetMgr getSingleton];
    Imageset * imgset = [imgsetMgr getImageset: @"renderer"];
	if ( [imgset isDefined: @"WaveYellowL"] )
		mImageWaveLeft0 = [imgset getImage: @"WaveYellowL"];
	if ( [imgset isDefined: @"WaveYellowM"] )
		mImageWaveMiddle0 = [imgset getImage: @"WaveYellowM"];
	if ( [imgset isDefined: @"WaveYellowR"] )
		mImageWaveRight0 = [imgset getImage: @"WaveYellowR"];

	// 谱线光环
	if ( [imgset isDefined: @"WaveBlueL"] )
		mImageWaveLeft1 = [imgset getImage: @"WaveBlueL"];
	if ( [imgset isDefined: @"WaveBlueM"] )
		mImageWaveMiddle1 = [imgset getImage: @"WaveBlueM"];
	if ( [imgset isDefined: @"WaveBlueR"] )
		mImageWaveRight1 = [imgset getImage: @"WaveBlueR"];

	// 歌唱的靠谱的谱线
	if ( [imgset isDefined: @"WaveBlueL"] )
		mImageWaveLeft2 = [imgset getImage: @"WaveBlueL"];
	if ( [imgset isDefined: @"WaveBlueM"] )
		mImageWaveMiddle2 = [imgset getImage: @"WaveBlueM"];
	if ( [imgset isDefined: @"WaveBlueR"] )
		mImageWaveRight2 = [imgset getImage: @"WaveBlueR"];

	// 不靠谱的谱线
	if ( [imgset isDefined: @"WaveLightBlueL"] )
		mImageWaveLeft3 = [imgset getImage: @"WaveLightBlueL"];
	if ( [imgset isDefined: @"WaveLightBlueM"] )
		mImageWaveMiddle3 = [imgset getImage: @"WaveLightBlueM"];
	if ( [imgset isDefined: @"WaveLightBlueR"] )
		mImageWaveRight3 = [imgset getImage: @"WaveLightBlueR"];

	if ( [imgset isDefined: @"WaveBlueM"] )
		mImageWave = [imgset getImage: @"WaveBlueM"];
    
    /*
    mVecWave = [[NSMutableArray alloc] initWithCapacity:16];
    mVecCursors = [[NSMutableArray alloc] initWithCapacity:16];
    mVecCursorsPos = [[NSMutableArray alloc] initWithCapacity:16];
    mSentenceLineList = [[NSMutableArray alloc] initWithCapacity:16];
    */
    return self;
}

- (void) invalidate
{
    mbInvalidate = true;
}

//-----------------------------------------------------------------------------
// 设置曲谱模式是否为KTV模式(曲谱模式:KTV模式,游戏模式)
- (void) setMode:(bool)ktv_mode
{
	mbKtvMode = ktv_mode;
}

//-----------------------------------------------------------------------------
// 设置谱线
- (void) setLineGroup:(NSMutableArray *)wave_list Refresh:(bool)refresh
{
	// 设置标准谱线
	mVecWave = wave_list;
}

//-----------------------------------------------------------------------------
- (void) setStandardY:(int)y
{
	mStandard_y = y;
}

//-----------------------------------------------------------------------------
// 设置游标
- (void) setLyricCursor:(_tGuiLyricCursorInfo *)ci KtvError:(float)ktvErr GameError:(float)gameErr
{
	mfKtvErr = ktvErr;
	mfGameErr = gameErr;
	if ( mbKtvMode )
	{
		//mVecCursors.push_back( ci );
		[self _dealWithCursor: ci];
	}
	else
	{
		static float h = ( float )mImageWave.rect.size.height;			// Image高度
		//CGSize sz = window_size;

		// mLyricCursorInfo = ci;
		// float fci = ( sz.height - 4*h ) * ci.y + 2*h;
		// int ici = ((int)( fci / h )) * h;
		// mLyricCursorInfo.y = ( float )ici;
        
        if ( mLyricCursorInfo != nil )
        {
            [mLyricCursorInfo release];
            mLyricCursorInfo = nil;
        }

		mLyricCursorInfo = ci;
		mLyricCursorInfo.y = ci.y / h * h;
		if ( (mLyricCursorInfo.y-mfGameErr) <= mStandard_y && (mLyricCursorInfo.y+mfGameErr) >= mStandard_y )
		{
			mLyricCursorInfo.y = mStandard_y;
		}
		/*if ( (ci.y-gameErr) < h && (ci.y+gameErr) > h )
		{
			mLyricCursorInfo.y = h
		}*/
	}

	[self invalidate];
}

//-----------------------------------------------------------------------------
// 设置单句移动
- (void) setMovePos:(float)position
{
	mfStartPos = position;
	[self invalidate];
}

- (void) clearLyricCursor
{
	[mVecCursors removeAllObjects];
}

//-----------------------------------------------------------------------------
// 设置句尾线
- (void) setSentenceLineList:(NSMutableArray *)sentenceline_list Refresh:(bool)refresh
{
	mSentenceLineList = sentenceline_list;
}

//-----------------------------------------------------------------------------
// update 
- (void) updateSelf:(float)elapsed
{
	// 谱线光环闪烁
	if ( mbKtvMode && mbEnableWaveEffect )
	{
		if ( ![mImageWaveTrans isEnd] )
		{
			[mImageWaveTrans trans: elapsed];
		}
	}
}

//-----------------------------------------------------------------------------
// 重置所有数据
- (void) reset
{
	[mVecWave removeAllObjects];
	[mVecCursors removeAllObjects];
	mfStartPos = 0.0f;
	mLyricCursorInfo.x = mLyricCursorInfo.y = 0.0f;
	mLyricCursorInfo.r = RANK_NONE;
	[mSentenceLineList removeAllObjects];
	mLyricCursorPos.x = mLyricCursorPos.y = 0.0f;
	mLyricLastCursorPos.x = mLyricLastCursorPos.y = 0.0f;

//	CEGUI::GeometryBuffer & geo = getGeometryBuffer();
//	geo.reset();
    
    [[[ImgsetMgr getSingleton] getImageset:@"renderer"] clear];
}

//-----------------------------------------------------------------------------
// 开启/关闭谱线光环特效
- (void) enableWaveEffect:(bool)enable
{
	mbEnableWaveEffect = enable;
	//mbEnableWaveEffect = true;
}

//-----------------------------------------------------------------------------
- (void) populateGeometryBuffer
{
//	CEGUI::GeometryBuffer & geo = getGeometryBuffer();
//	geo.reset();
    [[[ImgsetMgr getSingleton] getImageset:@"renderer"] clear];

    if ( !mbInvalidate )
    {
        return;
    }
    
	if ( mbKtvMode )
	{
		// 画实时谱线
        if ( mVecWave )
        {
            [self _drawPitch: mVecWave];
        }

		// 画光标
		[self _drawCursor];
	}
	else
	{
		// 画背景头部
		Image * head_img = [[[ImgsetMgr getSingleton] getImageset:@"renderer"] getImage:@"GameBkg"];
		if ( head_img )
		{
			CGRect dest_rect = CGRectMake( 0, 0, window_size.width, head_img.rect.size.height );
            [head_img draw: dest_rect ClipRect: nil ColorRect: COLOR_RECT_WHITE];
		}
        
        // 画分割线
		Image * seperator_img = [[[ImgsetMgr getSingleton] getImageset:@"renderer"] getImage:@"GameBkgSeperator"];
		if ( seperator_img )
		{
			CGRect dest_rect = CGRectMake( 80, 0, seperator_img.rect.size.width, seperator_img.rect.size.height );
			[seperator_img draw: dest_rect ClipRect: nil ColorRect: COLOR_RECT_WHITE];
		}
        
		// 画谱线
        if ( mVecWave )
        {
            [self _drawPitch: mVecWave];
        }

		// 画句尾线
        if ( mSentenceLineList )
		{
            [self _drawSentenceLine: mSentenceLineList];
        }

		// 画光标
		[self _drawCursor];
	}
}

//-----------------------------------------------------------------------------
// 绘制句尾线
- (void) _drawSentenceLine:(NSArray *)sentenceline_list
{
	CGSize rt = window_size;
	int x = 0;
    static KKColorRect color_rect( 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF );

	static Image * image_sentence_line = [[[ImgsetMgr getSingleton] getImageset: @"renderer"] getImage: @"GameBkgSeperator"];
	static float image_width = image_sentence_line.rect.size.width;
	static float image_height = image_sentence_line.rect.size.height;

	for( NSNumber * sentenceline in sentenceline_list )
	{
		x = [sentenceline intValue];
		if ( x >= 0 && x < rt.width )
		{
            CGRect dest_rect = CGRectMake( x, 0, image_width, image_height );
			[image_sentence_line draw: dest_rect ClipRect:nil ColorRect: color_rect];
		}
	}
}

//-----------------------------------------------------------------------------
// 绘制游戏模式光标
- (void) _drawCursor
{
	if ( mbKtvMode )
	{
		//CGSize sz = window_size;

		/*
		// 谱线中的光标特效
		static Image * move_image = [[[ImgsetMgr getSingleton] getImageset: @"renderer"] getImage: @"ImageWaveMove"];
        // 谱线中的星星特效
		static int star_image_count = 13;
		static Image * star_image[13] =
		{
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar1"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar2"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar3"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar4"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar5"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar6"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar7"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar8"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar9"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar10"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar11"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar12"],
			[[[ImgsetMgr getSingleton] getImageset: @"Skin2"] getImage: @"ImageEffectStar13"]
		};
        */

		if (!mImageWaveMiddle2 || !mImageWaveRight2 || !mImageWaveLeft2 || 
			!mImageWaveMiddle3 || !mImageWaveRight3 || !mImageWaveLeft3/* ||
			!move_image*/ )
		{// 没有相应的Image
			return;
		}

		// 移动光标的位置
		CGPoint move_pos = CGPointMake( 0.0f, 0.0f );

		// 靠谱的谱线图片参数
		static float h = mImageWaveMiddle2.rect.size.height;
		static float hh = h / 2;
		static float lw = mImageWaveLeft2.rect.size.width;
		static float rw = mImageWaveRight2.rect.size.width;

		// 不靠谱的谱线图片参数
		static float h_s = mImageWaveMiddle3.rect.size.height;
		static float hh_s = h_s / 2;
		static float lw_s = mImageWaveLeft3.rect.size.width;
		static float rw_s = mImageWaveRight3.rect.size.width;

		//bool  bMiddle = false, bEnd = false,bfirst = true;
		float width = 0.0f;
		
        int item_count = [mVecCursors count];
		for ( int i = 0; i < item_count; ++i )
		{
            _tGuiLyricCursorInfo * lyric_cursor_info = (_tGuiLyricCursorInfo *)[mVecCursors objectAtIndex:i];
			mLyricCursorInfo = lyric_cursor_info;
			CGPoint pos, next;//tmp;

			pos.x = mLyricCursorInfo.x;
			pos.y = mLyricCursorInfo.y;

			if ( (i + 1) != item_count )
			{
                _tGuiLyricCursorInfo * lyric_cursor_info_next = (_tGuiLyricCursorInfo *)[mVecCursors objectAtIndex:i+1];
				next.y = lyric_cursor_info_next.y;
				if ( (int)next.y == (int)pos.y )
				{
					static Image * _il = NULL;
					static Image * _im = NULL;
					static Image * _ir = NULL;

					static float _h = 0.0f;
					static float _hh = 0.0f;
					static float _lw = 0.0f;
					static float _rw = 0.0f;

					static float _alpha = 1.0f;

					if ( mLyricCursorInfo.b )
					{// 靠谱
						_il = mImageWaveLeft2;
						_im = mImageWaveMiddle2;
						_ir = mImageWaveRight2;

						_h = h;
						_hh = hh;
						_lw = lw;
						_rw = rw;

						_alpha = 1.0f;

						move_pos.x = lyric_cursor_info_next.x;
						move_pos.y = lyric_cursor_info_next.y;

						mbEnableMoveImage = true;
					}
					else
					{// 不靠谱
						_il = mImageWaveLeft3;
						_im = mImageWaveMiddle3;
						_ir = mImageWaveRight3;

						_h = h_s;
						_hh = hh_s;
						_lw = lw_s;
						_rw = rw_s;

						_alpha = 0.5f;

						move_pos.x = 0.0f;
						move_pos.y = 0.0f;

						mbEnableMoveImage = false;
					}
					// float dest_width = ((*it_next).x - (*it).x) * (sz.width - 6);
					float dest_width = lyric_cursor_info_next.x - lyric_cursor_info.x;
					pos.y -= _hh;
                    KKColor c( 1.0f, 1.0f, 1.0f, _alpha );
					KKColorRect cr( c );
					if ( dest_width > ( _lw + _rw ) )
					{
						//width = _lw;
                        CGRect dest_rect_left = CGRectMake( pos.x, pos.y, _lw, _h );
						[_il draw: dest_rect_left ClipRect: nil ColorRect: cr];

						// width  = ((*it_next).x - (*it).x) * (sz.width - 6);
						width  = lyric_cursor_info_next.x - lyric_cursor_info.x;
						width -= _rw;
						width -= _lw;
						pos.x += _rw;
                        CGRect dest_rect_middle = CGRectMake(pos.x, pos.y, width, _h);
                        [_im draw: dest_rect_middle ClipRect: nil ColorRect: cr];
						pos.x += width;
                        CGRect dest_rect_right = CGRectMake(pos.x, pos.y, rw, _h);
						[_ir draw: dest_rect_right ClipRect: nil ColorRect: cr];
					}
					else if ( dest_width >= 10.0f )
					{
						float draw_width = dest_width * 0.5f;
						CGRect clip_rect_left = CGRectMake( pos.x, pos.y, draw_width, _h );
                        CGRect dest_rect_left = CGRectMake( pos.x, pos.y, _lw, _h );
						[_il draw: dest_rect_left ClipRect: &clip_rect_left ColorRect: cr];

						CGRect clip_rect_right = CGRectMake( pos.x + draw_width, pos.y, draw_width, _h );
                        CGRect dest_rect_right = CGRectMake( pos.x + draw_width - _rw, pos.y, _rw, _h );
						[_il draw: dest_rect_right ClipRect: &clip_rect_right ColorRect: cr];

						pos.x += draw_width;
					}
				}
			}
		}
	}
	else
	{
		NSString * cursor_name = nil;
        if ( mLyricCursorInfo.r == RANK_GREEN )
            cursor_name = [[NSString alloc] initWithFormat:@"CursorGreen"];
        else if ( mLyricCursorInfo.r == RANK_YELLOW )
            cursor_name = [[NSString alloc] initWithFormat:@"CursorYellow"];
        else if ( mLyricCursorInfo.r == RANK_RED )
            cursor_name = [[NSString alloc] initWithFormat:@"CursorRed"];
        
        if ( cursor_name != nil )
        {
            Image * cursor_img = [[[ImgsetMgr getSingleton] getImageset: @"renderer"] getImage: cursor_name];
            
            if ( cursor_img )
            {
                //CGSize sz = window_size;
                CGPoint pos = CGPointMake(mLyricCursorInfo.x, mLyricCursorInfo.y - ( cursor_img.rect.size.height/2 ));
                
                CGRect dest_rect = CGRectMake(pos.x, pos.y, cursor_img.rect.size.width, cursor_img.rect.size.height);
                [cursor_img draw: dest_rect ClipRect:nil ColorRect: COLOR_RECT_WHITE];
                //[cursor_img release];//////////////glp
            }
            
        }
	}
}

//-----------------------------------------------------------------------------
// 绘制谱线
- (void) _drawPitch:(NSArray *)waves
{
	CGSize rt = window_size;
	CGPoint l = CGPointZero;
	CGPoint r = CGPointZero;

	if ( mbKtvMode )
	{		
		static int h = ( ( int )mImageWaveMiddle0.rect.size.height );				// Image的高度( 左中右 一样)
		static int hh = h / 2;													// Image一半的高度( 左中右 一样)
		static int lw = ( int )mImageWaveLeft0.rect.size.width;
		static int rw = ( int )mImageWaveRight0.rect.size.width;

		static int h1 = ( ( int )mImageWaveMiddle1.rect.size.height );				// Image的高度( 左中右 一样)
		static int hh1 = h1 / 2;												// Image一半的高度( 左中右 一样)
		static int lw1 = ( int )mImageWaveLeft1.rect.size.width;
		static int rw1 = ( int )mImageWaveRight1.rect.size.width;

		for( _tGuiWaveInfo * wave in waves )
		{
			l.x = wave.l;
			r.x = wave.r;

			l.y = r.y = wave.y - hh;		// 减去mImageWaveMiddle0的一半高度 21 * 0.5

			l.x = ( l.x > 0 ) ? l.x : WAVE_EFFECT_WIDTH;
			r.x = ( r.x < rt.width ) ? r.x : rt.width - WAVE_EFFECT_WIDTH;

			float dest_width = r.x - l.x;

			if ( dest_width > (lw + rw) )
			{
				float width = r.x - l.x - lw - rw;
                CGRect dest_rect_middle = CGRectMake(l.x + lw, l.y, (width> 0 ? width : 0 ), h );
				[mImageWaveMiddle0 draw: dest_rect_middle ClipRect:nil ColorRect: COLOR_RECT_WHITE ];
                
                CGRect dest_rect_left = CGRectMake(l.x, l.y, lw, h );
				[mImageWaveLeft0 draw: dest_rect_left ClipRect: nil ColorRect: COLOR_RECT_WHITE];
                
                CGRect dest_rect_right = CGRectMake(r.x - rw, l.y, rw, h );
				[mImageWaveRight0 draw: dest_rect_right ClipRect: nil ColorRect: COLOR_RECT_WHITE];
			}
			else if ( dest_width >= 10.0f )
			{
				float draw_width = ( float )( ( int )( dest_width * 0.5f ) );
				CGRect clip_rect_left = CGRectMake( l.x, l.y, draw_width, h );
				CGRect clip_rect_right = CGRectMake( l.x + draw_width, l.y, draw_width, h );
                
                CGRect dest_rect_left = CGRectMake( l.x , l.y, lw, h );
				[mImageWaveLeft0 draw: dest_rect_left ClipRect: &clip_rect_left ColorRect: COLOR_RECT_WHITE];
                
                CGRect dest_rect_right = CGRectMake( r.x - rw, l.y, rw, h );
				[mImageWaveRight0 draw: dest_rect_right ClipRect: &clip_rect_right ColorRect: COLOR_RECT_WHITE];
			}

			// 画光环
			float falpha = [mImageWaveTrans getAlpha];
			if ( falpha > 1.0f )
				falpha = 1.0f;
			else if ( falpha <= 0.0f )
				falpha = 0.01f;

            KKColor c( 1.0, 1.0, 1.0, falpha );
			KKColorRect cr( c );
			if ( mbEnableWaveEffect )
			{
				CGPoint l1 = CGPointZero;
                CGPoint r1 = CGPointZero;
				
				// 光环显示的位置
				l1.y = r1.y = wave.y - hh1;		// 减去mImageWaveMiddle0的一半高度 23 * 0.5

				l1.x = l.x - 1;
				r1.x = r.x - 1;

				float dest_width1 = r1.x - l1.x;

				if ( dest_width1 > (lw1 + rw1) )
				{
					float width = r1.x - l1.x - lw1 - rw1;
                    
                    CGRect dest_rect_middle = CGRectMake(l1.x + lw1, l1.y, (width> 0 ? width : 0 ), h1);
					[mImageWaveMiddle1 draw: dest_rect_middle ClipRect: nil ColorRect: cr];
                    
                    CGRect dest_rect_left = CGRectMake(l1.x, l1.y, lw1, h1);
					[mImageWaveLeft1 draw: dest_rect_left ClipRect: nil ColorRect: cr];
                    
                    CGRect dest_rect_right = CGRectMake(r1.x - rw1, l1.y, rw1, h1);
                    [mImageWaveRight1 draw: dest_rect_right ClipRect: nil ColorRect: cr];
				}
				else if ( dest_width1 >= 10.0f )
				{
					//float draw_width = ( float )( ( int )( dest_width1 * 0.5f ) );
                    
					//CGRect clip_rect_left = CGRectMake( l1.x, l1.y, draw_width, h1 );
					//CGRect clip_rect_right = CGRectMake( l1.x + draw_width, l1.y, draw_width, h1 );
                    
                    CGRect dest_rect_left = CGRectMake( l1.x , l1.y, lw1, h1 );
					CGRect dest_rect_right = CGRectMake( r1.x - rw1, l1.y, rw1, h1 );
					[mImageWaveLeft0 draw: dest_rect_left ClipRect: nil ColorRect: cr];
					[mImageWaveRight0 draw: dest_rect_right ClipRect: nil ColorRect: cr];
				}
			}
		}
	}
	else
	{
		static int h = ( int )mImageWave.rect.size.height;			// mImageWave高度
		static int hh = h / 2;									// mImageWave一半的高度

		for( _tGuiWaveInfo * wave in waves )
		{
			int left = wave.l;
			int right = wave.r;
			if ( left >= 0 || right >= 0 )
			{
				if ( left < 0 )
				{
					left = 0;
				}

				l.x = left;
				r.x = right;
				l.y = r.y = wave.y - hh;					// 减去mImageWave的一半高度 10 * 0.5

				float width = 0.0f;
				if ( r.x <= rt.width )
				{
					width = r.x - l.x;
				}
				else
				{
					width = rt.width - l.x;
				}
                CGRect dest_rect_wave = CGRectMake( l.x, l.y, (width > 0 ? width : 0 ), h );
				[mImageWave draw: dest_rect_wave ClipRect:nil ColorRect:COLOR_RECT_WHITE];

				if ( l.x >= rt.width )
				{
					break;
				}
			}
		}
	}
}

//--------------------------------------------------------------------------
// 计算游标绝对位置
- (void) _locateCursor
{
	static float h = ( float )mImageWave.rect.size.height;			// Image高度
	CGSize sz = window_size;
	mLyricCursorPos.x = mLyricCursorInfo.x * sz.width;
	mLyricCursorPos.y = ( sz.height - 4*h ) * mLyricCursorInfo.y + 2*h;
}

//--------------------------------------------------------------------------
//处理游标
- (void) _dealWithCursor:(_tGuiLyricCursorInfo*)ci
{
    if ( nil == mImageWaveLeft3 )
    {
        NSLog( @"ERROR:_dealWithCursor error 0." );
        return;
    }
	int size = [mVecCursors count];

	static int h = ( int )mImageWaveLeft3.rect.size.height;						// mImageWaveLeft3高度
	//static int hh = ( ( int )mImageWaveLeft2.rect.size.height ) / 2;			// mImageWaveLeft2一半的高度
	//CGSize sz = window_size;
    
    if ( h <= 0 )
    {
        NSLog( @"ERROR:_dealWithCursor error 1." );
        return;
    }
	
	_tGuiLyricCursorInfo * _ci = [[_tGuiLyricCursorInfo alloc] initWithParams:ci.x YValue:ci.y BValue:ci.b RValue:ci.r];
	
	bool bfind = false;
	bool b = false;															// 是否落在标准谱线的某个区间内
	int ici = ( ( int )( ci.y / h ) ) * h;

	for( _tGuiWaveInfo * wi in mVecWave )
	{//查看是否落在标准谱线的某个区间内，如果是，设置Y值为标准谱线的Y值。
		if ( ci.x >= wi.l && ci.x <= wi.r && wi.r - wi.l >= 10 )
		{
			bfind = true;
			int temp = ci.y - wi.y;
			if ( temp >= -mfKtvErr && temp <= mfKtvErr )
			{
				ici = wi.y;
				b = true;
			}
		}

		if ( bfind )
		{
			break;
		}
	}

	_ci.y = ici;
	_ci.b = b;

	if ( size >= 2 )
	{
		_tGuiLyricCursorInfo * c = [mVecCursors objectAtIndex:(size-1)];
		_tGuiLyricCursorInfo * l = [mVecCursors objectAtIndex:(size-2)];

		if ( c.y == l.y && l.y == ici )
		{
            [mVecCursors replaceObjectAtIndex:(size-1) withObject:_ci];
		}
		else
		{
			if ( c.x != _ci.x )
			{
				[mVecCursors addObject: _ci];
			}
		}
	}
	else if ( size >= 1 )
	{
		_tGuiLyricCursorInfo * c = [mVecCursors objectAtIndex:(size-1)];
		if ( c.x != _ci.x )
		{
			[mVecCursors addObject: _ci];
		}
	}
	else
	{
		[mVecCursors addObject: _ci];
	}
    [_ci release];/////////glp
}

@end // WaveRender