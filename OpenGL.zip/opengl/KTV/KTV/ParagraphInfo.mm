//
//  ParagraphInfo.mm
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "ParagraphInfo.h"

@implementation _tGuiParagraphInfo
@synthesize sentence_index, duration;

- (id) init
{
    self = [super init];
    sentence_index = -1;
    duration = 0;
    return self;
}

@end // _tGuiParagraphInfo