//
//  ViewController.m
//  Karaoke
//
//  Created by guliping_imac on 12-9-7.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "ViewController.h"
#import "InputViewController.h"
#import "EAGLView.h"
#import "SceneMgr.h"
#import "SceneObjectEx.h"

@interface ViewController ()

@end

@implementation ViewController

//@synthesize idleTimerDisabled;

@synthesize label1,label2,label3,label4;
@synthesize stopButton;
@synthesize picker;
@synthesize column1;
@synthesize column2;
@synthesize column3;
@synthesize column4;
@synthesize itabelView;
@synthesize selectFileName;
@synthesize currentFileName;
@synthesize scene_objectex;
@synthesize scene_mgr;
@synthesize button;
@synthesize listData;


- (void)dealloc
{
    [label1 release];
    [label2 release];
    [label3 release];
    [label4 release];
    [stopButton release];
    [picker release];
    [column4 release];
    [column3 release];
    [column2 release];
    [column1 release];
    [currentFileName release];
    [selectFileName release];
    [button release];
    [itabelView release];
    [listData release];
    [scene_objectex release];
    [scene_mgr release];
    [super dealloc];
}

- (IBAction)toggleControls:(id)sender
{
    if([sender selectedSegmentIndex]==kSwitchesSegmentIndex)
    {
        itabelView.hidden = NO;
        picker.hidden = YES;
        label1.hidden = YES;
        label2.hidden = YES;
        label3.hidden = YES;
        label4.hidden = YES;
    }
    else
    {
        itabelView.hidden = YES;
        picker.hidden = NO;
        label1.hidden = NO;
        label2.hidden = NO;
        label3.hidden = NO;
        label4.hidden = NO;
    }
}

- (IBAction)stopButtonPressed
{
    if (currentFileName == nil) {
        return ;
    }
    
    [scene_mgr addObjectToRemove:scene_objectex];
    [scene_mgr stopAnimation];
    AQPlayer *aqPlayer = [scene_objectex getAudioPlayer];
    AQRecorder *aqRecorder = [scene_objectex getAudioRecorder];
    aqPlayer->PauseQueue();
    aqRecorder->StopRecord();
    mbStop = true;
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    currentFileName = nil;
    [self.button setTitle: @"Play" forState: UIControlStateHighlighted];
    [self.button setTitle: @"Play" forState: UIControlStateNormal];
}

- (IBAction)buttonPressed
{
    // begin the game.
    if (selectFileName == nil) {
        NSString *message = [[NSString alloc] initWithFormat:@"请选择歌曲"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"select song" message:message delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil];
        
        [alert show];
        [alert release];
        [message release];
        return ;
    }
    else if(currentFileName != selectFileName)
    {
        //NSInteger selectCol1 = [picker selectedRowInComponent:0];//算法
        NSInteger selectCol2 = [picker selectedRowInComponent:1];//静音阈值
        NSInteger selectCol3 = [picker selectedRowInComponent:2];//评分间隔
        NSInteger selectCol4 = [picker selectedRowInComponent:3];//采样率
        
        AQRecorder * aqRecorder;
        aqRecorder = nil;
        
        if (currentFileName !=nil) {
            [scene_mgr addObjectToRemove:scene_objectex];
            [scene_mgr stopAnimation];
            AQPlayer *aqPlayer = [scene_objectex getAudioPlayer];
            aqRecorder = [scene_objectex getAudioRecorder];
            aqPlayer->StopQueue();
            aqRecorder->StopRecord();
            //[scene_objectex release];
            //scene_objectex = nil;
        }
        currentFileName = selectFileName;
        scene_objectex = [[SceneObjectEx alloc] init:currentFileName andkBufferDurationSeconds:col3[selectCol3] andSampleRate:col4[selectCol4] anddBUpperLimit:col2[selectCol2]];
        aqRecorder = [scene_objectex getAudioRecorder];
        if (aqRecorder != nil) {
            aqRecorder->StartRecord1(CFSTR("recordedFile.caf"));
                
        }
        
        
        [scene_mgr addObjectToScene: scene_objectex];
        [scene_mgr startScene];
        [self.button setTitle: @"Pause" forState: UIControlStateHighlighted];
        [self.button setTitle: @"Pause" forState: UIControlStateNormal];
        mbStop = false;
        [UIApplication sharedApplication].idleTimerDisabled = YES;
        return ;
    }
    
    AQPlayer * aqPlayer = [scene_objectex getAudioPlayer];
    //AQRecorder * aqRecorder = [scene_objectex getAudioRecorder];
    if (aqPlayer->IsRunning()) {
        [self.button setTitle: @"Play" forState: UIControlStateHighlighted];
        [self.button setTitle: @"Play" forState: UIControlStateNormal];
        [scene_mgr stopAnimation];
        aqPlayer->StopQueue();
        //aqRecorder->StopRecord();
        [UIApplication sharedApplication].idleTimerDisabled = NO;

    }
    else
    {
        [self.button setTitle: @"Pause" forState: UIControlStateHighlighted];
        [self.button setTitle: @"Pause" forState: UIControlStateNormal];
        [scene_mgr startAnimation];
        aqPlayer->StartQueue(!mbStop);
        //aqRecorder->StartRecord();
        //self.idleTimerDisabled = YES;
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage * buttonImageNormal = [UIImage imageNamed:@"whiteButton.png"];
    UIImage * stretchableButtonImageNormal = [buttonImageNormal stretchableImageWithLeftCapWidth:12 topCapHeight:0];
    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
    [stopButton setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
    
    UIImage * buttonImagePressed = [UIImage imageNamed:@"blueButton.png"];
    UIImage * stretchableButtonImagePressed = [buttonImagePressed stretchableImageWithLeftCapWidth:12 topCapHeight:0];
    [button setBackgroundImage:stretchableButtonImagePressed forState:UIControlStateHighlighted];
    [stopButton setBackgroundImage:stretchableButtonImagePressed forState:UIControlStateHighlighted];
    
     scene_mgr = [SceneMgr getSingleton];
    
	// make a new input view controller, and save it as an instance variable
	InputViewController * input_controller = [[InputViewController alloc] initWithNibName:nil bundle:nil];
	scene_mgr.inputController = input_controller;
    [input_controller release];/////////glp
    
    // 添加OpenGL窗口
    CGRect r = CGRectMake(0, 0, 320, 128);
    EAGLView * glview = [[EAGLView alloc] initWithFrame:r];
    scene_mgr.inputController.view = glview;
	scene_mgr.openGLView = glview;
    
    [self.view addSubview:glview];
    [glview release];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //NSMutableArray *everyTitle = [[NSMutableArray alloc] init];
    //NSArray *filePaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //NSString *filePath = [filePaths objectAtIndex:0];
    //    NSLog(@"%@",filePath);
//    NSDirectoryEnumerator *direnum = [fileManager enumeratorAtPath:@"/Users/hujianping_NB/Downloads/projects/top100/mdm100/"];
    NSString *basePath0 = [[NSBundle mainBundle] bundlePath];
    NSRange range = [basePath0 rangeOfString:@"/KTV.app"];
    NSString *basePath1 = [basePath0 substringWithRange:NSMakeRange(0, range.location)];
    NSString *path = [[NSString alloc] initWithFormat:@"%@/Documents/top100/mdm100/", basePath1];

    NSDirectoryEnumerator *direnum = [fileManager enumeratorAtPath:path];
    //    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *fileName;
    NSMutableArray *tmplist = [[NSMutableArray alloc] init];//
    while ((fileName = [direnum nextObject])) {
        if([[fileName pathExtension] isEqualToString:@"mdm"]){
            
            NSArray *strings = [fileName componentsSeparatedByString:@"."];
            NSString *fileTitle = [strings objectAtIndex:0];
            //[everyTitle addObject:fileTitle];
            
            [tmplist addObject:fileTitle];
            
        }
    }
    self.listData = tmplist;
    [tmplist release];
    [path release];
    
    self.picker.hidden = YES;
    self.label1.hidden = YES;
    self.label2.hidden = YES;
    self.label3.hidden = YES;
    self.label4.hidden = YES;
    
    NSArray * array1 = [[NSArray alloc] initWithObjects:@"0",@"1", nil];
    NSArray * array2 = [[NSArray alloc] initWithObjects:@"20",@"0",@"10",@"25", nil];
    NSArray * array3 = [[NSArray alloc] initWithObjects:@"0.07",@"0.05",@"0.1",@"0.14", nil];
    NSArray * array4 = [[NSArray alloc] initWithObjects:@"22050",@"11025",@"44100", nil];
    self.column1 = array1;
    self.column2 = array2;
    col2[0] = 20;
    col2[1] = 0;
    col2[2] = 10;
    col2[3] = 25;
    
    self.column3 = array3;
    col3[0] = 0.07f;
    col3[1] = 0.05f;
    col3[2] = 0.1f;
    col3[3] = 0.14f;
    
    self.column4 = array4;
    col4[0] = 22050;
    col4[1] = 11025;
    col4[2] = 44100;
    
    [array1 release];
    [array2 release];
    [array3 release];
    [array4 release];
    
    mbStop = false;
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    self.label1 = nil;
    self.label2 = nil;
    self.label3 = nil;
    self.label4 = nil;
    self.stopButton = nil;
    self.column2 = nil;
    self.column1 = nil;
    self.column3 = nil;
    self.column4 = nil;
    self.picker = nil;
    self.itabelView = nil;
    self.listData = nil;
    self.currentFileName = nil;
    self.selectFileName = nil;
    self.button = nil;
    self.scene_mgr = nil;
    self.scene_objectex = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table View Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.listData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //表单元键
    static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier";
    //保存出列单元
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SimpleTableIdentifier];
    //如果出列单元为空，（程序一开始要初始化一个屏幕的表视图单元。以后只要使用出列单元即可，节省内存）
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpleTableIdentifier] autorelease];
    }
    
    //UIImage *image = [UIImage imageNamed:@"star.png"];
    //cell.imageView.image = image;//放在行左侧的图标
    
    NSUInteger row = [indexPath row];
    cell.textLabel.text = [listData objectAtIndex:row];
    cell.textLabel.font = [UIFont boldSystemFontOfSize:18];//设置字体大小
    /*
    if(row < 7)
    {
        cell.detailTextLabel.text = @"Mr. Disney";
    }
    else
    {
        cell.detailTextLabel.text = @"Mr. Tolkien";
    }
    */
    return cell;
}

#pragma mark Table Delegate Methods
- (NSInteger)tableView:(UITableView *)tableView indentationLevelForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSUInteger row = [indexPath row];
    //return row;//缩进级别
    return 0;
}
- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSUInteger row = [indexPath row];
    //if(row == 0)//第一行不能选
    //{
    //    return nil;
    //}
    //else
    //{
    return indexPath;
    //}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row = [indexPath row];
    selectFileName = [listData objectAtIndex:row];
    //[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath//修改行高
{
    return 25;
}

#pragma mark Picker Data Source Methods
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    //return 6;//组件行数
    if (component == 0) {
        return [self.column1 count];
    }
    else if(component == 1)
    {
        return [self.column2 count];
    }
    else if(component == 2)
    {
        return [self.column3 count];
    }
    return [self.column4 count];
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 4;//几个组件
}

#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if(component == 0)
    {
        return [self.column1 objectAtIndex:row];
    }
    else if(component == 1)
    {
        return [self.column2 objectAtIndex:row];
    }
    else if(component == 2)
    {
        return [self.column3 objectAtIndex:row];
    }
    return [self.column4 objectAtIndex:row];
}


@end
