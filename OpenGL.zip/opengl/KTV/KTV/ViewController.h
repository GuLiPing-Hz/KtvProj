//
//  ViewController.h
//  Karaoke
//
//  Created by guliping_imac on 12-9-7.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SceneObjectEx;
@class SceneMgr;

#define kSwitchesSegmentIndex   0

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,UIPickerViewDataSource,UIPickerViewDelegate>
{
    
    
    UIButton * button;
    UIButton * stopButton;
    NSString * currentFileName;
    NSString * selectFileName;
    
    UITableView * itableView;
    NSArray *listData;
    
    UIPickerView * picker;
    NSArray *column1;//算法
    UILabel *label1;
    NSArray *column2;//静音阈值
    UILabel *label2;
    NSArray *column3;//评分
    UILabel *label3;
    NSArray *column4;//采样率
    UILabel *label4;
    
    bool mbStop;
    int col2[4];
    float col3[4];
    double col4[3];
    
@private
    SceneObjectEx * scene_objectex;
    SceneMgr * scene_mgr;
}


//@property(nonatomic, getter=isIdleTimerDisabled) BOOL idleTimerDisabled;
//设置屏幕常亮（YES）
@property (nonatomic,retain) IBOutlet UILabel * label1;
@property (nonatomic,retain) IBOutlet UILabel * label2;
@property (nonatomic,retain) IBOutlet UILabel * label3;
@property (nonatomic,retain) IBOutlet UILabel * label4;
@property (nonatomic,retain) IBOutlet UIButton * stopButton;
@property (nonatomic,retain) IBOutlet UIPickerView * picker;
@property (nonatomic,retain) NSArray *column1;
@property (nonatomic,retain) NSArray *column2;
@property (nonatomic,retain) NSArray *column3;
@property (nonatomic,retain) NSArray *column4;
@property (nonatomic,retain) IBOutlet UITableView * itabelView;
@property (nonatomic,retain) NSString * selectFileName;
@property (nonatomic,retain) NSString * currentFileName;
@property (nonatomic,retain) NSArray *listData;
@property (nonatomic,retain) IBOutlet UIButton *button;
@property (nonatomic,retain) SceneObjectEx * scene_objectex;
@property (nonatomic,retain) SceneMgr * scene_mgr;

- (IBAction)toggleControls:(id)sender;
- (IBAction)buttonPressed;
- (IBAction)stopButtonPressed;
@end
