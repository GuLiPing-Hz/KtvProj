//
//  BBMaterialController.h
//  SpaceRocks
//
//  Created by ben smith on 14/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <QuartzCore/QuartzCore.h>
#import "RenderConfig.h"
#import "KKType.h"

@class Image;

@interface Imageset: NSObject {
    NSString * mImagesetName;
    GLuint mTextureID;
    CGSize mTextureSize;
    NSMutableDictionary * mImages;
    
    GLfloat *vs;        // 顶点坐标    8的倍数
    GLfloat *uvs;       // UV坐标     8的倍数
    GLfloat *cs;        // 颜色       16的倍数
    
    int     cur_geo_idx;
    int     geometry_count;
    GLenum  renderStyle;
    _eQuadSplitMode quad_split_mode;
}

- (void) load: (NSString*) imgset_name;

- (Image*) genImage: (NSDictionary*) plist_item;

- (Image*) getImage: (NSString*)img_name;

- (BOOL) isDefined: (NSString*)img_name;

- (void) addImage: (NSString*) img_name ImageRect: (CGRect) img_rect ImageOffset: (CGPoint) img_offset;

- (void) setTexture: (GLuint) tex_id TextureSize: (CGSize) tex_size;

- (void) draw: (CGRect&) source_rect DestRect: (CGRect&) dest_rect ClipRect: (CGRect*) pclip_rect ColorRect: (KKColorRect&) color_rect;

- (void) resizeGeometryBuffer: (int) count;

// grabs the openGL texture ID from the library and calls the openGL bind texture method
- (void) bindTexture;

- (void) render;

- (void) clear;

@end
