//
//
//  Karaoke
//
//  Created by 天格glp on 12-8-21.
//
//

#import <Foundation/Foundation.h>
@class SceneObject;
@class InputViewController;
@class EAGLView;

@interface SceneMgr : NSObject {
	NSMutableArray * sceneObjects;
    
    NSMutableArray * objectsToAdd;
    NSMutableArray *objectsToRemove;
	
	InputViewController * inputController;
	EAGLView * openGLView;
	
	NSTimer *animationTimer;
	NSTimeInterval animationInterval;
    
    NSTimeInterval deltaTime;
	NSDate * levelStartDate;
    
    // 获取时间
    CFTimeInterval          startTimeInterval;
    CFTimeInterval          curTimeInterval;
    // 每一帧累计的精确到毫秒的值
    unsigned int            durationMS;
}

@property (nonatomic,retain) InputViewController * inputController;
@property (nonatomic,retain) EAGLView * openGLView;
@property (retain) NSDate * levelStartDate;

@property (nonatomic)NSTimeInterval deltaTime;
@property (nonatomic) NSTimeInterval animationInterval;
@property (nonatomic,retain) NSTimer *animationTimer;

+ (SceneMgr*) getSingleton;
- (void) loadScene;
- (void) startScene;
- (void) gameLoop;
- (void) renderScene;
- (void) setAnimationInterval:(NSTimeInterval)interval ;
- (void) setAnimationTimer:(NSTimer *)newTimer ;
- (void) startAnimation ;
- (void) stopAnimation ;
- (void) updateModel: (NSNumber * ) ns_elapsed_ms;

- (void) addObjectToScene:(SceneObject *)object;
- (void) addObjectToRemove:(SceneObject *)object;
- (void) removeObjectFromScene:(SceneObject *)object;

// 11 methods

@end
