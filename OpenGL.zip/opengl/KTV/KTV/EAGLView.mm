//
//  EAGLView.m
//  BBOpenGLIntro
//
//  Created by ben smith on 21/06/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//



#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/EAGLDrawable.h>

#import "EAGLView.h"

#define USE_DEPTH_BUFFER 0
//表示不想使用深度缓冲区，如果要使用，改成1.

// A class extension to declare private methods
@interface EAGLView ()

@property (nonatomic, retain) EAGLContext *context;

- (BOOL) createFramebuffer;
- (void) destroyFramebuffer;

@end


@implementation EAGLView

@synthesize context;


// You must implement this method
+ (Class)layerClass {
    return [CAEAGLLayer class];
}


// The GL view is stored in the nib file. When it's unarchived it's sent -initWithCoder:
- (id)initWithFrame:(CGRect)rect {
    
    if ((self = [super initWithFrame:rect])) {
        // Get the layer
        CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;
        
        eaglLayer.opaque = NO;//不使用透明元素
        eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithBool:NO], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
        //kEAGLDrawablePropertyRetainedBacking表示内容显示之后如何处理内存。
        //保存当前帧的内存就是CAEAGLLayer的后台缓冲，通常都在渲染新的帧，而不需要保存当前帧
        
        //kEAGLDrawablePropertyColorFormat可以设置OpenGL的内存格式，
        //kEAGLColorFormatRGB65会比RGBA8性能好，但是颜色略差。
        
        
        context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        //EAGLContext上下文。基本负责EAGLLayer的渲染。     OpenGL ES 1.1风格
        
        if (!context || ![EAGLContext setCurrentContext:context]) {
//            [self release];
            return nil;
        }
    }
    
    //self.multipleTouchEnabled = YES;//多点触控
    
    return self;
}


- (void)setupViewLandscape
{
    //设置OpenGL ES的矩阵和变换
    glViewport(0, 0, backingWidth, backingHeight);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glRotatef(-90.0f, 0.0f, 0.0f, 1.0f);
    
    //设置视口(照相机)，使其对应屏幕像素
    glOrthof(-backingHeight/2.0, backingHeight/2.0, -backingWidth/2.0, backingHeight/2.0, -1.0f, 1.0f);
    
    glMatrixMode(GL_MODELVIEW);
    //通过黑色清除视图
    glClearColor(0.5f, 0.5f, 0.5f, 0.0f);
}

- (void)setupViewPortrait
{		
	// 设置查看场景需要透过的窗口
	glViewport(0, 0, backingWidth, backingHeight);
	
	// switch to the projection matrix and setup our 'camera lens'
    //切换到投影矩阵模式，并设置“照相机镜头”
	glMatrixMode(GL_PROJECTION);//透视模式（裸眼），正面投射模式（2D，技术性3）
	glLoadIdentity();//清除投影矩阵中的内容，将起设置回单位矩阵。
	glOrthof(-backingWidth/2.0, backingWidth/2.0, -backingHeight/2.0, backingHeight/2.0, -1.0f, 1.0f);//正面模式，左，右，下，上，近，远，glFrustrum 透视模式，参数一样

	// switch to model mode and set our background color
    //切换到模型模式，并设置背景颜色（纯净色）。
	glMatrixMode(GL_MODELVIEW);
//	glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    //通过黑色清除视图
    glClearColor(0.5f, 0.5f, 0.5f, 0.8f);
}


//渲染循环的开始
-(void)beginDraw
{
	// Make sure that you are drawing to the current context
	[EAGLContext setCurrentContext:context];
    //绑定帧缓冲区。告诉OpenGL，用我们定义的帧缓冲区来绘图
	glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
	// make sure we are in model matrix mode and clear the frame
	glMatrixMode(GL_MODELVIEW);
	glClear(GL_COLOR_BUFFER_BIT);
	// set a clean transform空变换。
	glLoadIdentity();//载入单位矩阵（白板）。
}
//渲染循环的结束。
-(void)finishDraw
{
    //绑定渲染缓冲区
	glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
    //传递给上下文，推入屏幕。
	[context presentRenderbuffer:GL_RENDERBUFFER_OES];	
}

- (void)layoutSubviews 
{
    //创建帧缓冲区，并首次设置视图
	[EAGLContext setCurrentContext:context];
	[self destroyFramebuffer];//如果存在帧缓冲区，则销毁
	[self createFramebuffer];//重新创建
	[self setupViewPortrait];
}

- (BOOL)createFramebuffer {
    
    //帧缓冲区，渲染缓冲区，深度缓冲区
    //用于保存渲染单独一帧所需要的各种数据；渲染这一帧所在的位置，渲染之后复制到CAEAGLLayer缓冲区，最后显示到屏幕上。
    glGenFramebuffersOES(1, &viewFramebuffer);
    glGenRenderbuffersOES(1, &viewRenderbuffer);
    
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
	
    [context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)self.layer];
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, viewRenderbuffer);
    
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
    
    if (USE_DEPTH_BUFFER) {//是否使用深度缓冲区（耗性能）
        glGenRenderbuffersOES(1, &depthRenderbuffer);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, depthRenderbuffer);
        glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, backingWidth, backingHeight);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, depthRenderbuffer);
    }
    
    if(glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) {
        NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }
    
    return YES;
}


- (void)destroyFramebuffer {
    
    //销毁所有缓冲，并将引用计数设为0。
    glDeleteFramebuffersOES(1, &viewFramebuffer);
    viewFramebuffer = 0;
    glDeleteRenderbuffersOES(1, &viewRenderbuffer);
    viewRenderbuffer = 0;
    
    if(depthRenderbuffer) {
        glDeleteRenderbuffersOES(1, &depthRenderbuffer);
        depthRenderbuffer = 0;
    }
}

//桌面版本OpenGL提供gluPerspective。通过宽高比和观察视角来定义视锥体
//视场的垂直角度，宽高比，近，远。
-(void)perspectiveFovY:(GLfloat)fovY 
								aspect:(GLfloat)aspect 
								 zNear:(GLfloat)zNear
									zFar:(GLfloat)zFar 
{
	const GLfloat pi = 3.1415926;
	//	Half of the size of the x and y clipping planes.
	// - halfWidth = left, halfWidth = right
	// - halfHeight = bottom, halfHeight = top
	GLfloat halfWidth, halfHeight;
	//	Calculate the distance from 0 of the y clipping plane. Basically trig to calculate
	//	position of clip plane at zNear.
	halfHeight = tan( (fovY / 2) / 180 * pi ) * zNear;	
	//	Calculate the distance from 0 of the x clipping plane based on the aspect ratio.
	halfWidth = halfHeight * aspect;
	//	Finally call glFrustum with our calculated values.
	glFrustumf( -halfWidth, halfWidth, -halfHeight, halfHeight, zNear, zFar );
}



- (void)dealloc {
    
    if ([EAGLContext currentContext] == context) {
        [EAGLContext setCurrentContext:nil];
    }
    
    [context release];
    [super dealloc];
}

@end
