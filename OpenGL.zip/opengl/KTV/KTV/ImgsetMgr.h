//
//  ImgsetMgr.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Imageset;
@class Image;

@interface ImgsetMgr : NSObject
{
@private
    NSMutableDictionary * mImagesets;
}

@property (nonatomic,retain) NSMutableDictionary *mImagesets;

+ (ImgsetMgr *) getSingleton;
- (Imageset *) addImageSet: (NSString *)imgset_name;
- (void) renderAll;

- (Imageset *) getImageset:(NSString *)imgset_name;
- (Image *) getImage:(NSString *)imgset_name ImageName:(NSString *)img_name;

@end