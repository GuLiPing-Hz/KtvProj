//
//
//  Karaoke
//
//  Created by 天格glp on 12-8-21.
//
//

#import <UIKit/UIKit.h>


@interface InputViewController : UIViewController {
	NSMutableSet* touchEvents;
}

@property (nonatomic,retain) NSMutableSet* touchEvents;

//- (BOOL)touchesDidBegin;
- (void)clearEvents;
//- (void)didReceiveMemoryWarning ;
//- (void)loadView ;
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;

// 7 methods



@end
