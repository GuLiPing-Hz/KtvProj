//
//  TransParams.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KKType.h"

// ALPHA 变换参数
@interface TransParams: NSObject
{
@private
    _eTansType	meTransType;		// 变换类型
    BOOL	mbLoop;					// 是否
    BOOL	mbEnd;					// 结束

    CGFloat	mfTransTm;				// 变换时间

    CGFloat	mfAlpha;				// ALPHA值
    CGFloat	mfScale;				// 缩放
    CGFloat	mfAngle;				// 旋转角度

    CGFloat	mfAlphaBegin;			// ALPHA初始值
    CGFloat	mfFadeinTm;				// 淡入延时
    CGFloat	mfDelayTm;				// Alpah值为1.0时(Scale的值为1.0时)显示延时
    CGFloat	mfFadeoutTm;			// 淡出延时

    CGFloat	mfRotateTm;				// 旋转周期时间

    CGFloat	mfFadeinFactor;			// 淡入因子
    CGFloat	mfFadeoutFactor;		// 淡出因子
    CGFloat	mfRotateFactor;			// 旋转因子
};

- (id) init;

- (id) initByParams:
            (BOOL) bLoop
            TransType: (_eTansType) eTransType/* = TRANS_ALPHA */
            AlphaBegin: (CGFloat) fAlphaBegin/* = 0.0f */
            FadeinTm: (CGFloat) fFadeinTm/* = 0.5f */
            DelayTm: (CGFloat) fDelayTm/* = 0.5f */
            FadeoutTm: (CGFloat) fFadeoutTm/* = 0.5f */
            RotateTm: (CGFloat) fRotateTm/* = 0.6f */;

// 重置所有属性
- (void) reset;

// 获取缩放和ALPHA值
- (void) trans: (CGFloat) elapsed_tm;

// 设置是否循环
- (void) setLoop: (BOOL) _loop;

// 获取是否循环
- (BOOL) getLoop;

// 获取Alpha值
- (CGFloat) getAlpha;

// 获取Scale值
- (CGFloat) getScale;

// 获取Angle值
- (CGFloat) getAngle;

// 是否结束
- (BOOL) isEnd;

@end//TransParams

