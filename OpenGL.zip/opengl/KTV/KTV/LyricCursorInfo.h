//
//  LyricCursorInfo.h
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "KKType.h"

//-----------------------------------------------------------------------------
// 光标信息
@interface _tGuiLyricCursorInfo : NSObject {
    int	x;
    int	y;
    bool b;											// 是否落在标准谱线Y位置的某个区间内
    int r;
}

@property (assign) int x;
@property (assign) int y;
@property (assign) bool b;
@property (assign) int r;

- (id) init;

- (id) initWithParams: (int) _x
               YValue: (int) _y
               BValue: (bool) _b
               RValue:(int)_r;

@end
