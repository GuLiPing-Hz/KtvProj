//
//  Imageset.h
//  Imageset
//
//  Created by 天格 on 12-8-21.
//
//

#import "Imageset.h"
#import "Image.h"

const uint VERTEX_FLOAT_COUNT = 2;
const uint COLOR_FLOAT_COUNT = 4;
const uint GEOMETRY_VERTEX_COUNT = 6;

@implementation Imageset

- (id) init
{
	self = [super init];
    
    cur_geo_idx = 0;
    geometry_count = 0;
    renderStyle = GL_TRIANGLES;
    quad_split_mode = TopLeftToBottomRight;
    
    if (mImages == nil)
    {
        mImages = [[NSMutableDictionary alloc] init];
    }
    
	return self;
}

- (void) load: (NSString*) imgset_name
{
    // 保存Imageset名称
    mImagesetName = [[NSString alloc] initWithFormat: @"%@", imgset_name];
    
	if (mImages == nil)
    {
        mImages = [[NSMutableDictionary alloc] init];
    }
    
	//加载图册
	mTextureSize = [self loadTextureImage:[imgset_name stringByAppendingPathExtension:@"png"] ImagesetName:imgset_name];
    
    //读取元数据，
	NSArray * plist_items = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imgset_name ofType:@"plist"]];
	//遍历元数据，为每种纹理构件一个新的四边形。
	for (NSDictionary * plist_item in plist_items) {
		Image * img = [self genImage:plist_item];
		[mImages setObject:img forKey:[plist_item objectForKey:@"name"]];
	}
}

- (Image*) getImage: (NSString*)img_name
{
	return [mImages objectForKey:img_name];
}

- (BOOL) isDefined: (NSString*)img_name
{
    if ( [mImages objectForKey: img_name] )
    {
        return YES;
    }
    return NO;
}

- (void) addImage: (NSString*) img_name ImageRect: (CGRect) img_rect ImageOffset: (CGPoint) img_offset
{
	Image * img = [[Image alloc] init];
   	// find the normalized texture coordinates计算归一化的纹理坐标
	img.rect = img_rect;
    img.offset = img_offset;
	img.imgset = self;
    
    [mImages setObject:img forKey:img_name];
    [img release];///////////glp
}

- (Image*) genImage: (NSDictionary*) plist_item
{
	GLfloat x = [[plist_item objectForKey:@"xLocation"] floatValue];
	GLfloat y = [[plist_item objectForKey:@"yLocation"] floatValue];
	GLfloat w = [[plist_item objectForKey:@"width"] floatValue];
	GLfloat h = [[plist_item objectForKey:@"height"] floatValue];
    
	CGRect rect = CGRectMake(x,y,w,h);
	Image * img = [[Image alloc] init];
   	// find the normalized texture coordinates计算归一化的纹理坐标
	img.rect = rect;
	img.imgset = self;
    return [img autorelease];/////////////glp
}

- (void) setTexture: (GLuint) tex_id TextureSize: (CGSize) tex_size
{
    mTextureID = tex_id;
    mTextureSize = tex_size;
}

- (void) drawVertex: (int)geometry_index VertexIndex: (int) vertex_index Position: (CGPoint) position Color: (KKColor&) colour_val TexCoords: (CGPoint) tex_coords
{
    int uv_idx = cur_geo_idx * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT + vertex_index * VERTEX_FLOAT_COUNT;
    int v_idx = cur_geo_idx * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT + vertex_index * VERTEX_FLOAT_COUNT;
    int c_idx = cur_geo_idx * GEOMETRY_VERTEX_COUNT * COLOR_FLOAT_COUNT + vertex_index * COLOR_FLOAT_COUNT;
    
    static CGFloat half_width = window_size.width / 2;
    static CGFloat half_height = window_size.height / 2;

    vs[v_idx+0] = position.x - half_width;
    vs[v_idx+1] = half_height - position.y;
    
    uvs[uv_idx+0] = tex_coords.x;
	uvs[uv_idx+1] = tex_coords.y;

    cs[c_idx+0]   = colour_val.r;
    cs[c_idx+1]   = colour_val.g;
    cs[c_idx+2]   = colour_val.b;
    cs[c_idx+3]   = colour_val.a;
}

// grabs the openGL texture ID from the library and calls the openGL bind texture method
- (void) draw: (CGRect&) source_rect DestRect: (CGRect&) dest_rect ClipRect: (CGRect*) pclip_rect ColorRect: (KKColorRect&) color_rect
{
    if ( cur_geo_idx >= geometry_count )
    {
        int count = 16;
        if ( 0 != geometry_count )
        {
            count = geometry_count * 2;
        }
        [self resizeGeometryBuffer: count];
    }
    CGRect final_rect = dest_rect;
    
    if ( pclip_rect != nil )
    {
        final_rect = CGRectIntersection( dest_rect, *pclip_rect );
    }
    
    if ( final_rect.size.width == 0 || final_rect.size.height == 0 )
    {
        return;
    }
    
    float tex_per_pix_x = source_rect.size.width / dest_rect.size.width;
    float tex_per_pix_y = source_rect.size.height / dest_rect.size.height;
    
    CGFloat l = (source_rect.origin.x + ((final_rect.origin.x - dest_rect.origin.x) * tex_per_pix_x));
    CGFloat t = (source_rect.origin.y + ((final_rect.origin.y - dest_rect.origin.y) * tex_per_pix_y));
    CGFloat r = (source_rect.origin.x + source_rect.size.width + ((final_rect.origin.x + final_rect.size.width - dest_rect.origin.x - dest_rect.size.width ) * tex_per_pix_x));
    CGFloat b = (source_rect.origin.y + source_rect.size.height + ((final_rect.origin.y + final_rect.size.height - dest_rect.origin.y - dest_rect.size.height) * tex_per_pix_y));
    
    GLfloat uMin = l / mTextureSize.width;
    GLfloat vMin = t / mTextureSize.height;
    GLfloat uMax = r / mTextureSize.width;
    GLfloat vMax = b / mTextureSize.height;
    
    CGPoint pos_left_top = CGPointMake(final_rect.origin.x, final_rect.origin.y);
    CGPoint pos_left_bottom = CGPointMake(final_rect.origin.x, final_rect.origin.y + final_rect.size.height);
    CGPoint pos_right_top = CGPointMake(final_rect.origin.x + final_rect.size.width, final_rect.origin.y);
    CGPoint pos_right_bottom = CGPointMake(final_rect.origin.x + final_rect.size.width, final_rect.origin.y + final_rect.size.height);
    
    CGPoint tex_left_top = CGPointMake(uMin,vMin);
    CGPoint tex_left_bottom = CGPointMake(uMin,vMax);
    CGPoint tex_right_top = CGPointMake(uMax,vMin);
    CGPoint tex_right_bottom = CGPointMake(uMax,vMax);
    
    // vertex 0
    [self drawVertex: cur_geo_idx VertexIndex: 0 Position: pos_left_top Color:color_rect.left_top_color TexCoords: tex_left_top];
    
    // vertex 1
    [self drawVertex: cur_geo_idx VertexIndex: 1 Position: pos_left_bottom Color:color_rect.left_bottom_color TexCoords: tex_left_bottom];
    
    // vertex 2
    // top-left to bottom-right diagonal
    if (quad_split_mode == TopLeftToBottomRight)
    {
        [self drawVertex: cur_geo_idx VertexIndex: 2 Position: pos_right_bottom Color:color_rect.right_bottom_color TexCoords: tex_right_bottom];
    }
    // bottom-left to top-right diagonal
    else
    {
//        [self drawVertex: cur_geo_idx VertexIndex: 2 Position: pos_right_top Color:color_rect.right_bottom_color TexCoords: tex_right_top];
        [self drawVertex: cur_geo_idx VertexIndex: 2 Position: pos_right_top Color:color_rect.right_top_color TexCoords: tex_right_top];
    }

    // vertex 3
    [self drawVertex: cur_geo_idx VertexIndex: 3 Position: pos_right_top Color:color_rect.right_top_color TexCoords: tex_right_top];
    
    // vertex 4
    // top-left to bottom-right diagonal
    if (quad_split_mode == TopLeftToBottomRight)
    {
        [self drawVertex: cur_geo_idx VertexIndex: 4 Position: pos_left_top Color:color_rect.left_top_color TexCoords: tex_left_top];
    }
    // bottom-left to top-right diagonal
    else
    {
//        [self drawVertex: cur_geo_idx VertexIndex: 4 Position: pos_left_bottom Color:color_rect.left_top_color TexCoords: tex_left_bottom];
        [self drawVertex: cur_geo_idx VertexIndex: 4 Position: pos_left_bottom Color:color_rect.left_bottom_color TexCoords: tex_left_bottom];
    }
        
    // vertex 5
    [self drawVertex: cur_geo_idx VertexIndex: 5 Position: pos_right_bottom Color:color_rect.right_bottom_color TexCoords: tex_right_bottom];

    cur_geo_idx++;
}

- (void) resizeBuffer: (GLfloat**) buffer OldSize: (int) old_size NewSize: (int) new_size
{
    GLfloat * temp = (GLfloat *)(malloc( new_size ));
    if ( *buffer )
    {
        memcpy(temp, *buffer, old_size );
        free( *buffer );
        *buffer = temp;
    }
    else
    {
        *buffer = temp;
    }    
}

- (void) resizeGeometryBuffer: (int) count
{
    if ( geometry_count == count )
    {
        return;
    }
    
    int old_size = sizeof(GLfloat) * geometry_count * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT;
    int new_size = sizeof(GLfloat) * count * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT;
    [self resizeBuffer: &vs OldSize:old_size NewSize: new_size];
    [self resizeBuffer: &uvs OldSize:old_size NewSize: new_size];
    old_size = sizeof(GLfloat) * geometry_count * GEOMETRY_VERTEX_COUNT * COLOR_FLOAT_COUNT;
    new_size = sizeof(GLfloat) * count * GEOMETRY_VERTEX_COUNT * COLOR_FLOAT_COUNT;
    [self resizeBuffer: &cs OldSize:old_size NewSize: new_size];

    geometry_count = count;
}

- (void) bindTexture
{
	glEnable(GL_TEXTURE_2D);                    //启动纹理
	glBindTexture(GL_TEXTURE_2D, mTextureID);   //绑定纹理，系统开销可能很大，尽可能将使用同一种纹理的对象组织在一起。
}

// does the heavy lifting for getting a named image into a texture
// that is loaded into openGL
// this is a modified version of the way Apple loads textures in their sample code
-(CGSize)loadTextureImage: (NSString*) imgfile_name ImagesetName: (NSString*) imgset_name
{
	CGContextRef spriteContext; //UIImage的上下文引用
	GLubyte *spriteData; // 保存图像数据的临时缓冲
	size_t	width, height;
    
	// 从文件系统中获得图像，将图像存入spriteImage中
	UIImage*	uiImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imgfile_name ofType:nil]];
    //如果用imageNamed方法会完成图像数据的一些自动缓存，这些图像数据我们不需要缓存。
	CGImageRef spriteImage = [uiImage CGImage];
	// Get the width and height of the image
	width = CGImageGetWidth(spriteImage);
	height = CGImageGetHeight(spriteImage);
	
	CGSize imageSize = CGSizeMake(width, height);
	// Texture dimensions must be a power of 2. If you write an application that allows users to supply an image,
	// you'll want to add code that checks the dimensions and takes appropriate action if they are not a power of 2.
	
	if (spriteImage) {
		// 分配位图上下文所需要的内存
		spriteData = (GLubyte *) malloc(width * height * 4);
		memset(spriteData, 0, (width * height * 4));
		// 创建一个大小和格式都正确的上下文 （for a 32-bit pixel format and an RGB color space, you would specify a value of 8 bits per component）
		spriteContext = CGBitmapContextCreate(spriteData, width, height, 8, width * 4, CGImageGetColorSpace(spriteImage), kCGImageAlphaPremultipliedLast);
        
		// After you create the context, 在上下文中绘制图像。
		CGContextDrawImage(spriteContext, CGRectMake(0.0, 0.0, (CGFloat)width, (CGFloat)height), spriteImage);
		// You don't need the context at this point, so you need to release it to avoid memory leaks.
		CGContextRelease(spriteContext);
		CGImageRelease(spriteImage);/////////////////glp
		// Use OpenGL ES to generate a name for the texture.
        //通知OpenGL为新的纹理预留空间，并且为这个纹理生成一个ID。
		glGenTextures(1, &mTextureID);
		// Bind the texture name. 通知OpenGL使得纹理ID表示的纹理成为活动纹理
		glBindTexture(GL_TEXTURE_2D, mTextureID);
		// Specidfy a 2D texture image, provideing the a pointer to the image data in memory
		
		//Convert "RRRRRRRRGGGGGGGGBBBBBBBBAAAAAAAA" to "RRRRGGGGBBBBAAAA"
		// this will make your images take up half as much space in memory
		// but you will lose half of your color depth.
		if ( CONVERT_TO_4444 ) {
			void*					tempData;
			unsigned int*			inPixel32;
			unsigned short*			outPixel16;
			
			tempData = malloc(height * width * 2);
			
			inPixel32 = (unsigned int*)spriteData;
			outPixel16 = (unsigned short*)tempData;
			NSUInteger i;
			for(i = 0; i < width * height; ++i, ++inPixel32)
				*outPixel16++ = ((((*inPixel32 >> 0) & 0xFF) >> 4) << 12) | ((((*inPixel32 >> 8) & 0xFF) >> 4) << 8) | ((((*inPixel32 >> 16) & 0xFF) >> 4) << 4) | ((((*inPixel32 >> 24) & 0xFF) >> 4) << 0);
			
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_SHORT_4_4_4_4, tempData);
			free(tempData);
		} else {
            //将图像数据压入OpenGL视频内存。
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, spriteData);
		}
		//释放图像数据。
		free(spriteData);
		// Release the image data
		// Set the texture parameters to use a minifying filter and a linear filer (weighted average)
        //设置纹理参数。告诉OpenGl在纹理不完全匹配的时候处理其中的像素方式。
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        //模糊滤波器（缩小）
        
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        //锐化滤波器（放大）
		
		// 启用2D纹理功能。
		glEnable(GL_TEXTURE_2D);
		// 设置要使用的一个混合函数。告诉OpenGL如何处理半透明的纹理
		//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		// 启用混合
		glEnable(GL_BLEND);
	} else {
        NSLog(@"no texture");
		return CGSizeZero;
	}
	
	return imageSize;
}

- (void) render
{
    glVertexPointer(2, GL_FLOAT, 0, vs);
    glEnableClientState(GL_VERTEX_ARRAY);
    glColorPointer(4, GL_FLOAT, 0, cs);
    glEnableClientState(GL_COLOR_ARRAY);
    
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, uvs);
    
    glDrawArrays(renderStyle, 0, GEOMETRY_VERTEX_COUNT * cur_geo_idx );
}

- (void) clear
{
    cur_geo_idx = 0;
}

- (void) dealloc
{
    [mImagesetName release];
	[mImages release];
    if(mTextureID !=0)
    {
        mTextureID = 0;
    }
	[super dealloc];
    
}

@end

