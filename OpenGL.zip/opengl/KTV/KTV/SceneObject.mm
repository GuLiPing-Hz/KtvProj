//
//  SceneObject.m
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//

#import "SceneObject.h"
#import "SceneMgr.h"
#import "InputViewController.h"
#import "ImgsetMgr.h"
#import "Image.h"

#pragma mark Spinny Square mesh

@implementation SceneObject

@synthesize active, meshBounds;

- (void)dealloc
{
    [super dealloc];
}

- (id) init
{
	self = [super init];
	if (self != nil) {
		active = NO;
		meshBounds = CGRectZero;
	}
	return self;
}

// called once when the object is first created.
-(void)awake
{
    /*
    ImgsetMgr * imgsetmgr = [ImgsetMgr getSingleton];
    [imgsetmgr addImageSet:@"renderer"];
    Image *img = [imgsetmgr getImage:@"renderer" ImageName:@"Number5"];
    [img draw:spinnySquareVertices andColors:spinnySquareColors];
     */
}

// called once every frame
-(void)update: (NSNumber * ) ns_elapsed_ms
{
	/*glPushMatrix();
	glLoadIdentity();
	
	// move to my position
	glTranslatef(translation.x, translation.y, translation.z);
	
	// rotate
	glRotatef(rotation.x, 1.0f, 0.0f, 0.0f);
	glRotatef(rotation.y, 0.0f, 1.0f, 0.0f);
	glRotatef(rotation.z, 0.0f, 0.0f, 1.0f);
	
	//scale
	glScalef(scale.x, scale.y, scale.z);
	// save the matrix transform
	glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
	//restore the matrix
	glPopMatrix();
	//if (collider != nil) [collider updateCollider:self];
    
    NSSet * touches = [[SceneMgr sharedSceneController].inputController touchEvents];
	for (UITouch * touch in [touches allObjects]) {
		// then we toggle our active state
		if (touch.phase == UITouchPhaseEnded) {
			active = !active;
		}
	}
	
	// if we are currently active, we will update our zRotation by 3 degrees
	if (active)
    {
        rotation.z += 3.0;
        translation.x -= 1.0;
    }
    if(translation.x < -160)
    {
        translation.x = 160;
        //outOfArena = YES;
    }
    */
}

// called once every frame
/*
 
-(void)render
{
	if (!mesh) return; // if we do not have a mesh, no need to render
	// clear the matrix
	glPushMatrix();
	glLoadIdentity();
	glMultMatrixf(matrix);
	[mesh render];	
	glPopMatrix();
}
*/

@end
