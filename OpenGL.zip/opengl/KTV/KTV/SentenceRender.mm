//
//  SentenceRender.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "SentenceRender.h"
#import "ImgsetMgr.h"

const int COUNTDOWN = 2000;

@implementation SentenceRender

//-----------------------------------------------------------------------------


- (void) dealloc
{
    [mNumberImages release];
	[mGradeImages release];
    [super dealloc];
}

- (id) init
{
    self = [super init];
    
    Image * img = nil;
    Imageset * imgset = [[ImgsetMgr getSingleton] getImageset:@"renderer"];
    mNumberImages = [[NSMutableArray alloc] initWithCapacity:10];
    
    for ( int i = 0; i < 10; ++i )
    {
        NSString * temp = [[NSString alloc] initWithFormat:@"Number%d", i];
        img = [imgset getImage:temp];
        if ( img )
        {
            [mNumberImages addObject:img];
        }
    }

    mGradeImages = [[NSMutableArray alloc] initWithCapacity:5];
    if ( nil != (img = [imgset getImage:@"Miss"]) ) [mGradeImages addObject:img];
    if ( nil != (img = [imgset getImage:@"Poor"]) ) [mGradeImages addObject:img];
    if ( nil != (img = [imgset getImage:@"Good"]) ) [mGradeImages addObject:img];
    if ( nil != (img = [imgset getImage:@"Great"]) ) [mGradeImages addObject:img];
    if ( nil != (img = [imgset getImage:@"Perfect"]) ) [mGradeImages addObject:img];

    return self;
}

//-----------------------------------------------------------------------------
- (void) invalidate
{
    mbInvalidate = true;
    miCountDown = COUNTDOWN;
}

//-----------------------------------------------------------------------------
- (void) showSentenceLevel: (_eSentenceGradeLevel) sentence_level
{
    meSentenceGradeLevel = sentence_level;
    [self invalidate];
}

//-----------------------------------------------------------------------------
- (void) showSentenceScore: (int) score
{
    mnScore = score < 0 ? 0 : ( score > 2000 ? 2000 : score );
	[self invalidate];
}


//-----------------------------------------------------------------------------
- (void) update: (unsigned int) elapsed_ms
{
    if ( mbInvalidate )
    {
        miCountDown -= elapsed_ms;
        if ( miCountDown < 0 )
        {
            mbInvalidate = false;
        }
    }
}

//-----------------------------------------------------------------------------
- (void) reset
{
	meSentenceGradeLevel = SENTENCEGRADELEVEL_NONE;
	mnScore = 0;
    
    // hjp
    // renderer.png对应的Imageset中的uvs vs cs 都已经在WaveRender中清空
    /*
	GeometryBuffer & geo = getGeometryBuffer();
	geo.reset();
    */
    // hjp
}

//-----------------------------------------------------------------------------
- (void) populateGeometryBuffer
{
    if ( !mbInvalidate )
    {
        return;
    }
    
    if ( [mNumberImages count] != 10 || [mGradeImages count] != 5 )
    {
        return;
    }
    
    // 渲染分数
	float pos_x = 320.0f;
    float pos_y = 9.0f;
    
    int score = mnScore;
    
	Image * img = nil;
    do
    {
        int i = ( score ) % 10;
        img = [mNumberImages objectAtIndex:i];
        if ( img )
        {
            CGRect dest_rect = CGRectMake( pos_x - img.rect.size.width, pos_y, img.rect.size.width, img.rect.size.height );
            [img draw: dest_rect ClipRect: nil ColorRect: COLOR_RECT_WHITE];
            
            pos_x -= img.rect.size.width;
        }
        score /= 10;
	}
    while( score );
    
    // 渲染句评分等级
    pos_x = 126.0f;
    pos_y = 16.0f;
    int grade_level = ((int)meSentenceGradeLevel) - 1;
    if ( grade_level >= 0 && grade_level <= 4 )
    {
        img = [mGradeImages objectAtIndex: grade_level];
        if ( img )
        {
            CGRect dest_rect = CGRectMake( pos_x, pos_y, img.rect.size.width, img.rect.size.height );
            [img draw: dest_rect ClipRect: nil ColorRect: COLOR_RECT_WHITE];
        }
    }
}

@end // SentenceScore