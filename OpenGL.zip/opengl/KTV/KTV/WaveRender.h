//
//  WaveRender.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KKType.h"
#import "Image.h"
#import "Imageset.h"
#import "TransParams.h"

//-----------------------------------------------------------------------------
@interface WaveRender : NSObject
{
@private
	float							mfStartPos;
	NSMutableArray *                mVecWave;           // 谱线(_tGuiWaveInfo)
	NSMutableArray *                mVecCursors;        // 游标数组(_tGuiLyricCursorInfo)
	NSMutableArray *                mVecCursorsPos;     // (_tGuiLyricCursorInfo)
	_tGuiLyricCursorInfo *          mLyricCursorInfo;   // 游标
	NSMutableArray *                mSentenceLineList;  // 句尾线(int)
	CGPoint                         mLyricCursorPos;
	CGPoint                         mLyricLastCursorPos;
	bool							mbKtvMode;
	float							mfKtvErr;
	float							mfGameErr;
	int								mStandard_y;

	// 标准的谱线
	Image *							mImageWaveLeft0;
	Image *							mImageWaveMiddle0;
	Image *							mImageWaveRight0;

	// 谱线光环
	Image *							mImageWaveLeft1;
	Image *							mImageWaveMiddle1;
	Image *							mImageWaveRight1;

	// 歌唱的靠谱的谱线
	Image *							mImageWaveLeft2;
	Image *							mImageWaveMiddle2;
	Image *							mImageWaveRight2;

	// 标准的不靠谱的谱线
	Image *							mImageWaveLeft3;
	Image *							mImageWaveMiddle3;
	Image *							mImageWaveRight3;

	Image *							mImageWave;

	bool							mbEnableWaveEffect;		// 打开谱线光环效果
	TransParams *                   mImageWaveTrans;		// 设置谱线周围光环的Alpha值

	bool							mbEnableMoveImage;		// 是否显示谱线上的移动光标
    bool                            mbInvalidate;
}

// 构造函数
- (id) init;

// 设置曲谱模式是否为KTV模式(曲谱模式:KTV模式,游戏模式)
- (void) setMode: (bool) ktv_mode;

// 设置谱线(NSArray _tGuiWaveInfo)
- (void) setLineGroup: ( NSMutableArray * ) wave_list Refresh: (bool) refresh/* = false */;

// 设置游标
- (void) setLyricCursor: (_tGuiLyricCursorInfo*) ci KtvError: (float) ktvErr GameError: (float) gameErr;

//
- (void) setStandardY: ( int ) y;

// 设置单句移动速度
- (void) setMovePos: ( float ) position;

// 清除游标
- (void) clearLyricCursor;

// 设置句尾线(std::vector<int>)
- (void) setSentenceLineList: (NSMutableArray *) sentenceline_list Refresh: (bool) refresh/* = false */;

// update self
- (void) updateSelf: (float) elapsed;

//
- (void) reset;

// 开启/关闭谱线光环特效
- (void) enableWaveEffect: ( bool ) enable/* = true */;

- (void) populateGeometryBuffer;

// 绘制句尾线(std::vector<int>)
- (void) _drawSentenceLine: (NSMutableArray *) sentenceline_list;

// 绘制游戏模式光标
- (void) _drawCursor;

// 绘制谱线(std::vector<_tGuiWaveInfo>)
- (void) _drawPitch: (NSMutableArray *) waves;

// 计算游标绝对位置
- (void) _locateCursor;

// 处理游标队列
- (void) _dealWithCursor: (_tGuiLyricCursorInfo*) ci;

@end //WaveRender
