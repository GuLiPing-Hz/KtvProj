#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioQueue.h>
#import <AudioToolbox/AudioServices.h>

#import "AQPlayer.h"
#import "AQRecorder.h"

#import "eval.h"

@interface AudioModule : NSObject {
	AQPlayer*					player;
	AQRecorder*					recorder;
	BOOL						playbackWasInterrupted;
	BOOL						playbackWasPaused;
    
    UInt32                      inputAvailable;
	
	CFStringRef					recordFilePath;
    
    float                       mkBufferDurationSeconds;
    double                      msampleRate;
    float                      mdBUpperLimit;
}

@property (readonly)			AQPlayer			*player;
@property (readonly)			AQRecorder			*recorder;
@property						BOOL				playbackWasInterrupted;

- (id)init:(float) kBufferDurationSeconds andSampleRate:(double) sampleRate anddBUpperLimit:(double)dBUpperLimit;
- (void)awakeFromNib;
- (void)initRecorder: (eval *) e CallbackObject: (id) call_back_object;
- (void)record;
- (void)play: (const char*) file_name;
- (AQPlayer *)getPlayer;
- (AQRecorder *)getRecorder;

@end
