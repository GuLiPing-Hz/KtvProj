/*
 
 File: AQRecorder.mm
 Abstract: n/a
 Version: 2.4
 
 Disclaimer: IMPORTANT:  This Apple software is supplied to you by Apple
 Inc. ("Apple") in consideration of your agreement to the following
 terms, and your use, installation, modification or redistribution of
 this Apple software constitutes acceptance of these terms.  If you do
 not agree with these terms, please do not use, install, modify or
 redistribute this Apple software.
 
 In consideration of your agreement to abide by the following terms, and
 subject to these terms, Apple grants you a personal, non-exclusive
 license, under Apple's copyrights in this original Apple software (the
 "Apple Software"), to use, reproduce, modify and redistribute the Apple
 Software, with or without modifications, in source and/or binary forms;
 provided that if you redistribute the Apple Software in its entirety and
 without modifications, you must retain this notice and the following
 text and disclaimers in all such redistributions of the Apple Software.
 Neither the name, trademarks, service marks or logos of Apple Inc. may
 be used to endorse or promote products derived from the Apple Software
 without specific prior written permission from Apple.  Except as
 expressly stated in this notice, no other rights or licenses, express or
 implied, are granted by Apple herein, including but not limited to any
 patent rights that may be infringed by your derivative works or by other
 works in which the Apple Software may be incorporated.
 
 The Apple Software is provided by Apple on an "AS IS" basis.  APPLE
 MAKES NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION
 THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND
 OPERATION ALONE OR IN COMBINATION WITH YOUR PRODUCTS.
 
 IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL
 OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION,
 MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED
 AND WHETHER UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE),
 STRICT LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.
 
 Copyright (C) 2009 Apple Inc. All Rights Reserved.
 
 
 */

#include "AQRecorder.h"
#import "SceneObjectEx.h"
#import "TargetConditionals.h"
#include "stdio.h"

#define MAKESHORT(low,high) ((short)((unsigned short)(((unsigned char)(low)) | ((unsigned short)((unsigned char)(high))) << 8)))

float   AQRecorder::mkBufferDurationSeconds;

// ____________________________________________________________________________________
// Determine the size, in bytes, of a buffer necessary to represent the supplied number
// of seconds of audio data.
int AQRecorder::ComputeRecordBufferSize(const AudioStreamBasicDescription *format, float seconds)
{
	int packets, frames, bytes = 0;
	try {
		frames = (int)ceil(seconds * format->mSampleRate);
		
		if (format->mBytesPerFrame > 0)
			bytes = frames * format->mBytesPerFrame;
		else {
			UInt32 maxPacketSize;
			if (format->mBytesPerPacket > 0)
				maxPacketSize = format->mBytesPerPacket;	// constant packet size
			else {
				UInt32 propertySize = sizeof(maxPacketSize);
				XThrowIfError(AudioQueueGetProperty(mQueue, kAudioQueueProperty_MaximumOutputPacketSize, &maxPacketSize,
                                                    &propertySize), "couldn't get queue's maximum output packet size");
			}
			if (format->mFramesPerPacket > 0)
				packets = frames / format->mFramesPerPacket;
			else
				packets = frames;	// worst-case scenario: 1 frame in a packet
			if (packets == 0)		// sanity check
				packets = 1;
			bytes = packets * maxPacketSize;
		}
	} catch (CAXException e) {
		char buf[256];
		fprintf(stderr, "Error: %s (%s)\n", e.mOperation, e.FormatError(buf));
		return 0;
	}
	return bytes;
}

// ____________________________________________________________________________________
// 转换为浮点型
void AQRecorder::GetMonoWaveData( const CAStreamBasicDescription & RecordFormat, unsigned char * indata, unsigned int indata_size, float *& outdata, unsigned int & outdata_size )
{
	//data_size意义是所有样本 * 每个样本所占的字节数
	
	//分别处理8bit和16bit的情况
	//8bit mono: 每个样本一个字节
	if (RecordFormat.mBitsPerChannel == 8)
    {
        outdata_size = indata_size;
        outdata = new float[outdata_size];
		for(unsigned int i = 0; i < indata_size; i++)
		{
			// make signed from unsigned
            unsigned char & uc = indata[i];
            /*
            if ( uc > 128 )
            {
                fprintf( stdout, "xxx");
            }
            */
			outdata[i] = (float)( uc - 128 );
		}
	}
	else if (RecordFormat.mBitsPerChannel == 16)
	{
        outdata_size = indata_size / 2;
        outdata = new float[outdata_size];
        
		//16bit mono: 每个样本两个字节
		//16bit的wave本身是从32767 ~ -32768
		//而负数的表示是由最高位为1来表示的
		//因此当用BYTE取得数据后拼装转换成WORD是无符号数据
		for(int i=0, j=0; i < indata_size; i=i+2, j++)
		{
			unsigned low, high;
			low = indata[i];
			high = indata[i+1];
			//MAKEWORD(low,high)把两个字节组合成16位的无符号数
			//(__int16)把16位的无符号数强制转换成有符号数, 注:如果用(int)则不行
			outdata[j] = (float)MAKESHORT(low, high);
		}
	}
}

// ____________________________________________________________________________________

bool AQRecorder::ReadTmpWav(char* &outBuffer, uint &outSize)
{
    NSString *basePath0 = [[NSBundle mainBundle] bundlePath];
    NSRange range = [basePath0 rangeOfString:@"/KTV.app"];
    NSString *basePath1 = [basePath0 substringWithRange:NSMakeRange(0, range.location)];
    //NSString *path = [[NSString alloc] initWithFormat:@"%@/Documents/wav/", basePath1];
    
    char cpath[256] = {0};
    sprintf(cpath, "%s/Documents/wav/wavread.tmp",[basePath1 UTF8String]);
    FILE * fp = fopen(cpath, "rb");
    if (fp == NULL) {
        NSLog(@"wavread.tmp open error");
        return false;
    }

    outSize = fread(outBuffer, 1, outSize, fp);
    fclose(fp);

    return true;
}
// AudioQueue callback function, called when an input buffers has been filled.
void AQRecorder::MyInputBufferHandler(	void *								inUserData,
                                      AudioQueueRef						inAQ,
                                      AudioQueueBufferRef					inBuffer,
                                      const AudioTimeStamp *				inStartTime,
                                      UInt32								inNumPackets,
                                      const AudioStreamPacketDescription*	inPacketDesc)
{
	AQRecorder *aqr = (AQRecorder *)inUserData;
	try {
		if (inNumPackets > 0) {
			// write packets to file
			XThrowIfError(AudioFileWritePackets(aqr->mRecordFile, FALSE, inBuffer->mAudioDataByteSize,
                                                inPacketDesc, aqr->mRecordPacket, &inNumPackets, inBuffer->mAudioData),
                          "AudioFileWritePackets failed");
            
            float * outdata = NULL;
            unsigned int outdata_size = 0;
            GetMonoWaveData( aqr->mRecordFormat, (unsigned char*)inBuffer->mAudioData, (unsigned int)inBuffer->mAudioDataByteSize, outdata, outdata_size );
            
            NSString *basePath0 = [[NSBundle mainBundle] bundlePath];
            NSRange range = [basePath0 rangeOfString:@"/KTV.app"];
            NSString *basePath1 = [basePath0 substringWithRange:NSMakeRange(0, range.location)];
            //NSString *path = [[NSString alloc] initWithFormat:@"%@/Documents/wav/", basePath1];
            
            char cpath[256] = {0};
            sprintf(cpath, "%s/Documents/wav/wavread.tmp",[basePath1 UTF8String]);
            FILE * fp = fopen(cpath, "ab");
            if (fp == NULL) {
                NSLog(@"wavread.tmp open error");
            }
            else
            {
                fwrite((unsigned char*)inBuffer->mAudioData, 1, (unsigned int)inBuffer->mAudioDataByteSize, fp);
                fflush(fp);
                fclose(fp);
            }
            
            
            unsigned int sentence_index = -1;
            float pitch = 0.0f;
            float pitchdiff = 1000.0f;
            float realtime_score = 0.0f;
            unsigned int rank = 0.0f;
            float accumulated_sentence_score = 0.0f;
            bool switch_sentence = false;
            
            [aqr->mEvalInstance realtimeEval:outdata BufferSize:outdata_size CurTimeMs:aqr->mnCurTimeMs Pitch:pitch RealtimeScore:realtime_score Rank:rank SentenceIndex: sentence_index AccumulatedSentenceScore:accumulated_sentence_score SwitchSentence:switch_sentence];
            
            _tRealtimeGrade realtime_grade;
            realtime_grade.cur_tm = aqr->mnCurTimeMs;
            realtime_grade.cur_pitch = pitch;
            realtime_grade.sentence_index = sentence_index;
            realtime_grade.realtime_score = realtime_score;
            realtime_grade.accumulate_score = accumulated_sentence_score;
            SceneObjectEx * obj = (SceneObjectEx*)aqr->mSceneObjectEx;
            [obj RealtimeGrade: realtime_grade];

            aqr->mSentenceGrade.sentence_score = accumulated_sentence_score;
            if ( switch_sentence )
            {
                if ( accumulated_sentence_score > 800 )
                    aqr->mSentenceGrade.sentence_level = SENTENCEGRADELEVEL_PERFECT;
                else if ( accumulated_sentence_score > 700 )
                    aqr->mSentenceGrade.sentence_level = SENTENCEGRADELEVEL_GREAT;
                else if ( accumulated_sentence_score > 600 )
                    aqr->mSentenceGrade.sentence_level = SENTENCEGRADELEVEL_GOOD;
                else if ( accumulated_sentence_score > 300 )
                    aqr->mSentenceGrade.sentence_level = SENTENCEGRADELEVEL_POOR;
                else
                    aqr->mSentenceGrade.sentence_level = SENTENCEGRADELEVEL_MISS;
                
                [obj SentenceGrade:aqr->mSentenceGrade];
            }
            if ( sentence_index != -1 )
            {
                aqr->mSentenceGrade.sentence_index = sentence_index;
            }
            
            /*
            fprintf(stdout, "SentenceIndex[%d] cur_timeMs[%d] pitch[%0.3f] pitchdiff[%0.3f] realtime_score[%0.3f] rank[%d] accumulated_sentence_score[%0.3f]\n", sentence_index, aqr->mnCurTimeMs, pitch, pitchdiff, realtime_score, rank, accumulated_sentence_score );
            */
            static unsigned int step = (unsigned int)(mkBufferDurationSeconds * 1000);
            aqr->mnCurTimeMs += step;
            delete []outdata;
            
            static unsigned int frames = 0;
            ++frames;
            
            if ( ( frames % 20 ) == 0 )
            {
                NSLog( @"frames[%d] mnCurTimeMs[%d].", frames, aqr->mnCurTimeMs );
            }
            
			aqr->mRecordPacket += inNumPackets;
		}
		
		// if we're not stopping, re-enqueue the buffe so that it gets filled again
		if (aqr->IsRunning())
			XThrowIfError(AudioQueueEnqueueBuffer(inAQ, inBuffer, 0, NULL), "AudioQueueEnqueueBuffer failed");
	} catch (CAXException e) {
		char buf[256];
		fprintf(stderr, "Error: %s (%s)\n", e.mOperation, e.FormatError(buf));
	}
}

AQRecorder::AQRecorder(float kBufferDurationSeconds,double sampleRate)
{
	mIsRunning = false;
	mRecordPacket = 0;
    
    mkBufferDurationSeconds = kBufferDurationSeconds;
    msampleRate = sampleRate;
}

AQRecorder::~AQRecorder()
{
    if ( mEvalInstance != NULL )
    {
        mEvalInstance = NULL;
    }
	AudioQueueDispose(mQueue, TRUE);
	AudioFileClose(mRecordFile);
	if (mFileName) CFRelease(mFileName);
}

// ____________________________________________________________________________________
// Copy a queue's encoder's magic cookie to an audio file.
void AQRecorder::CopyEncoderCookieToFile()
{
	UInt32 propertySize;
	// get the magic cookie, if any, from the converter
	OSStatus err = AudioQueueGetPropertySize(mQueue, kAudioQueueProperty_MagicCookie, &propertySize);
	
	// we can get a noErr result and also a propertySize == 0
	// -- if the file format does support magic cookies, but this file doesn't have one.
	if (err == noErr && propertySize > 0) {
		Byte *magicCookie = new Byte[propertySize];
		UInt32 magicCookieSize;
		XThrowIfError(AudioQueueGetProperty(mQueue, kAudioQueueProperty_MagicCookie, magicCookie, &propertySize), "get audio converter's magic cookie");
		magicCookieSize = propertySize;	// the converter lies and tell us the wrong size
		
		// now set the magic cookie on the output file
		UInt32 willEatTheCookie = false;
		// the converter wants to give us one; will the file take it?
		err = AudioFileGetPropertyInfo(mRecordFile, kAudioFilePropertyMagicCookieData, NULL, &willEatTheCookie);
		if (err == noErr && willEatTheCookie) {
			err = AudioFileSetProperty(mRecordFile, kAudioFilePropertyMagicCookieData, magicCookieSize, magicCookie);
			XThrowIfError(err, "set audio file's magic cookie");
		}
		delete[] magicCookie;
	}
}

void AQRecorder::SetupAudioFormat(Float64 inSampleRate, UInt32 inChannelsPerFrame, UInt32 inBitsPerChannel)
{
	memset(&mRecordFormat, 0, sizeof(mRecordFormat));
/*
	UInt32 size = sizeof(mRecordFormat.mSampleRate);
	XThrowIfError(AudioSessionGetProperty(	kAudioSessionProperty_PreferredHardwareSampleRate,
                                          &size,
                                          &mRecordFormat.mSampleRate), "couldn't get hardware sample rate");
    
	size = sizeof(mRecordFormat.mChannelsPerFrame);
	XThrowIfError(AudioSessionGetProperty(	kAudioSessionProperty_CurrentHardwareInputNumberChannels,
                                          &size,
                                          &mRecordFormat.mChannelsPerFrame), "couldn't get input channel count");
*/
    mRecordFormat.mSampleRate = inSampleRate;
	mRecordFormat.mFormatID = kAudioFormatLinearPCM;
    mRecordFormat.mChannelsPerFrame = inChannelsPerFrame;
	// if we want pcm, default to signed 8-bit little-endian
	mRecordFormat.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;
	mRecordFormat.mBitsPerChannel = inBitsPerChannel;
    mRecordFormat.mBytesPerFrame = (inBitsPerChannel / 8) * inChannelsPerFrame;
    mRecordFormat.mFramesPerPacket = 1;
	mRecordFormat.mBytesPerPacket = mRecordFormat.mBytesPerFrame * mRecordFormat.mFramesPerPacket;
}

void AQRecorder::StartRecord(CFStringRef inRecordFile)
{
	int i, bufferByteSize;
	UInt32 size;
	CFURLRef url;
	
	try {
		mFileName = CFStringCreateCopy(kCFAllocatorDefault, inRecordFile);
        
		// specify the recording format
		SetupAudioFormat( 22050, 1, 8 );
		
		// create the queue
		XThrowIfError(AudioQueueNewInput(
                                         &mRecordFormat,
                                         MyInputBufferHandler,
                                         this /* userData */,
                                         NULL /* run loop */, NULL /* run loop mode */,
                                         0 /* flags */, &mQueue), "AudioQueueNewInput failed");
		
		// get the record format back from the queue's audio converter --
		// the file may require a more specific stream description than was necessary to create the encoder.
		mRecordPacket = 0;
        
		size = sizeof(mRecordFormat);
		XThrowIfError(AudioQueueGetProperty(mQueue, kAudioQueueProperty_StreamDescription,
                                            &mRecordFormat, &size), "couldn't get queue's format");
        
		NSString *recordFile = [NSTemporaryDirectory() stringByAppendingPathComponent: (__bridge NSString*)inRecordFile];
        
		url = CFURLCreateWithString(kCFAllocatorDefault, (CFStringRef)recordFile, NULL);
		
		// create the audio file
		XThrowIfError(AudioFileCreateWithURL(url, kAudioFileCAFType, &mRecordFormat, kAudioFileFlags_EraseFile,
                                             &mRecordFile), "AudioFileCreateWithURL failed");
		CFRelease(url);
		
		// copy the cookie first to give the file object as much info as we can about the data going in
		// not necessary for pcm, but required for some compressed audio
		CopyEncoderCookieToFile();
		
		// allocate and enqueue buffers
		bufferByteSize = ComputeRecordBufferSize(&mRecordFormat, mkBufferDurationSeconds);	// enough bytes for half a second
		for (i = 0; i < kNumberRecordBuffers; ++i) {
			XThrowIfError(AudioQueueAllocateBuffer(mQueue, bufferByteSize, &mBuffers[i]),
                          "AudioQueueAllocateBuffer failed");
			XThrowIfError(AudioQueueEnqueueBuffer(mQueue, mBuffers[i], 0, NULL),
                          "AudioQueueEnqueueBuffer failed");
		}
		// start the queue
		mIsRunning = true;
		XThrowIfError(AudioQueueStart(mQueue, NULL), "AudioQueueStart failed");
	}
	catch (CAXException &e) {
		char buf[256];
		fprintf(stderr, "Error: %s (%s)\n", e.mOperation, e.FormatError(buf));
	}
	catch (...) {
		fprintf(stderr, "An unknown error occurred\n");
	}	
    
}

void AQRecorder::Init(eval * e, id callbackobject, Float64 inSampleRate, UInt32 inChannelsPerFrame, UInt32 inBitsPerChannel)
{
    mEvalInstance = e;
    
    // specify the recording format
    SetupAudioFormat( inSampleRate, inChannelsPerFrame, inBitsPerChannel );
    mSceneObjectEx = callbackobject;
}

void AQRecorder::StartRecord1(CFStringRef inRecordFile)
{
	int i, bufferByteSize;
	UInt32 size;
	CFURLRef url;
    
    // 开始录制同时计时作为评分当前时间
    mnCurTimeMs = 0;

    mSentenceGrade.sentence_index = -1;
    mSentenceGrade.sentence_score = 0;
    mSentenceGrade.sentence_level = SENTENCEGRADELEVEL_NONE;
    mSentenceGrade.combo_value = 0.0f;
	
	try {
		mFileName = CFStringCreateCopy(kCFAllocatorDefault, inRecordFile);
        
		// create the queue
		XThrowIfError(AudioQueueNewInput(
                                         &mRecordFormat,
                                         MyInputBufferHandler,
                                         this /* userData */,
                                         NULL /* run loop */, NULL /* run loop mode */,
                                         0 /* flags */, &mQueue), "AudioQueueNewInput failed");
		
		// get the record format back from the queue's audio converter --
		// the file may require a more specific stream description than was necessary to create the encoder.
		mRecordPacket = 0;
        
		size = sizeof(mRecordFormat);
        
        /*
         */
		XThrowIfError(AudioQueueGetProperty(mQueue, kAudioQueueProperty_StreamDescription,
                                            &mRecordFormat, &size), "couldn't get queue's format");
        
#if TARGET_IPHONE_SIMULATOR
        static const char szFile[] = "file://localhost/Users/tiange01/Library/Application Support/iPhone Simulator/5.1/tmp/recordedFile.caf";
        url = CFURLCreateWithBytes( NULL, (const UInt8 *) szFile, sizeof(szFile), kCFStringEncodingASCII, NULL );
#else
		NSString *recordFile = [NSTemporaryDirectory() stringByAppendingPathComponent: (__bridge NSString*)inRecordFile];
        CFStringRef strrefRecordFile = ( __bridge CFStringRef )recordFile;
		url = CFURLCreateWithString(kCFAllocatorDefault, strrefRecordFile, NULL);
#endif
		// create the audio file
		XThrowIfError(AudioFileCreateWithURL(url, kAudioFileCAFType, &mRecordFormat, kAudioFileFlags_EraseFile,
                                             &mRecordFile), "AudioFileCreateWithURL failed");
		CFRelease(url);
		
		// copy the cookie first to give the file object as much info as we can about the data going in
		// not necessary for pcm, but required for some compressed audio
		CopyEncoderCookieToFile();
		
		// allocate and enqueue buffers
		bufferByteSize = ComputeRecordBufferSize(&mRecordFormat, mkBufferDurationSeconds);	// enough bytes for half a second
		for (i = 0; i < kNumberRecordBuffers; ++i) {
            XThrowIfError(AudioQueueAllocateBuffer(mQueue, bufferByteSize, &mBuffers[i]),
                          "AudioQueueAllocateBuffer failed");
			XThrowIfError(AudioQueueEnqueueBuffer(mQueue, mBuffers[i], 0, NULL),
                          "AudioQueueEnqueueBuffer failed");
		}
		// start the queue
		mIsRunning = true;
		XThrowIfError(AudioQueueStart(mQueue, NULL), "AudioQueueStart failed");
	}
	catch (CAXException &e) {
		char buf[256];
		fprintf(stderr, "Error: %s (%s)\n", e.mOperation, e.FormatError(buf));
	}
	catch (...) {
		fprintf(stderr, "An unknown error occurred\n");
	}
    
}

void AQRecorder::StopRecord()
{
	// end recording
	mIsRunning = false;
	XThrowIfError(AudioQueueStop(mQueue, true), "AudioQueueStop failed");	
	// a codec may update its cookie at the end of an encoding session, so reapply it to the file now
	CopyEncoderCookieToFile();
	if (mFileName)
	{
		CFRelease(mFileName);
		mFileName = NULL;
	}
    printf("AQRecorder::StopRecord");
	AudioQueueDispose(mQueue, true);
	AudioFileClose(mRecordFile);
}
