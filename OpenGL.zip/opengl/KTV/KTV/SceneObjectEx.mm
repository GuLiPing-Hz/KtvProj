//
//  SceneObject.m
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//

#import "SceneObjectEx.h"
#import "SceneMgr.h"
#import "InputViewController.h"
#import "ImgsetMgr.h"
#import "Image.h"
#include "string.h"

// 谱线窗口常量定义
const int WAVEWND_WIDTH_TIMEMS = 2222;//5000;		// 一屏5000毫秒
const int WAVEWND_WIDTH_PIXELS = 320;//720;		// 一屏宽度720像素
const int WAVEWND_HEIGHT_PIXELS = 87;//79;		// 曲谱的高度40像素
const int WAVEWND_HEIGHT_PIXELS_KTV = 87;//105;	// 曲谱的高度40像素
const int WAVEWND_LEFT_PIXELS = 80;//170;		// 左边的像素
const int CURSOR_WIDTH_PIXELS = 36;			// 光标宽度
const int WAVEWND_LEFT_TIMEMS = 1210;		// WAVEWND_WIDTH_TIMEMS * WAVEWND_LEFT_PIXELS / WAVEWND_WIDTH_PIXELS + 30;

const int WAVEWND_WIDTH_PIXELS_KTV = 320;//460;	// 一屏宽度632像素(KTV模式)

const int SHOW_TIP_IMAGE_MSEC = 4000;		// 4000毫秒~2000毫秒	显示提示图标（图标闪烁）
const int SHOW_MOVE_IMAGE_MSEC = 2000;		// 2000毫秒~0毫秒		显示光标滑动动画
const int NEED_SHOW_MOVE_IMAGE_MSEC = 500;	// >= 1000毫秒			需要显示光标滑动动画

// 估算16号字体的中文英文字符宽度
const int CHAR_WIDTH_CHS = 21;				// 中文字体宽度高度
const int CHAR_WIDTH_EN = 12;				// 英文字体宽度高度

#pragma mark Spinny Square mesh

@implementation SceneObjectEx

@synthesize mfileName;
@synthesize eval_module;

- (void)dealloc
{
    [mGuiLyricVect release];
    [mGuiPitchVect release];
    [mGuiSentencelineVect release];
    [mParagraphVect release];
    [lyric_render release];
    [wave_render release];
    [sentence_render release];
    [audio_module release];
    [eval_module release];
    [mfileName release];
    [super dealloc];
}

- (AQRecorder *)getAudioRecorder
{
    return [audio_module getRecorder];
}

- (AQPlayer *)getAudioPlayer
{
    return [audio_module getPlayer];
}

- (id) init:(NSString *)mdmName andkBufferDurationSeconds:(float)kBufferDurationSeconds andSampleRate:(double)sampleRate anddBUpperLimit:(double)dBUpperLimit
{
	self = [super init];
	if (self != nil) {
        [[ImgsetMgr getSingleton] addImageSet:@"renderer"];
		lyric_render = [[LyricRender alloc] init];
        wave_render = [[WaveRender alloc] init];
        sentence_render = [[SentenceRender alloc] init];
        
        audio_module = [[AudioModule alloc] init:kBufferDurationSeconds andSampleRate:sampleRate anddBUpperLimit:dBUpperLimit];
        int time_step = (int)(kBufferDurationSeconds*1000);
        eval_module = [[eval alloc] init:sampleRate dBLimit:dBUpperLimit TimeStep:time_step]; //Magic:0.0f];
        
        mbInterpolation = true;
        
        mGuiLyricVect = [[NSMutableArray alloc] initWithCapacity:128];
        mGuiPitchVect = [[NSMutableArray alloc] initWithCapacity:128];
        mGuiSentencelineVect = [[NSMutableArray alloc] initWithCapacity:128];
        mParagraphVect = [[NSMutableArray alloc] initWithCapacity:128];
        
        self.mfileName = mdmName;
	}
	return self;
}

//-----------------------------------------------------------------------------
// 生成谱线和歌词
- (void) genWaveAndLyric: (_tSongInfo&) song_info
{   
	[mGuiLyricVect removeAllObjects];
	[mGuiPitchVect removeAllObjects];
	[mGuiSentencelineVect removeAllObjects];
	[mParagraphVect removeAllObjects];
    
	unsigned int sentence_count = song_info.sentence_size;
	_tSentenceInfo * sentences = song_info.sentence_info;
    
	// 生成歌词及位置信息（位置为全局的像素值）
	int pos = 0;
	
	for ( unsigned int i = 0; i < sentence_count; ++i )
	{
		const _tSentenceInfo & sentence = sentences[ i ];
		
		for ( unsigned int j = 0; j < sentence.word_size; ++j )
		{
			const _tWordInfo & word_info = sentence.word_list[ j ];
			if ( word_info.lyric_size )
			{
                static NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
				_tGuiLyricInfo * gui_lyric_info = [[_tGuiLyricInfo alloc] init];
                gui_lyric_info.lyric	= [[NSString alloc] initWithBytes: word_info.lyric length:word_info.lyric_size encoding:enc];
				gui_lyric_info.pos		= word_info.begin_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
				// 如果通过实践计算出的字符位置与前一个字符重叠，校正
				if ( gui_lyric_info.pos < pos )
				{
					gui_lyric_info.pos = pos;
				}
				[mGuiLyricVect addObject: gui_lyric_info];
                
				// 避免与前一个字符重叠
				pos = gui_lyric_info.pos + 1;
				for ( unsigned int k = 0; k < word_info.lyric_size; ++ k )
				{
					pos += ( word_info.lyric[ k ] > 0x00FF ) ? 21 : 12;
				}
                [gui_lyric_info release];//////////////glp
			}
		}
	}
        
	// 生成谱线句尾线及位置信息（位置为全局的像素值）
	for ( unsigned int i = 0; i < sentence_count; ++i )
	{
        _tGuiWaveInfo * gui_pitch = nil;
		const _tSentenceInfo & sentence = sentences[ i ];
        
        for ( unsigned int j = 0; j < sentence.pitchgroup_size; ++j )
        {
            const _tPitchGroup & pitch_group = sentence.pitchgroup_list[j];
            
            for ( unsigned int k = 0; k < pitch_group.pitch_size; ++k )
            {
                gui_pitch = [[_tGuiWaveInfo alloc] init];
                
                const _tPitch & pitch_info = pitch_group.pitch_list[ k ];
                gui_pitch.l = pitch_info.begin_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
                gui_pitch.r = pitch_info.end_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
                gui_pitch.y = ( WAVEWND_HEIGHT_PIXELS - 18 ) * ( song_info.pitch_max - pitch_info.pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 9;
                [mGuiPitchVect addObject: gui_pitch];
                [gui_pitch release];/////////glp
            }
        }

		// 最后谱线的结尾应该是句结尾
        int _sentenceline_pos = sentence.endMsec * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
        NSNumber * nsnumber_sentenceline_pos = [[NSNumber alloc] initWithInt: _sentenceline_pos];
        
		if ( gui_pitch != nil && gui_pitch.r != _sentenceline_pos )
		{
			NSLog( @"sentence line position is error sentence index = [%d].", ( int )i );
		}
		[mGuiSentencelineVect addObject: nsnumber_sentenceline_pos];
        //[nsnumber_sentenceline_pos release];/////////glp
	}
    
	// 设置段落(需要提前显示歌词并提示)
	unsigned long end_msec = 0;			// 第一句，上句结束时间为0；第二句上句时间为第一句的结束时间
	for ( unsigned int i = 0; i < sentence_count; ++i )
	{
		const _tSentenceInfo & sentence = sentences[ i ];
		if ( sentence.beginMsec >= end_msec )
		{
			unsigned long duration = 0;		// 当前句离上一句结束的时间
			duration = sentence.beginMsec - end_msec;
            
			if ( duration >= NEED_SHOW_MOVE_IMAGE_MSEC )
			{
				duration = duration / 500 * 500;
				if ( duration > SHOW_TIP_IMAGE_MSEC )
				{
					duration = SHOW_TIP_IMAGE_MSEC;
				}
                _tGuiParagraphInfo * paragraph_info = [[_tGuiParagraphInfo alloc] init];
                paragraph_info.sentence_index = i;
                paragraph_info.duration = duration;
				[mParagraphVect addObject:paragraph_info];
                [paragraph_info release];////////////glp
			}
		}
		else
		{
			NSLog( @"sentence time stamp is error,sentence index is [%d].", ( int )i );
		}
		end_msec = sentence.endMsec;
	}
}

- (void) RealtimeGrade: ( const _tRealtimeGrade & ) realtime_grade
{
    if ( mnCallbackRealtimeGradeCount < 16 )
    {
        mCallbackRealtimeGrade[mnCallbackRealtimeGradeCount] = realtime_grade;
        mnCallbackRealtimeGradeCount++;
    }
    else
    {
        mnCallbackRealtimeGradeCount = 0;
        mCallbackRealtimeGrade[mnCallbackRealtimeGradeCount] = realtime_grade;
        mnCallbackRealtimeGradeCount++;
    }
}

- (void) SentenceGrade: (const _tSentenceGrade & ) sentence_grade
{
    if ( mnCallbackSentenceGradeCount < 8 )
    {
        mCallbackSentenceGrade[mnCallbackSentenceGradeCount] = sentence_grade;
        mnCallbackSentenceGradeCount++;
    }
    else
    {
        mnCallbackSentenceGradeCount = 0;
        mCallbackSentenceGrade[mnCallbackSentenceGradeCount] = sentence_grade;
        mnCallbackSentenceGradeCount++;
    }
}

- (void) eventMainUpdate: (unsigned int) elapsed_ms
{
    bool call_realtime_grade = false;
	// 谱线描绘是否插值
	if ( mbInterpolation )
	{
		if ( !mbIsCallback )
		{// 如果不是AV模块回调
            // hjp
			/*_tRealtimeGrade next_grade;
			// 如果AV模块实时评分回调队列中存在下一帧
			if ( TOP::box().av->peekTopRealtimeGrade( next_grade ) )
        	{
				call_realtime_grade = true;
			}
			else
			{// 如果AV模块实时评分回调队列中不存在下一帧
				if ( mbIsMe )
				{// 如果自己在麦上，当前播放时间向前步进elapsed_tm
					call_realtime_grade = true;
				}
				else
				{// 如果是听众，停住不向前预测。
					//LOG_GAME( "CStateStageSing::eventMainUpdate real time grade queue is empty." );
				}
			}
            */
            // hjp
            call_realtime_grade = true;
		}
	}
    
	if ( call_realtime_grade )
	{
		[self eventAvRealtimeGrade: elapsed_ms RealtimeGrade: mCurGrade IsCallback: false];
	}
    /*
	if ( mbKtvMode && ( mbInterpolation || mbIsCallback ) )
	{
		// 1.动画显示闪烁图标、滑动图标
		unsigned int i = 0;
		unsigned int iParagraphCount = mParagraphVect.size();
		for ( i = 0; i < iParagraphCount; ++i )
		{
			std::pair< int, int > & paragraph = mParagraphVect[ i ];
			int & sentence_index = paragraph.first;
			int & duration = paragraph.second;
			if ( ( miCurSentence - 1 ) == sentence_index )
			{// 如果需要显示闪烁图标或滑动图标
				int temp_msec = ( int )mCurSentenceLyric.beginMsec - ( int )mCurGrade.cur_tm;
				if ( temp_msec <= duration )
				{// 如果需要
					if ( temp_msec <= SHOW_MOVE_IMAGE_MSEC )
					{// 显示滑动图标
						float temp_pos = (float)( SHOW_MOVE_IMAGE_MSEC - temp_msec ) / SHOW_MOVE_IMAGE_MSEC;
						TOP::box().gui->getStage()->setLyricMovePos( temp_pos );
					}
                    / *
                     else if ( temp_msec < SHOW_TIP_IMAGE_MSEC )
                     {// 显示闪烁图标
                     float temp_trans = (float)( 500 - temp_msec % 500 ) / 500.0f;
                     TOP::box().gui->getStage()->setLyricTipImageTrans( temp_trans );
                     }
                     * /
				}
				break;
			}
		}
        
		// 2.着色歌词
		// 当前演唱语句的字数
		unsigned int nWordCount = mCurSentenceLyric.nWordCount;
        
		// 歌词Vect的总数
		unsigned int nGuiLyricCount = ( unsigned int )mCurGuiLyricVect.size();
        
		if ( miCurSentence >= 1 && nWordCount > 0 && nGuiLyricCount > 0 )
		{
			// 当前句总时间（毫秒）
			float total_msec = mCurSentenceLyric.endMsec-mCurSentenceLyric.beginMsec;
            
			// 距离句首的时间差（毫秒）
			// 减去75毫秒（生成评分用的麦克风声音缓冲和评分本身消耗的时间）
			float left_msec = mCurGrade.cur_tm - mCurSentenceLyric.beginMsec - 75;
            
			// 总长度（单位：像素）
			float total = 0.0f;
			bool first_sentence = ( ( ( miCurSentence - 1 ) % 2 ) == 0 );
			if ( first_sentence )
				total = mFirstLyricWidth;
			else
				total = mSecondLyricWidth;
            
			total += Gui::FONT24_SPACE * ( nWordCount - 1 );
            
			if ( total > 1.0f )
			{
				// 着色的长度（单位：像素）
				float left = 0.0f;
				for ( i = 0; i < nWordCount && i < nGuiLyricCount; ++i )
				{
					WordInfo & word_info = mCurSentenceLyric.words[i];
					Gui::_tGuiLyricInfo & lyric_info = mCurGuiLyricVect[i];
					if ( mCurGrade.cur_tm > word_info.endMsec )
					{
						left += lyric_info.width;
						left += Gui::FONT24_SPACE;
					}
					else
					{
						if ( mCurGrade.cur_tm >= word_info.beginMsec)
						{
							float word_msec = word_info.endMsec-word_info.beginMsec;
							if ( word_msec < 1.0f )
								word_msec = 1.0f;
							
							long temp_msec = mCurGrade.cur_tm - word_info.beginMsec;
							if ( temp_msec < 0 )
								temp_msec = 0;
                            
							left += lyric_info.width * temp_msec / word_msec;
						}
						break;
					}
				}
                
				mCurRate = left / total;
				
				if ( first_sentence )
				{
					TOP::box().gui->getStage()->setFirstLyricStartPos( mCurRate );
				}
				else
				{
					TOP::box().gui->getStage()->setNextLyricStartPos( mCurRate );
				}
			}
            
			if ( total_msec > 1.0f && left_msec >= 0.0f )
			{
				if ( left_msec > total_msec )
					left_msec = total_msec;
                
				mMoveRate = left_msec / total_msec;
			}
			else
			{
				mMoveRate = 0.0f;
			}
			TOP::box().gui->getStage()->setMovePos( mMoveRate );
		}
	}
    */
    
	if ( mbIsCallback )
	{// AV模块回调，复位标志，不重复调用eventAvRealtimeGrade函数
		mbIsCallback = false;
	}
}

//-----------------------------------------------------------------------------
// av：音频实时评分
- (void) eventAvRealtimeGrade: (unsigned int) elasped_ms RealtimeGrade: (_tRealtimeGrade &) grade IsCallback: (bool) is_callback/* = true*/
{
	mbIsCallback = is_callback;
    
	miLastElapsedCount += elasped_ms;
    
    /*
    if ( ( miLastElapsedCount - miElapsedCount ) > 1000 )
    {
        miElapsedCount += 1000;
        NSLog(@"miElapsedCount[%d].", miElapsedCount / 1000);
    }
    */
	if ( mbInterpolation )
	{// 使用插值
		// 使用帧渲染中的时间作为插值
		int cur_tm = ( int )mCurGrade.cur_tm;
		cur_tm += elasped_ms;
        
		if ( mbIsCallback )
		{
			// 校正当前时间
			int temp = cur_tm - grade.cur_tm;
			
			if ( temp < -2000 || temp > 2000)
			{
				cur_tm = grade.cur_tm;
			}
            
            mCurGrade = grade;
            mCurGrade.cur_tm = ( unsigned int )cur_tm;
		}
		else
		{
			mCurGrade = grade;
			mCurGrade.cur_tm = cur_tm;
		}
	}
	else
	{// 不用插值
		mCurGrade = grade;
	}
    
	mCurTime = mCurGrade.cur_tm;
    
	const _tSongInfo & song_info = mSongInfo;
    
	// 显示歌曲进度
	if ( mCurGrade.cur_tm <= song_info.song_tm*1000 && mCurGrade.cur_tm >= mPreTime )
	{
		// 计算并显示歌曲进度
		float progress = ( float )mCurGrade.cur_tm / ( float )(song_info.song_tm*1000);
		//TOP::box().gui->getStage()->showSongProgress( progress );
        
		// 显示歌曲时间
		//TOP::box().gui->getStage()->setCurentPlayTime( mCurGrade.cur_tm );
        
		// 显示歌曲时间
		int cur_tm = ( int )( mCurGrade.cur_tm / 1000.0f );
		//int second = cur_tm % 60;
		//int minute = cur_tm / 60;
		//std::string song_tm = boost::str( boost::format( "%02d:%02d" ) % minute % second );
		//TOP::box().gui->getStage()->showSongTime( song_tm );
        
		mPreTime = mCurGrade.cur_tm;
	}
    
	if ( mCurTime > song_info.begin_tm && mCurSingTime < song_info.end_tm )
	{
		mCurSingStage = SINGSTAGE_SING;
	}
	else if ( mCurTime > song_info.end_tm )
	{
		mCurSingStage = SINGSTAGE_FINALE;
	}
    
	if ( mbIsMe )
	{
		if ( mCurGrade.cur_tm > song_info.song_tm*1000 )
		{
			NSLog( @"my cur_tm error : [%d][%d]", (int)(mCurGrade.cur_tm), (int)(song_info.end_tm) );
		}
	}
	
	if ( mCurGrade.cur_tm > song_info.song_tm*1000 || mCurGrade.cur_tm < mPreTime )
	{
		// LOG_GAME_ERR( "cur_tm error : " << (int)(mCurGrade.cur_tm) << (int)(song_info.end_tm) );
		return;
	}
    
	unsigned int word_count = 0;
	unsigned int pitch_count = 0;
    
	unsigned int sentence_count = song_info.sentence_size;
	_tSentenceInfo * sentences = song_info.sentence_info;
    
	// 显示累加句评分进度条
	//TOP::box().gui->getStage()->showSentenceProgress( mCurGrade.accumulate_score / 1000.0f );
    
	// 当前的时间，确定在分割线上，分割线的左右。分割线的左侧是已经唱过的歌词，分割线的右测是没有唱过的歌词
	// 如果改变方案，那么需要将时间改正，显示应该提前5秒显示
    /*
	if ( mbKtvMode )
	{
		bool bScroll = false;
		if ( mbChangeMode )
		{
			bScroll = true;
		}
        
		unsigned int i = 0;
		// 显示歌词的当前时间
		unsigned long show_lyric_time = mCurGrade.cur_tm;
		for ( i = 0; i < mParagraphVect.size(); ++i )
		{
			std::pair< int, int > & paragraph = mParagraphVect[ i ];
			int & sentence_index = paragraph.first;
			int & duration = paragraph.second;
			if ( sentence_index == miCurSentence )
			{
				show_lyric_time += duration;			// 如果是段落，需要提前X秒显示歌词
				break;
			}
		}
        
		// 计算当前播放的句
		for ( i = miCurSentence; i < sentence_count; ++i )
		{
			const SentenceInfo & sentence = sentences[i];
			if ( show_lyric_time >= sentence.beginMsec && show_lyric_time <= sentence.endMsec )
			{
				if ( mCurSentenceLyric.beginMsec != sentence.beginMsec )
				{
					mCurSentenceLyric = sentence;
					miCurSentence = i + 1;
					if ( i + 1 < sentence_count )
					{
						mNextSentenceLyric = sentences[ i + 1 ];
					}
					else
					{
						memset( &mNextSentenceLyric, 0, sizeof(SentenceInfo) );
					}
					bScroll = true;
				}
				break;
			}
		}
        
		if ( mCurGrade.cur_tm > song_info.end_tm )
		{
			memset( &mCurSentenceLyric, 0, sizeof(SentenceInfo) );
			memset( &mNextSentenceLyric, 0, sizeof(SentenceInfo) );
		}
        
		if ( bScroll )
		{
			// 清空歌词列表
			mCurGuiLyricVect.clear();
			mNextGuiLyricVect.clear();
            
			unsigned long pt_left	= mCurSentenceLyric.beginMsec;
			unsigned long pt_right	= mCurSentenceLyric.endMsec - mCurSentenceLyric.beginMsec;
            
            // 显示第一句(大歌词)
			Gui::_tGuiLyricInfo gui_lyric_info;
            
			// 第一句歌词
			word_count = mCurSentenceLyric.nWordCount;
			for ( unsigned int i = 0; i < word_count; ++i )
			{
				const WordInfo & word_info = mCurSentenceLyric.words[ i ];
				if ( word_info.chars )
				{
					gui_lyric_info.lyric = Ci::CUtility::wc2CeguiString( word_info.chars );
					mCurGuiLyricVect.push_back( gui_lyric_info );
				}
			}
            
			// 第二句歌词
			word_count = mNextSentenceLyric.nWordCount;
			for ( unsigned int i = 0; i < word_count; ++i )
			{
				const WordInfo & word_info = mNextSentenceLyric.words[ i ];
				if ( word_info.chars )
				{
					gui_lyric_info.lyric = Ci::CUtility::wc2CeguiString( word_info.chars );
					mNextGuiLyricVect.push_back( gui_lyric_info );
				}
			}
            
			// 歌词不滚动
			bool current_is_first_sentence = ( ( ( miCurSentence - 1 ) % 2 ) == 0 );
			TOP::box().gui->getStage()->switchSentence( current_is_first_sentence );
            
			// 歌词提示光标位置复位
			TOP::box().gui->getStage()->setLyricMovePos( 0.0f );
            
			if ( current_is_first_sentence )
			{
				mFirstLyricWidth = TOP::box().gui->getStage()->showFirstLyric( mCurGuiLyricVect, false );
				mSecondLyricWidth = TOP::box().gui->getStage()->showSecondLyric( mNextGuiLyricVect, true );
			}
			else
			{
				mFirstLyricWidth = TOP::box().gui->getStage()->showFirstLyric( mNextGuiLyricVect, false );
				mSecondLyricWidth = TOP::box().gui->getStage()->showSecondLyric( mCurGuiLyricVect, true );
			}
            
			// 显示谱线
			Gui::_tGuiWaveInfo gui_pitch;
			std::vector< Gui::_tGuiWaveInfo > gui_pitch_list;
			unsigned int pitch_count = mCurSentenceLyric.nPitchCount;
			for ( unsigned int i = 0; i < pitch_count; ++i )
			{
				const PitchInfo & pitch_info = mCurSentenceLyric.pitches[ i ];
				if ( pt_right > 0.0f )
				{
					gui_pitch.l = ( pitch_info.beginMsec - pt_left ) * WAVEWND_WIDTH_PIXELS_KTV / pt_right;
					gui_pitch.r = ( pitch_info.endMsec - pt_left ) * WAVEWND_WIDTH_PIXELS_KTV / pt_right;
				}
				gui_pitch.y = ( WAVEWND_HEIGHT_PIXELS_KTV - 35 ) * abs( song_info.pitch_max - pitch_info.pitch ) / (float)( song_info.pitch_max - song_info.pitch_min ) + 11;
				gui_pitch_list.push_back( gui_pitch );
			}
            
			TOP::box().gui->getStage()->showWave( gui_pitch_list );
            
			TOP::box().gui->getStage()->clearLyricCursor();
		}
		// 显示星光特效图标
		if ( mbIsCallback )
		{
			// 计算当前评分，用于判断是否需要显示星光特效
			mfPitchRealGrade += grade.realtime_score;
		}
		unsigned int pitch_count = mCurSentenceLyric.nPitchCount;
		for ( unsigned int i = 0; i < pitch_count; ++i )
		{
			const PitchInfo & pitch_info = mCurSentenceLyric.pitches[ i ];
			int _left_tm = pitch_info.endMsec - _elapsed_tm;
			int _right_tm = pitch_info.endMsec + _elapsed_tm;
			if ( mCurTime >= _left_tm && mCurTime < _right_tm )
			{
				if ( mfPitchRealGrade > 0.0f )
				{
					TOP::box().gui->getStage()->enableStarEffect( i, true );
				}
				mfPitchRealGrade = 0.0f;
				break;
			}
		}
        
		// 显示游标
		float cur_pitch = mCurGrade.cur_pitch;
        
		Gui::_tGuiLyricCursorInfo cursor;
		cursor.r = Gui::_tGuiLyricCursorInfo::RANK_YELLOW;
		
		cursor.y = ( WAVEWND_HEIGHT_PIXELS_KTV - 35 ) * abs( song_info.pitch_max - cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 11;
		// cursor.y = ( song_info.pitch_max - mCurGrade.cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min );
		cursor.x = WAVEWND_WIDTH_PIXELS_KTV * mMoveRate;
        
		if ( cursor.x > WAVEWND_WIDTH_PIXELS_KTV )
		{
			cursor.x = WAVEWND_WIDTH_PIXELS_KTV;
		}
		TOP::box().gui->getStage()->showLyricCursor( cursor, mfKtvErr, mfGameErr );
	}
	else
    */
	{
		// 计算偏移
		int offset = mCurGrade.cur_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS - WAVEWND_LEFT_PIXELS;
		
		// 显示歌词
        NSMutableArray * gui_lyric_list = nil;
		for( _tGuiLyricInfo * i in mGuiLyricVect )
		{
			int pos = i.pos - offset;
			if ( pos < -20 )
			{
				continue;
			}
            
			if ( pos > WAVEWND_WIDTH_PIXELS )
			{
				break;
			}
            
			_tGuiLyricInfo * temp = [[_tGuiLyricInfo alloc] init];
            temp.lyric = i.lyric;
            temp.width = i.width;

            temp.pos = pos;
            if ( nil == gui_lyric_list )
            {
                gui_lyric_list = [[NSMutableArray alloc] init];
            }
			[gui_lyric_list addObject: temp];
		}
        
        //if ( nil != gui_lyric_list )
		{
            [lyric_render showFirstLyric: gui_lyric_list Refresh: true];
        }
        
		// 显示谱线
		NSMutableArray * gui_pitch_list = nil;
		for( _tGuiWaveInfo * i in mGuiPitchVect )
		{
			int left = i.l - offset;
			int right = i.r - offset;
			if ( left > WAVEWND_WIDTH_PIXELS )
			{
				break;
			}
			if ( left >= 0 || right >= 0 )
			{
				if ( left < 0 )
				{
					left = 0;
				}
                
				_tGuiWaveInfo * temp = [[_tGuiWaveInfo alloc] init];
                temp.y = i.y;
				temp.l = left;
				temp.r = right;
                
                if ( nil == gui_pitch_list )
                {
                    gui_pitch_list = [[NSMutableArray alloc] init];
                }
				[gui_pitch_list addObject: temp];
                [temp release];
			}
		}
        
        //if ( nil != gui_pitch_list )
        {
            [wave_render setLineGroup: gui_pitch_list Refresh: true];
        }
		//[gui_lyric_list release];glp
		//显示句尾线
		NSMutableArray * gui_sentenceline_list = nil;
		for( NSNumber * i in mGuiSentencelineVect )
		{
			int pos = [i intValue] - offset;
			if ( pos > WAVEWND_WIDTH_PIXELS )
			{
				break;
			}
            
			if ( pos >= 0 )
			{
                NSNumber * nsnumber_pos = [[NSNumber alloc] initWithInt: pos];
                
                if ( nil == gui_sentenceline_list )
                {
                    gui_sentenceline_list = [[NSMutableArray alloc] init];
                }
				[gui_sentenceline_list addObject: nsnumber_pos];
			}
		}
        //if ( nil != gui_sentenceline_list )
		{
            [wave_render setSentenceLineList: gui_sentenceline_list Refresh: true];
        }
        //[gui_lyric_list release];
		// 显示游标
		float cur_pitch = mCurGrade.cur_pitch;
        
		float standard_pitch;
		for ( int i = 0; i < sentence_count; ++i )
		{
			const _tSentenceInfo & sentence = sentences[i];
			if ( mCurGrade.cur_tm >= sentence.beginMsec && mCurGrade.cur_tm <= sentence.endMsec )
			{
                for ( unsigned int j = 0; j < sentence.pitchgroup_size; ++j ) {
                    const _tPitchGroup & pitch_group = sentence.pitchgroup_list[j];
                    int pitch_count = pitch_group.pitch_size;
                    for (int j = 0; j < pitch_count; ++j )
                    {
                        if ( mCurGrade.cur_tm >= pitch_group.pitch_list[j].begin_tm && mCurGrade.cur_tm <= pitch_group.pitch_list[j].end_tm )
                        {
                            const _tPitch & pitch_info = pitch_group.pitch_list[j];
                            standard_pitch = pitch_info.pitch;
                            break;
                        }
                    }
                }
				break;
			}
		}
        
        _tGuiLyricCursorInfo * cursor = [[_tGuiLyricCursorInfo alloc] init];
        cursor.r = (int)RANK_YELLOW;
        int standard_y = ( WAVEWND_HEIGHT_PIXELS - 18 ) * abs( song_info.pitch_max - standard_pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 9;
        //cursor.y = ( song_info.pitch_max - mCurGrade.cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min );
        cursor.x = WAVEWND_LEFT_PIXELS - CURSOR_WIDTH_PIXELS;

        if ( cur_pitch >= song_info.pitch_min )
		{
            cursor.y = ( WAVEWND_HEIGHT_PIXELS - 18 ) * abs( song_info.pitch_max - cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 9;
        }
        else
        {
            cursor.y = -1000;
        }
        
        [wave_render setStandardY: standard_y];
        [wave_render setLyricCursor: cursor KtvError: mfKtvErr GameError: mfGameErr];
    }
    
	// 复位标志位
	if ( mbChangeMode )
	{
		mbChangeMode = false;
	}
}

//-----------------------------------------------------------------------------
// av：音频单句评分
- (void) eventAvSentenceGrade: (_tSentenceGrade &) grade
{
    _eSentenceGradeLevel sentence_level = grade.sentence_level;
    [sentence_render showSentenceLevel: sentence_level];
    
    // 界面模块，句评分分数显示
    int sentence_score = ( int )grade.sentence_score;
    [sentence_render showSentenceScore: sentence_score];
    
    // 场景模块，动作切换规则
    static bool sentence_grade_good = true;
    static int sentence_grade_num = 0;
    bool cur_good = false;
    if ( grade.sentence_level > 1 )
        cur_good = true;
    if ( cur_good == sentence_grade_good )
    {
        sentence_grade_num ++;
    }
    else
    {
        sentence_grade_num	= 0;
        sentence_grade_good	= cur_good;
    }
    
    // 切换是否显示谱线周围光环特效
    bool enable_waveeffect = sentence_grade_good && ( sentence_grade_num > 0 );
    [wave_render enableWaveEffect: enable_waveeffect];
}

//-----------------------------------------------------------------------------
// 获取歌曲中所有歌词(排除重复)
// 返回Unicode编码的不重复的歌词
-(NSString *) getLyric: (_tSongInfo&) song_info
{
    NSMutableString * strLyric = [[NSMutableString alloc] init];
    NSMutableDictionary * mapWord = [[NSMutableDictionary alloc] initWithCapacity:256];
	for (unsigned int i = 0; i < song_info.sentence_size; i++)
	{
		for (unsigned int j = 0; j < song_info.sentence_info[i].word_size; j++)
		{
			const _tWordInfo & word_info = song_info.sentence_info[i].word_list[j];
            NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            NSString * unicodeStr = [[NSString alloc] initWithBytes: word_info.lyric length:word_info.lyric_size encoding:enc];
            //NSString * unicodeStr = [NSString stringWithCString:[asciiStr UTF8String] encoding:NSUnicodeStringEncoding];
            
			for ( unsigned int k = 0; k < unicodeStr.length; k++ )
			{
                NSString * word = [unicodeStr substringWithRange:NSMakeRange(k, 1)];
                //wchar_t unicode_char = [unicodeStr characterAtIndex:k];
				
                id w = [mapWord objectForKey:word];
				if ( w == nil )
				{
                    NSNumber * n = [[NSNumber alloc] initWithInt:1];
					[mapWord setObject:n forKey:word];
                    [n release];
					[strLyric appendString:word];
                    
				}
				else
				{
                    NSNumber * n = (NSNumber*)w;
                    NSNumber * n1 = [[NSNumber alloc] initWithInt:([n intValue] + 1)];
					
                    [mapWord setObject:n1 forKey:word];
				}
			}
            [unicodeStr release];
		}
	}
    [mapWord release];////////////glp
	return [strLyric autorelease];
}

// called once when the object is first created.
-(void) awake
{
    /*
    FreeTypeFont * ftt = [[FreeTypeFont alloc] init];
    [ftt load: nil LyricString:@"来白桦"];
    CGPoint pt = CGPointMake( 0, 0 );
    KKColorRect color_rect(0xFFFF0000, 0xFFFF0000, 0xFFFF0000, 0xFFFF0000);
    [ftt drawText: @"来白桦" OffsetPoint: pt ClipRect: nil ColorRect: color_rect];
    [ftt render];
    return;
    */
    /*
    [[ImgsetMgr getSingleton] addImageSet:@"renderer"];
    CGRect dest_rect = CGRectMake( 0, 0, 26, 11 );
    //CGRect clip_rect = CGRectMake( 0, 0, 15, 50 );
    Image * img = [[[ImgsetMgr getSingleton] getImageset:@"renderer"] getImage:@"WaveBlueM"];
    
    [img draw: dest_rect ClipRect:nil ColorRect:COLOR_RECT_WHITE];

    dest_rect.origin.x += 26;
    dest_rect.origin.y += 11;
    
    [img draw: dest_rect ClipRect:nil ColorRect:COLOR_RECT_WHITE];
    
    
    [[[ImgsetMgr getSingleton] getImageset:@"renderer"] render];
    
    return;
    */
    
    [audio_module awakeFromNib];
    [audio_module initRecorder:eval_module CallbackObject: self];
    
    char MdmName[256] = {0};
    
    NSString *basePath0 = [[NSBundle mainBundle] bundlePath];
    NSRange range = [basePath0 rangeOfString:@"/KTV.app"];
    NSString *basePath1 = [basePath0 substringWithRange:NSMakeRange(0, range.location)];
    const char * basePath = [basePath1 UTF8String];
    
//    static char basePath[256] = "/Users/hujianping_NB/Downloads/projects/";
    
    sprintf(MdmName, "%s/Documents/top100/mdm100/%s.mdm",[basePath1 UTF8String],[mfileName cStringUsingEncoding:NSUTF8StringEncoding]);
    [eval_module loadSongInfo:mSongInfo FileName:MdmName];
    
    // 暂时用结束时间代替。
    mSongInfo.song_tm = mSongInfo.end_tm / 1000.0f + 5.0f;
    NSString * strLyric = [self getLyric: mSongInfo];
    [self genWaveAndLyric: mSongInfo];
    [lyric_render loadFont: strLyric ];
    [lyric_render setMode: false];

    [wave_render setMode: false];
    
    char Mp3Name[256] = {0};
    sprintf(Mp3Name, "%s/Documents/top100/top100_1/%s.mp3",[basePath1 UTF8String],[mfileName cStringUsingEncoding:NSUTF8StringEncoding]);
    [audio_module play:Mp3Name];
    [audio_module record];
}

// called once every frame
-(void) update: (NSNumber * ) ns_elapsed_ms
{
    //return;
    unsigned int elapsed_ms = [ns_elapsed_ms unsignedIntegerValue];
    /*
    if ( elapsed_ms > 17 || elapsed_ms < 16 )
    {
        NSLog( @"elapsed_ms[%d]", elapsed_ms );
    }
    */
    if ( mnCallbackRealtimeGradeCount > 0 )
	{
        _tRealtimeGrade & realtime_grade = mCallbackRealtimeGrade[mnCallbackRealtimeGradeCount-1];
        [self eventAvRealtimeGrade: elapsed_ms RealtimeGrade: realtime_grade IsCallback: true];
        mnCallbackRealtimeGradeCount--;
    }
    
    [self eventMainUpdate: elapsed_ms];

    if ( mnCallbackSentenceGradeCount > 0 )
	{
        _tSentenceGrade & sentence_grade = mCallbackSentenceGrade[mnCallbackSentenceGradeCount-1];
        [self eventAvSentenceGrade: sentence_grade];
        mnCallbackSentenceGradeCount--;
    }
    
    //用于倒计时更新时间。
    [sentence_render update:elapsed_ms];
    
    [wave_render populateGeometryBuffer];
    [lyric_render populateGeometryBuffer];
    [sentence_render populateGeometryBuffer];
}

// called once every frame
/*
 
-(void)render
{
	if (!mesh) return; // if we do not have a mesh, no need to render
	// clear the matrix
	glPushMatrix();
	glLoadIdentity();
	glMultMatrixf(matrix);
	[mesh render];	
	glPopMatrix();
}
*/

@end
