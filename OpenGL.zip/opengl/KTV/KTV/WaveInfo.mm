//
//  WaveInfo.cpp
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "WaveInfo.h"

@implementation _tGuiWaveInfo

@synthesize l, r, y;

- (id) init
{
    self = [super init];
    l = 0;
    r = 0;
    y = 0;
    return self;
}

@end