//
//  LyricRender.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KKType.h"
#import "FreeTypeFont.h"

//-----------------------------------------------------------------------------
@interface LyricRender : NSObject
{
@private
	NSMutableArray *                    mVecLyric;          // std::vector<_tGuiLyricInfo>
	NSMutableArray *                    mVecLittleLyric;    // std::vector<_tGuiLyricInfo>
    
	NSString *							mSongName;
	NSString *							mSongPlayedTime;
    
	bool								mbFirstSentence;
    
	float								mfMovieImagePos;
	float								mfTipImageTrans;
	float								mfStartPos;
	float								mfNextStartPos;
	float								mfTextPos;
	float								mfTextLittlePos;
	float								mfTextWidth;
	float								mfNextTextWidth;
	float								mfSongNameWidth;
	bool								mbKtvMode;
    
    bool                                mbInvalidate;
    
    FreeTypeFont *                      mFreeTypeFont;
}

// 加载歌词字体
- (void) loadFont: (NSString *) strLyric;

// 设置曲谱模式是否为KTV模式(曲谱模式:KTV模式,游戏模式)
- (void) setMode: ( bool ) ktv_mode;

// 设置歌词框演唱起点
- (void) setFirstLyricStartPos: ( float ) start_pos;

// 设置歌词框演唱起点
- (void) setNextLyricStartPos: ( float ) start_pos;

// 歌曲播放时间
- (void) setSongTime: ( NSString* ) curtime;

// 歌曲名称
- (void) setSongName: ( NSString* ) curname;

// 显示歌词(std::vector<_tGuiLyricInfo>)
- (float) showFirstLyric: (NSMutableArray*) lyric_list  Refresh: ( bool ) refresh/* = false */;

// 显示小歌词(std::vector<_tGuiLyricInfo>)
- (float) showSecondLyric: (NSMutableArray*) lyric_list  Refresh: ( bool ) refresh/* = false */;

// 设置滑动图标位置
- (void) setLyricMovePos: ( float ) position;

// 设置提示图标透明度
- (void) setLyricTipImageTrans: ( float ) trans;

// 设置当前句是否为第一句
- (void) switchSentence: ( bool ) bFirstSentence;

// 重置所有标志位
- (void) reset;

- (void) populateGeometryBuffer;

@end // LyricRender
