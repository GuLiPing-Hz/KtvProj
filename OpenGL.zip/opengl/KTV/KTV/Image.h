//
//  BBTexturedQuad.h
//  SpaceRocks
//
//  Created by ben smith on 14/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Imageset.h"
#import "KKType.h"

@interface Image : NSObject {
    CGRect rect;
    CGPoint offset;
	Imageset * imgset;
}

@property (assign) CGRect rect;
@property (assign) CGPoint offset;
@property (retain) Imageset * imgset;

- (void) draw: (CGRect&) dest_rect ClipRect: (CGRect*) pclip_rect ColorRect: (KKColorRect&) color_rect;

@end
