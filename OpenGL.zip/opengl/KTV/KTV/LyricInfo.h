//
//  LyricInfo.h
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>

//-----------------------------------------------------------------------------
// 谱线位置信息
@interface _tGuiLyricInfo : NSObject {
    NSString *      lyric;
    float			width;
    int             pos;
}

@property (nonatomic,retain) NSString * lyric;
@property (assign) float width;
@property (assign) int pos;

@end
