//
//  FreeTypeFont.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#include "FreeTypeFont.h"
#include "KKType.h"
#import "Image.h"
#import "Imageset.h"
#import "ImgsetMgr.h"

@implementation FreeTypeFont

@synthesize m_Imageset;

- (void)dealloc
{
    [m_Imageset release];
    [super dealloc];
}

- (id) init
{
    TEXSIZE                 = 512;
    self = [super init];
    
    return self;
}

//----------------------------------------------------------------------------//
/*!
 \brief
 Copy the current glyph data into \a buffer, which has a width of
 \a buf_width pixels (not bytes).
 
 \param buffer
 Memory buffer large enough to receive the imagery for the currently
 loaded glyph.
 
 \param buf_width
 Width of \a buffer in pixels (where each pixel is a argb_t).
 
 \return
 Nothing.
 */
- (void) drawGlyphToBuffer: (uint *)buffer BufferWidth: (uint) buf_width GlyphBitmap: (FT_Bitmap *) glyph_bitmap XOffset: (int) xoff/* = 0*/ YOffset: (int) yoff/* = 0*/ Background: (BOOL) bkg/* = YES */
{
	switch (glyph_bitmap->pixel_mode)
	{
        case FT_PIXEL_MODE_GRAY:
		{
			buffer += buf_width * yoff;
			for (int i = 0; i < glyph_bitmap->rows; ++i)
			{
				u_char *src = glyph_bitmap->buffer + ( i * glyph_bitmap->pitch );
				u_char *dst = (u_char*)( buffer + xoff );
				for (int j = 0; j < glyph_bitmap->width; ++j)
				{
					// RGBA
                    
					if ( bkg )
					{
                        *dst++ = 0xFF;
                        *dst++ = 0xFF;
                        *dst++ = 0xFF;

						*dst = ( *src ) >> 1;
					}
					else
					{
						if ( *src != 0 )
						{
                            *dst++ = 0xFF;
                            *dst++ = 0xFF;
                            *dst++ = 0xFF;

							if ( *dst == 0 )
							{
								*dst = *src;
							}
							else if ( *dst + *src > glyph_bitmap->num_grays - 1 )
							{
								*dst = glyph_bitmap->num_grays - 1;
							}
							else
							{
								*dst = ( u_char )( *dst + *src );
							}
                            
                            ++dst;
						}
						else
						{
                            dst += 4;
                            // if current pixel alpha value is 0,ignore.
						}
					}
                    
					++src;
				}
				buffer += buf_width;
			}
		}
        break;
            
        case FT_PIXEL_MODE_MONO:
		{
			for (int i = 0; i < glyph_bitmap->rows; ++i)
			{
				u_char *src = glyph_bitmap->buffer + ( ( i + yoff ) * glyph_bitmap->pitch) + xoff;
                
				for (int j = 0; j < glyph_bitmap->width; ++j)
					buffer [j] = (src [j / 8] & (0x80 >> (j & 7))) ? 0xFFFFFFFF : 0x00000000;
                
				buffer += buf_width;
			}
		}
        break;
            
        default:
        break;
	}
}

- (BOOL) load:(NSString *)ftt_filename LyricString:(NSString *)strLyric
{
    // 初始化变量
    uint tex_x = 0;
    uint tex_y = 0;
    uint tex_yb = 0;
    uint * d_memBuffer = (uint *)( malloc(sizeof(uint) * TEXSIZE * TEXSIZE) );
    
    GLuint texID = 0;

    // 初始化字体库
    FT_Library library;
    FT_Face face;
    
    FT_Error error = FT_Init_FreeType( &library );
    
#if TARGET_IPHONE_SIMULATOR
    error = FT_New_Face( library, "/Library/Fonts/华文黑体.ttf", 0, &face );
#else
    error = FT_New_Face( library, "/System/Library/Fonts/Cache/STHeiti-Light.ttc", 0, &face );
#endif
        
    error = FT_Set_Char_Size(face, // handle to face object
                             6*64, // char_width in 1/64th of points
                             6*64, // char_height in 1/64th of points
                             326, // horizontal device resolution
                             326 ); // vertical device resolution

    /*
    error = FT_Set_Pixel_Sizes(face, // handle to face object
                               0, // pixel_width
                               18 ); // pixel_height
    */
    
    int l = [strLyric length];
    for ( int i = 0; i < l; ++i )
    {
        NSString * substr = [strLyric substringWithRange:NSMakeRange(i, 1)];
        unichar uc = [strLyric characterAtIndex:i];
        FT_ULong c = (FT_ULong)(uc);

        uint glyph_w = 0;
        uint glyph_h = 0;
        
        // Render the glyph
        bool is_load = (0 == FT_Load_Char(face, c, FT_LOAD_RENDER | FT_LOAD_FORCE_AUTOHINT | FT_LOAD_TARGET_NORMAL));
        
        if ( is_load )
        {
            glyph_w = face->glyph->bitmap.width + INTER_GLYPH_PAD_SPACE;
            glyph_h = face->glyph->bitmap.rows + INTER_GLYPH_PAD_SPACE;
        }
        
        // Check if glyph right margin does not exceed texture size
        uint x_next = tex_x + glyph_w;
        if (x_next > TEXSIZE)
        {
            tex_x = INTER_GLYPH_PAD_SPACE;
            x_next = tex_x + glyph_w;
            tex_y = tex_yb;
        }
        
        // Check if glyph bottom margine does not exceed texture size
        uint y_bot = tex_y + glyph_h;
        if (y_bot > TEXSIZE)
        {
            m_Imageset = 0;
        }
        
        if ( nil == m_Imageset )
        {
            memset(d_memBuffer, 0, TEXSIZE * TEXSIZE * sizeof(uint));
            
            // NSString * name = [[NSString alloc] initWithFormat:@"_auto_glyph_images_%d", (int)(c)];
            glGenTextures(1, &texID );

            m_Imageset = [[ImgsetMgr getSingleton] addImageSet:@"FreeTypeFont"];
            
            CGSize tex_size = CGSizeMake( TEXSIZE, TEXSIZE );
            [m_Imageset setTexture: texID TextureSize:tex_size];
            
            tex_x = INTER_GLYPH_PAD_SPACE;
            tex_y = INTER_GLYPH_PAD_SPACE;
            tex_yb = INTER_GLYPH_PAD_SPACE;
            
            x_next = tex_x + glyph_w;
            y_bot = tex_y + glyph_h;
        }
        
        if ( !is_load )
        {
            NSLog(@"Font::loadFreetypeGlyph - Failed to load glyph for codepoint: %@.  Will use an empty image for this glyph!", substr);
            
            // Create a 'null' image for this glyph so we do not seg later
            CGRect area = CGRectZero;
            CGPoint offset = CGPointZero;
            NSString *name = [[NSString alloc] initWithFormat:@"%c", ((uint)c)];
            [m_Imageset addImage: name ImageRect: area ImageOffset: offset];
            [name release];///////////glp
        }
        else
        {
            uint * buf = d_memBuffer + (tex_y * TEXSIZE) + tex_x;
            FT_Bitmap * glyphBitmap = &face->glyph->bitmap;
            
            [self drawGlyphToBuffer: buf BufferWidth: TEXSIZE GlyphBitmap: glyphBitmap XOffset:0 YOffset:0 Background: NO];
            
            // Create a new image in the imageset
            CGRect area = CGRectMake( (CGFloat)tex_x,
                      (CGFloat)tex_y,
                      (CGFloat)(face->glyph->bitmap.width),
                      (CGFloat)(face->glyph->bitmap.rows));
            
            CGPoint offset = CGPointMake( face->glyph->metrics.horiBearingX * (CGFloat)(FT_POS_COEF),
                         -face->glyph->metrics.horiBearingY * (CGFloat)(FT_POS_COEF));
            
            [m_Imageset addImage: substr ImageRect: area ImageOffset: offset];
            
            // Advance to next position
            tex_x = x_next;
            if (y_bot > tex_yb)
            {
                tex_yb = y_bot;
            }
        }
    }
    
    FT_Done_Face(face);
    FT_Done_FreeType(library);
    glBindTexture(GL_TEXTURE_2D, texID);

    // Copy our memory buffer into the texture
    //设置纹理参数。告诉OpenGl在纹理不完全匹配的时候处理其中的像素方式。
    //模糊滤波器（缩小）
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    //锐化滤波器（放大）
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // 启用2D纹理功能。
    glEnable(GL_TEXTURE_2D);
    // 设置要使用的一个混合函数。告诉OpenGL如何处理半透明的纹理
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
     
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, TEXSIZE, TEXSIZE, 0, GL_RGBA, GL_UNSIGNED_BYTE, d_memBuffer);
    
    // 启用混合
    glEnable(GL_BLEND);
    
    free(d_memBuffer);

    return YES;
}

- (CGFloat) getTextExtent: (NSString*) strLyric
{
    CGFloat w = 0.0f;
    int l = [strLyric length];
    for ( int i = 0; i < l; ++i ) {
        NSString * strWord = [strLyric substringWithRange:NSMakeRange(i,1)];
        Image * img = [m_Imageset getImage: strWord];
        w += img.rect.size.width;
    }
    
    return w;
}

- (void) drawText: (NSString*) strText OffsetPoint: (CGPoint&) pt ClipRect: (CGRect*) pclip_rect ColorRect: (KKColorRect&) color_rect
{
    int l = (int)([strText length]);
    int x = pt.x;
    int y = pt.y;
    
    for ( int i = 0; i < l; ++i ) {
        NSString * substr = [strText substringWithRange:NSMakeRange(i, 1)];
        Image * img = [m_Imageset getImage:substr];
        if ( img )
        {
            CGRect dest_rect = CGRectMake( x, y, img.rect.size.width, img.rect.size.height);
            [img draw: dest_rect ClipRect: pclip_rect ColorRect: color_rect];
            x += img.rect.size.width;
        }
    }
}

- (void) render
{
    [m_Imageset render];
}

@end // FreeTypeFont