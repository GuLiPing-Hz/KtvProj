//
//  WaveInfo.h
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>

//-----------------------------------------------------------------------------
// 谱线位置信息
@interface _tGuiWaveInfo : NSObject {
    int l;
    int r;
    int y;		// 左 右 y轴全局像素位置
}

@property (assign) int l;
@property (assign) int r;
@property (assign) int y;

@end
