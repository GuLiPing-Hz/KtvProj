//
//  ImgsetMgr.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import "ImgsetMgr.h"
#import "Imageset.h"
#import "Image.h"

@implementation ImgsetMgr


@synthesize mImagesets;

- (void)dealloc
{
    [mImagesets release];
    
    [super dealloc];
}

+ (ImgsetMgr *) getSingleton
{
    static ImgsetMgr * instance = nil;
    @synchronized(self)
    {
        if (!instance)
            instance = [[ImgsetMgr alloc] init];
		
        return instance;
    }
	return instance;
}

- (Imageset *) getImageset:(NSString *)imgset_name
{
    if (mImagesets == nil) {
        return  nil;
    }
    Imageset * imgset = [mImagesets valueForKey:imgset_name];
    return imgset;
}

- (Image *) getImage:(NSString *)imgset_name ImageName:(NSString *)img_name
{
    if (mImagesets == nil) {
        return  nil;
    }
    Imageset * imgset = [mImagesets valueForKey:imgset_name];
    return [imgset getImage:img_name];
}

- (Imageset *) addImageSet:(NSString *)imgset_name
{
    if( imgset_name != nil )
    {
        Imageset * imgset = [[Imageset alloc] init];
        [imgset load:imgset_name];
        if (mImagesets == nil) {
            mImagesets = [[NSMutableDictionary alloc] init];
        }
        [mImagesets setObject:imgset forKey:imgset_name];
        
        return [imgset autorelease];////////////glp
    }
    return nil;
}

- (void) renderAll
{
    if (mImagesets == nil) {
        return;
    }
    NSArray * imgsets = [mImagesets allValues];
    for ( Imageset * imgset in imgsets) {
        [imgset bindTexture];
        [imgset render];
    }
}



@end