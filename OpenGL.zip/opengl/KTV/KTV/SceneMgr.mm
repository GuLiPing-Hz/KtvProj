//
//
//  Karaoke
//
//  Created by 天格glp on 12-8-21.
//
//

#include <sys/time.h>
#import "SceneMgr.h"
#import "InputViewController.h"
#import "EAGLView.h"
#import "SceneObject.h"
#import "ImgsetMgr.h"

@implementation SceneMgr

@synthesize inputController, openGLView;
@synthesize animationInterval, animationTimer;

// Singleton accessor.  this is how you should ALWAYS get a reference
// to the scene controller.  Never init your own. 
+(SceneMgr*) getSingleton
{
    static SceneMgr *instance = nil;
    @synchronized(self)
    {
        if (!instance)
            instance = [[SceneMgr alloc] init];
    }
    return instance;
}

- (void) addObjectToScene:(SceneObject *)object
{
    if (objectsToAdd == nil) {
        objectsToAdd = [[NSMutableArray alloc] init];
    }
    object.active = YES;
    [object awake];
    [objectsToAdd addObject:object];
}

- (void) addObjectToRemove:(SceneObject *)object
{
    if (objectsToRemove == nil) {
        objectsToRemove = [[NSMutableArray alloc] init];
    }
    [objectsToRemove addObject:object];
}

- (void) removeObjectFromScene:(SceneObject *)object
{
    if (objectsToRemove == nil) {
        objectsToRemove = [[NSMutableArray alloc] init];
        [objectsToRemove addObject:object];
    }
}

#pragma mark scene preload

// this is where we initialize all our scene objects
-(void) loadScene
{
/*
	// this is where we store all our objects
	if (sceneObjects == nil) sceneObjects = [[NSMutableArray alloc] init];
	[sceneObjects removeAllObjects];
	
	//Add a single scene object just for testing
	SceneObject * object = [[SceneObject alloc] init];
	[self addObjectToScene:object];
*/
// hjp
//	[object release];
    /*BBSpaceShip * ship = [[BBSpaceShip alloc] init];
    [ship awake];
	[self addObjectToScene:ship];
	[ship release];*/
}

-(void) startScene
{
	self.animationInterval = 1.0/60.0;
	[self startAnimation];
    // reset clock
    startTimeInterval = CFAbsoluteTimeGetCurrent();
}

#pragma mark Game Loop

- (void) gameLoop
{
    @autoreleasepool {
        // apply our inputs to the objects in the scene
        //@NSAutoreleasePool{使用自己使用的释放池
        //添加任何排队的场景对象
        if ([objectsToAdd count] > 0) {
            if (sceneObjects == nil)
            {
                sceneObjects = [[NSMutableArray alloc] init];
            }
            
            [sceneObjects addObjectsFromArray:objectsToAdd];
            [objectsToAdd removeAllObjects];
        }
                
        curTimeInterval = CFAbsoluteTimeGetCurrent();
        unsigned int elapsed_ms = ( (unsigned int)( ( curTimeInterval - startTimeInterval ) * 1000 ) - durationMS );
        durationMS += elapsed_ms;
                
        NSNumber * ns_elapsed_ms = [[NSNumber alloc] initWithUnsignedInt:elapsed_ms];
        
        /*
        static int last_duration_s = 0;
        int duration_s = (int)(durationSeconds);
        if ( duration_s != last_duration_s )
        {
            last_duration_s = duration_s;
            NSLog( @"duration_ms[%d].", duration_s );
        }
        */
        [self updateModel: ns_elapsed_ms];
        [ns_elapsed_ms release];/////////////////glp
        // send our objects to the renderer
        [self renderScene];
        
        
        //删除任何需要删除的对象
        if([objectsToRemove count] > 0)
        {
            [sceneObjects removeObjectsInArray:objectsToRemove];
            [objectsToAdd removeAllObjects];
        }
    }
}

- (void) updateModel: (NSNumber * ) ns_elapsed_ms
{
	// simply call 'update' on all our scene objects
	[sceneObjects makeObjectsPerformSelector:@selector(update:) withObject: ns_elapsed_ms ];
	// be sure to clear the events
	[inputController clearEvents];
}

- (void) renderScene
{
	// turn openGL 'on' for this frame
	[openGLView beginDraw];//为这一帧启动
	// simply call 'render' on all our scene objects
	[[ImgsetMgr getSingleton] renderAll];
	// finalize this frame
	[openGLView finishDraw];//结束这一帧
}


#pragma mark Animation Timer

// these methods are copied over from the EAGLView template

- (void) startAnimation {
    //启动定时器
	self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:animationInterval target:self selector:@selector(gameLoop) userInfo:nil repeats:YES];
    
    //还有一种方法：显示链接，硬件触发的回调函数在1／60秒屏幕刷新的时候调用gameLoop一次
    //CADisplayLink *displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(gameLoop)];
    //displayLink.FrameInterval = animationInterval;
    //[displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
}

- (void) stopAnimation {
	self.animationTimer = nil;
}

- (void) setAnimationTimer:(NSTimer *)newTimer {
	[animationTimer invalidate];
    NSLog(@"set AnimationTimer");
	animationTimer = newTimer;
}

- (void) setAnimationInterval:(NSTimeInterval)interval {	
	animationInterval = interval;
	if (animationTimer) {
		[self stopAnimation];
		[self startAnimation];
	}
}

#pragma mark dealloc

- (void) dealloc
{
	[self stopAnimation];
// hjp
    [sceneObjects release];
    [objectsToAdd release];
    [objectsToRemove release];
    [openGLView release];
    [animationTimer release];
    [inputController release];
    [levelStartDate release];
    
	[super dealloc];
// hjp
}


@end
