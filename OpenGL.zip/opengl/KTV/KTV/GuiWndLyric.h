#pragma once
#include "gui/GuiPrerequisites.h"
#include "gui/IGuiDef.h"

//-----------------------------------------------------------------------------
class CGuiWndLyric : public CEGUI::Window
{
public:
	// 构造函数
    CGuiWndLyric( const CEGUI::String & type, const CEGUI::String & name );

	// 析构函数
    virtual ~CGuiWndLyric();

	// 设置曲谱模式是否为KTV模式(曲谱模式:KTV模式,游戏模式)
	void setMode( bool ktv_mode );

	// 设置歌词框演唱起点
	void setFirstLyricStartPos( float start_pos );

	// 设置歌词框演唱起点
	void setNextLyricStartPos( float start_pos );

	// 歌曲播放时间
	void setSongTime( const std::string& curtime );

	// 歌曲名称
	void setSongName( const std::string& curname );

	// 显示歌词
	float showFirstLyric( std::vector< Gui::_tGuiLyricInfo > & lyric_list, bool refresh = false );

	// 显示小歌词
	float showSecondLyric( std::vector< Gui::_tGuiLyricInfo > & lyric_list, bool refresh = false  );

	// 设置滑动图标位置
	virtual void setLyricMovePos( float position );

	// 设置提示图标透明度
	virtual void setLyricTipImageTrans( float trans );

	// 设置当前句是否为第一句
	virtual void switchSentence( bool bFirstSentence );

	// 重置所有标志位
	void reset();


protected:
	virtual void populateGeometryBuffer();

private:
	std::vector< Gui::_tGuiLyricInfo >	mVecLyric;
	std::vector< Gui::_tGuiLyricInfo >	mVecLittleLyric;

	std::string							mSongName;
	std::string							mSongPlayedTime;

	bool								mbFirstSentence;

	float								mfMovieImagePos;
	float								mfTipImageTrans;
	float								mfStartPos;
	float								mfNextStartPos;
	float								mfTextPos;
	float								mfTextLittlePos;
	float								mfTextWidth;
	float								mfNextTextWidth;
	float								mfSongNameWidth;
	bool								mbKtvMode;
};

//-----------------------------------------------------------------------------
class CGuiWndLyricFactory : public CEGUI::WindowFactory
{
public:
    CGuiWndLyricFactory( void );

	~CGuiWndLyricFactory( void );
	
    CEGUI::Window * createWindow( const CEGUI::String & name );
	
    void destroyWindow( CEGUI::Window * window );
};


//-----------------------------------------------------------------------------
class CSongBegin : public CEGUI::Window
{
public:
	// 构造函数
	CSongBegin( const CEGUI::String & type, const CEGUI::String & name );

	// 析构函数
	virtual ~CSongBegin();

	void showSentenceScore( int score );

	void setBeginTotalTime( float begin_time );

	void setCurentTime( float elapsed_time );

	void reset();

protected:
	virtual void populateGeometryBuffer();
	

private:

	float							mfBeginTotalTime;
	float							mfLastChangTime;

	std::map< int, std::string >	mNumStringMap;

	std::vector< std::string >		mScoreText;

	typedef std::map< int, std::string >::const_iterator	NumStringMapConstIterator;
	typedef std::map< int, std::string >::iterator			NumStringMapIterator;


	unsigned int	miCount;

};

//-----------------------------------------------------------------------------
class CSongBeginFactory : public CEGUI::WindowFactory
{
public:
	CSongBeginFactory( void );

	~CSongBeginFactory( void );

	CEGUI::Window * createWindow( const CEGUI::String & name );

	void destroyWindow( CEGUI::Window * window );
};
