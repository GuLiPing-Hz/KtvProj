//
//  TransParams.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#include "TransParams.h"

@implementation TransParams

- (id) init
{
    self = [super init];
    
    meTransType = TRANS_NONE;
    mbLoop = NO;
    mbEnd = NO;

    mfTransTm = 0.0f;
    mfAlpha = 0.0f;
    mfScale = 0.0f;

    mfAlphaBegin = 0.0f;
    mfFadeinTm = 0.5f;
    mfDelayTm = 0.5f;
    mfFadeoutTm = 0.5f;

    mfRotateTm = 0.6f;

    if ( mfAlphaBegin > 1.0f )
        mfAlphaBegin = 1.0f;

    if ( mfFadeinTm > 0.0f )
        mfFadeinFactor = ( 1.0 - mfAlphaBegin ) / mfFadeinTm;
    else
        mfFadeinFactor = 0.0f;

    if ( mfFadeoutTm > 0.0f )
        mfFadeoutFactor = ( 1.0 - 0.0 ) / mfFadeoutTm;
    else
        mfFadeoutFactor = 0.0f;

    if ( mfRotateTm > 0.0f )
        mfRotateFactor = ( 1.0 - 0.0 ) / mfRotateTm;
    else
        mfRotateFactor = 0.0f;
        
    return self;
}

//-----------------------------------------------------------------------------
- (id) initByParams:
             (BOOL) bLoop
             TransType: (_eTansType) eTransType/* = TRANS_ALPHA */
             AlphaBegin: (CGFloat) fAlphaBegin/* = 0.0f */
             FadeinTm: (CGFloat) fFadeinTm/* = 0.5f */
             DelayTm: (CGFloat) fDelayTm/* = 0.5f */
             FadeoutTm: (CGFloat) fFadeoutTm/* = 0.5f */
             RotateTm: (CGFloat) fRotateTm/* = 0.6f */
{
    self = [super init];
    mbLoop = bLoop;
    meTransType = eTransType;
    mfAlphaBegin = fAlphaBegin;
    mfFadeinTm = fFadeinTm;
    mfDelayTm = fDelayTm;
    mfFadeoutTm = fFadeoutTm;
    mfRotateTm = fRotateTm;
    
    if ( mfAlphaBegin > 1.0f )
        mfAlphaBegin = 1.0f;
    
    if ( mfFadeinTm > 0.0f )
        mfFadeinFactor = ( 1.0 - mfAlphaBegin ) / mfFadeinTm;
    else
        mfFadeinFactor = 0.0f;
    
    if ( mfFadeoutTm > 0.0f )
        mfFadeoutFactor = ( 1.0 - 0.0 ) / mfFadeoutTm;
    else
        mfFadeoutFactor = 0.0f;
    
    if ( mfRotateTm > 0.0f )
        mfRotateFactor = ( 1.0 - 0.0 ) / mfRotateTm;
    else
        mfRotateFactor = 0.0f;
    
    [self reset];
    return self;
}

//-----------------------------------------------------------------------------
// 重置所有属性
- (void) reset
{
    //mbLoop = NO;
    //meTransType = TRANS_NONE
    mbEnd = NO;
    mfTransTm = 0.0f;
    mfAlpha = 0.0f;
    mfScale = 0.0f;
    mfAngle = 0.0f;
}

//-----------------------------------------------------------------------------
// 获取缩放和ALPHA值
- (void) trans: (CGFloat) elapsed_tm
{
    if ( mfTransTm <= ( mfFadeinTm + mfDelayTm + mfFadeoutTm ) )
    {
        if ( meTransType & TRANS_ALPHA )
        {
            if ( mfTransTm <= mfFadeinTm )
            {// 1.淡入
                mfAlpha += elapsed_tm * mfFadeinFactor;
            }
            else if ( mfTransTm <= ( mfFadeinTm + mfDelayTm ) )
            {// 2.保持ALPHA为1显示
                mfAlpha = 1.0f;
            }
            else
            {// 3.淡出
                mfAlpha -= elapsed_tm * mfFadeoutFactor;
            }
        }
        
        if ( meTransType & TRANS_SCALE )
        {
            if ( mfTransTm <= mfFadeinTm )
            {// 1.淡入
                mfScale += elapsed_tm * mfFadeinFactor;
            }
            else if ( mfTransTm <= ( mfFadeinTm + mfDelayTm ) )
            {// 2.保持ALPHA为1显示
                mfScale = 1.0f;
            }
            else
            {// 3.淡出
                mfScale -= elapsed_tm * mfFadeoutFactor;
            }
        }
        
        if ( meTransType & TRANS_ANGLE )
        {
            if ( mfTransTm <= mfRotateTm )
            {
                mfAngle += elapsed_tm * mfRotateFactor;
            }
        }
        
        mfTransTm += elapsed_tm;
    }
    else
    {
        if ( mbLoop )
        {
            [self reset];
        }
        else
        {
            mbEnd = YES;
        }
    }
}

//-----------------------------------------------------------------------------
// 设置是否循环
- (void) setLoop: (BOOL) _loop
{
    mbLoop = _loop;
}

//-----------------------------------------------------------------------------
// 获取是否循环
- (BOOL) getLoop
{
    return mbLoop;
}

//-----------------------------------------------------------------------------
// 获取Alpha值
- (CGFloat) getAlpha
{
    return mfAlpha;
}

//-----------------------------------------------------------------------------
// 获取Scale值
- (CGFloat) getScale
{
    return mfScale;
}

//-----------------------------------------------------------------------------
// 获取Angle值
- (CGFloat) getAngle
{
    return mfAngle;
}

//-----------------------------------------------------------------------------
// 是否结束
- (BOOL) isEnd
{
    return ( !mbLoop && mbEnd );
}

@end
