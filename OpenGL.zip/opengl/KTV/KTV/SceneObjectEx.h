//
//  SceneObjectEx.h
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//


#import "SceneObject.h"
#import "ftotype.h"
#import "eval.h"

#import "LyricRender.h"
#import "WaveRender.h"
#import "SentenceRender.h"

// 播放器相关
#import "AQPlayer.h"
#import "AQRecorder.h"
#import "AudioModule.h"

enum _eSingStage {
    SINGSTAGE_PRELUDE = 0,
    SINGSTAGE_SING = 1,
    SINGSTAGE_FINALE = 2,
};

@interface SceneObjectEx : SceneObject {
    NSMutableArray *        mGuiLyricVect;
    NSMutableArray *        mGuiPitchVect;
    NSMutableArray *        mGuiSentencelineVect;
    NSMutableArray *        mParagraphVect;
    
    bool                    mbInterpolation;
    bool                    mbIsCallback;
    bool                    mbIsMe;
    bool                    mbKtvMode;
    bool                    mbChangeMode;
    
    _tRealtimeGrade         mCurGrade;
    
    float                   mfElapsedCount;
    uint                    miElapsedCount;
    uint                    miLastElapsedCount;
    uint                    mErrCorrect;
    uint                    mPreTime;
    uint                    mCurTime;
    uint                    mCurSingTime;
    _eSingStage				mCurSingStage;
    
    float                   mfKtvErr;
    float                   mfGameErr;
    
    LyricRender *           lyric_render;
    WaveRender *            wave_render;
    SentenceRender *        sentence_render;
    
    
    // 播放器相关
    AudioModule *           audio_module;
    eval *                  eval_module;
    _tRealtimeGrade         mCallbackRealtimeGrade[16];
    uint                    mnCallbackRealtimeGradeCount;

    _tSentenceGrade         mCallbackSentenceGrade[8];
    uint                    mnCallbackSentenceGradeCount;

    _tSongInfo              mSongInfo;
    
    NSString *              mfileName;
}

@property (nonatomic,retain) NSString *mfileName;
@property (nonatomic,retain) eval * eval_module;

- (id) init:(NSString *)mdmName andkBufferDurationSeconds:(float)kBufferDurationSeconds andSampleRate:(double)sampleRate anddBUpperLimit:(double)dBUpperLimit;
- (void) dealloc;
- (void) awake;
//- (void) render;
- (void) update: (NSNumber * ) ns_elapsed_ms;

- (void) RealtimeGrade: (const _tRealtimeGrade & ) realtime_grade;

- (void) SentenceGrade: (const _tSentenceGrade & ) sentence_grade;

- (void) eventMainUpdate: (unsigned int) elapsed_ms;

// av：音频实时评分
- (void) eventAvRealtimeGrade: (unsigned int) elasped_ms RealtimeGrade: (_tRealtimeGrade &) grade IsCallback: (bool) is_callback/* = true*/;

// av：音频单句评分
- (void) eventAvSentenceGrade: (_tSentenceGrade &) grade;
//
- (AQPlayer *)getAudioPlayer;
- (AQRecorder *)getAudioRecorder;
@end
