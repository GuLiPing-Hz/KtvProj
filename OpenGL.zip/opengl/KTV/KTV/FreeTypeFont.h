//
//  FreeTypeFont.h
//  Karaoke
//
//  Created by 2012080303Imac on 12-8-23.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Imageset.h"

#include "ft2build.h"
#include "freetype.h"
#include "ftglyph.h"
#include "ftoutln.h"
#include "fttrigon.h"

@interface FreeTypeFont : NSObject
{
@private
    Imageset    * m_Imageset;
    uint        TEXSIZE;
}

@property (nonatomic, retain) Imageset * m_Imageset;

- (BOOL) load:(NSString*) ftt_filename LyricString: (NSString*) strLyric;
- (CGFloat) getTextExtent: (NSString*) strLyric;
- (void) drawText: (NSString*) strText OffsetPoint: (CGPoint&) pt ClipRect: (CGRect*) pclip_rect ColorRect: (KKColorRect&) color_rect;

- (void) render;
@end