//
//  KKType.h
//  Karaoke
//
//  Created by 2012080303Imac on 12-8-23.
//  Copyright (c) 2012年 9158. All rights reserved.
//
#ifndef __KKTYPE_H__
#define __KKTYPE_H__

#import <Foundation/Foundation.h>
#import "WaveInfo.h"
#import "LyricCursorInfo.h"
#import "LyricInfo.h"
#import "ParagraphInfo.h"

#ifdef __cplusplus
extern "C" {
#endif

// Pixels to put between glyphs
#define INTER_GLYPH_PAD_SPACE 2
// A multiplication coefficient to convert FT_Pos values into normal floats
#define FT_POS_COEF  (1.0/64.0)

const int WAVE_EFFECT_WIDTH = 1;
#define OFFSETWIDTH     90

#define NUM_COUNT       4
const float SCALE = 1.5f;			// 相对于16号字体的缩放比例 20 * 1.5f = 30
const float FONT_HEIGHT = 30;		// 字体高度（大概的）
const float LEFT_INDENT = 130;		// 第一句歌词左边缩进
const float RIGHT_INDENT = 100;		// 第二句歌词右边缩进
const float MAX_LYRIC_WIDTH = 700;	// 歌词最大宽度
    
const float TIP_IMAGE_CX = 0;//39;
const float TIP_IMAGE_Y1 = 0;
const float TIP_IMAGE_Y2 = 42;
    
const float MOVE_IMAGE_SPACE = 100;
const float MOVE_IMAGE_Y1 = 3;
const float MOVE_IMAGE_Y2 = 36;

#define FONT24_SPACE 2

static CGSize window_size = CGSizeMake(320,130);//getPixelSize();

//-----------------------------------------------------------------------------
typedef struct _KKColor
{
    CGFloat r;
    CGFloat g;
    CGFloat b;
    CGFloat a;
    
    _KKColor()
    {
        r = g = b = a = 1.0f;
    }
    
    _KKColor( CGFloat _r, CGFloat _g, CGFloat _b, CGFloat _a )
    {
        r = _r;
        g = _g;
        b = _b;
        a = _a;
    }
}KKColor;

//-----------------------------------------------------------------------------
typedef struct _KKColorRect
{
    KKColor left_top_color;
    KKColor left_bottom_color;
    KKColor right_top_color;
    KKColor right_bottom_color;
    
    _KKColorRect( uint lt, uint lb, uint rt, uint rb )
    {
        left_top_color.a = ((lt>>24)&0xFF) / 255.0f;
        left_top_color.r = ((lt>>16)&0xFF) / 255.0f;
        left_top_color.g = ((lt>>8)&0xFF) / 255.0f;
        left_top_color.b = ((lt)&0xFF) / 255.0f;
        
        left_bottom_color.a = ((lb>>24)&0xFF) / 255.0f;
        left_bottom_color.r = ((lb>>16)&0xFF) / 255.0f;
        left_bottom_color.g = ((lb>>8)&0xFF) / 255.0f;
        left_bottom_color.b = ((lb)&0xFF) / 255.0f;
        
        right_top_color.a = ((rt>>24)&0xFF) / 255.0f;
        right_top_color.r = ((rt>>16)&0xFF) / 255.0f;
        right_top_color.g = ((rt>>8)&0xFF) / 255.0f;
        right_top_color.b = ((rt)&0xFF) / 255.0f;
        
        right_bottom_color.a = ((rb>>24)&0xFF) / 255.0f;
        right_bottom_color.r = ((rb>>16)&0xFF) / 255.0f;
        right_bottom_color.g = ((rb>>8)&0xFF) / 255.0f;
        right_bottom_color.b = ((rb)&0xFF) / 255.0f;
    }
    
    _KKColorRect( KKColor & c )
    {
        left_top_color = c;
        left_bottom_color = c;
        right_top_color = c;
        right_bottom_color = c;
    }
}KKColorRect;
    
static KKColorRect COLOR_RECT_WHITE( 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF );
    
//-----------------------------------------------------------------------------
// 变换类型
enum _eTansType
{
    TRANS_NONE  = 0x00,
    TRANS_ALPHA = 0x01,
    TRANS_SCALE = 0x02,
    TRANS_ANGLE = 0x04
};
    
enum _eRank
{
    RANK_NONE = 0,                              // 无
    RANK_RED,                                   // 红阶
    RANK_YELLOW,                                // 黄阶
    RANK_GREEN                                  // 绿阶
};
    
enum _eQuadSplitMode
{
    TopLeftToBottomRight = 0,
    BottomLeftToTopRight = 1
};


#ifdef __cplusplus
}
#endif

#endif