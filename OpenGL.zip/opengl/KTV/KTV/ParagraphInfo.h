//
//  ParagraphInfo.h
//  Karaoke
//
//  Created by hujianping on 12-8-27.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>

//-----------------------------------------------------------------------------
// 谱线位置信息
@interface _tGuiParagraphInfo : NSObject {
    int             sentence_index;
    int             duration;
}

@property (assign) int sentence_index;
@property (assign) int duration;

@end // _tGuiParagraphInfo
