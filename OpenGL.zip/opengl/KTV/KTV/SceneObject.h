//
//  SceneObject.h
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <QuartzCore/QuartzCore.h>

#import "SceneMgr.h"
#import "InputViewController.h"

@interface SceneObject : NSObject {
	BOOL                    active;
    CGRect                  meshBounds;
}

@property (nonatomic) CGRect meshBounds;
@property (assign) BOOL active;

- (id) init;
- (void) dealloc;
- (void)awake;
//- (void)render;
- (void)update: (NSNumber * ) ns_elapsed_ms;

// 5 methods

@end
