//
//  Image.h
//
//  Created by 天格 on 12-8-21.
//
//

#import "Image.h"

@implementation Image

@synthesize rect, offset, imgset;

- (void)dealloc
{
    [imgset release];
    
    [super dealloc];
}

- (id) init
{
    self = [super init];
    return self;
}

- (void) draw: (CGRect&) dest_rect ClipRect: (CGRect*) pclip_rect ColorRect: (KKColorRect&) color_rect
{
    [imgset draw: rect DestRect: dest_rect ClipRect: pclip_rect ColorRect: color_rect ];
}

/*
// called once every frame
-(void)render//:(CGFloat *)vetex andcolors:(CGFloat *)colors
{
	glVertexPointer(vertexSize, GL_FLOAT, 0, vertexes);
	glEnableClientState(GL_VERTEX_ARRAY);
	glColorPointer(colorSize, GL_FLOAT, 0, colors);
	glEnableClientState(GL_COLOR_ARRAY);
	////////////////////////////////////
    
	if (materialKey != nil) {
		[[BBMaterialController sharedMaterialController] bindMaterial:materialKey];
        //调用材质控制器以绑定材质。
        //GL_TEXTURE_COORD_ARRAY,uvCoordinates它们是一组用来表示如何将纹理图像映射到表面的数字。
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        //确保启用纹理数组。
		glTexCoordPointer(2, GL_FLOAT, 0, uvCoordinates);
        //最后传入UV坐标。
	}
     ////////////////////////////////
    //NSLog(@"add is %i",funadd(10, 10));
    
    FT_Library library;
    FT_Face face;
    
    FT_Error error = FT_Init_FreeType( &library );
    
    error = FT_New_Face( library, "/Users/tiange01/Desktop/simhei.ttf", 0, &face );
    
    error = FT_Set_Char_Size(face, // handle to face object 
                             0, // char_width in 1/64th of points
                             16*64, // char_height in 1/64th of points 
                             300, // horizontal device resolution 
                             300 ); // vertical device resolution 
    
    error = FT_Set_Pixel_Sizes(face, // handle to face object 
                               0, // pixel_width 
                               16 ); // pixel_height 
    //while (<#condition#>) {
    
    const wchar_t *  charcode=L"古";
    FT_UInt glyph_index = FT_Get_Char_Index( face, *charcode );
    //}
    
    
    FT_Int32 load_flags = FT_LOAD_DEFAULT;
    error = FT_Load_Glyph(face, // handle to face object 
                          glyph_index, // glyph index 
                          load_flags ); // load flags, see below 
    
    //FT_Render_Mode render_mode = FT_RENDER_MODE_NORMAL;
    //error = FT_Render_Glyph( face->glyph, // glyph slot 
    //  render_mode ); // render mode 
    
    if (face->glyph->format != FT_GLYPH_FORMAT_BITMAP) {
        error = FT_Render_Glyph(face->glyph, FT_RENDER_MODE_NORMAL);
    }
    
    //error = FT_Set_Transform( face,  target face object
    // nil,//&matrix, //pointer to 2x2 matrix
    //nil);//&delta ); //pointer to 2d vector
    
    GLubyte *spriteData;
    
    size_t width,height;
    width = face->glyph->bitmap.width;
    height = face->glyph->bitmap.rows;
    FT_Bitmap *glyph_bitmap = &face->glyph->bitmap;
    
    
    spriteData = (GLubyte *) malloc(width * height * 4);
    memset(spriteData, 0, (width * height * 4));
    
    for (int i = 0; i < height; ++i)
    {
        unsigned char *src = glyph_bitmap->buffer + (i * glyph_bitmap->pitch);
        //switch (glyph_bitmap->pixel_mode)
        //{
        //   case FT_PIXEL_MODE_GRAY:
        // {
        
        //unsigned char *dst = reinterpret_cast<unsigned char*>(buffer);
        for (int j = 0; j < width; ++j)
        {
            // RGBA
            *spriteData++ = 0xFF;
            *spriteData++ = 0xFF;
            *spriteData++ = 0xFF;
            *spriteData++ = *src++;
        }
        //}
        //break;
        
        //case FT_PIXEL_MODE_MONO:
        //    for (int j = 0; j < glyph_bitmap->width; ++j)
        //       buffer [j] = (src [j / 8] & (0x80 >> (j & 7))) ? 0xFFFFFFFF : 0x00000000;
        //  break;
        
        //default:
        //   CEGUI_THROW(InvalidRequestException("Font::drawGlyphToBuffer: "
        //                                       "The glyph could not be drawn because the pixel mode is "
        //                                       "unsupported."));
        //   break;
        //}
        
        //buffer += buf_width;
    }
    
    GLuint _texture; // declared as un instance variable so its address never changes
    glGenTextures(1, &_texture);
    glBindTexture(GL_TEXTURE_2D, _texture);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, spriteData);
    free(spriteData);
    
    
    glEnable(GL_TEXTURE_2D); //启动纹理
	glBindTexture(GL_TEXTURE_2D, _texture);
    uvCoordinates = (CGFloat *)malloc(8*sizeof(CGFloat));
    uvCoordinates[0] = 0;
	uvCoordinates[1] = 1;
	
	uvCoordinates[2] = 1;
	uvCoordinates[3] = 1;
	
	uvCoordinates[4] = 0;
	uvCoordinates[5] = 0;
    
	uvCoordinates[6] = 1;
	uvCoordinates[7] = 0;
    
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, uvCoordinates);
    
    free(uvCoordinates);
	//render
	glDrawArrays(renderStyle, 0, vertexCount);
    glDeleteTextures(1, &_texture);
}
*/

@end
