//
//  SentenceRender.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KKType.h"
#import "Image.h"
#import "Imageset.h"
#import "TransParams.h"

#import "ftotype.h"

//-----------------------------------------------------------------------------
@interface SentenceRender : NSObject
{
    _eSentenceGradeLevel            meSentenceGradeLevel;
    int                             mnScore;
    bool                            mbInvalidate;
	NSMutableArray                  *mNumberImages;
	NSMutableArray                  *mGradeImages;
    int                             miCountDown;
}

- (void) showSentenceLevel: (_eSentenceGradeLevel) sentence_level;

- (void) showSentenceScore: (int) score;

- (void) update: (unsigned int) elapsed_tm;

- (void) reset;

- (void) populateGeometryBuffer;

@end //WaveRender
