//
//  main.m
//  Karaoke
//
//  Created by 2012080303Imac on 12-8-23.
//  Copyright (c) 2012年 9158. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
