//
//  eval.h
//  eval
//
//  Created by 2012080303Imac on 12-8-17.
//  Copyright (c) 2012年 2012080303Imac. All rights reserved.
//

#import <Foundation/Foundation.h>

#include "ftotype.h"

class Analyzer;
class CFtoExtractor;
struct Player;
struct VocalTrack;

@interface eval : NSObject
{
@private
    _tSongInfo mSongInfo;
    
    Analyzer * mpAnalyzer;
    CFtoExtractor * mpFtoExtractor;
    struct Player * mpPlayer;
    struct VocalTrack * mpVocalTrack;
    
    unsigned int *  mpSentenceRealtimeScoreCount;
    unsigned int    mnTimeStep;
    double          mfdBLimit;
    double          mfMagic;
    
    unsigned int    mSentenceIndex;
    float           mfTotalScore;
    float           mfAccumulatedSentenceScore;
    unsigned int	mnRealtimeScoreCount;
}

- (id) init:(int)rate dBLimit:(int)db_limit TimeStep:(int)time_step;

- (bool) loadSongInfo : ( _tSongInfo & ) song_info FileName : ( const char * ) file_name;

- (void) getTotalScore: (float &) total_score;

- (void) realtimeEval0 : (float const *)buffer BufferSize: (unsigned int)buffer_size CurTimeMs: (unsigned int)cur_timeMs Pitch: (float &) pitch PitchDiff: (float &) pitchdiff RealtimeScore: (float&) realtime_score Rank: (unsigned int &) rank SentenceIndex: (unsigned int &) sentence_index AccumulatedSentenceScore: (float &) accumulated_sentence_score SwitchSentence: (bool &) switch_sentence;

- (void) realtimeEval : (float const *)buffer BufferSize: (unsigned int)buffer_size CurTimeMs: (unsigned int)cur_timeMs Pitch: (float &) pitch  RealtimeScore: (float&) realtime_score Rank: (unsigned int &) rank SentenceIndex: (unsigned int &) sentence_index AccumulatedSentenceScore: (float &) accumulated_sentence_score SwitchSentence: (bool &) switch_sentence;

@end
