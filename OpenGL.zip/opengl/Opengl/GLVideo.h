#pragma once

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library


class CGLVideo
{
public:
	CGLVideo(int textureX = 0,int textureY = 0);
	~CGLVideo(void);

	bool GetTextureIDInit();
	BOOL Init(char *fileName);//
	BOOL LoadGLTexturesVideo();
	BOOL UpdateGLTextures();//��������
	void DrawVideo(float ScreenX,float ScreenY);
private:
	//��Ƶ����תΪ������ʽ������
	void ExchangeRedBlueC(BYTE* buffer);
	void ExchangeRedBlue(void* buffer)	;
	BOOL Video2TextureMem(BYTE* pVideo,BYTE* pTexture,int format=3);
	void makeTextureXY(int x,int y);

private:
	BYTE*	m_pvideoData;//��Ƶ����
	BYTE * m_pvideoTextureData;//��������
	GLuint	m_texture[1];			// Storage For One Texture
	float		m_uMax;
	float		m_uMin;
	float		m_vMax;
	float		m_vMin;

public:
	INT	m_videoWidth;//��Ƶ��
	INT	m_videoHeight;//��Ƶ��
	int	m_textureX;
	int	m_textureY;
	bool m_bInit;
};
