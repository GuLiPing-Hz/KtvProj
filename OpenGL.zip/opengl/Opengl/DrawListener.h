#pragma once
#include "timerex.h"

#include "Opengl.h"
#include "GLFlorid.h"
#include "GLVideo.h"
#include "staff/SceneMgr.h"

class DrawListener :
	public ITimerListener
{
public:
	DrawListener(CGLVideo* pglVideo=NULL,CGLFlorid* pglFlorid=NULL,SceneMgr* psceneMgr=NULL,float ScreenX=1280,float ScreenY=720);
	~DrawListener(void);
	virtual void onTimer( unsigned int elapsed_tm );
	virtual SceneMgr* GetSceneMgr();

	void SetSceneMgr(SceneMgr* psceneMgr);
	CGLVideo*	GetGLVideo();
	CGLFlorid*	GetGLFlorid();
	

private:
	CGLVideo*			m_pglVideo;//��Ƶ
	CGLFlorid*			m_pglFlorid;//Ч��
	SceneMgr*			m_sceneMgr;//���׳���

	float						m_ScreenX;
	float						m_ScreenY;
};
