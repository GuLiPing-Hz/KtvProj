#ifndef GLDEF__H__
#define GLDEF__H__


//glp

static char LOGPATH[] = "D:\\log.txt"; //��־path

typedef struct _CGPoint
{
	float x;
	float y;
	_CGPoint& operator=(const _CGPoint& a)
	{
		this->x = a.x;
		this->y = a.y;
		return *this;
	}
	bool operator==(const _CGPoint& a)
	{
		if (this->x==a.x&&this->y==a.y)
		{
			return true;
		}
		return false;
	}
	_CGPoint(float a=0,float b=0)
	{
		this->x = a;
		this->y = b;
	}
	_CGPoint(const _CGPoint& point)
	{
		this->x = point.x;
		this->y = point.y;
	}
}CGPoint;

typedef struct _CGSize 
{
	int width;
	int height;
	_CGSize& operator=(const _CGSize& a)
	{
		if ( this == &a )
			return *this;
		this->width = a.width;
		this->height = a.height;
		return *this;
	}
	bool operator==(const _CGSize& a)
	{
		if (this->width==a.width&&this->height==a.height)
		{
			return true;
		}
		return false;
	}
	_CGSize(int w=0,int h=0)
	{
		this->width = w;
		this->height = h;
	}
	_CGSize(const _CGSize& size)
	{
		this->width = size.width;
		this->height = size.height;
	}
}CGSize;

static CGSize CGSIZEZERO(0,0);

typedef struct _CGRect
{
	CGPoint origin;
	CGSize size;
	_CGRect& operator=(const _CGRect& a)
	{
		this->origin = a.origin;
		this->size = a.size;
		return *this;
	}
	bool operator==(const _CGRect& a)
	{
		if (this->origin==a.origin&&this->size==a.size)
		{
			return true;
		}
		return false;
	}
	_CGRect(const CGPoint& a=CGPoint(0.0f,0.0f),const CGSize& b=CGSize(0,0))
	{
		this->origin = a;
		this->size = b;
	}
	_CGRect(const _CGRect& rect)
	{
		this->origin = rect.origin;
		this->size = rect.size;
	}
}CGRect;

typedef float CGFloat;
typedef unsigned int  uint;
typedef unsigned long ulong;

//#define MSE_PITCHTRACK_ALGTYPE_YinACF	2

#endif//GLDEF__H__

