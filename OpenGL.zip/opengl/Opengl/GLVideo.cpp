#include "StdAfx.h"
#include "GLVideo.h"

#include "Opengl.h"
#include "PlayerDll/PlayerDll.h"

CGLVideo::CGLVideo(int textureX,int textureY):m_pvideoTextureData(NULL),
										m_videoHeight(0),
										m_videoWidth(0),
										m_textureX(textureX),
										m_textureY(textureY),
										m_pvideoData(NULL),
										m_uMax(0),
										m_uMin(0),
										m_vMin(0),
										m_vMax(0),
										m_bInit(false)
{
	m_texture[0] = 0;
}

bool CGLVideo::GetTextureIDInit()
{
	return m_bInit;
}


CGLVideo::~CGLVideo(void)
{
	if (m_pvideoTextureData)
	{
		delete [] m_pvideoTextureData;
		m_pvideoTextureData = NULL;
	}
	if (m_pvideoData)
	{
		delete [] m_pvideoData;
		m_pvideoData = NULL;
	}
}

BOOL CGLVideo::Video2TextureMem(BYTE* pVideo,BYTE* pTexture,int format)
{
	if (!pVideo || !pTexture)
	{
		return FALSE;
	}
	BYTE *tmpVideo = pVideo;
	BYTE *tmpTexture = pTexture;
	if ((m_videoWidth > m_textureX) || (m_videoHeight > m_textureY))
	{
		return FALSE;
	}
	for (int i=0;i<m_videoHeight;i++)
	{
		memcpy(tmpTexture,tmpVideo,m_videoWidth*format);
		tmpTexture = tmpTexture + m_textureX*format;
		tmpVideo = tmpVideo + m_videoWidth*format;
	}
	return TRUE;
}

BOOL CGLVideo::LoadGLTexturesVideo()
{
	BOOL Status=FALSE;									// Status Indicator

	GetFrameSize(m_videoWidth,m_videoHeight);
	//m_videoHeight = 512;
	//m_videoWidth = 512;
	//makeTextureXY(m_videoWidth,m_videoHeight);
	
	if (!m_pvideoData)
	{
		m_pvideoData= new BYTE[m_videoWidth*m_videoHeight*3];
	}
	//m_pvideoTextureData = new BYTE[m_textureX*m_textureY*3];
	if ( !m_pvideoData )
	{
		return Status;
	}

	//memset(m_pvideoData,0xFF,m_videoWidth*m_videoHeight*3);
	//int result = GetFrame(m_pvideoData,m_videoWidth,m_videoHeight);
	//if (result == 0)
	{
		//Video2TextureMem(m_pvideoData,m_pvideoTextureData);
		Status=TRUE;									// Set The Status To TRUE
		glGenTextures(1, &m_texture[0]);					// ����1������id

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, m_texture[0]);
//		glTexImage2D(GL_TEXTURE_2D, 0, 3, m_textureX, m_textureY, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_videoWidth, m_videoHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoData);

		glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE );
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

/*
		m_uMax = (float)m_videoWidth/m_textureX;
		m_uMin = (float)0.0/m_textureX;
		m_vMax = (float)m_videoHeight/m_textureY;
		m_vMin = (float)0.0/m_textureY;
*/
		m_uMax = 1.0f;
		m_uMin = 0.0f;
		m_vMax = 1.0f;
		m_vMin = 0.0f;

		m_bInit = true;
	}
	return Status;										// Return The Status
}

BOOL CGLVideo::UpdateGLTextures()//��������
{
	if (!m_bInit)
	{
		return FALSE;
	}
	if (!m_pvideoData)
	{
		return FALSE;
	}
	glBindTexture(GL_TEXTURE_2D, m_texture[0]);//������,֮ǰҪ����2D����
	int result = GetFrame(m_pvideoData,m_videoWidth,m_videoHeight);
	if (result == 0)
	{
		ExchangeRedBlue(m_pvideoData);
		/*if (*tmpVideoData == *m_pvideoData)
		{
			return TRUE;
		}*/
		//Video2TextureMem(m_pvideoData,m_pvideoTextureData);
		// ��������
		//glTexImage2D(GL_TEXTURE_2D, 0, 3, m_textureX, m_textureY, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
		glTexSubImage2D (GL_TEXTURE_2D, 0, 0, 0, m_videoWidth, m_videoHeight, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoData);
		//glTexSubImage2D (GL_TEXTURE_2D, 0, 0, 0, m_textureX, m_textureY, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
		
		return TRUE;
	}
	OutputDebugStringA("result==-1\n");
	//writeLog("result==-1");
	return FALSE;
}

void CGLVideo::DrawVideo(float ScreenX,float ScreenY)
{
	glTexCoord2f(m_uMin, m_vMin);//ָ��uv����
	glVertex3f(0.0f,-ScreenY, 0.0f);					// Bottom Left 

	glTexCoord2f(m_uMax, m_vMin);//ָ��uv����
	glVertex3f( ScreenX,-ScreenY, 0.0f);					// Bottom Right 

	glTexCoord2f(m_uMax, m_vMax);//ָ��uv����
	glVertex3f( ScreenX, -0.0f, 0.0f);					// Top Right 

	glTexCoord2f(m_uMin, m_vMax);//ָ��uv����
	glVertex3f(0.0f, 0.0f, 0.0f);					// Top Left 
}

void CGLVideo::makeTextureXY(int x,int y)
{
	int tx = 1;
	int ty = 1;
	while (tx<x)
	{
		tx = tx*2;
	}
	
	while(ty<y)
	{
		ty = ty*2;
	}
	//int txy = tx>ty?tx:ty;
	m_textureX = tx;
	m_textureY = ty;
}

void CGLVideo::ExchangeRedBlueC(BYTE* buffer)
{
	if (buffer == NULL)
	{
		return;
	}
	BYTE * tmpP = buffer;
	int sum = m_videoWidth*m_videoHeight*3;
	for (int i =0;i<sum;i+=3)
	{
		BYTE tmpB = tmpP[i];
		tmpP[i] = tmpP[i+2];
		tmpP[i+2] = tmpB;
	}
}

void CGLVideo::ExchangeRedBlue(void* buffer)										// Flips The Red And Blue Bytes (256x256)
{
	void* b = buffer;											// Pointer To The Buffer
	int s = m_videoHeight*m_videoWidth;
	__asm														// Assembler Code To Follow
	{
		mov ecx, s										// Counter Set To Dimensions Of Our Memory Block
		mov ebx, b												// Points ebx To Our Data (b)
		label:													// Label Used For Looping
				mov al,[ebx+0]										// Loads Value At ebx Into al
				mov ah,[ebx+2]										// Loads Value At ebx+2 Into ah
				mov [ebx+2],al										// Stores Value In al At ebx+2
				mov [ebx+0],ah										// Stores Value In ah At ebx

				add ebx,3											// Moves Through The Data By 3 Bytes
				dec ecx												// Decreases Our Loop Counter
				jnz label											// If Not Zero Jump Back To Label
	}
}
