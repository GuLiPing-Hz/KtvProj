//
//  FreeTypeFont.h
//  Karaoke
//
#pragma  once

#include "../Opengl.h"
#include "../staff/Imageset.h"

#include "ft2build.h"
#include "freetype/freetype.h"
#include "freetype/ftglyph.h"
#include "freetype/ftoutln.h"
#include "freetype/fttrigon.h"
#include "freetype/ftimage.h"
#include "freetype/fttypes.h"

class FreeTypeFont
{
public:
	FreeTypeFont();
	~FreeTypeFont();

	bool load( const CGSize& windowsize,const std::string & ftt_filename, const std::wstring & strLyric );
	CGFloat getTextExtent( const std::wstring & strLyric );
	void drawText( const std::wstring & strText,const CGPoint& pt, CGRect* pclip_rect,const  KKColorRect& color_rect );

	void render();

protected:
	void drawGlyphToBuffer( uint * buffer, uint buf_width, FT_Bitmap * glyph_bitmap, int xoff = 0, int yoff = 0, bool bkg = true );

private:
    Imageset *			m_Imageset;
    unsigned int        TEXSIZE;
};

