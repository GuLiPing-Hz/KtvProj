//
//  FreeTypeFont.mm
//  Karaoke
//

#include "FreeTypeFont.h"

#include "../staff/KKType.h"
#include "../staff/Image.h"
#include "../staff/Imageset.h"
#include "../staff/ImgsetMgr.h"

FreeTypeFont::FreeTypeFont():m_Imageset(NULL)
{
	TEXSIZE                 = 512;
}

FreeTypeFont::~FreeTypeFont()
{
	delete m_Imageset;
	m_Imageset = NULL;
}

//----------------------------------------------------------------------------//
/*!
 \brief
 Copy the current glyph data into \a buffer, which has a width of
 \a buf_width pixels (not bytes).
 
 \param buffer
 Memory buffer large enough to receive the imagery for the currently
 loaded glyph.
 
 \param buf_width
 Width of \a buffer in pixels (where each pixel is a argb_t).
 
 \return
 Nothing.
 */
void FreeTypeFont::drawGlyphToBuffer( uint * buffer, uint buf_width, FT_Bitmap * glyph_bitmap, int xoff/* = 0*/, int yoff/* = 0*/, bool bkg/* = true */ )
{
	switch (glyph_bitmap->pixel_mode)
	{
        case FT_PIXEL_MODE_GRAY:
		{
			buffer += buf_width * yoff;
			for (int i = 0; i < glyph_bitmap->rows; ++i)
			{
				u_char *src = glyph_bitmap->buffer + ( i * glyph_bitmap->pitch );
				u_char *dst = (u_char*)( buffer + xoff );
				for (int j = 0; j < glyph_bitmap->width; ++j)
				{
					// RGBA
                    
					if ( bkg )
					{
                        *dst++ = 0xFF;
                        *dst++ = 0xFF;
                        *dst++ = 0xFF;

						*dst = ( *src ) >> 1;
					}
					else
					{
						if ( *src != 0 )
						{
                            *dst++ = 0xFF;
                            *dst++ = 0xFF;
                            *dst++ = 0xFF;

							if ( *dst == 0 )
							{
								*dst = *src;
							}
							else if ( *dst + *src > glyph_bitmap->num_grays - 1 )
							{
								*dst = glyph_bitmap->num_grays - 1;
							}
							else
							{
								*dst = ( u_char )( *dst + *src );
							}
                            
                            ++dst;
						}
						else
						{
                            dst += 4;
                            // if current pixel alpha value is 0,ignore.
						}
					}
                    
					++src;
				}
				buffer += buf_width;
			}
		}
        break;
            
        case FT_PIXEL_MODE_MONO:
		{
			for (int i = 0; i < glyph_bitmap->rows; ++i)
			{
				u_char *src = glyph_bitmap->buffer + ( ( i + yoff ) * glyph_bitmap->pitch) + xoff;
                
				for (int j = 0; j < glyph_bitmap->width; ++j)
					buffer [j] = (src [j / 8] & (0x80 >> (j & 7))) ? 0xFFFFFFFF : 0x00000000;
                
				buffer += buf_width;
			}
		}
        break;
            
        default:
        break;
	}
}

bool FreeTypeFont::load( const CGSize& windowsize,const std::string & ftt_filename, const std::wstring & strLyric )
{
	//writeLog("FreeTypeFont::load enter");
    // ��ʼ������
	uint tex_x = 0;
    uint tex_y = 0;
    uint tex_yb = 0;
    uint * d_memBuffer = (uint *)( malloc(sizeof(uint) * TEXSIZE * TEXSIZE) );
    
    GLuint texID = 0;

    // ��ʼ�������
    FT_Library library;
    FT_Face face;
    
    FT_Error error = FT_Init_FreeType( &library );
	if (error!=0)
	{
		writeLog("FT_Init_FreeType error");
	}
	error = FT_New_Face( library, "C:\\Windows\\Fonts\\MSYH.TTF", 0, &face );//΢���ź�

	if (error!=0)
	{
		writeLog("FT_New_Face error");
	}
	
	
    error = FT_Set_Char_Size(face, // handle to face object
                             6*64, // char_width in 1/64th of points
                             6*64, // char_height in 1/64th of points
                             326, // horizontal device resolution
                             326 ); // vertical device resolution

	if (error!=0)
	{
		writeLog("FT_Set_Char_Size error");
	}
    /*
    error = FT_Set_Pixel_Sizes(face, // handle to face object
                               0, // pixel_width
                               18 ); // pixel_height
    */
    writeLog("FT_Set_Char_Size");
    int l = strLyric.length();
    for ( int i = 0; i < l; ++i )
    {
        const wchar_t & c = strLyric[i];

        uint glyph_w = 0;
        uint glyph_h = 0;
        
        // Render the glyph
        bool is_load = (0 == FT_Load_Char(face, c, FT_LOAD_RENDER | FT_LOAD_FORCE_AUTOHINT | FT_LOAD_TARGET_NORMAL));
        
        if ( is_load )
        {
			//writeLog("is_load is true");
            glyph_w = face->glyph->bitmap.width + INTER_GLYPH_PAD_SPACE;
            glyph_h = face->glyph->bitmap.rows + INTER_GLYPH_PAD_SPACE;
        }
        
        // Check if glyph right margin does not exceed texture size
        uint x_next = tex_x + glyph_w;
        if (x_next > TEXSIZE)
        {
            tex_x = INTER_GLYPH_PAD_SPACE;
            x_next = tex_x + glyph_w;
            tex_y = tex_yb;
        }
        
        // Check if glyph bottom margine does not exceed texture size
        uint y_bot = tex_y + glyph_h;
        if (y_bot > TEXSIZE)
        {
            m_Imageset = 0;
        }
        
        if ( NULL == m_Imageset )
        {
            memset(d_memBuffer, 0, TEXSIZE * TEXSIZE * sizeof(uint));
            
            // NSString * name = [[NSString alloc] initWithFormat:@"_auto_glyph_images_%d", (int)(c)];
            glGenTextures(1, &texID );
			//writeLog("glGenTextures(1, &texID );");
			m_Imageset = ImgsetMgr::getSingleton()->addImageSet( windowsize,L"FreeTypeFont" );
			char bufLog[256] = {0};
			//sprintf(bufLog,"m_Imageset[%p] ",m_Imageset);
            //writeLog(bufLog);
            CGSize tex_size = CGSizeMake( TEXSIZE, TEXSIZE );
            m_Imageset->setTexture( texID, tex_size );
            
            tex_x = INTER_GLYPH_PAD_SPACE;
            tex_y = INTER_GLYPH_PAD_SPACE;
            tex_yb = INTER_GLYPH_PAD_SPACE;
            
            x_next = tex_x + glyph_w;
            y_bot = tex_y + glyph_h;
        }
        
        if ( !is_load )
        {
            // OutputDebugStringA( "Font::loadFreetypeGlyph - Failed to load glyph for codepoint: %d.  Will use an empty image for this glyph!", c );
            
            // Create a 'null' image for this glyph so we do not seg later
            CGRect area;
            CGPoint offset;
			std::wstring ws;
			ws.append(1,c);
            m_Imageset->addImage( ws, area, offset );
        }
        else
        {
            uint * buf = d_memBuffer + (tex_y * TEXSIZE) + tex_x;
            FT_Bitmap * glyphBitmap = &face->glyph->bitmap;
            
            drawGlyphToBuffer( buf, TEXSIZE, glyphBitmap, 0, 0, false );
            
            // Create a new image in the imageset
            CGRect area = CGRectMake( (CGFloat)tex_x,
                      (CGFloat)tex_y,
                      (CGFloat)(face->glyph->bitmap.width),
                      (CGFloat)(face->glyph->bitmap.rows));
            
            CGPoint offset = CGPointMake( face->glyph->metrics.horiBearingX * (CGFloat)(FT_POS_COEF),
                         -face->glyph->metrics.horiBearingY * (CGFloat)(FT_POS_COEF));
			std::wstring wsg;
			wsg.append(1, c);
            m_Imageset->addImage( wsg, area, offset );//c
            
            // Advance to next position
            tex_x = x_next;
            if (y_bot > tex_yb)
            {
                tex_yb = y_bot;
            }
        }
    }
    
    FT_Done_Face(face);
    FT_Done_FreeType(library);
    glBindTexture(GL_TEXTURE_2D, texID);

    // Copy our memory buffer into the texture
    // ������������������OpenGl����������ȫƥ���ʱ�������е����ط�ʽ   
    // ģ���˲�������С )
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    // ���˲������Ŵ� )
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // ����2D��������
	glEnable(GL_TEXTURE_2D);
    // ����Ҫʹ�õ�һ����Ϻ���������OpenGL��δ�����͸��������glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
     
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, TEXSIZE, TEXSIZE, 0, GL_RGBA, GL_UNSIGNED_BYTE, d_memBuffer);
    
    // ���û��
    //glEnable(GL_BLEND);
    
    free(d_memBuffer);

    return true;
}

CGFloat FreeTypeFont::getTextExtent( const std::wstring & strLyric )
{
	//char bufLog[256] = {0};
	//wchar_t wbufLog[256] = {0};
	//writeLog("FreeTypeFont::getTextExtent enter");
    CGFloat w = 0.0f;
    int l =  strLyric.length();
    for ( int i = 0; i < l; ++i ) {
        const wchar_t & c = strLyric[i];
		std::wstring wsg;
		wsg.append(1,c);
        Image * img = m_Imageset->getImage( wsg );
		//swprintf(wbufLog,L"lyric:[%s]",wsg.c_str());
		//writeLog(wbufLog);
		if (img)//add by glp
		{
			  w += img->m_rect.size.width;
		}	
      
    }
    
    return w;
}

void FreeTypeFont::drawText( const std::wstring & strText,const CGPoint& pt, CGRect* pclip_rect,const KKColorRect& color_rect )
{
	//writeLog("FreeTypeFont::drawText enter");
    int l = strText.length();
    int x = pt.x;
    int y = pt.y;
    
    for ( int i = 0; i < l; ++i ) {
        const wchar_t & c = strText[i];
		std::wstring wsg;
		wsg.append(1,c);
        Image * img = m_Imageset->getImage( wsg );//c
        if ( img )
        {
            CGRect dest_rect = CGRectMake( x, y, img->m_rect.size.width, img->m_rect.size.height );
			img->draw( dest_rect, pclip_rect, color_rect );
            x += img->m_rect.size.width;
        }
    }
}

void FreeTypeFont::render()
{
    m_Imageset->render();
}
