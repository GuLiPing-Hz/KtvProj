#ifndef __EVAL_H__
#define __EVAL_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ftotype.h"

#ifdef EVAL_EXPORTS
#define EVAL_DLLAPI extern "C" __declspec(dllexport)
#else
#define EVAL_DLLAPI extern "C" __declspec(dllimport)
#endif

EVAL_DLLAPI void init( float sampleRate = 11025, float minFreq = 65, unsigned int timerInterval = 50 );

EVAL_DLLAPI void uninit();

EVAL_DLLAPI bool loadSongInfo( const char * szMDMFileName, _tSongInfo & song_info );

EVAL_DLLAPI void realtimeEval( const float * buffer, unsigned int buffer_size, unsigned int cur_timeMs, float & pitch, 
								  float & pitchdiff, float & realtime_score, int & rank, unsigned int & sentence_index, 
								  float & accumulated_sentence_score, bool & switch_sentence, int algorithm_type );

EVAL_DLLAPI void getTotalScore( float & total_score );

#endif // __EVAL_H__