#pragma once

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

class CGLFlorid
{
public:
	CGLFlorid(int textureX = 0,int textureY = 0);
	virtual ~CGLFlorid(void);

	GLuint GetTextureID();
	AUX_RGBImageRec *LoadBMP(const char *fileName);				//����ͼƬ
	BOOL LoadGLTextures(const char *fileName);									// Load Bitmaps And Convert To Textures

	virtual  void DrawFlorid();//ʲô��û��������ȥʵ��
private:
	void makeTextureXY(int x,int y);

private:
	GLuint	m_texture[1];			// Storage For One Texture
	int		m_textureX;
	int		m_textureY;
};
