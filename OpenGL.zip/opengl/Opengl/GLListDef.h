#pragma  once

#include <list>
#include <map>
#include <vector>
#include <wchar.h>


#include "staff/KKType.h"

typedef std::list<wchar_t> LISTWCHAR;
typedef std::map<wchar_t,int> MAPWCHARINT;

typedef std::list<_tGuiLyricInfo*>				LISTGUILYRICVECT;
typedef std::list<_tGuiWaveInfo*>				LISTGUIPITCHVECT;
typedef std::list<_tGuiParagraphInfo*>		LISTPARAGRAPHVECT;
typedef std::list<int>									LISTSENTENCELINEVECT;

typedef std::vector<_tGuiWaveInfo*>		VECTORGUIPITCHVECT;
