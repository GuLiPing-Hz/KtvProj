//
// CWavePlayer.h
//
/**
 ** Copyright (C) 2005 EnjoyView Inc., all rights reserved.
 **           Your View, Our Passion. Just Enjoy It!
 **
 **            http://spaces.msn.com/members/jemylu
 **
 **/

/*************************************************************************/

#ifndef __H_CWavePlayer__
#define __H_CWavePlayer__

//#include "CAVPlayer.h"

class CWavePlayer// : public CAVPlayer
{
private:
	DWORD			mThreadID;     // wave message processing thread
	WAVEFORMATEX *	mWaveFormat;   // wave format to be played

	HWAVEOUT		mhWaveOut;     // wave output device handle
	HANDLE			mDoneEvent;
	BOOL			mIsFlushing;   // flushing flag
	LONG			mHeadersLeft;  // playing buffer counter
	
public:
	CWavePlayer();
	~CWavePlayer();

	BOOL SetInputFormat(BYTE * inFormat, long inLength);

	BOOL Open(void);
	BOOL Close(void);
	BOOL Play(BYTE * inData, DWORD inLength, QWORD inSampleTime);
	BOOL Pause(void);
	BOOL Resume(void);
	BOOL Stop(void);

	BOOL HasPending(void);
	BOOL FlushPending(void);

private:
	void OnWaveOutMsg(void);
	static DWORD WINAPI  OnWaveOutThread(LPVOID lpParameter);
	static void CALLBACK WaveProc(HWAVEOUT hwo, UINT uMsg,
		DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);
};

#endif // __H_CWavePlayer__