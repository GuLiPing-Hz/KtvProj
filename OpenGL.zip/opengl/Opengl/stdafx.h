// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__B16364C8_3A76_4453_A670_EWKFJWEFK64564__INCLUDED_)
#define AFX_STDAFX_H__B16364C8_3A76_4453_A670_EWKFJWEFK64564__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include <atlbase.h>
#include <streams.h>
#define __IDxtCompositor_INTERFACE_DEFINED__  
#define __IDxtAlphaSetter_INTERFACE_DEFINED__  
#define __IDxtJpeg_INTERFACE_DEFINED__  
#define __IDxtKey_INTERFACE_DEFINED__  
#include <qedit.h>
#include "wmsdk.h"
// #include <cv.h>
// #include <cxcore.h>
// #include <highgui.h>

#define STATUS_OPENING							1
#define STATUS_OPENED							2
#define STATUS_OPEN_FAILED						3
#define STATUS_PLAYING							4
#define STATUS_STOPED							5
#define STATUS_PAUSED							6
#define STATUS_CLOSED							7
#define STATUS_BUFFERINGDATA					8


#ifndef SAFE_DELETE
#define SAFE_DELETE(x) \
	if (x != NULL)      \
{                   \
	delete x;        \
	x = NULL;        \
}
#endif

#ifndef SAFE_ARRAY_DELETE
#define SAFE_ARRAY_DELETE(x) \
	if (x != NULL)            \
{                         \
	delete[] x;            \
	x = NULL;              \
}
#endif

#ifndef SAFE_FREE
#define SAFE_FREE(x) \
	if (x != NULL)            \
{                         \
	free(x);            \
	x = NULL;              \
}
#endif

#ifndef SAFE_CLOSEHANDLE
#define SAFE_CLOSEHANDLE(h)         \
	if (h != NULL)                  \
{                               \
	CloseHandle(h);             \
	h = NULL;                   \
}
#endif

#ifndef SAFE_CLOSEFILEHANDLE
#define SAFE_CLOSEFILEHANDLE(h)     \
	if (h != INVALID_HANDLE_VALUE)  \
{                               \
	CloseHandle(h);             \
	h = INVALID_HANDLE_VALUE;   \
}
#endif 

// #pragma comment(lib,"cv")
// #pragma comment(lib,"cxcore")
// #pragma comment(lib,"highgui")
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__B16364C8_3A76_4453_A670_EWKFJWEFK64564__INCLUDED_)