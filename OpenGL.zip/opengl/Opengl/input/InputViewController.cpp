//
//
//  Karaoke
//
//  Created by glp on 12-8-21.
//
//
#include  "InputViewController.h"

InputViewController::InputViewController()
{

}
InputViewController::~InputViewController()
{

}
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// init our touch storage set
		touchEvents = [[NSMutableSet alloc] init];
	}
	return self;
}*/


//#pragma mark Touch Event Handlers

// just a handy way for other object to clear our events
void InputViewController::clearEvents()
{
	//[touchEvents removeAllObjects];
}

/*
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	// just store them all in the big set.
	[touchEvents addObjectsFromArray:[touches allObjects]];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	// just store them all in the big set.
	//[touchEvents addObjectsFromArray:[touches allObjects]];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	// just store them all in the big set.
	[touchEvents addObjectsFromArray:[touches allObjects]];
}


//#pragma mark unload, dealloc

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = NULL;
    self.touchEvents = NULL;
    [super viewDidUnload];
}


- (void)dealloc {

    [touchEvents release];
    [super dealloc];

}*/

