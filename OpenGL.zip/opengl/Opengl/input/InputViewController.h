//
//
//  Karaoke
//
//  Created by glp on 12-8-21.
//
//
#pragma  once
#include <set>
#include <string>

//typedef std::set<>  SETTOUCHENENT;

class InputViewController
{
public :
	InputViewController();
	~InputViewController();
	void clearEvents();
	//NSMutableSet* touchEvents;
public:
	//SETTOUCHENENT touchEvents;
};

//- (BOOL)touchesDidBegin;

//- (void)didReceiveMemoryWarning ;
//- (void)loadView ;
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;

// 7 methods

