#include "StdAfx.h"
#include "DrawListener.h"
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

extern HDC						g_hDC;		// Private GDI Device Context

DrawListener::DrawListener(CGLVideo* pglVideo,CGLFlorid* pglFlorid,SceneMgr* psceneMgr,float ScreenX,float ScreenY):
																											m_pglFlorid(pglFlorid),
																											m_pglVideo(pglVideo),
																											m_sceneMgr(psceneMgr),
																											m_ScreenX(ScreenX),
																											m_ScreenY(ScreenY)
																											
{

}

DrawListener::~DrawListener(void)
{
	SAFE_DELETE(m_pglVideo);
	SAFE_DELETE(m_pglFlorid);
	SAFE_DELETE(m_sceneMgr);
}

void DrawListener::SetSceneMgr(SceneMgr* psceneMgr)
{
	m_sceneMgr = psceneMgr;
}

CGLVideo*	DrawListener::GetGLVideo()
{
	return m_pglVideo;
}

CGLFlorid*	DrawListener::GetGLFlorid()
{
	return m_pglFlorid;
}

SceneMgr* DrawListener::GetSceneMgr()
{
	return m_sceneMgr;
}	

void DrawListener::onTimer( unsigned int elapsed_tm )
{
	//writeLog("onTimer enter");
	static ulong starTime = timeGetTime();
	//�����ɫ//����Ȼ�����
	glClear(GL_COLOR_BUFFER_BIT);// | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();									// Reset The Current Modelview Matrix
	glEnable(GL_TEXTURE_2D);
	if (m_pglVideo)
	{
		//bool bcanDrow = false;
		if (!m_pglVideo->GetTextureIDInit() )
		{
			m_pglVideo->LoadGLTexturesVideo();
			//bcanDrow = true;
		}
		else
		{
			//glBindTexture(GL_TEXTURE_2D, m_pglVideo->GetTextureID());
			if (m_pglVideo->UpdateGLTextures())
			{
				//bcanDrow = true;
			}
		}
		//if (bcanDrow)
		{
			glBegin(GL_QUADS);									// Draw A �ı��Σ�������+3
			//˳ʱ����Ƶ��Ƕ���ĺ���档�����˵�������������������εı��档��ʱ�뻭�����������β������泯������
			m_pglVideo->DrawVideo(m_ScreenX,m_ScreenY);	
			glEnd();	
		}
		//������,֮ǰҪ����2D����
		//��ͼ��ģʽGL_POINTS��GL_LINES��GL_QUADS,GL_QUAD_STRIP
		//	//����GL_LINE_STRIP��GL_LINE_LOOP��GL_TRIANGLES��GL_TRIANGLE_STRIP��GL_TRIANGLE_FAN
	}
	//glDisable(GL_TEXTURE_2D);
	//////////////////////////////////////////////////////////////////////////
	//glEnable(GL_TEXTURE_2D);
	if (m_sceneMgr)
	{
		m_sceneMgr->gameLoop(starTime);
	}
	glDisable(GL_TEXTURE_2D);
	if (m_pglFlorid)
	{
		if (m_pglFlorid->GetTextureID() == 0)
		{
			//m_pglFlorid->LoadGLTextures("Data/NeHe.bmp");
		}
		//if (m_pglFlorid->GetTextureID()!=0)
		{
			glPushMatrix();//�������ʹ����ĸı䲻Ӱ������
			//glBindTexture(GL_TEXTURE_2D, m_pglFlorid->GetTextureID());
			//glBegin(GL_QUADS);	
			m_pglFlorid->DrawFlorid();
			//glEnd();
			glPopMatrix();
		}
	}
	//glDisable(GL_TEXTURE_2D);
	//////////////////////////////////////////////////////////////////////////
	//glBegin(GL_QUADS);	
	//glColor4f(0.0f,0.0f,1.0f,1.0f);
	//glVertex3f(100.0f,-100.0f, 0.0f);					// Bottom Left 

	//glVertex3f( 200.0f,-100.0f, 0.0f);					// Bottom Right 

	//glColor4f(0.0f,1.0f,0.0f,1.0f);
	//glVertex3f( 200.0f, 0.0f, 0.0f);					// Top Right ��

	//glColor4f(1.0f,0.0f,0.0f,1.0f);
	//glVertex3f(100.0f, 0.0f, 0.0f);					// Top Left 
	//glColor4f(1.0f,1.0f,1.0f,1.0f);
	//glEnd();
	///////////////////////////////////////////////////////////

	glFlush();
	SwapBuffers(g_hDC);
}
