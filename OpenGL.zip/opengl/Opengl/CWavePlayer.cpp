//
// CWavePlayer.cpp
//
/**
 ** Copyright (C) 2005 EnjoyView Inc., all rights reserved.
 **           Your View, Our Passion. Just Enjoy It!
 **
 **            http://spaces.msn.com/members/jemylu
 **
 **/

/*************************************************************************/

#include "stdafx.h"
#include "CWavePlayer.h"

// #ifdef _DEBUG
// #define new DEBUG_NEW
// #undef THIS_FILE
// static char THIS_FILE[] = __FILE__;
// #endif
void WriteLog(char * szLog);

/////////////////////////////////////////////////////////////////////////////
CWavePlayer::CWavePlayer()
{
#ifdef _DEBUG
	DWORD threadId = GetCurrentThreadId();
#endif

	mThreadID    = 0;
	mWaveFormat  = NULL;
	mhWaveOut    = NULL;
	mHeadersLeft = 0;
	mIsFlushing  = FALSE;
	mDoneEvent   = CreateEvent(NULL, FALSE, FALSE, NULL);
}

CWavePlayer::~CWavePlayer()
{
	// Close the wave output device
	Close();

	if (mWaveFormat)
    {
        delete [] (BYTE*) mWaveFormat;
        mWaveFormat = NULL;
    }
	CloseHandle(mDoneEvent);
}

BOOL CWavePlayer::SetInputFormat(BYTE * inFormat, long inLength)
{
	if (mWaveFormat)
    {
        delete [] (BYTE*) mWaveFormat;
        mWaveFormat = NULL;
    }

	mWaveFormat = (WAVEFORMATEX *) new BYTE[inLength];
	if (NULL == mWaveFormat)
	{
		return FALSE;
	}
	CopyMemory(mWaveFormat, inFormat, inLength);
	return TRUE;
}

BOOL CWavePlayer::Open(void)
{
	if (mhWaveOut)
	{
		// Wait for pending buffers to be released!
		return FlushPending();
	}

	MMRESULT mmr = waveOutOpen(&mhWaveOut, WAVE_MAPPER, mWaveFormat,
		(DWORD) WaveProc, (DWORD) this,	CALLBACK_FUNCTION);
	if (MMSYSERR_NOERROR != mmr)
	{
		//WriteLog("waveOutOpen Failed.\n");
		return FALSE;
	}

	// Use another thread for wave output.
	HANDLE hThread = CreateThread(NULL, 0, OnWaveOutThread,	
		(LPVOID) this, NULL, &mThreadID);
	if (NULL == hThread)
	{
		waveOutClose(mhWaveOut);
		mhWaveOut = NULL;
		return FALSE;
	}
	else
	{
		// Close the thread handle, as it's no longer required in this thread.
		CloseHandle(hThread);
		mHeadersLeft = 0;
		return TRUE;
	}	
}

BOOL CWavePlayer::Close(void)
{
	// Close the wave output device.
	if (mhWaveOut)
	{
		// Wait for pending buffers to be released!
		FlushPending();

		if (MMSYSERR_NOERROR != waveOutClose(mhWaveOut))
		{
			return FALSE;
		}
		mhWaveOut = NULL;
	}
	return TRUE;
}

BOOL CWavePlayer::Play(BYTE * inData, DWORD inLength, QWORD inSampleTime)
{
	// Use Windows Multimedia wave handling functions to play the content. 
	// Allocate memory for header and data.
	LPWAVEHDR pwh = (LPWAVEHDR) new BYTE[sizeof(WAVEHDR) + inLength];
	if (NULL == pwh)
	{
		return FALSE;
	}

	pwh->lpData = (LPSTR)&pwh[1];
	pwh->dwBufferLength  = inLength; 
	pwh->dwBytesRecorded = inLength;
	pwh->dwUser  = (DWORD) inSampleTime;
	pwh->dwLoops = 0;
	pwh->dwFlags = 0;
	CopyMemory(pwh->lpData, inData, inLength);

	// Prepare the header for playing.
	MMRESULT mmr = waveOutPrepareHeader(mhWaveOut, pwh, sizeof(WAVEHDR));
	if (MMSYSERR_NOERROR != mmr)
	{
		delete [] (BYTE*) pwh;
		return FALSE;
	}

	// Send the sample to the wave output device.
	mmr = waveOutWrite(mhWaveOut, pwh, sizeof(WAVEHDR));
	if (MMSYSERR_NOERROR != mmr)
	{
		delete [] (BYTE*) pwh;
		return FALSE;
	}
////////////////////
	InterlockedIncrement(&mHeadersLeft);
	if (pwh)
	{
		delete [] (BYTE*) pwh;
		pwh = NULL;
	}
	return TRUE;
}

BOOL CWavePlayer::Pause(void)
{
	if (mhWaveOut)
	{
		// Pause the wave output device
		if (MMSYSERR_NOERROR != waveOutPause(mhWaveOut))
		{
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CWavePlayer::Resume(void)
{
	if (mhWaveOut)
	{
		// Resume the wave output device
		if (MMSYSERR_NOERROR != waveOutRestart(mhWaveOut))
		{
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CWavePlayer::Stop(void)
{
	// Reset the wave output device
	return FlushPending();
}

DWORD WINAPI CWavePlayer::OnWaveOutThread(LPVOID lpParameter)
{
	CWavePlayer* pThis = (CWavePlayer*) lpParameter;

	// Redirect the processing to a non-static member
	// function of the CWavePlayer class
	pThis->OnWaveOutMsg();

	return 0;
}

void CWavePlayer::OnWaveOutMsg(void)
{
	HRESULT     hr = S_OK;
	LPWAVEHDR   pwh = NULL;
	MMRESULT    mmr = MMSYSERR_NOERROR;
	MSG         uMsg;

#ifdef _DEBUG
	DWORD threadId = GetCurrentThreadId();
#endif

	// Create the message queue
	PeekMessage(&uMsg, NULL, WM_USER, WM_USER, PM_NOREMOVE);

	// Message queue has been created. Let's get the messages
	while (0 != GetMessage(&uMsg, NULL, 0, 0))
	{
		switch (uMsg.message)
		{
		case WOM_DONE:
			// Unprepare the wave header, as it has already been played
			pwh = (LPWAVEHDR) uMsg.wParam;
			mmr = waveOutUnprepareHeader(mhWaveOut, pwh, sizeof(WAVEHDR));
			// Added by qlu, or memory leak will occur!!!
			if (pwh)
			{
				delete [] (BYTE*) pwh;
				pwh = NULL;
			}

			if (MMSYSERR_NOERROR == mmr)
			{
				InterlockedDecrement(&mHeadersLeft);
			}
			else
			{
//				AfxMessageBox("Wave function (waveOutUnprepareHeader) failed.");
			}

			// When flushing, after all pending buffers processed, 
			// signal the event!
			if (mIsFlushing && (0 == mHeadersLeft))
	//		if (mIsFlushing)
			{
// 				FILE *fp;
// 				fp=fopen("c:\\log.txt","at");
// 				fprintf(fp,"SetEvent(mDoneEvent);\n");
//  				fclose(fp);
				SetEvent(mDoneEvent);
			}
			break;

		case WOM_CLOSE:
			PostQuitMessage(0);
			break;
		}
	}

	return;
}

void CALLBACK CWavePlayer::WaveProc(HWAVEOUT hwo, UINT uMsg, DWORD dwInstance,
									DWORD dwParam1, DWORD dwParam2)
{
#ifdef _DEBUG
	DWORD threadId = GetCurrentThreadId();
#endif

	CWavePlayer* pThis = (CWavePlayer*) dwInstance;
	
	// Redirect the processing to a different thread
	PostThreadMessage(pThis->mThreadID, uMsg, dwParam1, dwParam2);
}

BOOL CWavePlayer::HasPending(void)
{
	return (0 != mHeadersLeft);
}

BOOL CWavePlayer::FlushPending(void)
{
	if (!mhWaveOut)
	{
		return TRUE;
	}

	ResetEvent(mDoneEvent);
	mIsFlushing = TRUE;
	// Cancel all pending buffers
	if (MMSYSERR_NOERROR == waveOutReset(mhWaveOut))
	{
		if (0 != mHeadersLeft)
		{
			WaitForSingleObject(mDoneEvent, INFINITE);
		}
		mIsFlushing = FALSE;
		return TRUE;
	}
	
	mIsFlushing = FALSE;
	return FALSE;
}
