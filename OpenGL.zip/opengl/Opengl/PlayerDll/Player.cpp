// Player.cpp : Defines the entry point for the DLL application.
//
#include <windows.h>
#include "stdafx.h"
#include "Player.h"

///////////////////////////add by glp
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
//#include "lame_enc.h"

#include <wmsdk.h>
#include <streams.h>
#include <windows.h>
#include <stdio.h>
#define WM_CAPTURE_BITMAP   WM_APP + 1
#define BUFFERSIZE 200000
#define FILEBUFFER	(4*1024*1024)
typedef struct tagVIDEOINFOHEADER2 {
    RECT                rcSource;
    RECT                rcTarget;
    DWORD               dwBitRate;
    DWORD               dwBitErrorRate;
    REFERENCE_TIME      AvgTimePerFrame;
    DWORD               dwInterlaceFlags;
    DWORD               dwCopyProtectFlags;
    DWORD               dwPictAspectRatioX; 
    DWORD               dwPictAspectRatioY; 
    union {
        DWORD           dwControlFlags;
        DWORD           dwReserved1;
    };
    DWORD               dwReserved2;
    BITMAPINFOHEADER    bmiHeader;
} VIDEOINFOHEADER2;

TCHAR* PhaseString(const char *pszStrIn, char cTok);
BOOL IsWindowsMediaFile(TCHAR * strFileName);
BOOL IsURL(TCHAR * strFileName);
BOOL IsMP3(TCHAR * strFileName);
BOOL IsVideo(TCHAR * strFileName);


//BOOL initMp3Encoder(const char *mp3FileName);

// ȫ�ֱ���
CDXGraph *				g_FilterGraph;     // Filter Graph��װ
extern GETAUDIOSAMPLE	g_lpGetAudioSample;
extern GETAUDIOSAMPLE2	g_lpGetAudioSample2;
extern ISEOF			g_lpIsEOF;
extern SENDSTATUS   	g_lpSendStatus;
extern HWND				g_hwnd;
extern					g_status;
extern int			g_nStreamNumber;//add by glp


BOOL					g_bOneShot=FALSE;
DWORD					g_dwGraphRegister=0;  // For running object table

BOOL					g_bPlay=FALSE;
BYTE *					g_OutBuffer = NULL;
BYTE *					g_OutAudioBuffer = NULL;
LPWAVEHDR				g_pwh = NULL;
BUFFER_NODE*			g_pBufferNodeHeader;
BUFFER_NODE*			g_pBufferNodeOnSample;
BUFFER_NODE*			g_pBufferNodeFillBuffer;
////////////////////////////glp
BUFFER_NODE*			g_pBufferNodeFileBuffer;
ULONG				g_nUsedFileBufferCount;
/////video
VideoBufferNode*	g_pVideoNodeHeader;
VideoBufferNode*	g_pVideoWrite;
VideoBufferNode*	g_pVideoRead;
volatile LONG					g_nVideoNodeUsed;
///////////////////////
int						g_nUsedBufferCount;

double					g_fFileDuration;
long					g_nBitsPerSecond;
char *					g_LanguageString[]={"zh-cn","en-us","zh-hk","zh-mo","zh-sg","zh-tw","zh","ja","ko","fr","es","en","en-gb","de","ru"};
TCHAR *					g_Description[]= {TEXT("���� (�й�)"),TEXT("Ӣ�� (����)"),TEXT("���� (���)"),TEXT("���� (����)"),TEXT("���� (�¼���)"),TEXT("���� (̨��)"),TEXT("����"),TEXT("����"),TEXT("����"),TEXT("���� (����)"),TEXT("��������"),TEXT("Ӣ��"),TEXT("Ӣ�� (Ӣ��)"),TEXT("����"),TEXT("����")};

//BOOL				g_bLast200msOfFile = FALSE;//���ļ���������200ms
//BOOL				g_bCreateThread = FALSE;
//BOOL				g_bEOF = FALSE;//�ļ�����


// Structures
typedef struct _callbackinfo 
{
    double dblSampleTime;
    long lBufferSize;
    BYTE *pBuffer;
    BITMAPINFOHEADER bih;
	
} CALLBACKINFO;

CALLBACKINFO cb={0};

class CSampleGrabberCB : public ISampleGrabberCB 
{

public:

    // These will get set by the main thread below. We need to
    // know this in order to write out the bmp
    long Width;
    long Height;

    // Fake out any COM ref counting
    //
    STDMETHODIMP_(ULONG) AddRef() { return 2; }
    STDMETHODIMP_(ULONG) Release() { return 1; }

    // Fake out any COM QI'ing
    //
    STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
    {
        CheckPointer(ppv,E_POINTER);
        
        if( riid == IID_ISampleGrabberCB || riid == IID_IUnknown ) 
        {
            *ppv = (void *) static_cast<ISampleGrabberCB*> ( this );
            return NOERROR;
        }    

        return E_NOINTERFACE;
    }


    // We don't implement this one
    //
    STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample )
    {
        return 0;
    }


    // The sample grabber is calling us back on its deliver thread.
    // This is NOT the main app thread!
    //
    STDMETHODIMP BufferCB( double SampleTime, BYTE * pBuffer, long BufferSize )
    {

		/*if (NULL != g_OutBuffer)
		{  
			memcpy(g_OutBuffer,pBuffer,Width*Height*3);
		}*/
		if (g_nVideoNodeUsed<= (BUFFERLEN))
		{
			memcpy(g_pVideoWrite->pBuffer,pBuffer,Width*Height*3);
			g_pVideoWrite = g_pVideoWrite->pNext;
			g_nVideoNodeUsed ++;
		}
	    return 0;
    }
};
class CSampleGrabberCBAudio : public ISampleGrabberCB 
{
	
public:
	
    // These will get set by the main thread below. We need to
    // know this in order to write out the bmp
    long Width;
    long Height;
	LONG m_nAudioBufferCount;

    // Fake out any COM ref counting
    //
    STDMETHODIMP_(ULONG) AddRef() { return 2; }
    STDMETHODIMP_(ULONG) Release() { return 1; }
	
    // Fake out any COM QI'ing
    //
    STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
    {
        CheckPointer(ppv,E_POINTER);
        
        if( riid == IID_ISampleGrabberCB || riid == IID_IUnknown ) 
        {
            *ppv = (void *) static_cast<ISampleGrabberCB*> ( this );
            return NOERROR;
        }    
		
        return E_NOINTERFACE;
    }
	
	
    // We don't implement this one
    //
    STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample )
    {
        return 0;
    }
	
	
    // The sample grabber is calling us back on its deliver thread.
    // This is NOT the main app thread!
    //
    STDMETHODIMP BufferCB( double SampleTime, BYTE * pBuffer, long BufferSize )
    {
		int count=0;

		while (g_nUsedBufferCount>BUFFERLEN)//��buffer�����ݻ�δ��Ӧ�ó���ȡ��ʱ��ȴ���
		{
			Sleep(10);

			count++;
 			if (count>100)
 			{
 				return 0;
 			}
			continue;
		}

		CopyMemory(g_pBufferNodeOnSample->pBuffer, pBuffer, BufferSize);
		g_pBufferNodeOnSample->nBufferSize = BufferSize;
		g_pBufferNodeOnSample->nSampleTime = SampleTime;
		
		g_pBufferNodeOnSample = g_pBufferNodeOnSample->pNext;
		
		g_nUsedBufferCount++;

		m_nAudioBufferCount++;
		double endSampleTime = SampleTime+(double)BufferSize/g_nBitsPerSecond;//�����ֻ�����44.1kHz16bit����ֵ��



		g_lpGetAudioSample();//��������Ļص�������ȡ���ݡ�

		
		return 0;
    }
};

class CSampleGrabberCBAudio2 : public ISampleGrabberCB 
{

public:

	// These will get set by the main thread below. We need to
	// know this in order to write out the bmp
	long Width;
	long Height;
	LONG m_nAudioBufferCount;

	// Fake out any COM ref counting
	//
	STDMETHODIMP_(ULONG) AddRef() { return 2; }
	STDMETHODIMP_(ULONG) Release() { return 1; }

	// Fake out any COM QI'ing
	//
	STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
	{
		CheckPointer(ppv,E_POINTER);

		if( riid == IID_ISampleGrabberCB || riid == IID_IUnknown ) 
		{
			*ppv = (void *) static_cast<ISampleGrabberCB*> ( this );
			return NOERROR;
		}    

		return E_NOINTERFACE;
	}


	// We don't implement this one
	//
	STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample )
	{
		return 0;
	}


	// The sample grabber is calling us back on its deliver thread.
	// This is NOT the main app thread!
	//
	STDMETHODIMP BufferCB( double SampleTime, BYTE * pBuffer, long BufferSize )
	{
		int count=0;

		while (g_nUsedFileBufferCount>FILEBUFFER-50*1024)//��buffer�����ݻ�δ��Ӧ�ó���ȡ��ʱ��ȴ���
		{
			Sleep(10);

			count++;
			if (count>100)
			{
				return 0;
			}
			continue;
		}
		CopyMemory(g_pBufferNodeFileBuffer->pBuffer+g_nUsedFileBufferCount, pBuffer, BufferSize);
		//g_pBufferNodeFileBuffer->nBufferSize = BufferSize;
		//g_pBufferNodeFileBuffer->nSampleTime = SampleTime;
	
		//g_nUsedBufferCount++;
		g_nUsedFileBufferCount += BufferSize;
		m_nAudioBufferCount++;
		double endSampleTime = SampleTime+(double)BufferSize/g_nBitsPerSecond;//�����ֻ�����44.1kHz16bit����ֵ��



		g_lpGetAudioSample2();//��������Ļص�������ȡ���ݡ�


		return 0;
	}
};

CSampleGrabberCB CB;
CSampleGrabberCBAudio CBAudio;
CSampleGrabberCBAudio2 CBAudio2;

CPlayer::CPlayer()
{	
	Initialize();

}

BOOL CPlayer::Initialize()
{
	m_hwnd = NULL;
	m_bVideo = FALSE;
	m_bAudio = FALSE;
	m_bIsMultStream = FALSE;
	m_bIsSetTrack = FALSE;

	m_bMute = FALSE;


	
    // the playback graph when capturing video
    m_pTrackSwitch = NULL;	
    m_pIAMStreamConfig = NULL;	
    m_pAsfSource = NULL;	
    m_pIMySourseFilter = NULL;
	m_pIAMStreamConfig = NULL;
	m_FilterGraph = NULL;

	

	m_pszSourceFile  = new TCHAR[260];
	m_bCapStills = true;
    m_nCapState = 0;
    m_nCapTimes = 0;
	m_OutBuffer = NULL;

	g_pBufferNodeHeader = NULL;
	g_pBufferNodeOnSample = NULL;
	g_pBufferNodeFillBuffer = NULL; 
//////////////////////////////////////////////////////////////////////////video
	g_pVideoNodeHeader = NULL;
	g_pVideoWrite = NULL;
	g_pVideoRead = NULL;

	m_pszLanguage = NULL;
	m_nStreamNumber = 0;  

	m_bNeedGetAudio = TRUE;
	m_bNeedResample = FALSE;

	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
//	CoInitializeEx(NULL, COINIT_MULTITHREADED);
	g_pBufferNodeHeader = InitBufferList();

	m_bSeekable = TRUE;

	m_hwnd = g_hwnd;
//	InitMessageOnlyWindow(); 
	ZeroMemory(&m_mtAudioMediaType, sizeof(AM_MEDIA_TYPE));
	return TRUE; 
}

VideoBufferNode* CPlayer::InitVideoBufferList(ULONG size)
{
	VideoBufferNode *pVideoBufferNodeHeader,*pVideoCurrentBufferNode,*pVideoPrevBufferNode;
	if ((pVideoBufferNodeHeader=(VideoBufferNode*)malloc(sizeof(VideoBufferNode)))==NULL)
	{
		return NULL;
	}
	pVideoBufferNodeHeader->pBuffer=(BYTE *)malloc(size);

	pVideoBufferNodeHeader->pNext=NULL;

	pVideoPrevBufferNode=pVideoBufferNodeHeader;

	for (int i=0;i<BUFFERLEN;i++)
	{
		if ((pVideoCurrentBufferNode=(VideoBufferNode*)malloc(sizeof(VideoBufferNode)))==NULL)
		{
			return NULL;
		}
		pVideoCurrentBufferNode->pBuffer=(BYTE *)malloc(size);
		pVideoPrevBufferNode->pNext=pVideoCurrentBufferNode;
		pVideoCurrentBufferNode->pNext=NULL;
		pVideoPrevBufferNode=pVideoCurrentBufferNode;
	}
	pVideoPrevBufferNode->pNext=pVideoBufferNodeHeader;

	g_pVideoRead = pVideoBufferNodeHeader;
	g_pVideoWrite = pVideoBufferNodeHeader;
	g_nVideoNodeUsed = 0;

	return pVideoBufferNodeHeader;
}

BUFFER_NODE* CPlayer::InitBufferList()
{
	BUFFER_NODE *pBufferNodeHeader,*pCurrentBufferNode,*pPrevBufferNode;
	if ((pBufferNodeHeader=(BUFFER_NODE*)malloc(sizeof(BUFFER_NODE)))==NULL)
	{
		return NULL;
	}
	pBufferNodeHeader->pBuffer=(BYTE *)malloc(BUFFERSIZE);
	
	pBufferNodeHeader->pNext=NULL;
	
	pPrevBufferNode=pBufferNodeHeader;
	
	for (int i=0;i<BUFFERLEN;i++)
	{
		if ((pCurrentBufferNode=(BUFFER_NODE*)malloc(sizeof(BUFFER_NODE)))==NULL)
		{
			return NULL;
		}
		pCurrentBufferNode->pBuffer=(BYTE *)malloc(BUFFERSIZE);
		pPrevBufferNode->pNext=pCurrentBufferNode;
		pCurrentBufferNode->pNext=NULL;
		pPrevBufferNode=pCurrentBufferNode;
	}
	pPrevBufferNode->pNext=pBufferNodeHeader;

	g_pBufferNodeOnSample = pBufferNodeHeader;
	g_pBufferNodeFillBuffer = pBufferNodeHeader;
	g_nUsedBufferCount = 0;

	///////////////////////////////////////
	//g_pBufferNodeFileBuffer = new BUFFER_NODE;//add by glp
	//if (g_pBufferNodeFileBuffer == NULL)
	//{
	//	return NULL;
	//}
	//g_pBufferNodeFileBuffer->pBuffer = new BYTE[FILEBUFFER];
	//if (g_pBufferNodeFileBuffer->pBuffer == NULL)
	//{
	//	return NULL;
	//}
	//g_nUsedFileBufferCount = 0;

	return pBufferNodeHeader;
	
}
BOOL CPlayer::UnInitBufferList()
{
	BUFFER_NODE *pCurrentBufferNode, *pNextBufferNode;
	VideoBufferNode * pVideoCurrentBufferNode, *pVideoNextBufferNode;
	pCurrentBufferNode = g_pBufferNodeHeader;
	pVideoCurrentBufferNode = g_pVideoNodeHeader;
	if (pCurrentBufferNode != NULL)
	{
		for (int i=0;i<=BUFFERLEN;i++)
		{
			pNextBufferNode = pCurrentBufferNode->pNext;
			free(pCurrentBufferNode->pBuffer);
			free(pCurrentBufferNode);
			pCurrentBufferNode = pNextBufferNode;
		}
	}
	if (pVideoCurrentBufferNode != NULL)
	{
		for (int i=0;i<=BUFFERLEN;i++)
		{
			pVideoNextBufferNode = pVideoCurrentBufferNode->pNext;
			free(pVideoCurrentBufferNode->pBuffer);
			free(pVideoCurrentBufferNode);
			pVideoCurrentBufferNode = pVideoNextBufferNode;
		}
	}
	
	return TRUE;
}

BOOL CPlayer::UnInitialize()
{

	UnInitBufferList();
	if (g_OutAudioBuffer !=NULL)
	{
		free(g_OutAudioBuffer);
		g_OutAudioBuffer = NULL;
	}
	DestroyWindow(m_hwnd);
	CoUninitialize();
	return TRUE;
}
BOOL CPlayer::CreateGraph(void)
{
	
	DestroyGraph();
	g_status = STATUS_OPENING;
//	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	m_bVideo = FALSE;
	m_bAudio = FALSE;
	m_bIsMultStream = FALSE;
	m_bIsSetTrack = FALSE;
//	HRESULT hr;
// 	if (m_pszLanguage !=NULL)
// 	{
// 		delete m_pszLanguage;
// 		m_pszLanguage = NULL;
// 	}
	SAFE_ARRAY_DELETE(m_pszLanguage);
	if (g_OutBuffer != NULL)
	{
		free(g_OutBuffer);
		g_OutBuffer = NULL;
	}

	m_nAudioBufferCount = 0;

//	g_bLast200msOfFile = FALSE;

	m_FilterGraph = new CDXGraph();
	

	WriteLog("m_FilterGraph->Create()\n");
	if (m_FilterGraph->Create())
	{
		WriteLog("m_FilterGraph->Create() success\n");
		HRESULT hr;
//		char szFile[260];
//		strcpy(szFile,m_pszSourceFile);
//		WriteLog("szFile=\n");
//		WriteLog(szFile);

	/*	if (IsURL(m_pszSourceFile))
		{
			do
			{
				
				IBaseFilter *pFileSourceURL;
				
				hr = CoCreateInstance(CLSID_URLReader, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pFileSourceURL));
				
				
				if (FAILED(hr))
				{
					break;
				}
				hr =  m_FilterGraph->AddFilter(pFileSourceURL, L"pFileSourceURL");
				if (FAILED(hr))
				{
					break;
				}
				CComPtr< IFileSourceFilter > pIFileSourceURL;	
				hr =  pFileSourceURL->QueryInterface(IID_IFileSourceFilter,   (void   **)&pIFileSourceURL); 
				
				if (FAILED(hr))
				{
					break;
				}
				
				
				
				
				WCHAR   szwFile[MAX_PATH];
				MultiByteToWideChar(CP_ACP, 0, szFile, -1, szwFile, MAX_PATH);
				hr = pIFileSourceURL->Load(szwFile, NULL);
				pIFileSourceURL.Release();
				if(FAILED(hr))
				{
					
					break;
				}

				

				
				IPin* pPin = NULL;
				WriteLog("OutputPinOf pMyAsfReader\n");
				pPin =	m_FilterGraph->OutputPinOf(pFileSourceURL);
				if (NULL==pPin)
				{
					break;
				}
				
				WriteLog("RenderPin\n");
				if (!(m_FilterGraph->RenderPin(pPin)))
				{
					WriteLog("RenderPin Failed.\n");
					break;
				}
				// 				m_nStreamNumber = 1;
				// 				m_pAsfSource->Set_Stream(m_nStreamNumber);
				pPin->Release();
				pFileSourceURL->Release();
				
				WriteLog("m_FilterGraph->RenderPin(pPin) Successed!\n");
				IBaseFilter* pWMFDemux;
				//			HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IVideoWindow, &pVR);
				HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IWMReaderCallbackAdvanced, &pWMFDemux);
				if (FAILED(hr))
				{
					break;
				}
				WriteLog("m_FilterGraph->FindFilterByName Successed!\n");
				CComPtr< IWMReaderCallbackAdvanced > pIWMReaderCallbackAdvanced;	
				hr =  pWMFDemux->QueryInterface(IID_IWMReaderCallbackAdvanced,   (void   **)&pIWMReaderCallbackAdvanced);
				
				
				if (FAILED(hr))
				{
					break;
 				}
				WriteLog("pWMFDemux->QueryInterface Successed!\n");
				WORD nAudioStreamNum=1;
				WMT_STREAM_SELECTION wmtSS=WMT_OFF;
				pIWMReaderCallbackAdvanced->OnStreamSelection(1,&nAudioStreamNum,&wmtSS,0);
			} while(false);
// 			hr = m_FilterGraph->RenderFile(m_pszSourceFile);
// 			if (FAILED(hr))
// 			{	
// 				return FALSE;
// 			}
		}

		else */
		if (IsWindowsMediaFile(m_pszSourceFile))//�����wma�ļ���

		{
			do
			{
			
				IBaseFilter *pMyAsfReader;
				WriteLog("m_pszSourceFile=\n");
				WriteLogW(m_pszSourceFile);
				if (IsURL(m_pszSourceFile))
				{
					hr = CoCreateInstance(CLSID_ASFURLSource, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pMyAsfReader));
				}
				else
				{
					hr = CoCreateInstance(CLSID_ASFSource, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pMyAsfReader));
				}//ax��Ҫ�����Ӣ��Ŀ¼�У���֧������Ŀ¼������ʾû��ע�����

				
				if (FAILED(hr))
				{
					break;
				}
 				hr =  m_FilterGraph->AddFilter(pMyAsfReader, L"MyAsfReader");
 				if (FAILED(hr))
 				{
 					break;
 				}

				hr =  pMyAsfReader->QueryInterface(IID_IFileSourceFilter,   (void   **)&m_pIMySourseFilter); 
				
				if (FAILED(hr))
				{
					break;
				}
// 				WCHAR   szwFile[MAX_PATH];
// 				MultiByteToWideChar(CP_ACP, 0, szFile, -1, szwFile, MAX_PATH);
// 				WriteLog("Load File.\n");
				hr = m_pIMySourseFilter->Load(m_pszSourceFile, NULL);
				SAFE_RELEASE(m_pIMySourseFilter);
				//m_pIMySourseFilter->Release();
				if(FAILED(hr))
				{
					WriteLog("Load File Failed.\n");
					break;
				}
//				WriteLog(m_pszSourceFile);
				if (IsURL(m_pszSourceFile))
				{
					WriteLog("IsURL,QueryInterface\n");
					hr =  pMyAsfReader->QueryInterface(IID_IASFURLSource,   (void   **)&m_pAsfSource); 
				}
				else
				{
					hr =  pMyAsfReader->QueryInterface(IID_IASFSource,   (void   **)&m_pAsfSource); 
				}
				
				
				if (FAILED(hr))
				{
					WriteLog("QuaryInterFace Failed.\n");
					break;
				}
				
				m_pAsfSource->IsMultStream(m_bIsMultStream);


				if (!m_bIsMultStream)
				{
					m_FilterGraph->DelFilter(pMyAsfReader);

					//pMyAsfReader->Release();
					SAFE_RELEASE(pMyAsfReader);
					SAFE_RELEASE(m_pAsfSource);
					//m_pAsfSource->Release();
				//	pPin->Release();
					m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
					break;
				}
  				m_pAsfSource->Get_LanguageLen(m_nLanguageLen);
  				char * pszLanguage = new char[m_nLanguageLen+1];
  				
  				m_pAsfSource->Get_LanguageString(pszLanguage);
			//	char *pszStr;
				m_pszLanguage = PhaseString(pszLanguage,';');
				if (pszLanguage)
				{
					delete []pszLanguage;
					pszLanguage = NULL;
				}
				
				m_nLanguageLen = _tcslen(m_pszLanguage);

				IPin* pPin = NULL;
				WriteLog("OutputPinOf pMyAsfReader\n");
				pPin =	m_FilterGraph->OutputPinOf(pMyAsfReader);
				if (NULL==pPin)
				{
					break;
				}

				WriteLog("RenderPin\n");
				if (!(m_FilterGraph->RenderPin(pPin)))
				{
					WriteLog("RenderPin Failed.\n");
					break;
				}
				m_nStreamNumber = g_nStreamNumber;
				m_pAsfSource->Set_Stream(m_nStreamNumber);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				//pMyAsfReader->Release();
				SAFE_RELEASE(pMyAsfReader);
				
				WriteLog("m_FilterGraph->RenderPin(pPin) Successed!\n");


			} while(false);
			if (FAILED(hr))
			{
				hr = m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
				if(FAILED(hr))
				{
					return FALSE;
				}
			}
		}
		else
		{
			if (IsMP3(m_pszSourceFile))
			{
				do
				{
					
					
					IBaseFilter *pDCBassSource;
					hr = CoCreateInstance(CLSID_DCBassSource, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pDCBassSource));
					hr =  m_FilterGraph->AddFilter(pDCBassSource, L"pDCBassSource");

					if (FAILED(hr))
					{
						break;
					}

					hr =  pDCBassSource->QueryInterface(IID_IFileSourceFilter,   (void   **)&m_pIMySourseFilter); 
					if (FAILED(hr))
					{
						break;
					}
					
// 					WCHAR   szwFile[MAX_PATH];
// 					MultiByteToWideChar(CP_ACP, 0, szFile, -1, szwFile, MAX_PATH);
					hr = m_pIMySourseFilter->Load(m_pszSourceFile, NULL);
					SAFE_RELEASE(m_pIMySourseFilter);
					//m_pIMySourseFilter->Release();

					if(FAILED(hr))
					{
						break;
					}
					hr = RenderOutputPins(m_FilterGraph->mGraph, pDCBassSource);

					//pDCBassSource->Release();
					SAFE_RELEASE(pDCBassSource);

				}while (FALSE);
				if (FAILED(hr))
				{
					hr = m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
					if (FAILED(hr))
					{
						return FALSE;
					}					
				}
				
			}
			else
			{
				IBaseFilter *pFFDshow;
				m_FilterGraph->AddFilterByCLSID(m_FilterGraph->mGraph,CLSID_FFDshow,L"ffdshow video decode",&pFFDshow);
				SAFE_RELEASE(pFFDshow);
				hr = m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
				if (FAILED(hr))
				{	
					return FALSE;
					WriteLog("RenderFileTCHAR failed\n");
				}
				WriteLog("RenderFileTCHAR Success\n");
			}
		}



		DWORD dwCap;
		m_FilterGraph->mSeeking->GetCapabilities(&dwCap);
		if (dwCap & AM_SEEKING_CanSeekAbsolute) //�Ƿ�֧�������λ
		{
			m_bSeekable = TRUE;
		}
		else
		{
			m_bSeekable = FALSE;
		}
		if (IsURL(m_pszSourceFile))
		{
			m_bSeekable = FALSE;
		}
//		WriteLog("����ץȡ��Ƶ֡Filter\n");
		do //��Video Rendererǰ����ץȡ��Ƶ֡Filter.
		{
			IBaseFilter* pVR;
			HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IVideoWindow, &pVR);
			if (FAILED(hr))
			{
				if (IsVideo(m_pszSourceFile))
				{
					g_lpSendStatus(STATUS_MISSING_DECODE);
				}
				m_bVideo = FALSE;
				break;
			}
			
			
			IPin* pPin = m_FilterGraph->InputPinOf(pVR);
			AM_MEDIA_TYPE mt;
			pPin->ConnectionMediaType(&mt);
			//pPin->Release();
			SAFE_RELEASE(pPin);
			
			CMediaType mtIn = mt;
			
			FreeMediaType(mt);

			if (mtIn.subtype == MEDIASUBTYPE_Overlay)
			{
				IBaseFilter* pOvMix = NULL;
				hr = m_FilterGraph->NextUpstream(pVR,&pOvMix);
				//pVR->Release();
				SAFE_RELEASE(pVR);
				if (FAILED(hr))
				{
					break;
				}
				pVR = pOvMix;
			}
			CComPtr< ISampleGrabber > pGrabber;//=ISampleGrabber *pGrabber;
			hr = pGrabber.CoCreateInstance( CLSID_SampleGrabber );
			if (FAILED(hr))
			{
				break;
			}
			CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabberBase( pGrabber );
			hr = m_FilterGraph->AddFilter(pGrabberBase, L"Grabber");
			if (FAILED(hr))
			{
				break;
			}

			//����Ҫץȡ��ý������
			CMediaType GrabType;
			GrabType.SetType( &MEDIATYPE_Video );//��Ϊ��Ƶ
			GrabType.SetSubtype( &MEDIASUBTYPE_RGB24 );//24λ
			GrabType.SetFormatType(&FORMAT_VideoInfo);

		    hr = pGrabber->SetMediaType( &GrabType );//����

			hr = m_FilterGraph->ConnectUpstreamOf2(pVR, pGrabberBase);
			if (FAILED(hr))
			{
				WriteLog("ConnectUpstreamOf2 failed\n");
				break;
			}
			WriteLog("ConnectUpstreamOf2 success\n");
			m_FilterGraph->DelFilter(pVR);
			//pVR->Release();
			SAFE_RELEASE(pVR);
			VIDEOINFOHEADER2 * vih2 = (VIDEOINFOHEADER2*) mtIn.pbFormat;//
			if (vih2->bmiHeader.biWidth<=0||vih2->bmiHeader.biHeight<=0)
			{
				VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mtIn.pbFormat;//
				CB.Width  = vih->bmiHeader.biWidth;
				CB.Height = vih->bmiHeader.biHeight;
				m_nWidth = vih->bmiHeader.biWidth;
				m_nHeight = vih->bmiHeader.biHeight;
			}
			else
			{
				CB.Width  = vih2->bmiHeader.biWidth;
				CB.Height = vih2->bmiHeader.biHeight;
				m_nWidth = vih2->bmiHeader.biWidth;
				m_nHeight = vih2->bmiHeader.biHeight;
			}
			
			if (!g_pVideoNodeHeader)
			{
				g_pVideoNodeHeader = InitVideoBufferList(m_nWidth * m_nHeight * 3);
			}
			//g_OutBuffer = (BYTE *) malloc(m_nWidth * m_nHeight * 3);
			//m_OutBuffer = g_OutBuffer;


			// Don't buffer the samples as they pass through
			//
			hr = pGrabber->SetBufferSamples( FALSE );
			if (FAILED(hr))
			{
				break;
			}		
			// Only grab one at a time, stop stream after
			// grabbing one sample
			//
			hr = pGrabber->SetOneShot( FALSE );
			if (FAILED(hr))
			{
				break;
			}	
			// Set the callback, so we can grab the one sample
			//
		    hr = pGrabber->SetCallback( &CB, 1 );
			pGrabber.Release();
			pGrabberBase.Release();
		    if (FAILED(hr))
			{
			    break;
			}	
			m_bVideo = TRUE;
		} while(false);


		
//		WriteLog("������Ƶ�ز���Filter\n");
		if (m_bNeedResample)
		{
			do //��Audio Rendererǰ������Ƶ�ز���Filter.
			{

				IBaseFilter* pAR;
				HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IAMDirectSound , &pAR);
				if (FAILED(hr))
				{
					m_bAudio = FALSE;
					break;
				}
				
				
				IPin* pPin = m_FilterGraph->InputPinOf(pAR);
				AM_MEDIA_TYPE mt;
				pPin->ConnectionMediaType(&mt);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				IBaseFilter *pACMWrapper;
				hr = CoCreateInstance(CLSID_ACMWrapper, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pACMWrapper));
				if (FAILED(hr))
				{
					break;
				}


				hr =  m_FilterGraph->AddFilter(pACMWrapper, L"ACMWrapper");
				if (FAILED(hr))
				{

					break;
				}


				hr = m_FilterGraph->ConnectUpstreamOf(pAR, pACMWrapper);
				//pAR->Release();
				SAFE_RELEASE(pAR);
				if (FAILED(hr))
				{

					break;
				}


				IPin *pPinOut = m_FilterGraph->OutputPinOf(pACMWrapper);
				SAFE_RELEASE(m_pIAMStreamConfig);
// 				if (m_pIAMStreamConfig!=NULL)
// 				{
// 					m_pIAMStreamConfig->Release();
// 				}
				hr =  pPinOut->QueryInterface(IID_IAMStreamConfig,   (void   **)&m_pIAMStreamConfig); 
				//pPinOut->Release();
				SAFE_RELEASE(pPinOut);
				//pACMWrapper->Release();
				SAFE_RELEASE(pACMWrapper);
				if (FAILED(hr))
				{
					break;
				}

				CopyMemory(mt.pbFormat, &m_wfx ,mt.cbFormat);
							
				g_nBitsPerSecond = m_wfx.nAvgBytesPerSec;
				m_pIAMStreamConfig->SetFormat(&mt);
				FreeMediaType(mt);
				m_bAudio = TRUE;
			} while(false);
		}
//		WriteLog("�����л�����Filter\n");
		do //��audio rendererǰ�����л�����Filter.
		{

			IBaseFilter* pAR;
			HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IAMDirectSound , &pAR);
			if (FAILED(hr))
			{

				m_bAudio = FALSE;
				break;
			}

			if (!m_bNeedResample)
			{	
				IPin* pPin = m_FilterGraph->InputPinOf(pAR);
				AM_MEDIA_TYPE mt;
				pPin->ConnectionMediaType(&mt);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				CopyMemory(&m_wfx,mt.pbFormat,sizeof(m_wfx));
				FreeMediaType(mt);
			}

			
			
			IBaseFilter *pTrackSwitch;
			
			hr = CoCreateInstance(CLSID_TrackSwitch, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pTrackSwitch));
			
			if (FAILED(hr))
			{
				break;
			}

			hr =  m_FilterGraph->AddFilter(pTrackSwitch, L"TrackSwitch");
			if (FAILED(hr))
			{
	
				break;
			}
		
			hr = m_FilterGraph->ConnectUpstreamOf(pAR, pTrackSwitch);
			//pAR->Release();
			SAFE_RELEASE(pAR);
			if (FAILED(hr))
			{
			
				break;
			}
		
			SAFE_RELEASE(m_pTrackSwitch);
// 			if (m_pTrackSwitch!=NULL)
// 			{
// 				m_pTrackSwitch->Release();
// 				m
// 			}
			hr =  pTrackSwitch->QueryInterface(IID_ITrackSwitch,   (void   **)&m_pTrackSwitch); 
			SAFE_RELEASE(pTrackSwitch);
			//pTrackSwitch->Release();
			if (FAILED(hr))
			{
			
				break;
			}
			m_bIsSetTrack = TRUE;
			m_bAudio = TRUE;
		}while(false);
//		WriteLog("����ץȡ��Ƶ֡Filter\n");
		if (m_bNeedGetAudio)//��������Ҫȡ��Ƶ����,�粻��Ҫȡ��Ƶʱ���򲻼������filter.
		{

			do //��Audio Rendererǰ����ץȡ��Ƶ֡Filter.
			{
				IBaseFilter* pAR;
				HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IAMDirectSound , &pAR);
				if (FAILED(hr))
				{
				
					m_bAudio = FALSE;
					break;
				}
				
				if (m_bMute)
				{
					m_FilterGraph->mBasicAudio->put_Volume(-10000);//Randerer Mute.
				}

				IPin* pPin = m_FilterGraph->InputPinOf(pAR);
				pPin->ConnectionMediaType(&m_mtAudioMediaType);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				CComPtr< ISampleGrabber > pGrabber;//=ISampleGrabber *pGrabber;
				hr = pGrabber.CoCreateInstance( CLSID_SampleGrabber );
				if (FAILED(hr))
				{
					break;
				}
				CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabberBase( pGrabber );
				hr = m_FilterGraph->AddFilter(pGrabberBase, L"Grabber");
				if (FAILED(hr))
				{
					break;
				}

				hr = m_FilterGraph->ConnectUpstreamOf(pAR, pGrabberBase);
				if (FAILED(hr))
				{
					break;
				}

				//pAR->Release();
				SAFE_RELEASE(pAR);
				if (g_OutAudioBuffer==NULL)
				{
					g_OutAudioBuffer = (BYTE *) malloc(FILEBUFFER);
					//free(g_OutAudioBuffer);
				}
				
				
				//m_OutAudioBuffer = g_OutAudioBuffer;

				// Don't buffer the samples as they pass through
				//
				hr = pGrabber->SetBufferSamples( FALSE );
				if (FAILED(hr))
				{
					break;
				}		
				// Only grab one at a time, stop stream after
				// grabbing one sample
				//
				hr = pGrabber->SetOneShot( FALSE );
				if (FAILED(hr))
				{
					break;
				}	
				// Set the callback, so we can grab the one sample
				//
				hr = pGrabber->SetCallback( &CBAudio, 1 );
				pGrabber.Release();
				pGrabberBase.Release();
				CBAudio.m_nAudioBufferCount = 0;
				if (FAILED(hr))
				{
					break;
				}	
				m_bAudio = TRUE;
			} while(false);
		}
	
		WriteLog("SetNotifyWindow!\n");
		if (m_FilterGraph->SetNotifyWindow(m_hwnd))
		{
			WriteLog("SetNotifyWindow Success!\n");
		}
		else
		{
//			WriteLog("SetNotifyWindow Failed!\n");
		}
			;//���ý�����Ϣ�Ĵ��ھ��

		g_FilterGraph = m_FilterGraph;
		
		m_FilterGraph->GetDuration(&g_fFileDuration);
		if (!m_bAudio && !m_bVideo)
		{
			return FALSE;
		}
		WriteLog("Create Graph Successed!\n");
		//m_FilterGraph->Pause();
		return TRUE;
	}
	else
	{
		return FALSE;
	}

}

BOOL CPlayer::CreateGraph2(void)
{
	
	DestroyGraph();
	g_status = STATUS_OPENING;
//	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	m_bVideo = FALSE;
	m_bAudio = FALSE;
	m_bIsMultStream = FALSE;
	m_bIsSetTrack = FALSE;

	SAFE_ARRAY_DELETE(m_pszLanguage);
	if (g_OutBuffer != NULL)
	{
		free(g_OutBuffer);
		g_OutBuffer = NULL;
	}

	m_nAudioBufferCount = 0;

	m_FilterGraph = new CDXGraph();
	
	WriteLog("m_FilterGraph->Create()\n");
	if (m_FilterGraph->Create())
	{
		WriteLog("m_FilterGraph->Create() success\n");
		HRESULT hr;

		if (IsWindowsMediaFile(m_pszSourceFile))//�����wma�ļ���

		{
			do
			{
			
				IBaseFilter *pMyAsfReader;
				WriteLog("m_pszSourceFile=\n");
				WriteLogW(m_pszSourceFile);
				if (IsURL(m_pszSourceFile))
				{
					hr = CoCreateInstance(CLSID_ASFURLSource, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pMyAsfReader));
				}
				else
				{
					hr = CoCreateInstance(CLSID_ASFSource, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pMyAsfReader));
				}

				
				if (FAILED(hr))
				{
					break;
				}
 				hr =  m_FilterGraph->AddFilter(pMyAsfReader, L"MyAsfReader");
 				if (FAILED(hr))
 				{
 					break;
 				}

				hr =  pMyAsfReader->QueryInterface(IID_IFileSourceFilter,   (void   **)&m_pIMySourseFilter); 
				
				if (FAILED(hr))
				{
					break;
				}
				m_pIMySourseFilter->SetReaderTag(FALSE);//��Ҫ�Լ��ӽӿ�
				///////////////////////////add by glp
				char szAnsi[MAX_PATH];
				WideCharToMultiByte(CP_ACP, 0, m_pszSourceFile, -1, szAnsi, MAX_PATH, NULL, NULL);
				//g_pMp3File = fopen(szAnsi,"wr");
					///////////////////////
				hr = m_pIMySourseFilter->Load(m_pszSourceFile, NULL);
				SAFE_RELEASE(m_pIMySourseFilter);
				//m_pIMySourseFilter->Release();
				if(FAILED(hr))
				{
					WriteLog("Load File Failed.\n");
					break;
				}
//				WriteLog(m_pszSourceFile);
				if (IsURL(m_pszSourceFile))
				{
					WriteLog("IsURL,QueryInterface\n");
					hr =  pMyAsfReader->QueryInterface(IID_IASFURLSource,   (void   **)&m_pAsfSource); 
				}
				else
				{
					hr =  pMyAsfReader->QueryInterface(IID_IASFSource,   (void   **)&m_pAsfSource); 
					//���� NonDelegatingQueryInterface
				}
				
				
				if (FAILED(hr))
				{
					WriteLog("QuaryInterFace Failed.\n");
					break;
				}
				
				m_pAsfSource->IsMultStream(m_bIsMultStream);


				if (!m_bIsMultStream)
				{
					m_FilterGraph->DelFilter(pMyAsfReader);

					//pMyAsfReader->Release();
					SAFE_RELEASE(pMyAsfReader);
					SAFE_RELEASE(m_pAsfSource);
					//m_pAsfSource->Release();
				//	pPin->Release();
					m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
					break;
				}
  				m_pAsfSource->Get_LanguageLen(m_nLanguageLen);
  				char * pszLanguage = new char[m_nLanguageLen+1];
  				
  				m_pAsfSource->Get_LanguageString(pszLanguage);
			//	char *pszStr;
				m_pszLanguage = PhaseString(pszLanguage,';');
				if (pszLanguage)
				{
					delete []pszLanguage;
				}
				m_nLanguageLen = _tcslen(m_pszLanguage);

				IPin* pPin = NULL;
				WriteLog("OutputPinOf pMyAsfReader\n");
				pPin =	m_FilterGraph->OutputPinOf(pMyAsfReader);
				if (NULL==pPin)
				{
					break;
				}

				WriteLog("RenderPin\n");
				if (!(m_FilterGraph->RenderPin(pPin)))
				{
					WriteLog("RenderPin Failed.\n");
					break;
				}
				m_nStreamNumber = g_nStreamNumber;
				m_pAsfSource->Set_Stream(m_nStreamNumber);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				//pMyAsfReader->Release();
				SAFE_RELEASE(pMyAsfReader);
				
				WriteLog("m_FilterGraph->RenderPin(pPin) Successed!\n");


			} while(false);
			if (FAILED(hr))
			{
				hr = m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
				if(FAILED(hr))
				{
					return FALSE;
				}
			}
		}
		else
		{
			/*if (IsMP3(m_pszSourceFile))
			{
				do
				{
					
					
					IBaseFilter *pDCBassSource;
					hr = CoCreateInstance(CLSID_DCBassSource, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pDCBassSource));
					hr =  m_FilterGraph->AddFilter(pDCBassSource, L"pDCBassSource");

					if (FAILED(hr))
					{
						break;
					}

					hr =  pDCBassSource->QueryInterface(IID_IFileSourceFilter,   (void   **)&m_pIMySourseFilter); 
					if (FAILED(hr))
					{
						break;
					}
					
// 					WCHAR   szwFile[MAX_PATH];
// 					MultiByteToWideChar(CP_ACP, 0, szFile, -1, szwFile, MAX_PATH);
					hr = m_pIMySourseFilter->Load(m_pszSourceFile, NULL);
					SAFE_RELEASE(m_pIMySourseFilter);
					//m_pIMySourseFilter->Release();

					if(FAILED(hr))
					{
						break;
					}
					hr = RenderOutputPins(m_FilterGraph->mGraph, pDCBassSource);

					//pDCBassSource->Release();
					SAFE_RELEASE(pDCBassSource);

				}while (FALSE);
				if (FAILED(hr))
				{
					hr = m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
					if (FAILED(hr))
					{
						return FALSE;
					}					
				}
				
			}
			else
			{
				IBaseFilter *pFFDshow;
				m_FilterGraph->AddFilterByCLSID(m_FilterGraph->mGraph,CLSID_FFDshow,L"ffdshow video decode",&pFFDshow);
				SAFE_RELEASE(pFFDshow);
				hr = m_FilterGraph->RenderFileTCHAR(m_pszSourceFile);
				if (FAILED(hr))
				{	
					return FALSE;
				}
			}*/
		}

		DWORD dwCap;
		m_FilterGraph->mSeeking->GetCapabilities(&dwCap);
		if (dwCap & AM_SEEKING_CanSeekAbsolute) //�Ƿ�֧�������λ
		{
			m_bSeekable = TRUE;
		}
		else
		{
			m_bSeekable = FALSE;
		}
		if (IsURL(m_pszSourceFile))
		{
			m_bSeekable = FALSE;
		}
//		WriteLog("����ץȡ��Ƶ֡Filter\n");
		do //��Video Rendererǰ����ץȡ��Ƶ֡Filter.
		{
			IBaseFilter* pVR;
			HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IVideoWindow, &pVR);
			if (FAILED(hr))
			{
				if (IsVideo(m_pszSourceFile))
				{
					g_lpSendStatus(STATUS_MISSING_DECODE);
				}
				m_bVideo = FALSE;
				break;
			}
			/*
			IPin* pPin = m_FilterGraph->InputPinOf(pVR);
			AM_MEDIA_TYPE mt;
			pPin->ConnectionMediaType(&mt);
			//pPin->Release();
			SAFE_RELEASE(pPin);
			
			CMediaType mtIn = mt;
			
			FreeMediaType(mt);

			if (mtIn.subtype == MEDIASUBTYPE_Overlay)
			{
				IBaseFilter* pOvMix = NULL;
				hr = m_FilterGraph->NextUpstream(pVR,&pOvMix);
				//pVR->Release();
				SAFE_RELEASE(pVR);
				if (FAILED(hr))
				{
					break;
				}
				pVR = pOvMix;
			}
			CComPtr< ISampleGrabber > pGrabber;//=ISampleGrabber *pGrabber;
			hr = pGrabber.CoCreateInstance( CLSID_SampleGrabber );
			if (FAILED(hr))
			{
				break;
			}
			CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabberBase( pGrabber );
			hr = m_FilterGraph->AddFilter(pGrabberBase, L"Grabber");
			if (FAILED(hr))
			{
				break;
			}

			//����Ҫץȡ��ý������
			CMediaType GrabType;
			GrabType.SetType( &MEDIATYPE_Video );//��Ϊ��Ƶ
			GrabType.SetSubtype( &MEDIASUBTYPE_RGB24 );//24λ
			GrabType.SetFormatType(&FORMAT_VideoInfo);

		    hr = pGrabber->SetMediaType( &GrabType );//����

			hr = m_FilterGraph->ConnectUpstreamOf2(pVR, pGrabberBase);
			if (FAILED(hr))
			{
				break;
			}
			m_FilterGraph->DelFilter(pVR);
			//pVR->Release();
			SAFE_RELEASE(pVR);
			VIDEOINFOHEADER2 * vih2 = (VIDEOINFOHEADER2*) mtIn.pbFormat;//
			if (vih2->bmiHeader.biWidth<=0||vih2->bmiHeader.biHeight<=0)
			{
				VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mtIn.pbFormat;//
				CB.Width  = vih->bmiHeader.biWidth;
				CB.Height = vih->bmiHeader.biHeight;
				m_nWidth = vih->bmiHeader.biWidth;
				m_nHeight = vih->bmiHeader.biHeight;
			}
			else
			{
				CB.Width  = vih2->bmiHeader.biWidth;
				CB.Height = vih2->bmiHeader.biHeight;
				m_nWidth = vih2->bmiHeader.biWidth;
				m_nHeight = vih2->bmiHeader.biHeight;
			}
			
			g_OutBuffer = (BYTE *) malloc(m_nWidth * m_nHeight * 3);
			m_OutBuffer = g_OutBuffer;


			// Don't buffer the samples as they pass through
			//
			hr = pGrabber->SetBufferSamples( FALSE );
			if (FAILED(hr))
			{
				break;
			}		
			// Only grab one at a time, stop stream after
			// grabbing one sample
			//
			hr = pGrabber->SetOneShot( FALSE );
			if (FAILED(hr))
			{
				break;
			}	
			// Set the callback, so we can grab the one sample
			//
		    hr = pGrabber->SetCallback( &CB, 1 );
			pGrabber.Release();
			pGrabberBase.Release();
		    if (FAILED(hr))
			{
			    break;
			}	
			m_bVideo = TRUE;*/
		} while(false);


		
//		WriteLog("������Ƶ�ز���Filter\n");
		if (m_bNeedResample)
		{
			do //��Audio Rendererǰ������Ƶ�ز���Filter.
			{

				IBaseFilter* pAR;
				HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IAMDirectSound , &pAR);
				if (FAILED(hr))
				{
					m_bAudio = FALSE;
					break;
				}
				
				
				IPin* pPin = m_FilterGraph->InputPinOf(pAR);
				AM_MEDIA_TYPE mt;
				pPin->ConnectionMediaType(&mt);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				IBaseFilter *pACMWrapper;
				hr = CoCreateInstance(CLSID_ACMWrapper, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pACMWrapper));
				if (FAILED(hr))
				{
					break;
				}


				hr =  m_FilterGraph->AddFilter(pACMWrapper, L"ACMWrapper");
				if (FAILED(hr))
				{

					break;
				}


				hr = m_FilterGraph->ConnectUpstreamOf(pAR, pACMWrapper);
				//pAR->Release();
				SAFE_RELEASE(pAR);
				if (FAILED(hr))
				{

					break;
				}


				IPin *pPinOut = m_FilterGraph->OutputPinOf(pACMWrapper);
				SAFE_RELEASE(m_pIAMStreamConfig);
// 				if (m_pIAMStreamConfig!=NULL)
// 				{
// 					m_pIAMStreamConfig->Release();
// 				}
				hr =  pPinOut->QueryInterface(IID_IAMStreamConfig,   (void   **)&m_pIAMStreamConfig); 
				//pPinOut->Release();
				SAFE_RELEASE(pPinOut);
				//pACMWrapper->Release();
				SAFE_RELEASE(pACMWrapper);
				if (FAILED(hr))
				{
					break;
				}

				CopyMemory(mt.pbFormat, &m_wfx ,mt.cbFormat);
							
				g_nBitsPerSecond = m_wfx.nAvgBytesPerSec;
				m_pIAMStreamConfig->SetFormat(&mt);
				FreeMediaType(mt);
				m_bAudio = TRUE;
			} while(false);
		}
//		WriteLog("�����л�����Filter\n");
		do //��audio rendererǰ�����л�����Filter.
		{

			IBaseFilter* pAR;
			HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IAMDirectSound , &pAR);
			if (FAILED(hr))
			{

				m_bAudio = FALSE;
				break;
			}

			if (!m_bNeedResample)
			{	
				IPin* pPin = m_FilterGraph->InputPinOf(pAR);
				AM_MEDIA_TYPE mt;
				pPin->ConnectionMediaType(&mt);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				CopyMemory(&m_wfx,mt.pbFormat,sizeof(m_wfx));
				FreeMediaType(mt);
			}

			
			
			IBaseFilter *pTrackSwitch;
			
			hr = CoCreateInstance(CLSID_TrackSwitch, 0, CLSCTX_INPROC_SERVER, IID_IBaseFilter, reinterpret_cast<void**>(&pTrackSwitch));
			
			if (FAILED(hr))
			{
				break;
			}

			hr =  m_FilterGraph->AddFilter(pTrackSwitch, L"TrackSwitch");
			if (FAILED(hr))
			{
	
				break;
			}
		
			hr = m_FilterGraph->ConnectUpstreamOf(pAR, pTrackSwitch);
			//pAR->Release();
			SAFE_RELEASE(pAR);
			if (FAILED(hr))
			{
			
				break;
			}
		
			SAFE_RELEASE(m_pTrackSwitch);
// 			if (m_pTrackSwitch!=NULL)
// 			{
// 				m_pTrackSwitch->Release();
// 				m
// 			}
			hr =  pTrackSwitch->QueryInterface(IID_ITrackSwitch,   (void   **)&m_pTrackSwitch); 
			SAFE_RELEASE(pTrackSwitch);
			//pTrackSwitch->Release();
			if (FAILED(hr))
			{
			
				break;
			}
			m_bIsSetTrack = TRUE;
			m_bAudio = TRUE;
		}while(false);
//		WriteLog("����ץȡ��Ƶ֡Filter\n");
		if (m_bNeedGetAudio)//��������Ҫȡ��Ƶ����,�粻��Ҫȡ��Ƶʱ���򲻼������filter.
		{

			do //��Audio Rendererǰ����ץȡ��Ƶ֡Filter.
			{
				IBaseFilter* pAR;
				HRESULT hr=m_FilterGraph->FindFilterByInterface(IID_IAMDirectSound , &pAR);
				if (FAILED(hr))
				{
				
					m_bAudio = FALSE;
					break;
				}
				
				if (m_bMute)
				{
					m_FilterGraph->mBasicAudio->put_Volume(-10000);//Randerer Mute.
				}

				IPin* pPin = m_FilterGraph->InputPinOf(pAR);
				pPin->ConnectionMediaType(&m_mtAudioMediaType);
				//pPin->Release();
				SAFE_RELEASE(pPin);
				CComPtr< ISampleGrabber > pGrabber;//=ISampleGrabber *pGrabber;
				hr = pGrabber.CoCreateInstance( CLSID_SampleGrabber );
				if (FAILED(hr))
				{
					break;
				}
				CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabberBase( pGrabber );
				hr = m_FilterGraph->AddFilter(pGrabberBase, L"Grabber");
				if (FAILED(hr))
				{
					break;
				}

				hr = m_FilterGraph->ConnectUpstreamOf(pAR, pGrabberBase);
				if (FAILED(hr))
				{
					break;
				}

				//pAR->Release();
				SAFE_RELEASE(pAR);
				if (g_OutAudioBuffer==NULL)
				{
					g_OutAudioBuffer = (BYTE *) malloc(FILEBUFFER);
					//free(g_OutAudioBuffer);
				}
				
				
				//m_OutAudioBuffer = g_OutAudioBuffer;

				// Don't buffer the samples as they pass through
				//
				hr = pGrabber->SetBufferSamples( FALSE );
				if (FAILED(hr))
				{
					break;
				}		
				// Only grab one at a time, stop stream after
				// grabbing one sample
				//
				hr = pGrabber->SetOneShot( FALSE );
				if (FAILED(hr))
				{
					break;
				}	
				// Set the callback, so we can grab the one sample
				//
				hr = pGrabber->SetCallback( &CBAudio2, 1 );
				pGrabber.Release();
				pGrabberBase.Release();
				CBAudio2.m_nAudioBufferCount = 0;
				if (FAILED(hr))
				{
					break;
				}	
				m_bAudio = TRUE;
			} while(false);
		}
	
		WriteLog("SetNotifyWindow!\n");
		if (m_FilterGraph->SetNotifyWindow(m_hwnd))
		{
			WriteLog("SetNotifyWindow Success!\n");
		}
		else
		{
//			WriteLog("SetNotifyWindow Failed!\n");
		}
			;//���ý�����Ϣ�Ĵ��ھ��

		g_FilterGraph = m_FilterGraph;
		
		m_FilterGraph->GetDuration(&g_fFileDuration);
		if (!m_bAudio && !m_bVideo)
		{
			return FALSE;
		}
		WriteLog("Create Graph Successed!\n");
		//m_FilterGraph->Pause();
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

BOOL CPlayer::DestroyGraph(void)
{
	WriteLog("DestroyGraph !\n");
	if (m_FilterGraph)
	{
		// Stop the filter graph first

		m_FilterGraph->Stop();
		WriteLog("m_FilterGraph->Stoped; !\n");
		m_FilterGraph->SetNotifyWindow(NULL);
		WriteLog("m_pAsfSource.Release();; !\n");
 		if (m_bIsMultStream)
 		{
			SAFE_RELEASE(m_pAsfSource);
		//	m_pAsfSource->Release();
 		}
		WriteLog("delete m_FilterGraph;!\n");	
		m_pTrackSwitch = NULL;	
		m_pIAMStreamConfig = NULL;	
		m_pAsfSource = NULL;	
		m_pIMySourseFilter = NULL;
		m_pIAMStreamConfig = NULL;

		SAFE_RELEASE(m_pTrackSwitch);
		SAFE_RELEASE(m_pIAMStreamConfig);
		SAFE_RELEASE(m_pAsfSource);
		SAFE_RELEASE(m_pIMySourseFilter);
		SAFE_RELEASE(m_pIAMStreamConfig);
		delete m_FilterGraph;
		m_FilterGraph = NULL;
	//	WriteLog("FreeMediaType; !\n");
		if (m_bNeedGetAudio)//��������Ҫȡ��Ƶ����,�粻��Ҫȡ��Ƶʱ���򲻼������filter.
		{
			FreeMediaType(m_mtAudioMediaType);
		}
	//	CoUninitialize();
		return TRUE;
		WriteLog("DestroyGraph Successed!\n");

	}
//	CoUninitialize();
	return FALSE;
}
BOOL CPlayer::Mute(BOOL bMute)
{
	if (bMute)
	{
		m_FilterGraph->mBasicAudio->put_Volume(-10000);//Randerer Mute.
	}
	else
	{
		m_FilterGraph->mBasicAudio->put_Volume(0);//Randerer Mute.
	}
	return TRUE;
}
BOOL CPlayer::SetVolume(long nVolume)
{
	if (nVolume>0)
	{
		nVolume = 0;
	}
	if (nVolume<-10000)
	{
		nVolume = -10000;
	}
	m_FilterGraph->mBasicAudio->put_Volume(nVolume);//Randerer Mute.
	return TRUE;
}

// BOOL	CPlayer::Open( const char * pszFileIn )
// {
// 	return TRUE;
// }
// BOOL	CPlayer::Close()
// {
// 	return TRUE;
// }
BOOL	CPlayer::Start()
{
// 	g_bLast200msOfFile = FALSE;
// 	g_bCreateThread = FALSE;
// 	g_bEOF = FALSE;


	g_bPlay=TRUE;
	if (m_FilterGraph)
	{
		m_FilterGraph->Run();
	}
	return TRUE;
}
BOOL	CPlayer::Stop()
{
//	ClearSempleBuffer();

	WriteLog("CPlayer::Stop()\n");
	if (m_FilterGraph)
	{
		m_FilterGraph->Stop();
		WriteLog("m_FilterGraph->SetCurrentPosition()\n");
		m_FilterGraph->SetCurrentPosition(0);
	}

	g_pBufferNodeOnSample = g_pBufferNodeHeader;
	g_pBufferNodeFillBuffer = g_pBufferNodeHeader;
	g_nUsedBufferCount = 0;

	g_pVideoRead = g_pVideoNodeHeader;
	g_pVideoWrite = g_pVideoNodeHeader;
	g_nVideoNodeUsed = 0;
	

	return TRUE;

}
BOOL CPlayer::Pause()
{
	m_FilterGraph->Pause();

	return TRUE;
}
BOOL CPlayer::Resume()
{
	return TRUE;
}
BOOL CPlayer::SelectStreams(int nLanguageNumber)
{
// 	FILE *fp;
//  	fp=fopen("d:\\log.txt","at");
// //	fprintf(fp,"PlayerDll: %d:%d:%d:%d ",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
// 	fprintf(fp,"LanguageNumber = %d\n",nLanguageNumber);
//  	fclose(fp);
	if (m_pAsfSource!=NULL)
	{
// 		if (m_nStreamNumber == 1)
// 		{
// 			m_nStreamNumber = 2;
// 		}
// 		else
// 		{
// 			m_nStreamNumber = 1;
// 		}
		m_pAsfSource->Set_Stream(nLanguageNumber);

		if (!m_bVideo && m_bSeekable)
		{
			double currenttime;
			m_FilterGraph->GetCurrentPosition(&currenttime);
			m_FilterGraph->Stop();
			
			m_FilterGraph->SetCurrentPosition(currenttime);
			m_FilterGraph->Run();
		}
		else if(!m_bSeekable)
		{
// 			m_FilterGraph->Stop();
// 			m_FilterGraph->SetCurrentPosition(0);
// 			m_FilterGraph->Run();
		}
	}

// 	if (!m_bVideo)
// 	{
// 		double currenttime;	
// 
// 		m_FilterGraph->GetCurrentPosition(&currenttime);
// 		m_FilterGraph->Stop();
// 		
// 		m_FilterGraph->SetCurrentPosition(currenttime);
// 		g_pBufferNodeOnSample = g_pBufferNodeHeader;
// 		g_pBufferNodeFillBuffer = g_pBufferNodeHeader;
// 		
// 		g_nUsedBufferCount = 0;
// 		m_FilterGraph->Run();
// 	}
	return TRUE;
}
BOOL CPlayer::GetTime(QWORD &cnsCurrentTime)
{
	return TRUE;
}
BOOL CPlayer::GetAudio(double &SampleTime, BYTE * pBuffer, long &BufferSize)
{
	if (pBuffer == NULL)
	{
		WriteLog("pBuffer == NULL\n");
		return FALSE;
	}

	if (g_nUsedBufferCount>0)
	{
		SampleTime = g_pBufferNodeFillBuffer->nSampleTime;
		BufferSize = g_pBufferNodeFillBuffer->nBufferSize;
		CopyMemory( pBuffer, g_pBufferNodeFillBuffer->pBuffer, BufferSize );
		g_pBufferNodeFillBuffer = g_pBufferNodeFillBuffer->pNext; 
		g_nUsedBufferCount--;
	}
	else
	{
		SampleTime = 0;
		BufferSize = 0;
	}

	return TRUE;
}

BOOL CPlayer::GetAudio2(double &SampleTime, BYTE * pBuffer, long &BufferSize)
{
	if (pBuffer == NULL)
	{
		WriteLog("pBuffer == NULL\n");
		return FALSE;
	}

	if (g_nUsedFileBufferCount>0)
	{
		//SampleTime = g_pBufferNodeFillBuffer->nSampleTime;
		BufferSize = g_nUsedFileBufferCount;//g_pBufferNodeFillBuffer->nBufferSize;
		CopyMemory( pBuffer, g_pBufferNodeFillBuffer->pBuffer, g_nUsedFileBufferCount );
		//g_pBufferNodeFillBuffer = g_pBufferNodeFillBuffer->pNext; 
		g_nUsedFileBufferCount = 0;
	}
	else
	{
		//SampleTime = 0;
		//BufferSize = 0;
	}

	return TRUE;
}

BOOL CPlayer::GetAudioMideaType(AM_MEDIA_TYPE &AudioMideaType)
{
	AudioMideaType = m_mtAudioMediaType;
	return TRUE;
}
BOOL CPlayer::SetAudioMideaType(WAVEFORMATEX wfx)
{
	m_bNeedResample = TRUE;
	m_wfx = wfx;
	return TRUE;
}
BOOL CPlayer::SetTrackLeft()
{
	if (m_pTrackSwitch != NULL && m_wfx.nChannels == 2 && m_wfx.wBitsPerSample == 16)
	{
		m_pTrackSwitch->set_ch(0);
	}
	return TRUE;
}

BOOL CPlayer::SetTrackRight()
{

	if(m_pTrackSwitch != NULL  && m_wfx.nChannels == 2 && m_wfx.wBitsPerSample == 16 )
	{
		m_pTrackSwitch->set_ch(1);
	}

	return TRUE;
}

BOOL CPlayer::SetStereo()
{
	
	if(m_pTrackSwitch != NULL  && m_wfx.nChannels == 2 && m_wfx.wBitsPerSample == 16 )
	{
		m_pTrackSwitch->set_ch(2);
	}
	
	return TRUE;
}
BOOL CPlayer::ClearSempleBuffer()
{
	CBAudio.m_nAudioBufferCount=0;

	g_pBufferNodeOnSample = g_pBufferNodeHeader;
	g_pBufferNodeFillBuffer = g_pBufferNodeHeader;
	
	g_nUsedBufferCount = 0;
	return TRUE;
}



/*BOOL IsURL(char * strFileName)
{
    char szFilename[MAX_PATH];
	//	char szFile[260];
	strcpy(szFilename,strFileName);
    // Copy the file name to a local string and convert to lowercase
	//    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _strlwr(szFilename);
	
    if (strstr(szFilename, "http:"))
        return TRUE;
    else
        return FALSE;
}*/
BOOL IsURL(LPTSTR lpszFile)
{
    TCHAR szFilename[MAX_PATH];
	
    // Copy the file name to a local string and convert to lowercase
    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _tcslwr(szFilename);
	
    if (_tcsstr(szFilename, TEXT("http:")))
        return TRUE;
    else
        return FALSE;
}
/*BOOL IsWindowsMediaFile(char * strFileName)
{
    char szFilename[MAX_PATH];
//	char szFile[260];
	strcpy(szFilename,strFileName);
    // Copy the file name to a local string and convert to lowercase
//    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _strlwr(szFilename);
	
    if (//_tcsstr(szFilename, TEXT(".asf")) ||
        //_tcsstr(szFilename, TEXT(".wmv")) ||
        strstr(szFilename, ".wma"))
        return TRUE;
    else
        return FALSE;
}*/
BOOL IsWindowsMediaFile(LPTSTR lpszFile)
{
    TCHAR szFilename[MAX_PATH];
	
    // Copy the file name to a local string and convert to lowercase
    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _tcslwr(szFilename);
	
    if ( _tcsstr(szFilename, TEXT(".wma")) )
        return TRUE;
    else
        return FALSE;
}
BOOL IsMP3(LPTSTR lpszFile)
{
    TCHAR szFilename[MAX_PATH];
	
    // Copy the file name to a local string and convert to lowercase
    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _tcslwr(szFilename);
	
    if (_tcsstr(szFilename, TEXT(".mp3")))
        return TRUE;
    else
        return FALSE;
}
/*
BOOL IsMP3(char * strFileName)
{
    char szFilename[MAX_PATH];
	//	char szFile[260];
	strcpy(szFilename,strFileName);
    // Copy the file name to a local string and convert to lowercase
	//    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _strlwr(szFilename);
	
    if (//_tcsstr(szFilename, TEXT(".asf")) ||
        //_tcsstr(szFilename, TEXT(".wmv")) ||
        strstr(szFilename, ".mp3"))
        return TRUE;
    else
        return FALSE;
}*/
BOOL IsVideo(LPTSTR lpszFile)
{
    TCHAR szFilename[MAX_PATH];
	
    // Copy the file name to a local string and convert to lowercase
    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _tcslwr(szFilename);
	
    if (_tcsstr(szFilename, TEXT(".avi")) ||
        _tcsstr(szFilename, TEXT(".mp4")) ||
        _tcsstr(szFilename, TEXT(".rmvb")) ||
        _tcsstr(szFilename, TEXT(".wmv")) ||
        _tcsstr(szFilename, TEXT(".flv")) ||
        _tcsstr(szFilename, TEXT(".3gp")) ||
        _tcsstr(szFilename, TEXT(".mkv")))
        return TRUE;
    else
        return FALSE;
}
/*
BOOL IsVideo(char * strFileName)
{
    char szFilename[MAX_PATH];
	//	char szFile[260];
	strcpy(szFilename,strFileName);
    // Copy the file name to a local string and convert to lowercase
	//    _tcsncpy(szFilename, lpszFile, NUMELMS(szFilename)-1);
    szFilename[MAX_PATH-1] = 0;
    _strlwr(szFilename);
	
    if (strstr(szFilename, ".avi") ||
        strstr(szFilename, ".mp4") ||
        strstr(szFilename, ".rmvb") ||
        strstr(szFilename, ".wmv") ||
        strstr(szFilename, ".flv") ||
        strstr(szFilename, ".3gp") ||
        strstr(szFilename, ".mkv"))
        return TRUE;
    else
        return FALSE;
}*/
HRESULT CPlayer::RenderOutputPins(IGraphBuilder *pGB, IBaseFilter *pFilter)
{
    HRESULT         hr = S_OK;
    IEnumPins *     pEnumPin = NULL;
    IPin *          pConnectedPin = NULL, * pPin;
    PIN_DIRECTION   PinDirection;
    ULONG           ulFetched;
	
    // Enumerate all pins on the filter
    hr = pFilter->EnumPins( &pEnumPin );
	
    if(SUCCEEDED(hr))
    {
        // Step through every pin, looking for the output pins
        while (S_OK == (hr = pEnumPin->Next( 1L, &pPin, &ulFetched)))
        {
            // Is this pin connected?  We're not interested in connected pins.
            hr = pPin->ConnectedTo(&pConnectedPin);
            if (pConnectedPin)
            {
                //pConnectedPin->Release();
				SAFE_RELEASE(pConnectedPin);
                pConnectedPin = NULL;
            }
			
            // If this pin is not connected, render it.
            if (VFW_E_NOT_CONNECTED == hr)
            {
                hr = pPin->QueryDirection( &PinDirection );
                if ( ( S_OK == hr ) && ( PinDirection == PINDIR_OUTPUT ) )
                {
                    hr = pGB->Render(pPin);
                }
            }
           // pPin->Release();
			SAFE_RELEASE(pPin);
            // If there was an error, stop enumerating
            if (FAILED(hr))                      
                break;
        }
    }
	
    // Release pin enumerator
    //pEnumPin->Release();
	SAFE_RELEASE(pEnumPin);
    return hr;
}
BOOL CPlayer::SetNeedGetAudioData(BOOL bNeedGetAudio)//Ĭ��ΪTURE
{
	m_bNeedGetAudio = bNeedGetAudio;
	return TRUE;
}
//int SplitString(const char* psz, char cTok, CStringArray& ayItem)
// {
// 	const char* p = psz;
// 	const char* e = psz;
// 	while (*p++)
// 	{
// 		if (*p == cTok || *p == '\0')
// 		{
// 			if (p-e > 0)
// 			{
// 			/*				if ((int)p == (int)(e + 1))
// 			{
// 			CString sTmp = _T("aaa");
// 			ayItem.Add(sTmp);
// 			}
// 			else
// 			
// 			  else
// 				*/
// 				ayItem.Add(CString(e, (int)(p-e)));
// 			}
// 			e = p+1;
// 		}
// 	}
// 	return (unsigned int)ayItem.GetSize();
// }

TCHAR* PhaseString(const char *pszStrIn, char cTok)
{
	const char *p = pszStrIn;
	const char *e = pszStrIn;
	TCHAR* pszStrOut = new TCHAR[256];
	memset(pszStrOut,0,256);
//  	FILE *fp;
//  	fp=fopen("d:\\log.txt","at");
//  	fprintf(fp,"pszStrIn = %s\n", pszStrIn);
//   	fclose(fp);
	char *pszStr = NULL;
	while(*p++)
	{
		if(*p == cTok || *p == '\0')
		{
			if (p-e>0)
			{
				pszStr = new char[p-e+1];
				memset(pszStr,0,p-e+1);
				strncpy(pszStr,e,p-e);
				for (int i = 0;i<15;i++)
				{
					if (strcmp(g_LanguageString[i],pszStr)==0)// LanguageString[i] == Language)
					{
						_tcscat(pszStrOut,g_Description[i]);
						_tcscat(pszStrOut,TEXT(";"));
						break;
						//int len = strlen(m_pszLanguage);
					}
 				}
				delete []pszStr;

			}
			e = p+1;
		}
	}

// 	fp=fopen("d:\\log.txt","at");
// 	fprintf(fp,"pszStrOut = %s\n", pszStrOut);
// 	fclose(fp);
	return pszStrOut;
}

void WriteLog(char * szLog)
{
	SYSTEMTIME st;
	GetLocalTime(&st);
	// 	// 
	// 	// 
	FILE *fp;
	fp=fopen("D://log.txt","at");
	if (fp == NULL)
	{
		return;
	}
	fprintf(fp,"PlayerDll: %d:%d:%d:%d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	fprintf(fp,szLog);
	fclose(fp);
	// 	delete[] str;
}

void WriteLogW(TCHAR * szLog)
{
	/*
	SYSTEMTIME st;
	GetLocalTime(&st);
	// 
	// 
// 	DWORD dwLen = 260;
// 	LPSTR str = new char[260];
// 	GetCurrentDirectoryA(dwLen,str);
// 	strcat(str,"\\log.txt");
	FILE *fp;
	fp=fopen("D://log.txt","at");
	fwprintf(fp,L"PlayerDll: %d:%d:%d:%d ",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	fwprintf(fp,szLog);
	fclose(fp);
//	delete[] str;
*/
}



