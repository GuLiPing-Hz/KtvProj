// PlayerDll.h : main header file for the PLAYERDLL DLL
//

#if !defined(AFX_PLAYER_H__43E18343_E2AA_4620_9886_75BF05872CE6__INCLUDED_)
#define AFX_PLAYER_H__43E18343_E2AA_4620_9886_75BF05872CE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// #ifndef __AFXWIN_H__
// 	#error include 'stdafx.h' before including this file for PCH
// #endif
#include "StdAfx.h"
//#include "resource.h"		// main symbols
#include "CDXGraph.h"

#define BUFFERLEN	2

#define OEMRESOURCE 
#define SMALLDLGSIZE 0.5
#define ERROR_DIALOG_TITLE  _T( "WMPlayer Sample" )
#define HWND_MESSAGE     ((HWND)-3)
typedef unsigned __int64 QWORD;
// {A4B11047-79C1-44C5-B6F2-8A868755ABE5}
void WriteLog(char * szLog);
void WriteLogW(TCHAR * szLog);
typedef enum AUDIOSTATUS
{
	CLOSED = 0,
		STOP,
		PAUSE,
		PLAY,
		OPENING,
		ACQUIRINGLICENSE,
		INDIVIDUALIZING,
		STOPPING,
		READY,
		BUFFERING,
		LICENSEACQUIRED,
		INDIVIDUALIZED
} AUDIOSTATUS;
typedef   void (CALLBACK *GETAUDIOSAMPLE)();
typedef   void (CALLBACK *GETAUDIOSAMPLE2)();
typedef   void (CALLBACK *ISEOF)();
typedef   void (CALLBACK *SENDSTATUS)(int nStatus);
typedef struct BufferNode 
{
	BYTE *		pBuffer;
	long		nBufferSize;
	double		nSampleTime;
	QWORD		nSampleDuration;
	ULONG		nSampleDurationULONG;
	BOOL		bGetted;
	BufferNode *pNext;
}BUFFER_NODE, *BUFFER_HEADER, *CURRENT_BUFFER_NODE;

typedef struct VideoBufferNode
{
	BYTE * pBuffer;
	VideoBufferNode *pNext;
}VideoBufferNode;
///////////////////////////////////////////////////////////////////////////////

// CPlayerDllApp
// See PlayerDll.cpp for the implementation of this class
//
// #ifndef PLAYER_DLLAPI
// #define PLAYER_DLLAPI extern "C" __declspec(dllimport)
// #endif
class CPlayer
{
public:
	CPlayer();
	~CPlayer(){
		if (m_pszLanguage)
		{
			delete [] m_pszLanguage;
			m_pszLanguage = NULL;
		}
		if (m_OutBuffer)
		{
			delete[] m_OutBuffer;
			m_OutBuffer = NULL;
		}
		//UnInitialize();
	}

	
	BOOL Initialize();
	BOOL UnInitialize();
	BUFFER_NODE* InitBufferList();
	VideoBufferNode* InitVideoBufferList(ULONG size);
	BOOL UnInitBufferList();
	//BOOL UnVideoBufferList();
	BOOL InitMessageOnlyWindow();	
	BOOL SetNeedGetAudioData(BOOL bNeedGetAudio);//Ĭ��ΪTURE
//	BOOL SetNeedResample(BOOL bNeedResample);//Ĭ��ΪTURE
// 	BOOL Open( const char * pszFileIn );
//     BOOL Close();
	BOOL Start();

	BOOL Stop();
	BOOL Pause();
	BOOL Resume();
	BOOL Mute(BOOL bMute);
	BOOL SetVolume(long nVolume);

	BOOL SelectStreams(int nLanguageNumber);
	BOOL GetTime(QWORD &cnsCurrentTime);
	BOOL GetAudio(double &SampleTime, BYTE * pBuffer, long &BufferSize);
	BOOL GetAudio2(double &SampleTime, BYTE * pBuffer, long &BufferSize);//add by glp
	BOOL GetAudioMideaType(AM_MEDIA_TYPE &AudioMideaType);
	BOOL SetAudioMideaType(WAVEFORMATEX AudioMideaType);
	BOOL SetTrackLeft();
	BOOL SetTrackRight();
	BOOL SetStereo();
	BOOL ClearSempleBuffer();

    // either the capture live graph, or the capture still graph

    // the playback graph when capturing video

	
    // the sample grabber for grabbing stills

//    CComPtr< ITrackSwitch > m_pTrackSwitch;	
	ITrackSwitch *m_pTrackSwitch;
	IAMStreamConfig * m_pIAMStreamConfig;
	IASFSource * m_pAsfSource;
	IFileSourceFilter * m_pIMySourseFilter;	
 //   CComPtr< IAMStreamConfig > m_pIAMStreamConfig;	
 //   CComPtr< IASFSource > m_pAsfSource;
 //   CComPtr< IFileSourceFilter > m_pIMySourseFilter;	

	int m_nStreamNumber;
	
    // if you're in still mode or capturing video mode
    bool m_bCapStills;
	
    // when in video mode, whether capturing or playing back
    int m_nCapState;
	
    // how many times you've captured
    int m_nCapTimes;

	BOOL		m_bNeedGetAudio;
	BOOL		m_bNeedResample;

	HWND		m_hwnd;
	BOOL		m_bVideo;//�Ƿ�����Ƶ
	BOOL		m_bAudio;//�Ƿ�����Ƶ
	BOOL		m_bIsMultStream;//�Ƿ��ж�����
	int			m_nLanguageLen;
	TCHAR*		m_pszLanguage;
	BOOL		m_bIsSetTrack;//�л�����Filter�Ƿ���سɹ�

	BOOL		m_bSeekable;//�Ƿ�֧�������λ
	BOOL		m_bMute;

	DWORD		m_ThreadID;
	int			m_nWidth;
	int			m_nHeight;
	BYTE *		m_OutBuffer;
	BYTE *		m_OutAudioBuffer;

	LONG m_nAudioBufferCount;
	AM_MEDIA_TYPE m_mtAudioMediaType;
	WAVEFORMATEX  m_wfx;//��Ƶ��ʽ�����������ʵ���Ϣ��

	CDXGraph *   m_FilterGraph;     // Filter Graph��װ
	TCHAR *      m_pszSourceFile;      // Դ�ļ�
	
	BOOL CreateGraph(void);        // ����Filter Graph
	BOOL CreateGraph2(void);
	BOOL DestroyGraph(void);       // ����Filter Graph
	void RestoreFromFullScreen(void);
	
	// Just for testing...
	HRESULT FindFilterByInterface(REFIID riid, IBaseFilter** ppFilter);
	void ShowVRPropertyPage(void);
	BOOL IsMultStreams();
	HRESULT RenderOutputPins(IGraphBuilder *pGB, IBaseFilter *pFilter);
private:

//	static DWORD WINAPI  OnGetEndThread(LPVOID lpParameter);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlayerDllApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CPlayerDllApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYER_H__43E18343_E2AA_4620_9886_75BF05872CE6__INCLUDED_)
