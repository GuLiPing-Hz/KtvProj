#if !defined(__KTVDOANLOADSONG_H__)
#define __KTVDOANLOADSONG_H__

struct KTVDOWNPARAM //
{
	KTVDOWNPARAM::KTVDOWNPARAM( LPCTSTR lpszUrl, LPCTSTR lpszFilePath ,HWND hwndin)//, CWnd *pWnd)
		: strUrl( lpszUrl )
		, filePath( lpszFilePath )
		, hwnd( hwndin )
	{
		bPlaying = FALSE;
	}
	
	CString		 strUrl;
	CString		 filePath;
//	CWnd		*pNotifyWnd;
	HWND		hwnd;
	BOOL		bPlaying;
};

DWORD WINAPI KtvDownloadSongThread(LPVOID pParam);

#endif