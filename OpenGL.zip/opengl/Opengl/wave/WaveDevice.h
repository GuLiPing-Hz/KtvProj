// WaveDevice.h: interface for the CWaveDevice class.
//

#if !defined(AFX_WAVEDEVICE_H__FD02E292_FE4D_4B69_B268_428956261170__INCLUDED_)
#define AFX_WAVEDEVICE_H__FD02E292_FE4D_4B69_B268_428956261170__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Wave.h"

class CWaveDevice  
{
public:
	CWaveDevice(const CWaveDevice& copy);
	UINT GetDevice() const;
	bool IsOutputFormat(const CWave& wave);
	bool IsInputFormat(const CWave& wave);
	CWaveDevice(UINT nDevice = WAVE_MAPPER);
	virtual ~CWaveDevice();

private:
	UINT m_nDevice;
};

#endif // !defined(AFX_WAVEDEVICE_H__FD02E292_FE4D_4B69_B268_428956261170__INCLUDED_)
