// WaveIn.cpp: implementation of the CWaveIn class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WaveIn.h"


//#define _ROOM_DEBUG

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef _ROOM_DEBUG

//void MessageBoxToFile1(CString strFileName, CString strMsg, CString strTitle="");


void MessageBoxToFile1(CString strFileName, CString strMsg, CString strTitle) 
{
//	MessageBox(NULL,strFileName+"\r\n"+strMsg,strTitle,MB_OK);
//	return;
	
	FILE	*fp = NULL;
//	g_MsgToFile.Lock();
	fp = fopen((char *)(LPCTSTR)strFileName, "ab+");
	if (fp == NULL) {
		return;
	}
	fputs((char *)(LPCTSTR)(CTime::GetCurrentTime().Format("(%H:%M:%S)|") + strTitle + ":" + strMsg),fp);//��ҳ���ص�strMsg��ĩβ�������������ϵ�0��������strMsg+"\r\n"�Ļ���"\r\n"���ܱ������
	fprintf(fp, "\r\n");
	fclose(fp);
//	g_MsgToFile.Unlock();
}

#endif

//////////////////////////////////////////////////////////////////////
void CALLBACK waveInProc(HWAVEIN hwi, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	switch(uMsg) {
	case MM_WIM_DATA:
		WAVEHDR* pWaveHdr = ( (WAVEHDR*)dwParam1 );
		CWaveIn* pWaveIn = (CWaveIn*)(pWaveHdr->dwUser);

		if (pWaveHdr && hwi && pWaveIn) {
			if (pWaveHdr->dwFlags & WHDR_DONE == WHDR_DONE) {
				pWaveHdr->dwFlags = 0;
				if ( pWaveIn->IsError(waveInUnprepareHeader(hwi, pWaveHdr, sizeof(WAVEHDR))) ) {
					break;
				}
				if (pWaveHdr->dwBytesRecorded > 0) {
					pWaveIn->AddNewBuffer(pWaveHdr);
				}
				delete[] pWaveHdr->lpData;
				pWaveHdr->lpData = NULL;
			}

			if ( !pWaveIn->ResetRequired(pWaveIn) ) {
				if ( !pWaveIn->AddNewHeader(hwi) ) {
					break;
				}
			}
		}
		break;
	}
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
CWaveIn::CWaveIn(WAVEFORMATEX tagFormat, const CWaveDevice& aDevice) : m_waveDevice(aDevice), \
	m_hWaveIn(0), m_nIndexWaveHdr(NUMWAVEINHDR - 1), m_bResetRequired(true)
{
	SetWaveFormat(tagFormat);
	InitListOfHeader();
}

//////////////////////////////////////////////////////////////////////
CWaveIn::CWaveIn() : m_hWaveIn(0), m_nIndexWaveHdr(-1), m_bResetRequired(true)
{
	InitListOfHeader();
	m_dwLastBufferPos=0;
	m_posLastEnd=NULL;
	m_dwLastBufferStart=0;
}

//////////////////////////////////////////////////////////////////////
CWaveIn::~CWaveIn()
{
	Close();
	FreeListOfBuffer();
	FreeListOfHeader();
}

//////////////////////////////////////////////////////////////////////
// Initialisation
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
void CWaveIn::SetDevice(const CWaveDevice &aDevice)
{
	m_waveDevice = aDevice;
}

//////////////////////////////////////////////////////////////////////
void CWaveIn::SetWaveFormat(WAVEFORMATEX tagFormat)
{
	m_wave.BuildFormat(tagFormat.nChannels, tagFormat.nSamplesPerSec, tagFormat.wBitsPerSample);
}

//////////////////////////////////////////////////////////////////////
void CWaveIn::InitListOfHeader()
{
	for (int i = 0; i < NUMWAVEINHDR; i++) {
		m_tagWaveHdr[i].lpData = NULL;
	}
}

//////////////////////////////////////////////////////////////////////
// Son
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
bool CWaveIn::Close()
{
	if (m_hWaveIn != NULL) {
		if ( !Stop() ) {
			return false;
		}
		if ( IsError( waveInClose(m_hWaveIn)) ) {
			return false;
		}
		m_hWaveIn = 0;
		//GD�޸�[2006-05-19]�����close�Ժ��ڴ�û���ͷŵ����⡣
		FreeListOfBuffer();
		FreeListOfHeader();
		m_wave.Close();
		////////////////////
	}
	return true;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::Continue()
{
	if (m_hWaveIn) {
		return !IsError( waveInStart(m_hWaveIn) );
	}
	return true;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::Open()
{
	return !IsError( waveInOpen(&m_hWaveIn, m_waveDevice.GetDevice(), &m_wave.GetFormat(), (DWORD)waveInProc, NULL, CALLBACK_FUNCTION) );
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::Pause()
{
	if (m_hWaveIn) {
		return !IsError( waveInStop(m_hWaveIn) );
	}
	return true;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::Record(UINT nTaille/* = 4096*/)
{
	ASSERT(nTaille > 0);
	ASSERT(m_hWaveIn);

	if ( !Stop() ) {
		return false;
	}
	m_bResetRequired = false;
	FreeListOfBuffer();
	FreeListOfHeader();
	SetWaveFormat( m_wave.GetFormat() );
	m_nIndexWaveHdr = NUMWAVEINHDR - 1;
	m_nBufferSize = nTaille;
	for (int i = 0; i < NUMWAVEINHDR; i++) {
		if ( !AddNewHeader(m_hWaveIn) ) {
			return false;
		}
	}
	if ( IsError(waveInStart(m_hWaveIn)) ) {
		return false;
	}

	return true;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::Stop()
{
	if (m_hWaveIn != NULL) {
		m_bResetRequired = true;
		::Sleep(10);
		if ( IsError(waveInReset(m_hWaveIn)) ) {
			return false;
		}
	}
	return true;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::AddNewBuffer(WAVEHDR *pWaveHdr)
{
	ASSERT(pWaveHdr);

	m_listOfBuffer.AddTail(new CWaveBuffer);
	( (CWaveBuffer*)m_listOfBuffer.GetTail() )->CopyBuffer( pWaveHdr->lpData, \
		pWaveHdr->dwBytesRecorded / m_wave.GetFormat().nBlockAlign, \
		m_wave.GetFormat().nBlockAlign );
	return true;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::AddNewHeader(HWAVEIN hwi)
{
	ASSERT(m_nBufferSize > 0);

	m_nIndexWaveHdr = (m_nIndexWaveHdr == NUMWAVEINHDR - 1) ? 0 : m_nIndexWaveHdr + 1;
	if (m_tagWaveHdr[m_nIndexWaveHdr].lpData == NULL) {
		m_tagWaveHdr[m_nIndexWaveHdr].lpData = new char[m_nBufferSize];
	}
	ZeroMemory(m_tagWaveHdr[m_nIndexWaveHdr].lpData, m_nBufferSize);
	m_tagWaveHdr[m_nIndexWaveHdr].dwBufferLength = m_nBufferSize;
	m_tagWaveHdr[m_nIndexWaveHdr].dwFlags = 0;
	m_tagWaveHdr[m_nIndexWaveHdr].dwUser = (DWORD)(void*)this;
	if ( IsError(waveInPrepareHeader(hwi, &m_tagWaveHdr[m_nIndexWaveHdr], sizeof(WAVEHDR))) ) {
		return false;
	}
	if ( IsError(waveInAddBuffer(hwi, &m_tagWaveHdr[m_nIndexWaveHdr], sizeof(WAVEHDR))) ) {
		return false;
	}
	return true;
}

//////////////////////////////////////////////////////////////////////
void CWaveIn::FreeListOfHeader()
{
	for (int i = 0; i < NUMWAVEINHDR; i++) {
		delete[] m_tagWaveHdr[i].lpData;
		m_tagWaveHdr[i].lpData = NULL;
	}
}

//////////////////////////////////////////////////////////////////////
void CWaveIn::FreeListOfBuffer()
{
	POSITION pos = m_listOfBuffer.GetHeadPosition();
	while (pos) {
		CWaveBuffer* pBuf = (CWaveBuffer*)m_listOfBuffer.GetNext(pos);
		if (pBuf) {
			delete pBuf;
			pBuf = NULL;
		}
	}
	m_listOfBuffer.RemoveAll();
}

//////////////////////////////////////////////////////////////////////
// GET
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
DWORD CWaveIn::GetNumSamples()
{
	DWORD dwTotal = 0L;
	POSITION pos = m_listOfBuffer.GetHeadPosition();
	while (pos) {
		CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetNext(pos);
		dwTotal += p_waveBuffer->GetNumSamples();
	}
	return dwTotal;
}

//////////////////////////////////////////////////////////////////////
CString CWaveIn::GetError() const
{
	if (m_nError != MMSYSERR_NOERROR) {
		TCHAR szText[MAXERRORLENGTH + 1];
		if ( waveInGetErrorText(m_nError, szText, MAXERRORLENGTH) == MMSYSERR_NOERROR ) {
			return szText;
		}
	}
	return "";
}

//////////////////////////////////////////////////////////////////////
DWORD CWaveIn::GetPosition()
{
	if (m_hWaveIn) {
		MMTIME mmt;
		mmt.wType = TIME_SAMPLES;
		if ( IsError(waveInGetPosition(m_hWaveIn, &mmt, sizeof(MMTIME))) ) {
			return -1;
		}
		else {
			return mmt.u.sample;
		}
	}
	return -1;
}

//////////////////////////////////////////////////////////////////////
//addedy by forrest
DWORD CWaveIn::GetCurrentTime()
{
	if (m_hWaveIn) {
		MMTIME mmt;
		mmt.wType = TIME_MS;
		if ( IsError(waveInGetPosition(m_hWaveIn, &mmt, sizeof(MMTIME))) ) {
			return -1;
		}
		else {
			return mmt.u.ms;
		}
	}
	return -1;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::IsError(MMRESULT nResult)
{
	m_nError = nResult;
	return (m_nError != MMSYSERR_NOERROR);
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::IsRecording()
{
	bool bResult = false;
	if (m_nIndexWaveHdr > -1 && m_tagWaveHdr[m_nIndexWaveHdr].dwFlags != 0) {
		bResult |= !(m_tagWaveHdr[m_nIndexWaveHdr].dwFlags & WHDR_DONE == WHDR_DONE);
	}
	return bResult;
}

//////////////////////////////////////////////////////////////////////
CWave CWaveIn::MakeWave()
{
	void* pBuffer = new char[GetNumSamples() * m_wave.GetFormat().nBlockAlign];
	DWORD dwPosInBuffer = 0L;
	POSITION pos = m_listOfBuffer.GetHeadPosition();
	while (pos) {
		CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetNext(pos);
		CopyMemory( (char*)pBuffer + dwPosInBuffer, p_waveBuffer->GetBuffer(),\
			p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize() );
		dwPosInBuffer += p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
	}
	m_wave.SetBuffer( pBuffer, GetNumSamples() );
	return m_wave;
}

//////////////////////////////////////////////////////////////////////
bool CWaveIn::ResetRequired(CWaveIn* pWaveIn)
{
	return m_bResetRequired;
}


void CWaveIn::GetRestBuffer(const POSITION start_pos, 
							const DWORD start_dwPosInWaveBuffer, 
							void*& pBuffer, 
							DWORD& dwBufferLength,
							DWORD& dwRestNumSamples)
{
	//�ȼ�����Ҫ����Ŀռ��С(dwRestWaveBufferLength), ͬʱ�õ�������dwRestNumSamples
	POSITION pos = start_pos;
	DWORD dwPosInBuffer = 0L;
	DWORD dwRestWaveBufferLength = 0;
	dwBufferLength = 0;
	dwRestNumSamples = 0;
	if(pos) 
	{
		CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetNext(pos);
		DWORD dwPosEndWaveBuffer = p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
		DWORD dwPosStartWaveBuffer = start_dwPosInWaveBuffer;
		dwRestWaveBufferLength = dwPosEndWaveBuffer - dwPosStartWaveBuffer;
		dwRestNumSamples = dwRestWaveBufferLength / p_waveBuffer->GetSampleSize();
		while(pos)
		{
			p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetNext(pos);
			dwRestWaveBufferLength += p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
			dwRestNumSamples += p_waveBuffer->GetNumSamples();
		}
	}
	
	dwBufferLength = dwRestWaveBufferLength;
	if ( dwBufferLength == 0)
	{
		pBuffer = NULL;
		return;
	}
	else
	{
		//��������
		pBuffer = new char[ dwBufferLength ];
		pos = start_pos;
		if(pos) 
		{
			CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetNext(pos);
			DWORD dwPosEndWaveBuffer = p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
			DWORD dwPosStartWaveBuffer = start_dwPosInWaveBuffer;
			dwRestWaveBufferLength = dwPosEndWaveBuffer - dwPosStartWaveBuffer;
			CopyMemory( (char*)pBuffer + dwPosInBuffer, 
				(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
				dwRestWaveBufferLength);
			dwPosInBuffer += dwRestWaveBufferLength;
			while(pos)
			{
				p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetNext(pos);
				DWORD dwCopyWaveBufferLength = p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
				CopyMemory( (char*)pBuffer + dwPosInBuffer, 
					(char*)p_waveBuffer->GetBuffer(), 
					dwCopyWaveBufferLength);
				dwPosInBuffer += dwCopyWaveBufferLength;
			}
		}
	}
	return;
	
}

void CWaveIn::GetBufferByNumSamples(const POSITION start_pos, 
									const DWORD start_dwPosInWaveBuffer,
									const DWORD num_samples,
									void*& pBuffer,
									DWORD& dwBufferLength,
									POSITION& end_pos,
									DWORD& end_dwPosInWaveBuffer)
{
	//ע�⣺�����nBlockAlign�͵���p_waveBuffer->GetSampleSize()
	//ע�⣺nBlockAlign�ĵ�λ���ֽ�(byte)������bit
	dwBufferLength = num_samples * m_wave.GetFormat().nBlockAlign;

	pBuffer = new char[ dwBufferLength ];
	memset(pBuffer,128,dwBufferLength);
	POSITION pos = start_pos;
	DWORD dwPosInBuffer = 0L;
	
	//�ж��Ƿ񽫸�waveBuffer��ʣ��������copy

	//����Ƕ�copy
		//ȫ��copy
		//����listOfBuffer�е���һ��waveBuffer
		//�ظ�step1
	//������Ƕ�copy
		//����Ҫcopy�ĳ���
		//���ݼ�������ĳ��ȣ�CopyMemory()

#ifdef _ROOM_DEBUG
	char buf[500];
		sprintf(buf,"һ���µĿ�������������������������\n");
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif



	DWORD dwNeedCopyBufferLength = dwBufferLength;
	if(pos) 
	{
		CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetAt(pos);
		DWORD dwPosEndWaveBuffer = p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
		DWORD dwPosStartWaveBuffer = start_dwPosInWaveBuffer;
		DWORD dwRestWaveBufferLength = dwPosEndWaveBuffer - dwPosStartWaveBuffer;
		if( dwRestWaveBufferLength < dwNeedCopyBufferLength)		
		{
			CopyMemory( (char*)pBuffer + dwPosInBuffer, 
				(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
				dwRestWaveBufferLength);

#ifdef _ROOM_DEBUG
		sprintf(buf,"�����ڴ���ʼλ�ã�%d���������ȣ�%d��Ӧ�ÿ������ܳ��ȣ�%d\n",dwPosInBuffer,
			dwRestWaveBufferLength,dwBufferLength);
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif

			dwPosInBuffer += dwRestWaveBufferLength;
			dwNeedCopyBufferLength -= dwRestWaveBufferLength;
			
			m_listOfBuffer.GetNext(pos); //pos++�����ã�������GetNext��ʹpos�ƶ�
			dwPosStartWaveBuffer = 0; //ע������һ��Ҫ��0����Ϊ�����buffer�鶼�Ǵ���ʼ0��ʼ����
			while(pos) 
			{
				p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetAt(pos);
				dwPosEndWaveBuffer = p_waveBuffer->GetNumSamples() * p_waveBuffer->GetSampleSize();
				dwRestWaveBufferLength = dwPosEndWaveBuffer - dwPosStartWaveBuffer;
				if( dwRestWaveBufferLength < dwNeedCopyBufferLength)		
				{
					CopyMemory( (char*)pBuffer + dwPosInBuffer, 
						(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
						dwRestWaveBufferLength);


#ifdef _ROOM_DEBUG
		sprintf(buf,"�����ڴ���ʼλ�ã�%d���������ȣ�%d��Ӧ�ÿ������ܳ��ȣ�%d\n",dwPosInBuffer,
			dwRestWaveBufferLength,dwBufferLength);
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif

					
					dwPosInBuffer += dwRestWaveBufferLength;
					dwNeedCopyBufferLength -= dwRestWaveBufferLength;
					dwPosStartWaveBuffer = 0;
					m_listOfBuffer.GetNext(pos);
				}
				else
				{
					if ( dwRestWaveBufferLength > dwNeedCopyBufferLength)
					{
						CopyMemory( (char*)pBuffer + dwPosInBuffer, 
							(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
							dwNeedCopyBufferLength);

#ifdef _ROOM_DEBUG
		sprintf(buf,"�����ڴ���ʼλ�ã�%d���������ȣ�%d��Ӧ�ÿ������ܳ��ȣ�%d\n",dwPosInBuffer,
			dwNeedCopyBufferLength,dwBufferLength);
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif
						
						dwPosInBuffer += dwNeedCopyBufferLength;
						dwPosStartWaveBuffer = dwPosStartWaveBuffer + dwNeedCopyBufferLength;
						dwNeedCopyBufferLength = 0;
						break;
					}
					else //��: dwRestWaveBufferLength == dwNeedCopyBufferLength
					{
						CopyMemory( (char*)pBuffer + dwPosInBuffer, 
							(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
							dwNeedCopyBufferLength);
#ifdef _ROOM_DEBUG
		sprintf(buf,"�����ڴ���ʼλ�ã�%d���������ȣ�%d��Ӧ�ÿ������ܳ��ȣ�%d\n",dwPosInBuffer,
			dwNeedCopyBufferLength,dwBufferLength);
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif


						dwPosInBuffer += dwNeedCopyBufferLength;
						dwPosStartWaveBuffer = 0;
						dwNeedCopyBufferLength = 0;
						m_listOfBuffer.GetNext(pos);
						break;
					}
				}
			}
		}
		else
		{
			if (dwRestWaveBufferLength > dwNeedCopyBufferLength)
			{
				CopyMemory( (char*)pBuffer + dwPosInBuffer, 
					(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
					dwNeedCopyBufferLength);

#ifdef _ROOM_DEBUG
		sprintf(buf,"�����ڴ���ʼλ�ã�%d���������ȣ�%d��Ӧ�ÿ������ܳ��ȣ�%d\n",dwPosInBuffer,
			dwNeedCopyBufferLength,dwBufferLength);
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif
				
				dwPosInBuffer += dwNeedCopyBufferLength;
				dwPosStartWaveBuffer = dwPosStartWaveBuffer + dwNeedCopyBufferLength;
			}
			else //����dwRestWaveBufferLength == dwNeedCompyBufferLength
			{
				CopyMemory( (char*)pBuffer + dwPosInBuffer, 
					(char*)p_waveBuffer->GetBuffer() + dwPosStartWaveBuffer, 
					dwNeedCopyBufferLength);
#ifdef _ROOM_DEBUG
		sprintf(buf,"�����ڴ���ʼλ�ã�%d���������ȣ�%d��Ӧ�ÿ������ܳ��ȣ�%d\n",dwPosInBuffer,
			dwNeedCopyBufferLength,dwBufferLength);
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif
				dwPosInBuffer += dwNeedCopyBufferLength;
				dwPosStartWaveBuffer = 0;
//				m_listOfBuffer.GetNext(pos);
			}
		}

		if(pos == NULL)
		{
#ifdef _ROOM_DEBUG
		sprintf(buf,"������������������������");
		MessageBoxToFile1("c:\\RSLOG_CopyMemory.txt", buf,"");
#endif
			
		}

		end_pos = pos;
		end_dwPosInWaveBuffer = dwPosStartWaveBuffer;
	}
}

POSITION CWaveIn::GetHeadPosition()
{
	return m_listOfBuffer.GetHeadPosition();
}

//zyg [2005-02-17] //////////////////////////////////////
POSITION CWaveIn::GetTailPosition()
{
	return m_listOfBuffer.GetTailPosition();
}

DWORD CWaveIn::GetPrePosition(POSITION &pos)
{
	CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetAt(pos);
	DWORD dwSample = p_waveBuffer->GetNumSamples();// * p_waveBuffer->GetSampleSize();
	m_listOfBuffer.GetPrev(pos);
	return dwSample;
}

DWORD CWaveIn::GetNextPosition(POSITION &pos)
{
	CWaveBuffer* p_waveBuffer = (CWaveBuffer*) m_listOfBuffer.GetAt(pos);
	DWORD dwSample = p_waveBuffer->GetNumSamples();// * p_waveBuffer->GetSampleSize();
	m_listOfBuffer.GetNext(pos);
	return dwSample;
}
//zyg [2005-02-17] //////////////////////////////////////

//��һ���ڴ棨�ӵ�n������������j������֮����ڴ棩��������ָ����λ�á�
void CWaveIn::MoveBufferByNumSamples(const POSITION start_pos,
									 const DWORD start_dwPosInWaveBuffer,
									 const DWORD num_samples, 
									 const DWORD start_desDwSamples)
{
	ASSERT(start_dwPosInWaveBuffer > 0);
	ASSERT(start_desDwSamples > 0);
	if(num_samples <= 0)
		return;

	if(num_samples <= 20000)
		int n1=0;

	void * pTmpBuf=NULL;
	BYTE * pBuf=NULL;
	DWORD dwBufferLength=0;
	POSITION end_pos=NULL;
	DWORD end_dwPosInWaveBuffer;

	POSITION temp_posInWaveBuf=NULL;
	DWORD temp_dwPOsInWaveBuf=0;

	if(!GetPositionBySamples(GetHeadPosition(),start_dwPosInWaveBuffer,
		temp_posInWaveBuf,temp_dwPOsInWaveBuf))
		return;

	//����ȡ��Դ��������Ӧ���ڴ�
	GetBufferByNumSamples(temp_posInWaveBuf,
		temp_dwPOsInWaveBuf,
		num_samples,
		pTmpBuf,
		dwBufferLength,
		end_pos,
		end_dwPosInWaveBuffer);

	pBuf = (BYTE*)pTmpBuf;

	static int ndex=0;

	char buf[100];
	sprintf(buf,"d:\\test-%d.wav",ndex);
	ndex++;
	
	CWave waveSave;
//	memset(pBuf,10,dwBufferLength);
	waveSave.BuildFormat(1,11025,8);
	waveSave.SetBuffer(pBuf,num_samples,true);
//	waveSave.ClipToNumSamples(num_samples);
	waveSave.Save(buf);
//	waveSave.Close();

	ASSERT(pBuf != NULL);

	//��Դ������Ӧ���ڴ濽����Ŀ����������λ�õ��ڴ棬��Ŀ��������ʼ��Ϊ׼

	//����ȷ��Ŀ���������λ��

	//����ȷ��Ŀ�����������ڴ��е�λ�ã�
	//���������е��ĸ�Ԫ�أ���Ԫ�صĵڼ����������λ�á�

	DWORD temp_dwBuffSize=0;
	DWORD temp_dwThisBufSize=0;

	DWORD temp_desStartSamples=0;
	POSITION pos=GetHeadPosition();
	POSITION temp_pos=pos;
	while(pos != NULL)
	{
		CWaveBuffer * pBuffer= (CWaveBuffer *) m_listOfBuffer.GetNext(pos);
		
		DWORD dwBuffSamples=pBuffer->GetNumSamples();
		DWORD dwThisBufSize=dwBuffSamples * pBuffer->GetSampleSize();

		/******************************************************/
		//���ϴν���֮�󣬵��˴ο�ʼ֮ǰ��������0

		//����˴�buf�Ľ���������0��֮ǰ
		if(temp_dwBuffSize+dwThisBufSize > m_dwLastBufferPos)
		{
			//����˴�buf�Ŀ�ʼ������0��֮ǰ
			if(temp_dwBuffSize > m_dwLastBufferPos)
			{
				//���
				if(temp_desStartSamples+dwBuffSamples > start_desDwSamples)
				{
					memset(pBuffer->GetBuffer(),128,(start_desDwSamples-temp_desStartSamples)*pBuffer->GetSampleSize());
				}
				else
				{
					memset(pBuffer->GetBuffer(),128,dwThisBufSize);
				}
			}
			else
			{
				//�ϴμ�¼�Ľ������������������
				if(temp_desStartSamples+dwBuffSamples > start_desDwSamples)
				{
					//���εĿ�ʼ��Ҳ�������������
					
					if(start_desDwSamples*pBuffer->GetSampleSize() > m_dwLastBufferPos)
					{
						memset((BYTE *)pBuffer->GetBuffer()+m_dwLastBufferPos-temp_dwBuffSize,128,
							start_desDwSamples*pBuffer->GetSampleSize()-m_dwLastBufferPos);
					}
				}
				else
				{
					memset((BYTE *)pBuffer->GetBuffer()+m_dwLastBufferPos-temp_dwBuffSize,128,
						dwThisBufSize-(m_dwLastBufferPos-temp_dwBuffSize));
				}
			}
		}
		
		temp_dwBuffSize=temp_dwBuffSize+dwThisBufSize;
		/********************************************************/
		
		if(temp_desStartSamples + dwBuffSamples > start_desDwSamples)
		{

			//��ʱ��POSӦ����Ŀ���������ڵ�buf��pos
			break;
		}
		else
		{
			temp_desStartSamples=temp_desStartSamples+dwBuffSamples;
			//���浱ǰλ��
			temp_pos=pos;
		}
	}

//	ASSERT(temp_pos != NULL);
	if(temp_pos == NULL)
	{
		if(pBuf != NULL)
			delete pBuf;
		return;
	}

	//�ҵ���Ŀ���������ڵ�λ�ã���Ŀ���������ڴ��еľ���λ��
	CWaveBuffer *start_wavebuf=(CWaveBuffer *) m_listOfBuffer.GetAt(temp_pos);
	DWORD temp_thisbuffer=start_wavebuf->GetNumSamples()-(start_desDwSamples-temp_desStartSamples);


	DWORD temp_startDesSamples=start_wavebuf->GetNumSamples()-temp_thisbuffer;


	//��ô���ڵ�ǰpos���ڴ��У�temp_startDesSamples��Ϊ��ʼ��������
	//�Ӵ˴������㿪ʼ������һ�����ȵ��ڴ�
	//�೤��
	//2�����
	//1����Ҫ�������ڴ�ȸ�pos��Ԫ��ʣ�µ��ڴ泤����ʱ���� ��pos�ڴ�ĳ���-��ʼλ�õ��ڴ泤��
	//2����Ҫ�������ڴ�ȸ�pos��Ԫ��ʣ�µ��ڴ�̣���ʱ���� Դbuf���ڴ泤��

	DWORD dwSourceBufferLength=0;	//��¼�Ѿ������˶���
//	DWORD dwDesBufferLength=temp_startDesSamples;		//��¼��ǰpos�ڴ�ĳ���λ��

	//�������ĵ�ʱ�̵����ˣ���һ�ο�����

	temp_thisbuffer=temp_thisbuffer*start_wavebuf->GetSampleSize();
	temp_startDesSamples=temp_startDesSamples*start_wavebuf->GetSampleSize();
	//1��
	if(dwBufferLength > temp_thisbuffer)
	{
		CopyMemory((BYTE*)start_wavebuf->GetBuffer()+temp_startDesSamples,
			pBuf,temp_thisbuffer);

		dwSourceBufferLength=temp_thisbuffer;
	}
	else	//2��
	{
		CopyMemory((BYTE*)start_wavebuf->GetBuffer()+temp_startDesSamples,
			pBuf,dwBufferLength);

		dwSourceBufferLength=dwBufferLength;
	}

	//����˵�һ�ο������±߾���˳���Դbuf�����ݿ�����������Ԫ����ȥ��
	//��ʱҲ��2�����
	//1����ǰ�������Ĵ�С < Դ������ʣ�࿽���Ĵ�С����ʱ������ǰ��������С������
	//2����ǰ�������Ĵ�С �� Դ������ʣ��Ĵ�С����ʱ����ʣ��Ĵ�С����ֹͣ����

	while(pos != NULL)
	{
		temp_pos=pos;
		
		CWaveBuffer *pWaveBuf=(CWaveBuffer *) m_listOfBuffer.GetNext(pos);

		DWORD dwShengyuBufferLength=dwBufferLength-dwSourceBufferLength;

		if(dwShengyuBufferLength <= 0)
		{
			m_dwLastBufferStart=0;
			break;
		}

		DWORD nowBufferLength=pWaveBuf->GetNumSamples()*pWaveBuf->GetSampleSize();

		//1��
		if(dwShengyuBufferLength > nowBufferLength)
		{
			CopyMemory(pWaveBuf->GetBuffer(),
				pBuf+dwSourceBufferLength,
				nowBufferLength);

			dwSourceBufferLength=dwSourceBufferLength+nowBufferLength;
			
		}
		else
		{
			CopyMemory(pWaveBuf->GetBuffer(),
				pBuf+dwSourceBufferLength,
				dwShengyuBufferLength);

			dwSourceBufferLength=dwSourceBufferLength+dwShengyuBufferLength;

			m_dwLastBufferStart=dwShengyuBufferLength;

			break;
		}

	}

	//��¼���ο���������λ��
	m_dwLastBufferPos =  start_desDwSamples * start_wavebuf->GetSampleSize() + dwSourceBufferLength;
	m_posLastEnd=temp_pos;

	if(pBuf != NULL)
		delete pBuf;
}

BOOL CWaveIn::GetPositionBySamples(POSITION posBegain,DWORD dwSampleStart,POSITION & posStart,DWORD & dwBufStart)
{	
	DWORD temp_desStartSamples=0;
	POSITION pos=GetHeadPosition();
	POSITION temp_pos=pos;
	while(pos != NULL)
	{
		CWaveBuffer * pBuffer= (CWaveBuffer *) m_listOfBuffer.GetNext(pos);
		
		DWORD dwBuffSamples=pBuffer->GetNumSamples();

		if(temp_desStartSamples + dwBuffSamples > dwSampleStart)
		{
			posStart=temp_pos;

			pBuffer=(CWaveBuffer *)m_listOfBuffer.GetAt(temp_pos);
			dwBufStart=(dwSampleStart - temp_desStartSamples)*pBuffer->GetSampleSize();

			return TRUE;

			//��ʱ��POSӦ����Ŀ���������ڵ�buf��pos
		}
		else
		{
			temp_desStartSamples=temp_desStartSamples+dwBuffSamples;
			//���浱ǰλ��
			temp_pos=pos;
		}
	}

	return FALSE;
}

void CWaveIn::ZeroEndData()
{
	if(m_posLastEnd == NULL)
		return;

	POSITION pos=m_posLastEnd;
	DWORD nBegain=m_dwLastBufferStart;

	while(pos != NULL)
	{
		CWaveBuffer * pBuf=(CWaveBuffer *)m_listOfBuffer.GetNext(pos);

		memset((BYTE *)pBuf->GetBuffer()+nBegain,128,pBuf->GetNumSamples() * pBuf->GetSampleSize()-nBegain);
		nBegain=0;
	}
}
