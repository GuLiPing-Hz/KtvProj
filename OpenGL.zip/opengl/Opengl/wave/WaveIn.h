// WaveIn.h: interface for the CWaveIn class.
//

#if !defined(AFX_WAVEIN_H__2473839B_76B0_45EB_9F9A_386D27903BB1__INCLUDED_)
#define AFX_WAVEIN_H__2473839B_76B0_45EB_9F9A_386D27903BB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////////
#include "Wave.h"
#include "WaveDevice.h"

//////////////////////////////////////////////////////////////////////
void CALLBACK waveInProc(HWAVEIN hwi, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);

//////////////////////////////////////////////////////////////////////
#ifdef WAVE_IN_BUFFER_SIZE
#undef WAVE_IN_BUFFER_SIZE
#endif

#ifdef _SMALL_WAVE_IN_BUFFER_SIZE
	#define WAVEIN_BUFFER_SIZE 512
#else
	#define WAVEIN_BUFFER_SIZE 4096
#endif

#define NUMWAVEINHDR 2

//////////////////////////////////////////////////////////////////////
class CWaveIn  
{
	friend void CALLBACK waveInProc(HWAVEIN hwi, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);
public:

	POSITION m_posLastEnd;
	DWORD m_dwLastBufferStart;

	void ZeroEndData();
	BOOL GetPositionBySamples(POSITION posBegain,DWORD dwSampleStart,POSITION & posStart,DWORD & dwBufStart);

	DWORD m_dwLastBufferPos;
	void MoveBufferByNumSamples(const POSITION start_pos,
		const DWORD start_dwPosInWaveBuffer,
		const DWORD num_samples,
		const DWORD start_desDwSamples);

	POSITION GetHeadPosition();
	//zyg [2005-02-17] //////////////////////////////////////
	POSITION GetTailPosition();
	DWORD GetPrePosition(POSITION &pos);
	DWORD GetNextPosition(POSITION &pos);
	//zyg [2005-02-17] //////////////////////////////////////
	
	void GetBufferByNumSamples(const POSITION start_pos, 
		const DWORD start_dwPosInWaveBuffer,
		const DWORD num_samples,
		void*& pBuffer,
		DWORD& dwBufferLength,
		POSITION& end_pos,
		DWORD& end_dwPosInWaveBuffer);
	
	void GetRestBuffer(const POSITION start_pos, 
		const DWORD start_dwPosInWaveBuffer,
		void*& pBuffer,
		DWORD& dwBufferLength,
		DWORD& dwRestNumSamples);
	
	CString GetError() const;
	DWORD GetPosition();
	bool IsRecording();
	CWave MakeWave();

	//addedy by forrest
	DWORD GetCurrentTime();

	bool Close();
	bool Continue();
	bool Open();
	bool Pause();
	bool Record(UINT nTaille = WAVEIN_BUFFER_SIZE);
	bool Stop();

	void SetDevice(const CWaveDevice& aDevice);
	void SetWaveFormat(WAVEFORMATEX tagFormat);

	CWaveIn();
	CWaveIn(WAVEFORMATEX tagFormat, const CWaveDevice& aDevice);
	virtual	~CWaveIn();
private:
	bool AddNewBuffer(WAVEHDR* pWaveHdr);
	bool AddNewHeader(HWAVEIN hwi);
	void FreeListOfBuffer();
	DWORD GetNumSamples();
	void FreeListOfHeader();
	void InitListOfHeader();
	bool IsError(MMRESULT nResult);
	bool ResetRequired(CWaveIn* pWaveIn);
private:

	

	bool m_bResetRequired;
	HWAVEIN	m_hWaveIn;
	CPtrList m_listOfBuffer;
	UINT m_nError;
	int	m_nIndexWaveHdr;
	UINT m_nBufferSize;
	WAVEHDR	m_tagWaveHdr[NUMWAVEINHDR];
	CWave m_wave;
	CWaveDevice m_waveDevice;
};

#endif // !defined(AFX_WAVEIN_H__2473839B_76B0_45EB_9F9A_386D27903BB1__INCLUDED_)
