// WaveBuffer.cpp: implementation of the CWaveBuffer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WaveBuffer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
CWaveBuffer::CWaveBuffer() : m_dwNum(0), m_pBuffer(NULL), m_nSampleSize(0)
{
}

//////////////////////////////////////////////////////////////////////
CWaveBuffer::~CWaveBuffer()
{
	m_dwNum = 0L;
	delete[] m_pBuffer;
	m_pBuffer = NULL;
}

//////////////////////////////////////////////////////////////////////
void* CWaveBuffer::GetBuffer() const
{
	return m_pBuffer;
}

//////////////////////////////////////////////////////////////////////
DWORD CWaveBuffer::GetNumSamples() const
{
	return m_dwNum;
}

//////////////////////////////////////////////////////////////////////
void CWaveBuffer::CopyBuffer(void* pBuffer, DWORD dwNumSamples, int nSize)
{
	ASSERT(dwNumSamples >= 0);
	ASSERT(nSize);

	//m_pBuffer��û��ֵ�������
	if (!m_pBuffer)
		SetNumSamples(dwNumSamples, nSize);

	//��pBuffer��m_pBuffer�̣���m_pBuffer�ж�������� 0 ����
	if (__min(m_dwNum, dwNumSamples) * nSize > 0) {
		ZeroMemory(m_pBuffer, m_dwNum * m_nSampleSize);
		CopyMemory(m_pBuffer, pBuffer, __min(m_dwNum, dwNumSamples) * nSize);
	}
}

void CWaveBuffer::AddBuffer(void* pBuffer, DWORD dwNumSamples, int nSize /* = sizeof */)
{
	ASSERT(dwNumSamples >= 0);
	ASSERT(nSize);
	//m_pBuffer��û��ֵ�������
	if (!m_pBuffer)
	{
		CopyBuffer(pBuffer, dwNumSamples, nSize);
		return;
	}

	//����һ���µĳ�������
	//nSize��m_nSampleSize�������
	void* pNewBuffer = NULL;
	pNewBuffer = new char[nSize * (m_dwNum + dwNumSamples)];
	
	if ( dwNumSamples * nSize > 0 )
	{
		CopyMemory(pNewBuffer, m_pBuffer, m_dwNum * m_nSampleSize);
		CopyMemory((char *)pNewBuffer + m_dwNum * m_nSampleSize, pBuffer, dwNumSamples * nSize);
	}
	
	SetBuffer(pNewBuffer, (m_dwNum+dwNumSamples), m_nSampleSize);
}

//////////////////////////////////////////////////////////////////////
void CWaveBuffer::SetNumSamples(DWORD dwNumSamples, int nSize)
{
	ASSERT(dwNumSamples >= 0);
	ASSERT(nSize > 0);

	void* pBuffer = NULL;

	//sunshuai�޸ģ�06-1-22
	if(dwNumSamples > 0)
	{
		pBuffer = new char[nSize * dwNumSamples];
	}
	
	SetBuffer(pBuffer, dwNumSamples, nSize);
}

//////////////////////////////////////////////////////////////////////
void CWaveBuffer::SetBuffer(void *pBuffer, DWORD dwNumSamples, int nSize)
{
	ASSERT(dwNumSamples >= 0);
	ASSERT(nSize);

	//sunshuai�޸ģ�06-1-22
	if(m_pBuffer != NULL)
		delete[] m_pBuffer;

	m_pBuffer = pBuffer;
	m_dwNum = dwNumSamples;
	m_nSampleSize = nSize;
}

//////////////////////////////////////////////////////////////////////
int CWaveBuffer::GetSampleSize() const
{
	return m_nSampleSize;
}

void CWaveBuffer::ClipToNumSamples(DWORD dwNumSamples)
{
	m_dwNum = dwNumSamples;
}

