// WaveDevice.cpp: implementation of the CWaveDevice class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WaveDevice.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
CWaveDevice::CWaveDevice(UINT nDevice/* = WAVE_MAPPER*/) : m_nDevice(nDevice)
{
}

//////////////////////////////////////////////////////////////////////
CWaveDevice::CWaveDevice(const CWaveDevice &copy)
{
	m_nDevice = copy.GetDevice();
}

//////////////////////////////////////////////////////////////////////
CWaveDevice::~CWaveDevice()
{
}

//////////////////////////////////////////////////////////////////////
bool CWaveDevice::IsInputFormat(const CWave& wave)
{
	return (waveInOpen(
		NULL,
		GetDevice(),
		&wave.GetFormat(),
		NULL,
		NULL,
		WAVE_FORMAT_QUERY) == MMSYSERR_NOERROR);
}

//////////////////////////////////////////////////////////////////////
bool CWaveDevice::IsOutputFormat(const CWave& wave)
{
	return (waveOutOpen(
		NULL,
		GetDevice(),
		&wave.GetFormat(),
		NULL,
		NULL,
		WAVE_FORMAT_QUERY) == MMSYSERR_NOERROR);
}

//////////////////////////////////////////////////////////////////////
//inline UINT CWaveDevice::GetDevice() const
UINT CWaveDevice::GetDevice() const
{
	return m_nDevice;
}
