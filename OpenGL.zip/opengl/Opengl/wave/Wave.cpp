// Wave.cpp: implementation of the CWave class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Wave.h"
#include <fstream>
#include <vector>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
 
IMPLEMENT_SERIAL(CWave, CObject, 1)

//////////////////////////////////////////////////////////////////////
CWave::CWave()
{
	ZeroMemory((void*)&m_pcmWaveFormat, sizeof(m_pcmWaveFormat));
	m_pcmWaveFormat.wFormatTag = 1;
}

//////////////////////////////////////////////////////////////////////
CWave::CWave(const CWave &copy)
{
	m_pcmWaveFormat = copy.GetFormat();
	m_buffer.SetNumSamples( copy.GetNumSamples(), copy.GetFormat().nBlockAlign ) ;
	m_buffer.CopyBuffer( copy.GetBuffer(), copy.GetNumSamples(), copy.GetFormat().nBlockAlign );
}

//////////////////////////////////////////////////////////////////////
CWave& CWave::operator =(const CWave& wave)
{
	if (&wave != this) {
		m_pcmWaveFormat = wave.GetFormat();
		m_buffer.SetNumSamples( wave.GetNumSamples(), wave.GetFormat().nBlockAlign );
		m_buffer.CopyBuffer( wave.GetBuffer(), wave.GetNumSamples(), wave.GetFormat().nBlockAlign );
	}
	return *this;
}

//////////////////////////////////////////////////////////////////////
CWave::~CWave()
{
}

void CWave::LoadFormatFromFile(const string& fname)
{
	WORD nChannels;
	DWORD nFrequency;
	WORD nBits;
	ifstream ifile;
	ifile >> nChannels >> nFrequency >> nBits;

	BuildFormat(nChannels, nFrequency, nBits);
}

//////////////////////////////////////////////////////////////////////
void CWave::BuildFormat(WORD nChannels, DWORD nFrequency, WORD nBits)
{
	m_pcmWaveFormat.wFormatTag = WAVE_FORMAT_PCM;
	m_pcmWaveFormat.nChannels = nChannels;
	m_pcmWaveFormat.nSamplesPerSec = nFrequency;
	m_pcmWaveFormat.nAvgBytesPerSec = nFrequency * nChannels * nBits / 8;
	m_pcmWaveFormat.nBlockAlign = nChannels * nBits / 8;
	m_pcmWaveFormat.wBitsPerSample = nBits;
	m_buffer.SetNumSamples(0L, m_pcmWaveFormat.nBlockAlign);
}	

//////////////////////////////////////////////////////////////////////
//inline WAVEFORMATEX CWave::GetFormat() const
WAVEFORMATEX CWave::GetFormat() const
{
	return m_pcmWaveFormat;
}

//////////////////////////////////////////////////////////////////////
/*
void CWave::Serialize( CArchive& archive )
{
	CFile* f = archive.GetFile();
	if (archive.IsLoading())
		Load(f);
	else
		Save(f);
}
*/
//////////////////////////////////////////////////////////////////////
void CWave::Load(const CString &strFile)
{
	CFile f(strFile, CFile::modeRead);
	Load(&f);
	f.Close();
}

//////////////////////////////////////////////////////////////////////
void CWave::Load(CFile *f)
{
	char szTmp[10];
	WAVEFORMATEX pcmWaveFormat;
	ZeroMemory(szTmp, 10 * sizeof(char));
	f->Read(szTmp, 4 * sizeof(char)) ;
	if (strncmp(szTmp, _T("RIFF"), 4) != 0) 
		::AfxThrowFileException(CFileException::invalidFile, -1, f->GetFileName());
	DWORD dwFileSize/* = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36*/ ;
	f->Read(&dwFileSize, sizeof(dwFileSize)) ;
	ZeroMemory(szTmp, 10 * sizeof(char));
	f->Read(szTmp, 8 * sizeof(char)) ;
	if (strncmp(szTmp, _T("WAVEfmt "), 8) != 0) 
		::AfxThrowFileException(CFileException::invalidFile, -1, f->GetFileName());
	DWORD dwFmtSize; //= 16L, ��һ����16!
	f->Read(&dwFmtSize, sizeof(dwFmtSize)) ;
	f->Read(&pcmWaveFormat.wFormatTag, sizeof(pcmWaveFormat.wFormatTag)) ;
	f->Read(&pcmWaveFormat.nChannels, sizeof(pcmWaveFormat.nChannels)) ;
	f->Read(&pcmWaveFormat.nSamplesPerSec, sizeof(pcmWaveFormat.nSamplesPerSec)) ;
	f->Read(&pcmWaveFormat.nAvgBytesPerSec, sizeof(pcmWaveFormat.nAvgBytesPerSec)) ;
	f->Read(&pcmWaveFormat.nBlockAlign, sizeof(pcmWaveFormat.nBlockAlign)) ;
	f->Read(&pcmWaveFormat.wBitsPerSample, sizeof(pcmWaveFormat.wBitsPerSample)) ;

	//�ļ��ж���Ŀ�������
	pcmWaveFormat.nAvgBytesPerSec = pcmWaveFormat.nSamplesPerSec 
				* pcmWaveFormat.nChannels * pcmWaveFormat.wBitsPerSample / 8;
	pcmWaveFormat.nBlockAlign = pcmWaveFormat.nChannels 
				* pcmWaveFormat.wBitsPerSample / 8;

	//����format chunk�еĿ���ʣ�ಿ��
	//ǰ���Ѿ����˵�format�е��ֽ����� 16
	int bytes_need_to_jump;
	bytes_need_to_jump = dwFmtSize - 16;
	if ( bytes_need_to_jump != 0)
	{
		BYTE temp;
		for (int i = 0; i < bytes_need_to_jump; i++)
			f->Read(&temp, sizeof(BYTE));
	}
	
	//������data��chunk
	char idTemp[5];//,
	memset(idTemp,0,5);
	f->Read(idTemp, 4 * sizeof(BYTE));
	while ( strncmp(idTemp, "data", 4) != 0 )
	{
		DWORD chunk_size;
		f->Read(&chunk_size, sizeof(DWORD));
		BYTE temp;
		for (int i = 0; i < (int)chunk_size; i++)
			f->Read(&temp, sizeof(BYTE));
		
		f->Read(idTemp, 4 * sizeof(BYTE));
	}
				
	strncpy(szTmp, idTemp, 4);
	if (strncmp(szTmp, _T("data"), 4) != 0) 
		::AfxThrowFileException(CFileException::invalidFile, -1, f->GetFileName());
	m_pcmWaveFormat = pcmWaveFormat;
	DWORD dwNum;
	f->Read(&dwNum, sizeof(dwNum)) ;
	m_buffer.SetNumSamples(dwNum / pcmWaveFormat.nBlockAlign, pcmWaveFormat.nBlockAlign);
	f->Read(m_buffer.GetBuffer(), dwNum ) ;
}

void CWave::LoadSegment(const CString& strFile, const double secLen)
{
	CFile f(strFile, CFile::modeRead);
	LoadSegment(&f, secLen);
	f.Close();
}
void CWave::LoadSegment(CFile* f, const double secLen)
{
	char szTmp[10];
	WAVEFORMATEX pcmWaveFormat;
	ZeroMemory(szTmp, 10 * sizeof(char));
	f->Read(szTmp, 4 * sizeof(char)) ;
	if (strncmp(szTmp, _T("RIFF"), 4) != 0) 
		::AfxThrowFileException(CFileException::invalidFile, -1, f->GetFileName());
	DWORD dwFileSize/* = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36*/ ;
	f->Read(&dwFileSize, sizeof(dwFileSize)) ;
	ZeroMemory(szTmp, 10 * sizeof(char));
	f->Read(szTmp, 8 * sizeof(char)) ;
	if (strncmp(szTmp, _T("WAVEfmt "), 8) != 0) 
		::AfxThrowFileException(CFileException::invalidFile, -1, f->GetFileName());
	DWORD dwFmtSize; //= 16L, ��һ����16!
	f->Read(&dwFmtSize, sizeof(dwFmtSize)) ;
	f->Read(&pcmWaveFormat.wFormatTag, sizeof(pcmWaveFormat.wFormatTag)) ;
	f->Read(&pcmWaveFormat.nChannels, sizeof(pcmWaveFormat.nChannels)) ;
	f->Read(&pcmWaveFormat.nSamplesPerSec, sizeof(pcmWaveFormat.nSamplesPerSec)) ;
	f->Read(&pcmWaveFormat.nAvgBytesPerSec, sizeof(pcmWaveFormat.nAvgBytesPerSec)) ;
	f->Read(&pcmWaveFormat.nBlockAlign, sizeof(pcmWaveFormat.nBlockAlign)) ;
	f->Read(&pcmWaveFormat.wBitsPerSample, sizeof(pcmWaveFormat.wBitsPerSample)) ;
	
	//�ļ��ж���Ŀ�������
	pcmWaveFormat.nAvgBytesPerSec = pcmWaveFormat.nSamplesPerSec 
		* pcmWaveFormat.nChannels * pcmWaveFormat.wBitsPerSample / 8;
	pcmWaveFormat.nBlockAlign = pcmWaveFormat.nChannels 
		* pcmWaveFormat.wBitsPerSample / 8;
	
	//����format chunk�еĿ���ʣ�ಿ��
	//ǰ���Ѿ����˵�format�е��ֽ����� 16
	int bytes_need_to_jump;
	bytes_need_to_jump = dwFmtSize - 16;
	if ( bytes_need_to_jump != 0)
	{
		BYTE temp;
		for (int i = 0; i < bytes_need_to_jump; i++)
			f->Read(&temp, sizeof(BYTE));
	}
	
	//������data��chunk
	char idTemp[4];
	f->Read(idTemp, 4 * sizeof(BYTE));
	while ( strncmp(idTemp, "data", 4) != 0 )
	{
		DWORD chunk_size;
		f->Read(&chunk_size, sizeof(DWORD));
		BYTE temp;
		for (int i = 0; i < (int)chunk_size; i++)
			f->Read(&temp, sizeof(BYTE));
		
		f->Read(idTemp, 4 * sizeof(BYTE));
	}
				
	strncpy(szTmp, idTemp, 4);
	if (strncmp(szTmp, _T("data"), 4) != 0) 
		::AfxThrowFileException(CFileException::invalidFile, -1, f->GetFileName());
	m_pcmWaveFormat = pcmWaveFormat;

	//���������ʱ��secLen(��),������Ҫ����ĳ���
	DWORD dwNum;
	dwNum = (DWORD)( pcmWaveFormat.nSamplesPerSec * secLen * pcmWaveFormat.nBlockAlign );
	m_buffer.SetNumSamples(dwNum / pcmWaveFormat.nBlockAlign, pcmWaveFormat.nBlockAlign);
	f->Read(m_buffer.GetBuffer(), dwNum ) ;
}
//////////////////////////////////////////////////////////////////////
void CWave::Save(const CString &strFile)
{
	CFile f(strFile, CFile::modeCreate | CFile::modeWrite);
	Save(&f);
	f.Close();
}

//////////////////////////////////////////////////////////////////////
void CWave::Save(CFile *f)
{
	if ( m_buffer.GetNumSamples() > 0 )
	{
		f->Write("RIFF", 4) ;
		DWORD dwFileSize = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36 ;
		f->Write(&dwFileSize, sizeof(dwFileSize)) ;
		f->Write("WAVEfmt ", 8) ;
		DWORD dwFmtSize = 16L;
		f->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
		f->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
		f->Write(&m_pcmWaveFormat.nChannels, sizeof(m_pcmWaveFormat.nChannels)) ;
		f->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
		f->Write(&m_pcmWaveFormat.nAvgBytesPerSec, sizeof(m_pcmWaveFormat.nAvgBytesPerSec)) ;
		f->Write(&m_pcmWaveFormat.nBlockAlign, sizeof(m_pcmWaveFormat.nBlockAlign)) ;
		f->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
		f->Write("data", 4) ;
		DWORD dwNum = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
		f->Write(&dwNum, sizeof(dwNum));
		f->Write(m_buffer.GetBuffer(), dwNum);
	}
}

void CWave::SaveLeft(const CString &strFile)
{
	CFile f(strFile, CFile::modeCreate | CFile::modeWrite);
	SaveLeft(&f);
	f.Close();
}

//////////////////////////////////////////////////////////////////////
void CWave::SaveLeft(CFile *f)
{
	ASSERT( m_buffer.GetNumSamples() > 0 );
	
	WORD nChannels, nBlockAlign;
	DWORD nAvgBytesPerSec;
	nChannels = 1; //������
	nBlockAlign = nChannels * m_pcmWaveFormat.wBitsPerSample / 8;
	nAvgBytesPerSec = nBlockAlign * m_pcmWaveFormat.nSamplesPerSec;

	f->Write("RIFF", 4) ;
	DWORD dwFileSize = m_buffer.GetNumSamples() * nBlockAlign + 36 ;
	f->Write(&dwFileSize, sizeof(dwFileSize)) ;
	f->Write("WAVEfmt ", 8) ;
	DWORD dwFmtSize = 16L;
	f->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
	f->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
	f->Write(&nChannels, sizeof(nChannels)); //������
	f->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
	f->Write(&nAvgBytesPerSec, sizeof(nAvgBytesPerSec)) ;
	f->Write(&nBlockAlign, sizeof(nBlockAlign)) ; //���ݿ鳤��
	f->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
	f->Write("data", 4);
	DWORD dwLength = m_buffer.GetNumSamples() * nBlockAlign;
	f->Write(&dwLength, sizeof(dwLength));
	//һ���ֽ�һ���ֽڵĶ��룬�ٱ���
	BYTE* pBuffer;
	pBuffer = (BYTE *)m_buffer.GetBuffer();

	//����8λ��16λ�����
	DWORD dwOrigLength = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
	if (m_pcmWaveFormat.wBitsPerSample == 8)
	{
		int i = 0; //����������
		vector<BYTE> vBuffer;
		while( i < (int)dwOrigLength )
		{
			//f->Write(pBuffer+i, 1);//Ч�ʼ��͵�����
			vBuffer.push_back( (BYTE) *(BYTE *)(pBuffer + i) );
			i += 2;
		}

//VC6.0����C++��׼��֮ǰ�����ģ�����C++��׼�﷨֧����ȱ��
//����˺꣬��Ӧ��ʹ��VC6.0�������Ĺ���
//ʹ�÷���������Ӧ���̵�Stdafx.h�ļ��м��� #define _RS_VC60�����ɱ���ͨ��
#ifdef _RS_VC60
		f->Write((BYTE *)vBuffer.begin(), vBuffer.size() );
#else
		f->Write((BYTE *)vBuffer.begin().operator ->(), vBuffer.size() );
#endif
		
	}
	else if (m_pcmWaveFormat.wBitsPerSample == 16)
	{
		int i = 0; //����������
		vector<__int16> vBuffer;
		while( i < (int)dwOrigLength )
		{
			//f->Write(pBuffer+i, 2); //Ч�ʼ��͵�����
			vBuffer.push_back( (__int16) *(WORD *)(pBuffer + i));
			i += 4;
		}
#ifdef _RS_VC60
		f->Write( (WORD *)vBuffer.begin(), vBuffer.size() * sizeof(WORD));
#else 
		f->Write( (WORD *)vBuffer.begin().operator ->(), vBuffer.size() * sizeof(WORD));
#endif
	}
}

void CWave::SaveMean(const CString &strFile)
{
	CFile f(strFile, CFile::modeCreate | CFile::modeWrite);
	SaveMean(&f);
	f.Close();
}

//////////////////////////////////////////////////////////////////////
void CWave::SaveMean(CFile *f)
{
	ASSERT( m_buffer.GetNumSamples() > 0 );
	
	WORD nChannels, nBlockAlign;
	DWORD nAvgBytesPerSec;
	nChannels = 1; //������
	nBlockAlign = nChannels * m_pcmWaveFormat.wBitsPerSample / 8;
	nAvgBytesPerSec = nBlockAlign * m_pcmWaveFormat.nSamplesPerSec;
	
	f->Write("RIFF", 4) ;
	DWORD dwFileSize = m_buffer.GetNumSamples() * nBlockAlign + 36 ;
	f->Write(&dwFileSize, sizeof(dwFileSize)) ;
	f->Write("WAVEfmt ", 8) ;
	DWORD dwFmtSize = 16L;
	f->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
	f->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
	f->Write(&nChannels, sizeof(nChannels)); //������
	f->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
	f->Write(&nAvgBytesPerSec, sizeof(nAvgBytesPerSec)) ;
	f->Write(&nBlockAlign, sizeof(nBlockAlign)) ; //���ݿ鳤��
	f->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
	f->Write("data", 4);
	DWORD dwLength = m_buffer.GetNumSamples() * nBlockAlign;
	f->Write(&dwLength, sizeof(dwLength));
	//һ���ֽ�һ���ֽڵĶ��룬�ٱ���
	BYTE* pBuffer;
	pBuffer = (BYTE *)m_buffer.GetBuffer();
	
	//����8λ��16λ�����
	DWORD dwOrigLength = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
	if (m_pcmWaveFormat.wBitsPerSample == 8)
	{
		int i = 0; 
		vector<BYTE> vBuffer;
		while( i < (int)dwOrigLength )
		{
			BYTE lvalue, rvalue, mean;
			lvalue = *(pBuffer + i);
			rvalue = *(pBuffer + i + 1);
			mean = (float)(lvalue + rvalue) * 0.5;
			//f->Write(&mean, sizeof(mean));
			vBuffer.push_back(mean);
			i += 2;
		}

#ifdef _RS_VC60
		f->Write((BYTE *)vBuffer.begin(), vBuffer.size() );
#else
		f->Write((BYTE *)vBuffer.begin().operator ->(), vBuffer.size() );
#endif
	}
	else if (m_pcmWaveFormat.wBitsPerSample == 16)
	{
		int i = 0; 
		vector<__int16> vBuffer;
		while( i < (int)dwOrigLength )
		{
			WORD *p16;
			__int16 lvalue, rvalue, mean; 
			//���������__int16,������WORD,��Ϊ16λ��wav data���з��ŵ�
			
			p16 = (WORD *)(pBuffer + i);
			lvalue = *p16;
			p16 = (WORD *)(pBuffer + i + 2);
			rvalue = *p16;
			mean = (float)(lvalue + rvalue) * 0.5;
			//f->Write(&mean, sizeof(mean));
			vBuffer.push_back(mean);
			i += 4;
		}

	#ifdef _RS_VC60
		f->Write( (WORD *)vBuffer.begin(), vBuffer.size() * sizeof(WORD));
	#else 
		f->Write( (WORD *)vBuffer.begin().operator ->(), vBuffer.size() * sizeof(WORD));
	#endif
		
	}
}

void CWave::SaveRight(const CString &strFile)
{
	CFile f(strFile, CFile::modeCreate | CFile::modeWrite);
	SaveRight(&f);
	f.Close();
}

//////////////////////////////////////////////////////////////////////
void CWave::SaveRight(CFile *f)
{
	ASSERT( m_buffer.GetNumSamples() > 0 );
	
	WORD nChannels, nBlockAlign;
	DWORD nAvgBytesPerSec;
	nChannels = 1; //������
	nBlockAlign = nChannels * m_pcmWaveFormat.wBitsPerSample / 8;
	nAvgBytesPerSec = nBlockAlign * m_pcmWaveFormat.nSamplesPerSec;
	
	f->Write("RIFF", 4) ;
	DWORD dwFileSize = m_buffer.GetNumSamples() * nBlockAlign + 36 ;
	f->Write(&dwFileSize, sizeof(dwFileSize)) ;
	f->Write("WAVEfmt ", 8) ;
	DWORD dwFmtSize = 16L;
	f->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
	f->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
	f->Write(&nChannels, sizeof(nChannels)); //������
	f->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
	f->Write(&nAvgBytesPerSec, sizeof(nAvgBytesPerSec)) ;
	f->Write(&nBlockAlign, sizeof(nBlockAlign)) ; //���ݿ鳤��
	f->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
	f->Write("data", 4);
	DWORD dwLength = m_buffer.GetNumSamples() * nBlockAlign;
	f->Write(&dwLength, sizeof(dwLength));
	//һ���ֽ�һ���ֽڵĶ��룬�ٱ���
	BYTE* pBuffer;
	pBuffer = (BYTE *)m_buffer.GetBuffer();
	
	//����8λ��16λ�����
	DWORD dwOrigLength = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
	if (m_pcmWaveFormat.wBitsPerSample == 8)
	{
		int i = 1; //������������
		vector<BYTE> vBuffer;
		while( i < (int)dwOrigLength )
		{
			//f->Write(pBuffer+i, 1);
			vBuffer.push_back( (BYTE) *(BYTE *)(pBuffer + i) );
			i += 2;
		}

#ifdef _RS_VC60
		f->Write((BYTE *)vBuffer.begin(), vBuffer.size() );
#else
		f->Write((BYTE *)vBuffer.begin().operator ->(), vBuffer.size() );
#endif
	}
	else if (m_pcmWaveFormat.wBitsPerSample == 16)
	{
		int i = 2; //������������
		vector<__int16> vBuffer;
		while( i < (int)dwOrigLength )
		{
			//f->Write(pBuffer+i, 2);
			vBuffer.push_back( (__int16) *(WORD *)(pBuffer + i));
			i += 4;
		}
#ifdef _RS_VC60
		f->Write( (WORD *)vBuffer.begin(), vBuffer.size() * sizeof(WORD));
#else 
		f->Write( (WORD *)vBuffer.begin().operator ->(), vBuffer.size() * sizeof(WORD));
#endif
	}
}

void CWave::SaveLeftRight(const CString &strLeft, const CString& strRight)
{
	CFile fl(strLeft, CFile::modeCreate | CFile::modeWrite);
	CFile fr(strRight, CFile::modeCreate | CFile::modeWrite);
	SaveLeftRight(&fl, &fr);
	fl.Close();
	fr.Close();
}

//////////////////////////////////////////////////////////////////////
void CWave::SaveLeftRight(CFile *fl, CFile *fr)
{
	ASSERT( m_buffer.GetNumSamples() > 0 );
	
	WORD nChannels, nBlockAlign;
	DWORD nAvgBytesPerSec;
	nChannels = 1; //������
	nBlockAlign = nChannels * m_pcmWaveFormat.wBitsPerSample / 8;
	nAvgBytesPerSec = nBlockAlign * m_pcmWaveFormat.nSamplesPerSec;
	
	fl->Write("RIFF", 4) ;
	DWORD dwFileSize = m_buffer.GetNumSamples() * nBlockAlign + 36 ;
	fl->Write(&dwFileSize, sizeof(dwFileSize)) ;
	fl->Write("WAVEfmt ", 8) ;
	DWORD dwFmtSize = 16L;
	fl->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
	fl->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
	fl->Write(&nChannels, sizeof(nChannels)); //������
	fl->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
	fl->Write(&nAvgBytesPerSec, sizeof(nAvgBytesPerSec)) ;
	fl->Write(&nBlockAlign, sizeof(nBlockAlign)) ; //���ݿ鳤��
	fl->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
	fl->Write("data", 4);
	DWORD dwLength = m_buffer.GetNumSamples() * nBlockAlign;
	fl->Write(&dwLength, sizeof(dwLength));

	fr->Write("RIFF", 4) ;
	dwFileSize = m_buffer.GetNumSamples() * nBlockAlign + 36 ;
	fr->Write(&dwFileSize, sizeof(dwFileSize)) ;
	fr->Write("WAVEfmt ", 8) ;
	dwFmtSize = 16L;
	fr->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
	fr->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
	fr->Write(&nChannels, sizeof(nChannels)); //������
	fr->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
	fr->Write(&nAvgBytesPerSec, sizeof(nAvgBytesPerSec)) ;
	fr->Write(&nBlockAlign, sizeof(nBlockAlign)) ; //���ݿ鳤��
	fr->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
	fr->Write("data", 4);
	dwLength = m_buffer.GetNumSamples() * nBlockAlign;
	fr->Write(&dwLength, sizeof(dwLength));
	
	//һ���ֽ�һ���ֽڵĶ��룬�ٱ���
	BYTE* pBuffer;
	pBuffer = (BYTE *)m_buffer.GetBuffer();
	
	//����8λ��16λ�����
	DWORD dwOrigLength = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
	if (m_pcmWaveFormat.wBitsPerSample == 8)
	{
		int i = 0; 
		vector<BYTE> vlBuffer;
		vector<BYTE> vrBuffer;
		while( i < (int)dwOrigLength )
		{
			vlBuffer.push_back( (BYTE) *(BYTE *)(pBuffer + i) );
			vrBuffer.push_back( (BYTE) *(BYTE *)(pBuffer + 1 + i) );
			i += 2;
		}


#ifdef _RS_VC60
		fl->Write((BYTE *)vlBuffer.begin(), vlBuffer.size() );
		fr->Write((BYTE *)vrBuffer.begin(), vrBuffer.size() );
#else
		fl->Write((BYTE *)vlBuffer.begin().operator ->(), vlBuffer.size() );
		fr->Write((BYTE *)vrBuffer.begin().operator ->(), vrBuffer.size() );		
#endif

	}
	else if (m_pcmWaveFormat.wBitsPerSample == 16)
	{
		int i = 0;
		vector<__int16> vlBuffer;
		vector<__int16> vrBuffer;
		while( i < (int)dwOrigLength )
		{
			//f->Write(pBuffer+i, 2); //Ч�ʼ��͵�����
			vlBuffer.push_back( (__int16) *(WORD *)(pBuffer + i));
			vrBuffer.push_back( (__int16) *(WORD *)(pBuffer + 2 + i));
			i += 4;
		}
#ifdef _RS_VC60
		fl->Write((WORD *)vlBuffer.begin(), vlBuffer.size() * sizeof(WORD));
		fr->Write((WORD *)vrBuffer.begin(), vrBuffer.size() * sizeof(WORD));
#else 
		fl->Write((WORD *)vlBuffer.begin().operator ->(), vlBuffer.size() * sizeof(WORD));
		fr->Write((WORD *)vrBuffer.begin().operator ->(), vrBuffer.size() * sizeof(WORD));
#endif

	}
}

void CWave::SaveLeftRightRevert(const CString &strFile)
{
	CFile f(strFile, CFile::modeRead);
	SaveLeftRightRevert(&f);
	f.Close();
}

void CWave::SaveLeftRightRevert(CFile *f)
{
	ASSERT( m_buffer.GetNumSamples() > 0 );

	f->Write("RIFF", 4) ;
	DWORD dwFileSize = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36 ;
	f->Write(&dwFileSize, sizeof(dwFileSize)) ;
	f->Write("WAVEfmt ", 8) ;
	DWORD dwFmtSize = 16L;
	f->Write(&dwFmtSize, sizeof(dwFmtSize)) ;
	f->Write(&m_pcmWaveFormat.wFormatTag, sizeof(m_pcmWaveFormat.wFormatTag)) ;
	f->Write(&m_pcmWaveFormat.nChannels, sizeof(m_pcmWaveFormat.nChannels)) ;
	f->Write(&m_pcmWaveFormat.nSamplesPerSec, sizeof(m_pcmWaveFormat.nSamplesPerSec)) ;
	f->Write(&m_pcmWaveFormat.nAvgBytesPerSec, sizeof(m_pcmWaveFormat.nAvgBytesPerSec)) ;
	f->Write(&m_pcmWaveFormat.nBlockAlign, sizeof(m_pcmWaveFormat.nBlockAlign)) ;
	f->Write(&m_pcmWaveFormat.wBitsPerSample, sizeof(m_pcmWaveFormat.wBitsPerSample)) ;
	f->Write("data", 4) ;
	DWORD dwNum = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
	f->Write(&dwNum, sizeof(dwNum));
	

	//һ���ֽ�һ���ֽڵĶ��룬�ٱ���
	BYTE* pBuffer;
	pBuffer = (BYTE *)m_buffer.GetBuffer();

	//����8λ��16λ�����
	DWORD dwOrigLength = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign;
	if (m_pcmWaveFormat.wBitsPerSample == 8)
	{
		int i = 0; 
		vector<BYTE> vBuffer;
		while( i < (int)dwOrigLength )
		{
			vBuffer.push_back( (BYTE) *(BYTE *)(pBuffer + 1 + i) );
			vBuffer.push_back( (BYTE) *(BYTE *)(pBuffer + i) );
			i += 2;
		}


#ifdef _RS_VC60
		f->Write((BYTE *)vBuffer.begin(), vBuffer.size() );
#else
		f->Write((BYTE *)vBuffer.begin().operator ->(), vBuffer.size() );	
#endif

	}
	else if (m_pcmWaveFormat.wBitsPerSample == 16)
	{
		int i = 0;
		vector<__int16> vBuffer;
		while( i < (int)dwOrigLength )
		{
			//f->Write(pBuffer+i, 2); //Ч�ʼ��͵�����
			vBuffer.push_back( (__int16) *(WORD *)(pBuffer + 2 + i));
			vBuffer.push_back( (__int16) *(WORD *)(pBuffer + i));
			i += 4;
		}
#ifdef _RS_VC60
		f->Write((WORD *)vBuffer.begin(), vBuffer.size() * sizeof(WORD));
#else 
		f->Write((WORD *)vBuffer.begin().operator ->(), vBuffer.size() * sizeof(WORD));
#endif

	}
}

//////////////////////////////////////////////////////////////////////
void* CWave::GetBuffer() const
{
	return m_buffer.GetBuffer();
}

//////////////////////////////////////////////////////////////////////
DWORD CWave::GetNumSamples() const
{
	return m_buffer.GetNumSamples();
}

//////////////////////////////////////////////////////////////////////
DWORD CWave::GetBufferLength() const
{
	return ( m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign );
}

//////////////////////////////////////////////////////////////////////
void CWave::SetBuffer(void* pBuffer, DWORD dwNumSample, bool bCopy)
{
	//commented by zyg
	//ASSERT(pBuffer);
	//ASSERT(dwNumSample > 0);
	//ASSERT(m_pcmWaveFormat.nBlockAlign > 0);

	if (bCopy) {
		m_buffer.CopyBuffer(pBuffer, dwNumSample, m_pcmWaveFormat.nBlockAlign);
	}
	else {
		m_buffer.SetBuffer(pBuffer, dwNumSample, m_pcmWaveFormat.nBlockAlign);
	}
}


void CWave::ClipToNumSamples(DWORD dwNumSamples)
{
	m_buffer.ClipToNumSamples(dwNumSamples);

	return;
}

void CWave::Close()
{
	SetBuffer(NULL, 0, FALSE);
}

CWave& CWave::operator+(const CWave& wave)
{
	//ȷ������wave�ĸ�ʽ��ͬ
	WAVEFORMATEX wave_format;
	wave_format = wave.GetFormat();
//	if ( m_pcmWaveFormat == wave_format )
	{
		m_buffer.AddBuffer( wave.GetBuffer(), wave.GetNumSamples(), wave.GetFormat().nBlockAlign);		
	}
	return *this;
}

void CWave::GetBufferByNumSamples(const DWORD start_num_sample, 
								  const DWORD num_samples, 
								  void*& pBuffer,
								  DWORD& dwBufferLength) const
{
	dwBufferLength = num_samples * m_pcmWaveFormat.nBlockAlign;
	pBuffer = new char[ dwBufferLength ];
	
	DWORD restNumSamples;
	restNumSamples = GetNumSamples() - start_num_sample;
	
	if ( (dwBufferLength > 0) && (num_samples <= restNumSamples) )
		CopyMemory(pBuffer, (char *)m_buffer.GetBuffer() + start_num_sample * m_pcmWaveFormat.nBlockAlign, dwBufferLength);

	return;
}

void CWave::GetRestBuffer(const DWORD start_num_sample, 
						  void*& pBuffer, 
						  DWORD& dwBufferLength,
						  DWORD& dwRestNumSamples) const
{
	dwRestNumSamples = GetNumSamples() - start_num_sample;

	dwBufferLength = dwRestNumSamples * m_pcmWaveFormat.nBlockAlign;
	pBuffer = new char[ dwBufferLength ];
	
	if ( dwBufferLength > 0 )
		CopyMemory(pBuffer, (char *)m_buffer.GetBuffer() + start_num_sample * m_pcmWaveFormat.nBlockAlign, dwBufferLength);
	
	return;
}