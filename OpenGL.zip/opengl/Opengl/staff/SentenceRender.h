//
//  SentenceRender.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012�� 9158. All rights reserved.
//
#pragma once

#include <vector>

#include "KKType.h"
#include "Image.h"
#include "Imageset.h"
/*#include "TransParams.h"*/


#include "../fto/ftotype.h"

typedef std::vector<Image*> VECTORIMAGE;
//-----------------------------------------------------------------------------
class SentenceRender
{
public:
	SentenceRender(CGSize& winsize);
	~SentenceRender();

	void showSentenceLevel(_eSentenceGradeLevel sentence_level);

	void showSentenceScore(int score);

	void update(unsigned int elapsed_tm);

	void reset();

	void populateGeometryBuffer();

	void invalidate();

private:
	_eSentenceGradeLevel			meSentenceGradeLevel;
	int											mnScore;
	bool											mbInvalidate;
	//NSMutableArray					*mNumberImages;
	VECTORIMAGE						m_NumberImages;
	//NSMutableArray                  *mGradeImages;
	VECTORIMAGE						m_GradeImages;
	int                             miCountDown;

	CGSize						m_windowsize;
};




