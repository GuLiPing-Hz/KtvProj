//
//  SceneObject.m
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//

#include "SceneObject.h"


SceneObject::SceneObject(BOOL active):m_active(active)
{
	m_meshBounds = CGRectMake(0.0f,0.0f,0,0);
}

SceneObject::~SceneObject()
{

}




