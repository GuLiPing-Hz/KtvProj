#pragma once
//  BBTexturedQuad.h
//  SpaceRocks
//
//  Created by ben smith on 14/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//
#include "KKType.h"
#include <string>

class Imageset;

class Image {
public:
    CGRect m_rect;//??
    CGPoint m_offset;
	Imageset * m_imgset;
public:
	Image();
	Image(CGRect rect,Imageset* imgset);
	~Image();

	const int & getWidth() const;
	const int & getHeight() const;

	void SetPoint(CGPoint point);
	void SetRect(CGRect rect);
	void SetImageset(Imageset* imgset);
	//��ͼ����
	void draw(const CGRect& dest_rect,CGRect* pclip_rect,const KKColorRect& color_rect);
	void draw(const CGPoint& dest_point,CGRect* pclip_rect,const KKColorRect& color_rect=COLOR_RECT_WHITE);//Ĭ�ϰ�ɫ
	void draw(const CGPoint& dest_point,const CGSize& dest_size,CGRect* pclip_rect,const KKColorRect& color_rect=COLOR_RECT_WHITE);//Ĭ�ϰ�ɫ
	//void draw(CGPoint& dest_point,CGRect* pclip_rect);
};



