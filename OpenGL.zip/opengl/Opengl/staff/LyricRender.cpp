//
//  LyricRender.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012�� 9158. All rights reserved.
//
#include "../stdafx.h"
#include "LyricRender.h"
/*#include "../FreeTypeFont/FreeTypeFont.h"*/
#include "ImgsetMgr.h"

//-----------------------------------------------------------------------------
LyricRender::~LyricRender()
{
	if (mpFreeTypeFont)
	{
		delete mpFreeTypeFont;
		mpFreeTypeFont = NULL;
	}
}

// ��ʼ��
LyricRender::LyricRender(CGSize & window_size ):m_WindowSize(window_size)
{
    mbKtvMode = true;
    mbFirstSentence = true;
    mfMovieImagePos = 0.0f;
    mfTipImageTrans = 0.0f;
    mfTextPos = 0.0f;
    mfTextLittlePos = 0.0f;
    mfTextWidth = 0.0f;
    mfNextTextWidth = 0.0f;
    mfSongNameWidth = 0.0f;
    
	if ( mbKtvMode )
	{
		mfStartPos = 0.0f;
		mfNextStartPos = 0.0f;
	}
	else
	{
		mfStartPos = SING_START_B;//170.0f / 720.0f;
	}
    
    mbInvalidate = false;
    
    mpFreeTypeFont = new FreeTypeFont();
//////////////////////////////////////////////////////////////////////////
	mMoveImage = ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"Slider");
}

void LyricRender::invalidate()
{
    mbInvalidate = true;
}

// ���ظ������
void LyricRender::loadFont(const CGSize& windowsize,const std::wstring & strLyric )
{
	//writeLog("LyricRender::loadFont enter");
	char bufLog[256] = {0};
	//sprintf(bufLog,"mpFreeTypeFont [%p]",mpFreeTypeFont);
	//writeLog(bufLog);
    mpFreeTypeFont->load( windowsize,"", strLyric );
}

//-----------------------------------------------------------------------------
// ��������ģʽ�Ƿ�ΪKTVģʽ(����ģʽ:KTVģʽ,��Ϸģʽ)
void LyricRender::setMode(bool ktv_mode)
{
	mbKtvMode = ktv_mode;
	if ( mbKtvMode )
	{
		mfStartPos = 0.0f;
		mfNextStartPos = 0.0f;
	}
	else
	{
		mfStartPos = SING_START_B;//170.0f / 720.0f;
	}
}

//-----------------------------------------------------------------------------
// ���ø�ʿ��ݳ����
void LyricRender::setFirstLyricStartPos( float start_pos )
{
	mfStartPos = start_pos;
	mfNextStartPos = 0.0f;
	invalidate();
}

//-----------------------------------------------------------------------------
// ���ø�ʿ��ݳ����
void LyricRender::setNextLyricStartPos(float start_pos)
{
	mfStartPos = 0.0f;
	mfNextStartPos = start_pos;
	invalidate();
}

//-----------------------------------------------------------------------------
/// ��������ʱ��
void LyricRender::setSongTime(const std::string & curtime)
{
	mSongPlayedTime = curtime;
	invalidate();
}

//-----------------------------------------------------------------------------
// ��������
void LyricRender::setSongName(const std::string & curname)
{
/*
	//CEGUI::Font * songInfoFnt = &CEGUI::FontManager::getSingleton().get("simhei9"); 
	CEGUI::Font * songInfoFnt = &CEGUI::FontManager::getSingleton().get("simhei10"); 
	CEGUI::String & ch = Ci::CUtility::mbc2CeguiString( curname );
	mfSongNameWidth = songInfoFnt->getTextExtent( ch );

	mSongName = curname;
	invalidate();
*/
}

//-----------------------------------------------------------------------------
// ��ʾ���(���ظ�ʳ���)std::vector< _tGuiLyricInfo >
float LyricRender::showFirstLyric( LISTGUILYRICVECT & lyric_list, bool refresh/* = false*/ )
{
	char bufLog[512] = {0};
	wchar_t wbufLog[512] = {0};
	//writeLog("LyricRender::showFirstLyric enter");
	if ( !mpFreeTypeFont )
	{
		//LOG_GAME_ERR( "Get font simhei24 error." );
		//LOG_GAME_ERR( "Get font simhei16 error." );
		return 0.0f;
	}
	//CGSize sz = window_size;//getPixelSize();
	mfTextWidth = 0;
	std::wstring ceguiStrTemp;
	float offset = 0.0f;
	//std::vector< _tGuiLyricInfo >::iterator i;
	//sprintf(bufLog,"P-lyric_list:%x",&lyric_list);
	LISTGUILYRICVECT::iterator i;
	for( i = lyric_list.begin(); i != lyric_list.end(); ++i )
	{
		_tGuiLyricInfo* &li = *i;
		//swprintf(wbufLog,L"lyric:[%s]",li->lyric.c_str());
		//writeLog(wbufLog);
		li->width = mpFreeTypeFont->getTextExtent( li->lyric ) * SCALE;
		//////////////////////////////////////////////////////////////////////////	
		ceguiStrTemp+=li->lyric ;
        if ( mbKtvMode )
		{
			li->pos = ( int )offset;
			offset += li->width + FONT24_SPACE;
		}
	}
	
	float fRealTextWidth = mpFreeTypeFont->getTextExtent(ceguiStrTemp) * SCALE;		//20.0f / 16.0f
	mfTextWidth = fRealTextWidth + FONT24_SPACE * ( lyric_list.size() - 1 );
	mfTextPos = LEFT_INDENT;

	//mVecLyric = lyric_list;
	m_VecLyric = lyric_list;

	if ( refresh )
	{
		invalidate();
	}

	return fRealTextWidth;
}

//-----------------------------------------------------------------------------
// ��ʾС���std::vector< Gui::_tGuiLyricInfo >
float LyricRender::showSecondLyric( LISTGUILYRICVECT & lyric_list, bool refresh/* = false*/  )
{
	mfNextTextWidth = 0.0f;
	
	CGSize sz = m_WindowSize;
	std::wstring ceguiStrTemp;
	float offset = 0.0f;
	LISTGUILYRICVECT::iterator i;
	for( i = lyric_list.begin(); i != lyric_list.end(); ++i )
	{
		_tGuiLyricInfo* & li = *i;
		li->pos = ( int )offset;
		li->width = mpFreeTypeFont->getTextExtent( li->lyric ) * SCALE;
		ceguiStrTemp.append( li->lyric );
		offset += li->width + FONT24_SPACE;
	}

	float fRealTextWidth = mpFreeTypeFont->getTextExtent(ceguiStrTemp) * SCALE;		//20.0f / 16.0f
	mfNextTextWidth = fRealTextWidth + FONT24_SPACE * ( lyric_list.size() - 1 );
	mfTextLittlePos = sz.width - mfNextTextWidth - RIGHT_INDENT;

	//mVecLittleLyric = lyric_list;
	m_VecLittleLyric = lyric_list;

	if ( refresh )
	{
		invalidate();
	}

	return fRealTextWidth;
}

//-----------------------------------------------------------------------------
// ���û���ͼ��λ��
void LyricRender::setLyricMovePos(float position)
{
	mfMovieImagePos = position;
}

//-----------------------------------------------------------------------------
// ������ʾͼ��͸����
void LyricRender::setLyricTipImageTrans(float trans)
{
	mfTipImageTrans = trans;
}

//-----------------------------------------------------------------------------
// ���õ�ǰ���Ƿ�Ϊ��һ��
void LyricRender::switchSentence(bool bFirstSentence)
{
	mbFirstSentence = bFirstSentence;
}

//-----------------------------------------------------------------------------
// �������б�־λ
void LyricRender::reset()
{
	//mVecLyric.clear();
	m_VecLyric.clear();
	//mVecLittleLyric.clear();
	m_VecLittleLyric.clear();

	mbFirstSentence = true;
	mfMovieImagePos = 0.0f;
	mfTipImageTrans = 0.0f;

	mfTextPos = 0.0f;
	mfTextLittlePos = 0.0f;
	mfTextWidth = 0.0f;
	mfNextTextWidth = 0.0f;

	//GeometryBuffer & geo = getGeometryBuffer();
	//geo.reset();
	
	ImgsetMgr::getSingleton()->getImageset( L"FreeTypeFont" )->clear();
}

//-----------------------------------------------------------------------------
void LyricRender::populateGeometryBuffer()
{
	//writeLog("LyricRender::populateGeometryBuffer enter");
	static KKColorRect color_rect0( 0xFF65CCF4, 0xFF2366DF, 0xFF65CCF4, 0xFF2366DF );
	static KKColorRect color_rect1( 0xFFDDDDDD, 0xFFDDDDDD, 0xFFDDDDDD, 0xFFDDDDDD );
    
	//GeometryBuffer & geo = getGeometryBuffer();
	//geo.reset();
    ImgsetMgr::getSingleton()->getImageset( L"FreeTypeFont" )->clear();
    
    if ( !mbInvalidate )
    {
        return;
    }
    
	if ( mbKtvMode )
	{
		CGSize & sz = m_WindowSize;
		if ( mpFreeTypeFont )
		{
			CGPoint pt( 0, 3 ); 
			CGRect rt( pt, sz );

			CGRect clip_rect1	= rt;
			clip_rect1.origin.x			= mfTextPos;
			clip_rect1.size.width		= mfTextWidth * mfStartPos;//clip_rect1.d_left + ( clip_rect1.d_right - clip_rect1.d_left ) * mfStartPos;
			CGRect clip_rect2	= rt;
			clip_rect2.origin.x			= clip_rect1.origin.x + clip_rect1.size.width;

			//std::vector< _tGuiLyricInfo >::const_iterator i;
			LISTGUILYRICVECT::iterator i;
			for( i = m_VecLyric.begin(); i != m_VecLyric.end(); ++i )
			{
				 _tGuiLyricInfo* & li = *i;//const
				pt.x = li->pos + mfTextPos;//( float )i.pos * sz.d_width;

				std::wstring & ch = li->lyric;
				// 101,204,244 ������ 35,102,223
				mpFreeTypeFont->drawText( ch, pt, &clip_rect1, color_rect0 );
				mpFreeTypeFont->drawText( ch, pt, &clip_rect2, color_rect1 );
			}

			pt = CGPointMake( 0, FONT_HEIGHT + 6 ); 
			rt = CGRectMake( pt, sz );

			clip_rect1	= rt;
			clip_rect1.origin.x			= mfTextLittlePos;
			clip_rect1.size.width		= mfNextTextWidth * mfNextStartPos;//clip_rect1.d_left + ( clip_rect1.d_right - clip_rect1.d_left ) * mfStartPos;
			clip_rect2	= rt;
			clip_rect2.origin.x			= clip_rect1.origin.x + clip_rect1.size.width;

			//std::vector< _tGuiLyricInfo >::const_iterator i;
			//LISTGUILYRICVECT::const_iterator i;
			for( i = m_VecLittleLyric.begin(); i != m_VecLittleLyric.end(); ++i )
			{
				_tGuiLyricInfo* & li = *i;//////////////////////////////////////////////////////////////////////////
				pt.x = li->pos + mfTextLittlePos;//( float )i.pos * sz.d_width;

				const std::wstring & ch = li->lyric;
				// 101,204,244 ������ 35,102,223
				mpFreeTypeFont->drawText( ch, pt, &clip_rect1, color_rect0 );
				mpFreeTypeFont->drawText( ch, pt, &clip_rect2, color_rect1 );
			}
		}

		if ( mMoveImage )
		{
			// 2.���������
			//if ( mfStartPos <= 0.0f && mfNextStartPos <= 0.0f )		// ���ϲ������
			if ( mfStartPos < 1.0f && mfNextStartPos <= 1.0f )			// ���ϻ���꣬1.0�����1.0������
			{
				CGPoint	clip_pt;
				CGPoint	move_pos;

				if ( mbFirstSentence )
				{
					if ( mfStartPos <= 0.0f )
						move_pos.x = mfTextPos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX + MOVE_IMAGE_SPACE * mfMovieImagePos - mMoveImage->getWidth();
					else
						move_pos.x = mfTextPos + mfTextWidth * mfStartPos - mMoveImage->getWidth();

					move_pos.y = MOVE_IMAGE_Y1;

					clip_pt.x = mfTextPos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX;
					clip_pt.y = MOVE_IMAGE_Y1;
				}
				else
				{
					if ( mfNextStartPos <= 0.0f )
						move_pos.x = mfTextLittlePos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX + MOVE_IMAGE_SPACE * mfMovieImagePos - mMoveImage->getWidth();
					else
						move_pos.x = mfTextLittlePos + mfNextTextWidth * mfNextStartPos - mMoveImage->getWidth();

					move_pos.y = MOVE_IMAGE_Y2;

					clip_pt.x = mfTextLittlePos - MOVE_IMAGE_SPACE - TIP_IMAGE_CX;
					clip_pt.y = MOVE_IMAGE_Y2;
				}
				
				CGSize clip_sz( MOVE_IMAGE_SPACE + MAX_LYRIC_WIDTH, mMoveImage->getHeight() );
				CGRect clip_rect( clip_pt, clip_sz );
				
				mMoveImage->draw( move_pos, &clip_rect, COLOR_RECT_WHITE );
			}
		}
	}
	else
	{
        if ( m_VecLyric.empty() )
        {
            return;
        }
        
        CGSize sz = CGSizeMake( m_WindowSize.width, 40.0f );//getPixelSize();
        CGPoint pt = CGPointMake( 0.0f, FONT_HEIGHT );
        CGRect rt = CGRectMake(pt.x, pt.y, sz.width, sz.height);

        CGRect clip_rect0	= rt;
        clip_rect0.size.width		= (int)( clip_rect0.size.width * mfStartPos );
        CGRect clip_rect1	= rt;
        clip_rect1.size.width		-= clip_rect0.size.width;
        clip_rect1.origin.x         += clip_rect0.size.width;
        
		//std::vector< _tGuiLyricInfo >::const_iterator i;
		LISTGUILYRICVECT::iterator i;//const_
        for( i = m_VecLyric.begin(); i != m_VecLyric.end(); ++i )
        {
			_tGuiLyricInfo* & li = *i;//const 
            if ( li->pos > -20 && li->pos < sz.width )
            {
				const std::wstring & ch = li->lyric;
                pt.x = ( float )li->pos;
                mpFreeTypeFont->drawText( ch, pt, &clip_rect0, color_rect0);
                mpFreeTypeFont->drawText( ch, pt, &clip_rect1, color_rect1);
            }
        }
    }
}
