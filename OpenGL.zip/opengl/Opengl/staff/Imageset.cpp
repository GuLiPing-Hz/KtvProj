//
//  Imageset.h
//  Imageset
//
//  Created by ��� on 12-8-21.
//
//
#include "../stdafx.h"
#include <stdio.h>
#include <string.h>

#include "Imageset.h"
#include "Image.h"
#include "image.c"

const uint VERTEX_FLOAT_COUNT = 2;
const uint COLOR_FLOAT_COUNT = 4;
const uint GEOMETRY_VERTEX_COUNT = 6;



Imageset::Imageset(CGSize winsize):m_windowsize(winsize),
													vs(NULL),        // ��������    8�ı���
													uvs(NULL),        // UV����     8�ı���
													cs(NULL)
{   
    cur_geo_idx = 0;
    geometry_count = 0;
    renderStyle = GL_TRIANGLES;
    quad_split_mode = TopLeftToBottomRight;
    mImages.clear();
    /*if (mImages == NULL)
    {
        mImages = [[NSMutableDictionary alloc] init];
    }*/
}

Imageset::~Imageset()
{
	ClearMapImage();
	if(mTextureID !=0)
	{
		mTextureID = 0;
	}
}

int Imageset::getIntAttr( TiXmlElement * element, const char * attr_name )
{
	int iValue = 0;
	const char * p = element->Attribute( attr_name );
	if ( p ) iValue = atol( p );

	return iValue;
}

std::string Imageset::getStrAttr( TiXmlElement * element, const char * attr_name )
{
	std::string strValue;
	const char * p = element->Attribute( attr_name );
	if ( p ) strValue = p;

	return strValue;
}

bool Imageset::LoadXML(const std::string & strFile)
{
	TiXmlDocument doc( strFile.c_str() );
	bool result = doc.LoadFile();
	if ( !result )
	{
		return false;
	}

	std::string strImagesetName, strImagesetFile;
	const char * p			= NULL;
	TiXmlElement * el		= NULL;
	TiXmlElement * elc		= NULL;
	TiXmlElement * imageset_node	= doc.FirstChildElement( "Imageset" );
	if ( imageset_node )
	{
		strImagesetName = getStrAttr( imageset_node, "Name" );
		strImagesetFile = getStrAttr( imageset_node, "Imagefile" );
		if ( strImagesetName.empty() )
		{
			return false;
		}
		/*MAPMUTABLEIMAGE::iterator i;
		//MAPIMAGESET::iterator i;
		i = mImages.find(strImagesetName);//////////////////////////////////////////////////////////////////////////
		if ( i != mImages.end() )
		{
			mImages.erase( i );
		}��Ҫ��*/
//////////////////////////////////////////////////////////////////////////
		//Image mapImage;
		el = imageset_node->FirstChildElement( "Image" );
		while ( el )
		{
			std::string strImage = getStrAttr( el, "Name" );
			int x = getIntAttr( el, "XPos" );
			int y = getIntAttr( el, "YPos" );
			int w = getIntAttr( el, "Width" );
			int h = getIntAttr( el, "Height" );

			CGRect rect = CGRectMake(x,y,w,h);
			Image * img = new Image(rect,this);
			// find the normalized texture coordinates�����һ������������
			wchar_t unicodeImage[256] = {0};
			MultiByteToWideChar(CP_ACP, 0, strImage.c_str(), -1, unicodeImage, 255);
			//return [img autorelease];/////////////glp
			mImages.insert( std::pair<std::wstring,Image*>( unicodeImage, img ) );
			el = el->NextSiblingElement( "Image" );
		}

		//m_mapImageset.insert( std::pair<std::string,MAPIMAGE>( strImagesetName, mapImage ) );
		//m_mapImagesetFile[strImagesetName] = strImagesetFile;

		return true;
	}

	return false;
}

bool Imageset::load(const std::string dataDir,const std::string imgset_name)
{
    // ����Imageset����
    mImagesetName =  imgset_name;
    
	ClearMapImage();
    
	//����ͼ��
	char fileName[256] = {0};
	sprintf(fileName,"%s\\texture\\%s.png",dataDir.c_str(),imgset_name.c_str());
	//std::string fileName = imgset_name + ".png";
	mTextureSize = loadTextureImage(fileName);
	if (mTextureSize == CGSIZEZERO)
	{
		OutputDebugStringA("mTextureSize == zero\n");
		return false;
	}
    
    //��ȡԪ���ݣ�xml//
	//����Ԫ���ݣ�Ϊÿ����������һ���µ��ı��Ρ�
	char xmlName[256] = {0};
	sprintf(xmlName,"%s\\texture\\%s.xml",dataDir.c_str(),imgset_name.c_str());
	if (!LoadXML(xmlName))
	{
		return false;
	}
	return true;
}

Image* Imageset::getImage(const std::string& img_name)
{
	wchar_t ws[256] = {0};
	MultiByteToWideChar(CP_ACP,0,img_name.c_str(),-1,ws,255);
	std::wstring wstring = ws;
	return getImage(wstring);
}

Image* Imageset::getImage(const std::wstring& img_name)
{
	//writeLog(" Imageset::getImage enter");
	MAPMUTABLEIMAGE::const_iterator i;
	i = mImages.find(img_name);
	if ( i != mImages.end() )
	{
		return i->second;
	}
	return NULL;
}

bool Imageset::isDefined(const std::string& img_name)
{
	wchar_t ws[256] = {0};
	MultiByteToWideChar(CP_ACP,0,img_name.c_str(),-1,ws,255);
	std::wstring wstring = ws;
	return isDefined(wstring);
}

bool Imageset::isDefined(const std::wstring& img_name)
{
	MAPMUTABLEIMAGE::const_iterator i;
	i = mImages.find(img_name);
	if ( i != mImages.end() )
	{
		return true;
	}
	return false;
}

void Imageset::addImage( const std::string & img_name, const CGRect & img_rect , const CGPoint & img_offset)
{
	wchar_t ws[256] = {0};
	MultiByteToWideChar(CP_ACP,0,img_name.c_str(),-1,ws,255);
	std::wstring wstring = ws;
	return addImage(wstring,img_rect,img_offset);
}

void Imageset::addImage( const std::wstring & img_name, const CGRect & img_rect , const CGPoint & img_offset)
{
	Image * img = new Image(img_rect,this);
   	// find the normalized texture coordinates�����һ������������
    img->SetPoint(img_offset);
    
	mImages.insert(std::pair<std::wstring,Image*>( img_name, img ));
}

void Imageset::setTexture(GLuint tex_id ,CGSize& tex_size)
{
    mTextureID = tex_id;
    mTextureSize = tex_size;
}

void Imageset::drawVertex(int geometry_index ,int vertex_index ,const CGPoint& position ,const KKColor& colour_val ,const CGPoint& tex_coords)
{
	//writeLog("Imageset::drawVertex enter");
    int uv_idx = cur_geo_idx * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT + vertex_index * VERTEX_FLOAT_COUNT;
    int v_idx = cur_geo_idx * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT + vertex_index * VERTEX_FLOAT_COUNT;
    int c_idx = cur_geo_idx * GEOMETRY_VERTEX_COUNT * COLOR_FLOAT_COUNT + vertex_index * COLOR_FLOAT_COUNT;
    
    //static CGFloat half_width = window_size.width / 2;
    //static CGFloat half_height = window_size.height / 2;

    vs[v_idx+0] = position.x;// - half_width;
    vs[v_idx+1] = -position.y;//half_height - position.y;
    
    uvs[uv_idx+0] = tex_coords.x;
	uvs[uv_idx+1] = tex_coords.y;

    cs[c_idx+0]   = colour_val.r;
    cs[c_idx+1]   = colour_val.g;
    cs[c_idx+2]   = colour_val.b;
    cs[c_idx+3]   = colour_val.a;
}

// grabs the openGL texture ID from the library and calls the openGL bind texture method
void Imageset::draw(const CGRect& source_rect ,const CGRect& dest_rect ,CGRect* pclip_rect ,const KKColorRect& color_rect)
{
	//writeLog("Imageset::draw enter");
    if ( cur_geo_idx >= geometry_count )
    {
        int count = 16;
        if ( 0 != geometry_count )
        {
            count = geometry_count * 2;
        }
        resizeGeometryBuffer(count);
    }
    CGRect final_rect = dest_rect;
    
    if ( pclip_rect != NULL )
    {
        final_rect = CGRectIntersection( dest_rect, *pclip_rect );
    }
    
    if ( final_rect.size.width == 0 || final_rect.size.height == 0 )
    {
        return;
    }
    
    float tex_per_pix_x = source_rect.size.width / dest_rect.size.width;
    float tex_per_pix_y = source_rect.size.height / dest_rect.size.height;
    //final��dest���ұߣ��±�
    CGFloat l = (source_rect.origin.x + ((final_rect.origin.x - dest_rect.origin.x) * tex_per_pix_x));
    CGFloat t = (source_rect.origin.y + ((final_rect.origin.y - dest_rect.origin.y) * tex_per_pix_y));
    CGFloat r = (source_rect.origin.x + source_rect.size.width + ((final_rect.origin.x + final_rect.size.width - dest_rect.origin.x - dest_rect.size.width ) * tex_per_pix_x));
    CGFloat b = (source_rect.origin.y + source_rect.size.height + ((final_rect.origin.y + final_rect.size.height - dest_rect.origin.y - dest_rect.size.height) * tex_per_pix_y));
    
    GLfloat uMin = l / mTextureSize.width;
    GLfloat vMin = t / mTextureSize.height;
    GLfloat uMax = r / mTextureSize.width;
    GLfloat vMax = b / mTextureSize.height;
    
    CGPoint pos_left_top = CGPointMake(final_rect.origin.x, final_rect.origin.y);
    CGPoint pos_left_bottom = CGPointMake(final_rect.origin.x, final_rect.origin.y + final_rect.size.height);
    CGPoint pos_right_top = CGPointMake(final_rect.origin.x + final_rect.size.width, final_rect.origin.y);
    CGPoint pos_right_bottom = CGPointMake(final_rect.origin.x + final_rect.size.width, final_rect.origin.y + final_rect.size.height);
    
    CGPoint tex_left_top = CGPointMake(uMin,vMin);
    CGPoint tex_left_bottom = CGPointMake(uMin,vMax);
    CGPoint tex_right_top = CGPointMake(uMax,vMin);
    CGPoint tex_right_bottom = CGPointMake(uMax,vMax);
    
    // vertex 0
    drawVertex(cur_geo_idx ,0 ,pos_left_top ,color_rect.left_top_color , tex_left_top);
    
    // vertex 1
    drawVertex(cur_geo_idx ,1 , pos_left_bottom ,color_rect.left_bottom_color , tex_left_bottom);
    
    // vertex 2
    // top-left to bottom-right diagonal
    if (quad_split_mode == TopLeftToBottomRight)
    {
        drawVertex(cur_geo_idx , 2 , pos_right_bottom ,color_rect.right_bottom_color , tex_right_bottom);
    }
    // bottom-left to top-right diagonal
    else
    {
//        [self drawVertex: cur_geo_idx VertexIndex: 2 Position: pos_right_top Color:color_rect.right_bottom_color TexCoords: tex_right_top];
        drawVertex(cur_geo_idx , 2 , pos_right_top ,color_rect.right_top_color , tex_right_top);
    }

    // vertex 3
    drawVertex(cur_geo_idx , 3 , pos_right_top ,color_rect.right_top_color , tex_right_top);
    
    // vertex 4
    // top-left to bottom-right diagonal
    if (quad_split_mode == TopLeftToBottomRight)
    {
        drawVertex(cur_geo_idx , 4 , pos_left_top ,color_rect.left_top_color , tex_left_top);
    }
    // bottom-left to top-right diagonal
    else
    {
//        [self drawVertex: cur_geo_idx VertexIndex: 4 Position: pos_left_bottom Color:color_rect.left_top_color TexCoords: tex_left_bottom];
        drawVertex(cur_geo_idx , 4 , pos_left_bottom ,color_rect.left_bottom_color , tex_left_bottom);
    }
        
    // vertex 5
    drawVertex(cur_geo_idx , 5 , pos_right_bottom ,color_rect.right_bottom_color , tex_right_bottom);

    cur_geo_idx++;
}

void resizeBuffer(GLfloat** buffer ,int old_size ,int new_size)
{
    GLfloat * temp = (GLfloat *)(malloc( new_size ));
    if ( *buffer )
    {
        memcpy(temp, *buffer, old_size );
        free( *buffer );
        *buffer = temp;
    }
    else
    {
        *buffer = temp;
    }    
}

void Imageset::resizeGeometryBuffer(int count)
{
	//writeLog("Imageset::resizeGeometryBuffer enter");
    if ( geometry_count == count )
    {
        return;
    }
    
    int old_size = sizeof(GLfloat) * geometry_count * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT;
    int new_size = sizeof(GLfloat) * count * GEOMETRY_VERTEX_COUNT * VERTEX_FLOAT_COUNT;
    resizeBuffer(&vs ,old_size , new_size);
    resizeBuffer(&uvs ,old_size , new_size);
    old_size = sizeof(GLfloat) * geometry_count * GEOMETRY_VERTEX_COUNT * COLOR_FLOAT_COUNT;
    new_size = sizeof(GLfloat) * count * GEOMETRY_VERTEX_COUNT * COLOR_FLOAT_COUNT;
    resizeBuffer(&cs ,old_size , new_size);

    geometry_count = count;
}

void Imageset::bindTexture()
{               
	//�����Ѿ���������
	//writeLog("Imageset::bindTexture enter");
	glBindTexture(GL_TEXTURE_2D, mTextureID);
	//��������ϵͳ�������ܴܺ󣬾����ܽ�ʹ��ͬһ�������Ķ�����֯��һ��
}

// does the heavy lifting for getting a named image into a texture
// that is loaded into openGL
// this is a modified version of the way Apple loads textures in their sample code
void Imageset::FreeImage(_tImageInfo *_image)
{
	if (!_image)
		return;
	if (_image->hBitmap) {
		::DeleteObject(_image->hBitmap) ; 
	}
	delete _image ;
};

_tImageInfo* Imageset::LoadImage(const char *pngFile, bool onlyout, DWORD mask)
{
	LPBYTE pData = NULL;
	DWORD dwSize = 0;

	HANDLE hFile = ::CreateFile(pngFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, \
		FILE_ATTRIBUTE_NORMAL, NULL);
	if( hFile == INVALID_HANDLE_VALUE ) return NULL;
	dwSize = ::GetFileSize(hFile, NULL);
	if( dwSize == 0 ) return NULL;

	DWORD dwRead = 0;
	pData = new BYTE[ dwSize ];
	::ReadFile( hFile, pData, dwSize, &dwRead, NULL );
	::CloseHandle( hFile );

	if( dwRead != dwSize ) {
		delete[] pData;
		return NULL;
	}

	LPBYTE pImage = NULL;
	int x,y,n;
	pImage = stbi_load_from_memory(pData, dwSize, &x, &y, &n, 4);
	delete[] pData;
	if( !pImage ) return NULL;

	BITMAPINFO bmi;
	::ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = x;
	bmi.bmiHeader.biHeight = -y;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = x * y * 4;

	bool bAlphaChannel = false;
	LPBYTE pDest = NULL;
	HBITMAP hBitmap = ::CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void**)&pDest, NULL, 0);
	if( !hBitmap ) return NULL;

	LPBYTE _dest = pDest;
	if (!onlyout) {
		for( int i = 0; i < x * y; i++ ) 
		{
			pDest[i*4 + 3] = pImage[i*4 + 3];
			if( pDest[i*4 + 3] < 255 )
			{
				pDest[i*4] = (BYTE)(DWORD(pImage[i*4 + 2])*pImage[i*4 + 3]/255);
				pDest[i*4 + 1] = (BYTE)(DWORD(pImage[i*4 + 1])*pImage[i*4 + 3]/255);
				pDest[i*4 + 2] = (BYTE)(DWORD(pImage[i*4])*pImage[i*4 + 3]/255); 
				bAlphaChannel = true;
			}
			else
			{
				pDest[i*4] = pImage[i*4 + 2];
				pDest[i*4 + 1] = pImage[i*4 + 1];
				pDest[i*4 + 2] = pImage[i*4]; 
			}

			if( *(DWORD*)(&pDest[i*4]) == mask ) {
				pDest[i*4] = (BYTE)0;
				pDest[i*4 + 1] = (BYTE)0;
				pDest[i*4 + 2] = (BYTE)0; 
				pDest[i*4 + 3] = (BYTE)0;
				bAlphaChannel = true;
			}
		}
	} else {
		_dest = new BYTE[x*y*4];
		memcpy(_dest, pImage, x*y*4*sizeof(BYTE));
		for( int i = 0; i < x * y; i++ ) 
		{
			BYTE _tmp[3] = {_dest[i*4],_dest[i*4+1],_dest[i*4+2]};
			_dest[i*4] = _tmp[2];
			_dest[i*4+1] = _tmp[1];
			_dest[i*4+2] = _tmp[0];
		}
	}

	stbi_image_free(pImage);

	_tImageInfo* data = new _tImageInfo;
	data->hBitmap = hBitmap;
	data->nX = x;
	data->nY = y;
	data->alphaChannel = bAlphaChannel;
	data->bitmapData = _dest;
	return data;
};

BOOL Imageset::LoadGLTextures(BYTE* pglTextureData,int w,int h)
{
	BOOL Status=FALSE;									// Status Indicator
	if ( !pglTextureData )
	{
		return Status;
	}
	//Video2TextureMem(m_pvideoData,m_pvideoTextureData);
	Status=TRUE;									// Set The Status To TRUE
	glGenTextures(1, &mTextureID);					// ����1������id

	// Typical Texture Generation Using Data From The Bitmap
	glBindTexture(GL_TEXTURE_2D, mTextureID);
//	glTexImage2D(GL_TEXTURE_2D, 0, 3, m_textureX, m_textureY, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pvideoTextureData);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, pglTextureData);


	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	
	return Status;										// Return The Status
}


CGSize	Imageset::loadTextureImage(const char* imgfile_name)//,const std::string imgset_name)
{
	//CGContextRef spriteContext; //UIImage������������
	//GLubyte *spriteData; // ����ͼ�����ݵ���ʱ����
    _tImageInfo * pBitMapData =  LoadImage(imgfile_name);
	if (!pBitMapData)
	{
		return CGSizeMake(0,0);
	}
	// Get the width and height of the image
	int width = pBitMapData->nX;
	int height = pBitMapData->nY;
	
	CGSize imageSize = CGSizeMake(width, height);
	
	if (pBitMapData->bitmapData)
	{
		 //��ͼ������ѹ��OpenGL��Ƶ�ڴ档
		LoadGLTextures(pBitMapData->bitmapData,width,height);
		//�ͷ�ͼ�����ݡ�
		FreeImage(pBitMapData);
		return imageSize;
	}

	return CGSizeMake(0,0);
        //������������������OpenGl����������ȫƥ���ʱ�������е����ط�ʽ��
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        //ģ���˲�������С��
        
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        //���˲������Ŵ�
		
		// ����2D�������ܡ�
		//glEnable(GL_TEXTURE_2D);
		// ����Ҫʹ�õ�һ����Ϻ���������OpenGL��δ�����͸��������
		//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        //glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		// ���û��
		//glEnable(GL_BLEND);
}

void Imageset::render()//��Ҫ��
{
	glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2, GL_FLOAT, 0, vs);

	glEnableClientState(GL_COLOR_ARRAY);
    glColorPointer(4, GL_FLOAT, 0, cs);
    
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, uvs);
    
    glDrawArrays(renderStyle, 0, GEOMETRY_VERTEX_COUNT * cur_geo_idx );
}

void Imageset::clear()
{
	//writeLog("Imageset::clear enter");
    cur_geo_idx = 0;
}

void Imageset::ClearMapImage()
{
	if (!mImages.empty())
	{
		MAPMUTABLEIMAGE::iterator i;
		for (i = mImages.begin();i!=mImages.end();i++)
		{
			SAFE_DELETE(i->second);
		}
	}
	mImages.clear();
}




