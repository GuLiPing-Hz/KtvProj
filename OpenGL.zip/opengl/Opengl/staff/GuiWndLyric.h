#pragma once
#include "gui/GuiPrerequisites.h"
#include "gui/IGuiDef.h"

//-----------------------------------------------------------------------------
class CGuiWndLyric : public CEGUI::Window
{
public:
	// ���캯��
	CGuiWndLyric( const CEGUI::String & type, const CEGUI::String & name );

	// ��������
	virtual ~CGuiWndLyric();

	// ��������ģʽ�Ƿ�ΪKTVģʽ(����ģʽ:KTVģʽ,��Ϸģʽ)
	void setMode( bool ktv_mode );

	// ���ø�ʿ��ݳ����
	void setFirstLyricStartPos( float start_pos );

	// ���ø�ʿ��ݳ����
	void setNextLyricStartPos( float start_pos );

	// ��������ʱ��
	void setSongTime( const std::string& curtime );

	// ��������
	void setSongName( const std::string& curname );

	// ��ʾ���
	float showFirstLyric( std::vector< Gui::_tGuiLyricInfo > & lyric_list, bool refresh = false );

	// ��ʾС���
	float showSecondLyric( std::vector< Gui::_tGuiLyricInfo > & lyric_list, bool refresh = false  );

	// ���û���ͼ��λ��
	virtual void setLyricMovePos( float position );

	// ������ʾͼ��͸����
	virtual void setLyricTipImageTrans( float trans );

	// ���õ�ǰ���Ƿ�Ϊ��һ��
	virtual void switchSentence( bool bFirstSentence );

	// �������б�־λ
	void reset();


protected:
	virtual void populateGeometryBuffer();

private:
	std::vector< Gui::_tGuiLyricInfo >	mVecLyric;
	std::vector< Gui::_tGuiLyricInfo >	mVecLittleLyric;

	std::string							mSongName;
	std::string							mSongPlayedTime;

	bool								mbFirstSentence;

	float								mfMovieImagePos;
	float								mfTipImageTrans;
	float								mfStartPos;
	float								mfNextStartPos;
	float								mfTextPos;
	float								mfTextLittlePos;
	float								mfTextWidth;
	float								mfNextTextWidth;
	float								mfSongNameWidth;
	bool								mbKtvMode;
};

//-----------------------------------------------------------------------------
class CGuiWndLyricFactory : public CEGUI::WindowFactory
{
public:
	CGuiWndLyricFactory( void );

	~CGuiWndLyricFactory( void );

	CEGUI::Window * createWindow( const CEGUI::String & name );

	void destroyWindow( CEGUI::Window * window );
};


//-----------------------------------------------------------------------------
class CSongBegin : public CEGUI::Window
{
public:
	// ���캯��
	CSongBegin( const CEGUI::String & type, const CEGUI::String & name );

	// ��������
	virtual ~CSongBegin();

	void showSentenceScore( int score );

	void setBeginTotalTime( float begin_time );

	void setCurentTime( float elapsed_time );

	void reset();

protected:
	virtual void populateGeometryBuffer();


private:

	float							mfBeginTotalTime;
	float							mfLastChangTime;

	std::map< int, std::string >	mNumStringMap;

	std::vector< std::string >		mScoreText;

	typedef std::map< int, std::string >::const_iterator	NumStringMapConstIterator;
	typedef std::map< int, std::string >::iterator			NumStringMapIterator;


	unsigned int	miCount;

};

//-----------------------------------------------------------------------------
class CSongBeginFactory : public CEGUI::WindowFactory
{
public:
	CSongBeginFactory( void );

	~CSongBeginFactory( void );

	CEGUI::Window * createWindow( const CEGUI::String & name );

	void destroyWindow( CEGUI::Window * window );
};
