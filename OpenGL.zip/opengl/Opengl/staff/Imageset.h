
//  BBMaterialController.h
//  SpaceRocks
//
//  Created by ben smith on 14/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//
#pragma once

//#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include <string>
#include "RenderConfig.h"
//#include "KKType.h"
#include "Image.h"

#include "../xml/tinystr.h"
#include "../xml/tinyxml.h"

#include <map>


struct _tImageInfo
{
	HBITMAP hBitmap;
	int nX;
	int nY;
	bool alphaChannel;
	DWORD dwMask;
	LPBYTE bitmapData;
};

struct _tFastLessCompare
{
	bool operator() (const std::wstring& a, const std::wstring& b) const
	{
		const size_t la = a.length();
		const size_t lb = b.length();
		if (la == lb)
			return (wmemcmp(a.c_str(), b.c_str(), la) < 0);
		return (la < lb);
	}
};

typedef std::map<std::wstring,Image *,_tFastLessCompare>	MAPMUTABLEIMAGE;
typedef std::map<std::wstring,float,_tFastLessCompare>		MAPXMLITEM;

class Imageset
{

public:
	Imageset(CGSize winsize);
	~Imageset();

private:
	//xml ��غ���
	std::string getStrAttr( TiXmlElement * element, const char * attr_name );
	int getIntAttr( TiXmlElement * element, const char * attr_name );
	bool LoadXML(const std::string & strFile);

	void FreeImage(_tImageInfo *_image);
	_tImageInfo* LoadImage(const char *pngFile, bool onlyout = false, DWORD mask = 0);//��ȡpngͼƬ����
	BOOL LoadGLTextures(BYTE* pglTextureData,int w,int h);//���ݴ������ݣ�������������
	CGSize	loadTextureImage(const char* imgfile_name);//,const std::string imgset_name);//�������ݣ���������

	//���map����
	void ClearMapImage();

public:
	bool load(const std::string dataDir,const std::string imgset_name);//���е�load�������￪ʼ,����ӿ�
	//Image* genImage(MAPXMLITEM plist_item);
	Image* getImage(const std::string& img_name);
	Image* getImage( const std::wstring& img_name);

	bool isDefined(const std::string& img_name);
	bool isDefined(const std::wstring& img_name);

	void addImage( const std::string & img_name, const CGRect & img_rect , const CGPoint & img_offset);
	void addImage( const std::wstring & img_name, const CGRect & img_rect , const CGPoint & img_offset);

	void setTexture(GLuint tex_id ,CGSize& tex_size);

	void drawVertex(int geometry_index ,int vertex_index ,const CGPoint& position ,const KKColor& colour_val ,const CGPoint& tex_coords);
	void draw(const CGRect& source_rect ,const CGRect& dest_rect,CGRect* pclip_rect ,const KKColorRect& color_rect);

	void resizeGeometryBuffer (int count);

	// grabs the openGL texture ID from the library and calls the openGL bind texture method
	void bindTexture();

	void render();

	void clear();

public:
	std::string  mImagesetName;
	GLuint mTextureID;
	CGSize mTextureSize;
	CGSize m_windowsize;

	MAPMUTABLEIMAGE  mImages;

	GLfloat *vs;        // ��������    8�ı���
	GLfloat *uvs;       // UV����     8�ı���
	GLfloat *cs;        // ��ɫ       16�ı���

	int     cur_geo_idx;
	int     geometry_count;
	GLenum  renderStyle;
	_eQuadSplitMode quad_split_mode;
};



 



