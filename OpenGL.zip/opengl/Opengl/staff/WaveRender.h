//
//  WaveRender.h
//  Karaoke
//

#include <vector>

#include "KKType.h"
#include "Image.h"
#include "Imageset.h"

#include "../GLListDef.h"

// ALPHA �任����
class CTransParams
{
public:
	//-----------------------------------------------------------------------------
	// �任����
	enum _eTansType
	{
		TRANS_NONE  = 0x00,
		TRANS_ALPHA = 0x01,
		TRANS_SCALE = 0x02,
		TRANS_ANGLE = 0x04
	};
	//-----------------------------------------------------------------------------
	CTransParams()
	{
		meTransType = TRANS_NONE;
		mbLoop = false;
		mbEnd = false;

		mfTransTm = 0.0f;
		mfAlpha = 0.0f;
		mfScale = 0.0f;

		mfAlphaBegin = 0.0f;
		mfFadeinTm = 0.5f;
		mfDelayTm = 0.5f;
		mfFadeoutTm = 0.5f;

		mfRotateTm = 0.6f;

		if ( mfAlphaBegin > 1.0f )
			mfAlphaBegin = 1.0f;

		if ( mfFadeinTm > 0.0f )
			mfFadeinFactor = ( 1.0 - mfAlphaBegin ) / mfFadeinTm;
		else
			mfFadeinFactor = 0.0f;

		if ( mfFadeoutTm > 0.0f )
			mfFadeoutFactor = ( 1.0 - 0.0 ) / mfFadeoutTm;
		else
			mfFadeoutFactor = 0.0f;

		if ( mfRotateTm > 0.0f )
			mfRotateFactor = ( 1.0 - 0.0 ) / mfRotateTm;
		else
			mfRotateFactor = 0.0f;
	}

	//-----------------------------------------------------------------------------
	CTransParams( 
		bool bLoop,
		char transType = TRANS_ALPHA,
		float fAlphaBegin = 0.0f,
		float fFadeinTm = 0.5f,
		float fDelayTm = 0.5f,
		float fFadeoutTm = 0.5f,
		float fRotateTm = 0.6f
		)
		: mbLoop( bLoop )
		, meTransType( transType )
		, mfAlphaBegin( fAlphaBegin )
		, mfFadeinTm( fFadeinTm )
		, mfDelayTm( fDelayTm )
		, mfFadeoutTm( fFadeoutTm )
		, mfRotateTm( fRotateTm )
	{
		if ( mfAlphaBegin > 1.0f )
			mfAlphaBegin = 1.0f;

		if ( mfFadeinTm > 0.0f )
			mfFadeinFactor = ( 1.0 - mfAlphaBegin ) / mfFadeinTm;
		else
			mfFadeinFactor = 0.0f;

		if ( mfFadeoutTm > 0.0f )
			mfFadeoutFactor = ( 1.0 - 0.0 ) / mfFadeoutTm;
		else
			mfFadeoutFactor = 0.0f;

		if ( mfRotateTm > 0.0f )
			mfRotateFactor = ( 1.0 - 0.0 ) / mfRotateTm;
		else
			mfRotateFactor = 0.0f;

		reset();
	}

	//-----------------------------------------------------------------------------
	~CTransParams()	{}

	//-----------------------------------------------------------------------------
	void reset()
	{
		//mbLoop = false;
		//meTransType = TRANS_NONE
		mbEnd = false;
		mfTransTm = 0.0f;
		mfAlpha = 0.0f;
		mfScale = 0.0f;
		mfAngle = 0.0f;
	}

	//-----------------------------------------------------------------------------
	// ��ȡ���ź�ALPHAֵ
	void trans( float elapsed_tm )
	{
		if ( mfTransTm <= ( mfFadeinTm + mfDelayTm + mfFadeoutTm ) )
		{
			if ( meTransType & TRANS_ALPHA )
			{
				if ( mfTransTm <= mfFadeinTm )
				{// 1.����
					mfAlpha += elapsed_tm * mfFadeinFactor;
				}
				else if ( mfTransTm <= ( mfFadeinTm + mfDelayTm ) )
				{// 2.����ALPHAΪ1��ʾ
					mfAlpha = 1.0f;
				}
				else
				{// 3.����
					mfAlpha -= elapsed_tm * mfFadeoutFactor;
				}
			}

			if ( meTransType & TRANS_SCALE )
			{
				if ( mfTransTm <= mfFadeinTm )
				{// 1.����
					mfScale += elapsed_tm * mfFadeinFactor;
				}
				else if ( mfTransTm <= ( mfFadeinTm + mfDelayTm ) )
				{// 2.����ALPHAΪ1��ʾ
					mfScale = 1.0f;
				}
				else
				{// 3.����
					mfScale -= elapsed_tm * mfFadeoutFactor;
				}
			}

			if ( meTransType & TRANS_ANGLE )
			{
				if ( mfTransTm <= mfRotateTm )
				{
					mfAngle += elapsed_tm * mfRotateFactor;
				}
			}

			mfTransTm += elapsed_tm;
		}
		else
		{
			if ( mbLoop )
			{
				reset();
			}
			else
			{
				mbEnd = true;
			}
		}
	}

	//-----------------------------------------------------------------------------
	// �����Ƿ�ѭ��
	void setLoop( bool _loop )
	{
		mbLoop = _loop;
	}

	//-----------------------------------------------------------------------------
	// ��ȡ�Ƿ�ѭ��
	bool getLoop()
	{
		return mbLoop;
	}

	//-----------------------------------------------------------------------------
	// ��ȡAlphaֵ
	float getAlpha()
	{
		return mfAlpha;
	}

	//-----------------------------------------------------------------------------
	// ��ȡScaleֵ
	float getScale()
	{
		return mfScale;
	}

	//-----------------------------------------------------------------------------
	// ��ȡAngleֵ
	float getAngle()
	{
		return mfAngle;
	}

	//-----------------------------------------------------------------------------
	// �Ƿ����
	bool isEnd()
	{
		return ( !mbLoop && mbEnd );
	}

private:
	char	meTransType;			// �任����
	bool	mbLoop;					// �Ƿ�
	bool	mbEnd;					// ����

	float	mfTransTm;				// �任ʱ��

	float	mfAlpha;				// ALPHAֵ
	float	mfScale;				// ����
	float	mfAngle;				// ��ת�Ƕ�

	float	mfAlphaBegin;			// ALPHA��ʼֵ
	float	mfFadeinTm;				// ������ʱ
	float	mfDelayTm;				// AlpahֵΪ1.0ʱ(Scale��ֵΪ1.0ʱ)��ʾ��ʱ
	float	mfFadeoutTm;			// ������ʱ

	float	mfRotateTm;				// ��ת����ʱ��

	float	mfFadeinFactor;			// ��������
	float	mfFadeoutFactor;		// ��������
	float	mfRotateFactor;			// ��ת����
};

//-----------------------------------------------------------------------------
class WaveRender
{
public:
	// ���캯��
	WaveRender(CGSize & window_size);

	// ��������
	virtual ~WaveRender();

	// ��������ģʽ�Ƿ�ΪKTVģʽ(����ģʽ:KTVģʽ,��Ϸģʽ)
	void setMode( bool ktv_mode );

	// ��������
	void setLineGroup( const VECTORGUIPITCHVECT & wave_list, bool refresh = false );//std::vector< _tGuiWaveInfo >

	// �����α�
	void setLyricCursor( const _tGuiLyricCursorInfo & ci, float ktvErr, float gameErr );

	//
	void setStandardY( int y );

	// ���õ����ƶ��ٶ�
	void setMovePos( float position );

	// ����α�
	void clearLyricCursor();

	// ���þ�β��
	void setSentenceLineList( const LISTSENTENCELINEVECT & sentenceline_list, bool refresh = false );

	// update self
	void updateSelf(float elapsed);

	// 
	void reset();

	// ����/�ر����߹⻷��Ч
	virtual void enableWaveEffect( bool enable = true );

	// ����/�ر������ǹ���Ч
	//virtual void enableStarEffect( int pitch_index, bool enable = true );

	virtual void populateGeometryBuffer();

protected:
	void invalidate();

private:
	// ���ƾ�β��
	void _drawSentenceLine( const LISTSENTENCELINEVECT & sentenceline_list );//std::vector< int >

	// ������Ϸģʽ���
	void _drawCursor();

	// ��������
	void _drawPitch( VECTORGUIPITCHVECT & waves );//std::vector< _tGuiWaveInfo > const

	// �����α����λ��
	void _locateCursor();

	// �����α����
	void _dealWithCursor( const _tGuiLyricCursorInfo & ci );

private:
	float											mfStartPos;
	//LISTGUIPITCHVECT					mVecWave;// ����
	VECTORGUIPITCHVECT				mVecWave;
	std::vector< _tGuiLyricCursorInfo>				mVevCursors; //�α�����
	//std::vector< _tGuiLyricCursorInfo>				mVecCursorsPos;
	_tGuiLyricCursorInfo							mLyricCursorInfo;// �α�
	LISTSENTENCELINEVECT								mSentenceLineList;// ��β��
	CGPoint											mLyricCursorPos;
	CGPoint											mLyricLastCursorPos;
	bool											mbKtvMode;
	float											mfKtvErr;
	float											mfGameErr;
	int												mStandard_y;

	//����ͷ��
	Image *										m_head_img;
	//����ͷ���ָ�
	Image *										m_headsep_img;
	// ��׼������
	Image *										mImageWaveLeft0;
	Image *										mImageWaveMiddle0;
	Image *										mImageWaveRight0;

	// ���߹⻷
	Image *										mImageWaveLeft1;
	Image *										mImageWaveMiddle1;
	Image *										mImageWaveRight1;

	// �質�Ŀ��׵�����
	Image *										mImageWaveLeft2;
	Image *										mImageWaveMiddle2;
	Image *										mImageWaveRight2;

	// ��׼�Ĳ����׵�����
	Image *										mImageWaveLeft3;
	Image *										mImageWaveMiddle3;
	Image *										mImageWaveRight3;

	Image *										mImageWave;

	bool										mbEnableWaveEffect;		// �����߹⻷Ч��
	CTransParams								mImageWaveTrans;		// ����������Χ�⻷��Alphaֵ

	bool										mbEnableMoveImage;		// �Ƿ���ʾ�����ϵ��ƶ����

	typedef std::pair< int, CTransParams >	TRANSPARAM_PAIR;
	typedef std::vector< TRANSPARAM_PAIR >	TRANSPARAM_VECT;
	TRANSPARAM_VECT								mStarEffectVect;		// �ǹ���Ч���ڵڼ�������ʾ��ALPHAֵ��SCALEֵ�Ƕ��١�

	bool											mbInvalidate;
	CGSize										m_WindowSize;
	Image * mImageSentenceLine;
	float mImageSentenceLineWidth;
	float mImageSentenceLineHeight;

	Image * mMoveImage;							// �����еĹ����Ч
	static const int mnStarImageCount = 13;		// �����е�������Ч
	Image * mStarImages[mnStarImageCount];
};

