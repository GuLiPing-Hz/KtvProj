//
//  SceneObjectEx.h
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//
#pragma once

#include <stdio.h>
#include <string.h>
#include <string>

#include "SceneObject.h"
#include "../fto/ftotype.h"
#include "../fto/eval.h"

#include "LyricRender.h"
#include "WaveRender.h"
#include "SentenceRender.h"

// ���������

//¼��
#include "../wave/WZ_WaveUnit.h"

#include "../GLListDef.h"//video ���ſ���

enum _eSingStage {
	SINGSTAGE_PRELUDE = 0,
	SINGSTAGE_SING = 1,
	SINGSTAGE_FINALE = 2,
};


class SceneObjectEx : SceneObject 
{
public:
	SceneObjectEx(const std::string& dataDir,const std::string& fileName ,CGSize& winsize,
			const DWORD& nChannels=1, const DWORD& nFrequency=11025, const WORD& nBits=8,const std::string& textureName="renderer");
	~SceneObjectEx();
	virtual bool awake();//����
	//- (void) render;
	virtual void realtime(ulong ns_elapsed_ms);

	virtual void update(ulong  ns_elapsed_ms);

	virtual void end();//���Ž���

	void RealtimeGrade(const _tRealtimeGrade &  realtime_grade);

	void SentenceGrade(const _tSentenceGrade &  sentence_grade);

	void eventMainUpdate(unsigned int elapsed_ms);

	// av����Ƶʵʱ����
	void eventAvRealtimeGrade(unsigned int elasped_ms ,_tRealtimeGrade & grade ,bool is_callback = true);

	// av����Ƶ��������
	void eventAvSentenceGrade(_tSentenceGrade & grade);
	//
	//AQPlayer *getAudioPlayer();
	//AQRecorder *getAudioRecorder();

private:
	//void CreatePath(std::string strPath);
	std::wstring & getLyric(_tSongInfo& song_info);
	void genWaveAndLyric(_tSongInfo& song_info);

	template<class T>//���� �洢ָ���������
	void ClearListVectT(T & listVect)
	{
		T::iterator i;
		for (i=listVect.begin();i!=listVect.end();i++)
		{
			SAFE_DELETE(*i);
		}
		listVect.clear();
	}
private:		
// 	NSMutableArray *					mGuiLyricVect;
	LISTGUILYRICVECT						mGuiLyricVect;
// 	NSMutableArray *					mGuiPitchVect;
	LISTGUIPITCHVECT					mGuiPitchVect;
// 	NSMutableArray *					mGuiSentencelineVect;
	LISTSENTENCELINEVECT			mGuiSentencelineVect;
// 	NSMutableArray *					mParagraphVect;
	LISTPARAGRAPHVECT 				mParagraphVect;

	LISTGUILYRICVECT						m_tmpgui_lyric_list;
	VECTORGUIPITCHVECT				m_tmpgui_pitch_list;
	_tGuiLyricCursorInfo *				m_tmpcursor;

	bool                    mbInterpolation;
	bool                    mbIsCallback;
	bool                    mbIsMe;
	bool                    mbKtvMode;
	bool                    mbChangeMode;

	_tRealtimeGrade         mCurGrade;

	float                   mfElapsedCount;
	uint                    miElapsedCount;
	uint                    miLastElapsedCount;
	uint                    mErrCorrect;
	uint                    mPreTime;
	uint                    mCurTime;
	uint                    mCurSingTime;
	_eSingStage				mCurSingStage;

	float                   mfKtvErr;
	float                   mfGameErr;

	LyricRender *           lyric_render;
	WaveRender *            wave_render;
	SentenceRender *        sentence_render;


	// ���������
	//AudioModule *           audio_module;
	//¼��
	CWZ_WaveUnit*		m_WavRecorder;
	//eval *                  eval_module;
	_tRealtimeGrade         mCallbackRealtimeGrade[16];
	uint                    mnCallbackRealtimeGradeCount;

	_tSentenceGrade         mCallbackSentenceGrade[8];
	uint                    mnCallbackSentenceGradeCount;


	_tSongInfo              mSongInfo;
	std::string				mfileName;
	std::string				m_textureName;
	std::string				m_dataDir;

	CGSize						m_windowsize;
};


