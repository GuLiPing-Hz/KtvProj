
//  ImgsetMgr.h
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012�� 9158. All rights reserved.
//
#pragma once
#include "../Opengl.h"
#include "Imageset.h"

typedef std::map<std::wstring,Imageset *>	MAPMUTABLEIMAGESET;

class ImgsetMgr
{
public:
	ImgsetMgr();
	~ImgsetMgr();


	static ImgsetMgr * getSingleton();
	//����ͼ��
	Imageset * addImageSet(const CGSize& winsize,const std::wstring& imgset_name);//����FreeTypeFont ͼ��
	Imageset * addImageSet (const CGSize& winsize,const std::string& dataDir,const std::string& imgset_name);//��ͨ����ͼ��
	void renderAll();//

	Imageset* getImageset(const std::string& imgset_name);
	Imageset* getImageset(const std::wstring& imgset_name);

	Image*		  getImage(const std::string& imgset_name ,const std::string& img_name);
	Image*		  getImage(const std::wstring& imgset_name ,const std::wstring& img_name);

private:
	void ClearMapImageset();

private:
	static ImgsetMgr					cls_ImgsetMgr;
	MAPMUTABLEIMAGESET  m_Imagesets;
	CGSize									m_windowsize;
};

 

