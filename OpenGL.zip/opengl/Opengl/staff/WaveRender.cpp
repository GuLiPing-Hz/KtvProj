//
//  WaveRender.cpp
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012�� 9158. All rights reserved.
//
#include "../stdafx.h"
#include "WaveRender.h"
#include "ImgsetMgr.h"
#include "KKType.h"

//-----------------------------------------------------------------------------
// ���캯��
WaveRender::WaveRender(CGSize & window_size)
: m_WindowSize(window_size)
, mfStartPos( 0.0f)
, mLyricCursorPos( 149.8125f, 1.0f)
, mLyricLastCursorPos( mLyricLastCursorPos )
, mLyricCursorInfo( mfStartPos, -1.0f, false, RANK_GREEN )//_tGuiLyricCursorInfo::
, mbKtvMode( true )
,m_head_img(NULL)
,m_headsep_img(NULL)
, mImageWaveLeft0( NULL )
, mImageWaveMiddle0( NULL )
, mImageWaveRight0( NULL )
, mImageWaveLeft1( NULL )
, mImageWaveMiddle1( NULL )
, mImageWaveRight1( NULL )
, mImageWaveLeft2( NULL )
, mImageWaveMiddle2( NULL )
, mImageWaveRight2( NULL )
, mImageWaveLeft3( NULL )
, mImageWaveMiddle3( NULL )
, mImageWaveRight3( NULL )
, mImageWave( NULL )
, mbEnableWaveEffect( false )
, mImageWaveTrans( true, CTransParams::TRANS_ALPHA, 0.0f, 1.0f, 0.0f, 1.0f )
, mbEnableMoveImage( false )
, mbInvalidate( false )
{

	//����ͷ��
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"GameBkg" ) )
		m_head_img = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"GameBkg" );

	//����ͷ���ָ�
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"GameBkgSeperator" ) )
		m_headsep_img = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"GameBkgSeperator" );

	// ��׼������WaveYellowL
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveYellowL" ) )
		mImageWaveLeft0 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveYellowL" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveYellowM" ) )
		mImageWaveMiddle0 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveYellowM" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveYellowR" ) )
		mImageWaveRight0 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveYellowR" );

	// ���߹⻷WaveBlueL
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveBlueL" ) )
		mImageWaveLeft1 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveBlueL" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveBlueM" ) )
		mImageWaveMiddle1 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveBlueM" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveBlueR" ) )
		mImageWaveRight1 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveBlueR" );

	// �質�Ŀ��׵�����WaveLightBlueL
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveLightBlueL" ) )
		mImageWaveLeft2 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveLightBlueL" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveLightBlueM" ) )
		mImageWaveMiddle2 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveLightBlueM" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveLightBlueR" ) )
		mImageWaveRight2 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveLightBlueR" );

	// �����׵�����WaveYellowL
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveYellowL" ) )
		mImageWaveLeft3 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveYellowL" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveYellowM" ) )
		mImageWaveMiddle3 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveYellowM" );
	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveYellowR" ) )
		mImageWaveRight3 = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveYellowR" );

	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"WaveBlueM" ) )
		mImageWave = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"WaveBlueM" );

	if ( ImgsetMgr::getSingleton()->getImageset( L"renderer" )->isDefined( L"SentenceLine" ) )//��β��
	{
		mImageSentenceLine =  ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"SentenceLine" );
		mImageSentenceLineWidth = mImageSentenceLine->getWidth();
		mImageSentenceLineHeight = mImageSentenceLine->getHeight();
	}

	// �����еĹ����Ч
	mMoveImage = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"Slider" );

	/*mStarImages[0] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar1" );
	mStarImages[1] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar2"  );
	mStarImages[2] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar3"  );
	mStarImages[3] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar4"  );
	mStarImages[4] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar5"  );
	mStarImages[5] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar6"  );
	mStarImages[6] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar7"  );
	mStarImages[7] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar8"  );
	mStarImages[8] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar9"  );
	mStarImages[9] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar10" );
	mStarImages[10] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar11" );
	mStarImages[11] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar12" );
	mStarImages[12] = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( L"ImageEffectStar13" );*/

	mStarEffectVect.clear();
}

//-----------------------------------------------------------------------------
// ��������
WaveRender::~WaveRender()
{

}
void WaveRender::invalidate()
{
    mbInvalidate = true;
}

//-----------------------------------------------------------------------------
// ��������ģʽ�Ƿ�ΪKTVģʽ(����ģʽ:KTVģʽ,��Ϸģʽ)
void WaveRender::setMode( bool ktv_mode )
{
	mbKtvMode = ktv_mode;
}

//-----------------------------------------------------------------------------
// ��������
void WaveRender::setLineGroup( const VECTORGUIPITCHVECT & wave_list, bool refresh/* = false*/ )
{
	//writeLog("WaveRender::setLineGroup enter");
	// ���ñ�׼����
	mVecWave = wave_list;
	// ����ǹ���Ч
	mStarEffectVect.clear();
	if ( refresh )
	{
		invalidate();
	}
}

//-----------------------------------------------------------------------------
void WaveRender::setStandardY( int y )
{
	mStandard_y = y;
}

//-----------------------------------------------------------------------------
// �����α�
void WaveRender::setLyricCursor( const _tGuiLyricCursorInfo & ci, float ktvErr, float gameErr )
{
	//writeLog("WaveRender::setLyricCursor enter");
	mfKtvErr = ktvErr;
	mfGameErr = gameErr;
	if ( mbKtvMode )
	{
		//mVevCursors.push_back( ci );
		_dealWithCursor( ci );
	}
	else
	{
		static float h = ( float )mImageWave->m_rect.size.height;			// Image�߶�

		mLyricCursorInfo = ci;
		mLyricCursorInfo.y = ci.y / h * h;
		if ( (mLyricCursorInfo.y-mfGameErr) <= mStandard_y && (mLyricCursorInfo.y+mfGameErr) >= mStandard_y )
		{
			mLyricCursorInfo.y = mStandard_y;
		}
	}

	invalidate();
}

//-----------------------------------------------------------------------------
// ���õ����ƶ�
void WaveRender::setMovePos( float position )
{
	mfStartPos = position;
	invalidate();
}

void WaveRender::clearLyricCursor()
{
	mVevCursors.clear();
}

//-----------------------------------------------------------------------------
// ���þ�β��
void WaveRender::setSentenceLineList( const LISTSENTENCELINEVECT & sentenceline_list, bool refresh/* = false*/ )
{
	//writeLog("WaveRender::setSentenceLineList enter");
	mSentenceLineList = sentenceline_list;
}

//-----------------------------------------------------------------------------
// update 
void WaveRender::updateSelf(float elapsed)
{
	// ���߹⻷��˸
	if ( mbKtvMode && mbEnableWaveEffect )
	{
		if ( !mImageWaveTrans.isEnd() )
		{
			mImageWaveTrans.trans( elapsed );
		}
	}

	if ( mbKtvMode && mStarEffectVect.size() > 0 )
	{
		TRANSPARAM_VECT::iterator it;
		for ( it = mStarEffectVect.begin(); it != mStarEffectVect.end(); )
		{
			int & _index = it->first;
			CTransParams & _trans_params = it->second;
			if ( _trans_params.isEnd() )
			{ 
				it = mStarEffectVect.erase( it );
			}
			else
			{
				_trans_params.trans( elapsed );
				++ it;
			}
		}
	}
}
//-----------------------------------------------------------------------------
// ������������
void WaveRender::reset()
{
	mVecWave.clear();
	mVevCursors.clear();
	mfStartPos = 0.0f;
	mLyricCursorInfo.x = mLyricCursorInfo.y = 0.0f;
	mLyricCursorInfo.r = RANK_NONE;
	mSentenceLineList.clear();
	mLyricCursorPos.x = mLyricCursorPos.y = 0.0f;
	mLyricLastCursorPos.x = mLyricLastCursorPos.y = 0.0f;
    
	ImgsetMgr::getSingleton()->getImageset( L"renderer" )->clear();
}

//-----------------------------------------------------------------------------
// ����/�ر����߹⻷��Ч
void WaveRender::enableWaveEffect( bool enable/* = true*/ )
{
	mbEnableWaveEffect = enable;
}

//-----------------------------------------------------------------------------
void WaveRender::populateGeometryBuffer()
{
	//writeLog("WaveRender::populateGeometryBuffer enter");
	ImgsetMgr::getSingleton()->getImageset( L"renderer" )->clear();

    if ( !mbInvalidate )
    {
        return;
    }
    
	if ( mbKtvMode )
	{
		// ��ʵʱ����
		_drawPitch( mVecWave );

		// �����
		_drawCursor();
	}
	else
	{
		// ������ͷ��
		if ( m_head_img )
		{
			CGPoint pos( 0.0f, STAFF_HEIGHT );
			CGSize sz = CGSizeMake( m_WindowSize.width, m_head_img->getHeight() );
			m_head_img->draw( pos, sz, NULL, COLOR_RECT_WHITE );
		}

		// ������ͷ�ָ�
		if ( m_headsep_img )
		{
			CGPoint pos( m_WindowSize.width*SING_START_B, STAFF_HEIGHT+1.0f );
			m_headsep_img->draw( pos, NULL, COLOR_RECT_WHITE );
		}


		// ������
		_drawPitch( mVecWave );

		// ����β��
		_drawSentenceLine( mSentenceLineList );

		// �����
		_drawCursor();
	}
}

//-----------------------------------------------------------------------------
// ���ƾ�β��
void WaveRender::_drawSentenceLine( const LISTSENTENCELINEVECT & sentenceline_list )
{
	//writeLog("WaveRender::_drawSentenceLine enter");
	CGSize & rt = m_WindowSize;
	int x = 0;
	static KKColorRect c2( KKColor(0x88888888) );

	LISTSENTENCELINEVECT::const_iterator i;
	for( i = sentenceline_list.begin(); i != sentenceline_list.end(); ++i )
	{
		x = *i;
		if ( x >= 0 && x < rt.width )
		{
			mImageSentenceLine->draw( CGPoint(x, STAFF_HEIGHT ), CGSize( mImageSentenceLineWidth, mImageSentenceLineHeight*1.66), NULL, c2 );
		}
	}
}

//-----------------------------------------------------------------------------
// ������Ϸģʽ���
void WaveRender::_drawCursor()
{
	//writeLog("WaveRender::_drawCursor enter");
	if ( mbKtvMode )
	{
		CGSize & sz = m_WindowSize;

		if ( !mImageWaveMiddle2 || !mImageWaveRight2 || !mImageWaveLeft2 || 
			!mImageWaveMiddle3 || !mImageWaveRight3 || !mImageWaveLeft3 ||
			!mMoveImage )
		{// û����Ӧ��Image
			return;
		}

		// �ƶ�����λ��
		CGPoint move_pos( 0.0f, STAFF_HEIGHT );

		// ���׵�����ͼƬ����
		static float h = mImageWaveMiddle2->getHeight();
		static float hh = h / 2;
		static float lw = mImageWaveLeft2->getWidth();
		static float rw = mImageWaveRight2->getWidth();

		// �����׵�����ͼƬ����
		static float h_s = mImageWaveMiddle3->getHeight();
		static float hh_s = h_s / 2;
		static float lw_s = mImageWaveLeft3->getWidth();
		static float rw_s = mImageWaveRight3->getWidth();

		bool bfirst = true, bMiddle = false, bEnd = false;
		float width = 0.0f;
		std::vector< _tGuiLyricCursorInfo>::iterator it, it_next;
		for ( it = mVevCursors.begin(); it != mVevCursors.end(); ++it )
		{
			mLyricCursorInfo = (*it);
			CGPoint pos, next, tmp;

			pos.x = mLyricCursorInfo.x;
			pos.y = mLyricCursorInfo.y;

			it_next = it + 1;
			if ( it_next != mVevCursors.end() )
			{
				next.y = it_next->y;
				if ( (int)next.y == (int)pos.y )
				{
					static Image * _il = NULL;
					static Image * _im = NULL;
					static Image * _ir = NULL;

					static float _h = 0.0f;
					static float _hh = 0.0f;
					static float _lw = 0.0f;
					static float _rw = 0.0f;

					static float _alpha = 1.0f;

					if ( mLyricCursorInfo.b )
					{// ����
						_il = mImageWaveLeft2;
						_im = mImageWaveMiddle2;
						_ir = mImageWaveRight2;

						_h = h;
						_hh = hh;
						_lw = lw;
						_rw = rw;

						_alpha = 1.0f;

						move_pos.x = it_next->x;
						move_pos.y = it_next->y;

						mbEnableMoveImage = true;
					}
					else
					{// ������
						_il = mImageWaveLeft3;
						_im = mImageWaveMiddle3;
						_ir = mImageWaveRight3;

						_h = h_s;
						_hh = hh_s;
						_lw = lw_s;
						_rw = rw_s;

						_alpha = 0.5f;

						move_pos.x = 0.0f;
						move_pos.y = 0.0f;

						mbEnableMoveImage = false;
					}
					// float dest_width = ((*it_next).x - (*it).x) * (sz.d_width - 6);
					float dest_width = (*it_next).x - (*it).x;
					pos.y -= _hh;
					KKColorRect cr( KKColor( 1.0f, 1.0f, 1.0f, _alpha ) );
					if ( dest_width > ( _lw + _rw ) )
					{
						width = _lw;
						_il->draw( pos, CGSize( _lw, _h ), NULL, cr );

						// width  = ((*it_next).x - (*it).x) * (sz.d_width - 6);
						width  = (*it_next).x - (*it).x;
						width -= _rw;
						width -= _lw;
						pos.x += _rw;
						_im->draw( pos, CGSize( width, _h ), NULL, cr );
						pos.x += width;
						_ir->draw( pos, CGSize( rw, _h ), NULL, cr );
					}
					else if ( dest_width >= 10.0f )
					{
						float draw_width = dest_width * 0.5f;
						CGRect clip_rect_left( pos, CGSize(draw_width,_h));
						_il->draw( pos, 
							CGSize( _lw, _h ), &clip_rect_left, cr );

						CGRect clip_rect_right(CGPoint( pos.x + draw_width, pos.y ), CGSize(draw_width,_h));
						_ir->draw( CGPoint( pos.x + dest_width - _rw, pos.y ),
							CGSize( _rw, _h ), &clip_rect_right, cr );

						pos.x += draw_width;
					}
				}
			}
		}

		if ( mbEnableMoveImage )
		{
			static float mw = mMoveImage->getWidth();
			static float mhh = mMoveImage->getHeight() * 0.5;
			mMoveImage->draw( CGPoint( move_pos.x - mw, move_pos.y - mhh ), NULL );
		}

		if ( mStarEffectVect.size() > 0 )
		{
			TRANSPARAM_VECT::iterator i;
			for( i = mStarEffectVect.begin(); i != mStarEffectVect.end(); ++i )
			{
				int & _index = i->first;
				CTransParams & _trans_params = i->second;

				float fAngle = _trans_params.getAngle();
				int _star_image_index = ( int )( fAngle * mnStarImageCount );

				if ( _star_image_index >= mnStarImageCount )_star_image_index = mnStarImageCount - 1;
				else if ( _star_image_index < 0 )_star_image_index = 0;

				if ( mStarImages[ _star_image_index ] )
				{
					float sw = mStarImages[ _star_image_index ]->getWidth();
					float sh = mStarImages[ _star_image_index ]->getHeight();
					float shh = sh / 2;

					if ( _index >= 0 && _index < mVecWave.size() )
					{
						_tGuiWaveInfo* & wi = mVecWave[ _index ];

						CGSize _size( sw * _trans_params.getScale(), sh * _trans_params.getScale() );
						CGPoint pos( wi->r - sw + ( sw - _size.width ) * 0.5, wi->y - sh + ( sh - _size.height ) * 0.5 );
						KKColorRect cr( KKColor( 1.0, 1.0, 1.0, _trans_params.getAlpha() ) );
						mStarImages[ _star_image_index ]->draw( pos, _size, NULL, cr );
					}
				}
			}
		}
	}
	else
	{//////////////////////////////////////////////////////////////////////////
		static wchar_t * GRankCursorImagNames[] = { L"", L"CursorRed", L"CursorYellow", L"CursorGreen", L"", L"", L"", L"" };
		const wchar_t * rank_coursor_name = GRankCursorImagNames[ mLyricCursorInfo.r ];

		Image * cursor_img = NULL;
		if ( wcslen(rank_coursor_name) )//!rank_coursor_name.empty()
		{
			cursor_img = ( Image * )ImgsetMgr::getSingleton()->getImageset( L"renderer" )->getImage( rank_coursor_name );
		}

		if ( cursor_img )
		{
			CGPoint pos;
			pos.x = mLyricCursorInfo.x;
			pos.y = STAFF_HEIGHT+mLyricCursorInfo.y - ( cursor_img->getHeight()/2 );

			cursor_img->draw( pos, NULL, COLOR_RECT_WHITE );
		}
	}
}

//-----------------------------------------------------------------------------
// ��������
void WaveRender::_drawPitch( VECTORGUIPITCHVECT & waves )//const 
{
	//writeLog("WaveRender::_drawPitch enter");
	CGSize & rt = m_WindowSize;
	CGPoint l( 0.0f, 0.0f );
	CGPoint r( 0.0f, 0.0f );

	if ( mbKtvMode )
	{
		static int h = ( ( int )mImageWaveMiddle0->getHeight() );				// Image�ĸ߶�( ������ һ��)
		static int hh = h / 2;													// Imageһ��ĸ߶�( ������ һ��)
		static int lw = ( int )mImageWaveLeft0->getWidth();
		static int rw = ( int )mImageWaveRight0->getWidth();

		static int h1 = ( ( int )mImageWaveMiddle1->getHeight() );				// Image�ĸ߶�( ������ һ��)
		static int hh1 = h1 / 2;												// Imageһ��ĸ߶�( ������ һ��)
		static int lw1 = ( int )mImageWaveLeft1->getWidth();
		static int rw1 = ( int )mImageWaveRight1->getWidth();

		VECTORGUIPITCHVECT::iterator i;//const_
		for( i = waves.begin(); i != waves.end(); ++i )
		{
			_tGuiWaveInfo* & wave = *i;//const
			l.x = wave->l;
			r.x = wave->r;

			l.y = r.y = wave->y - hh;		// ��ȥmImageWaveMiddle0��һ��߶� 21 * 0.5

			l.x = ( l.x > 0 ) ? l.x : WAVE_EFFECT_WIDTH;
			r.x = ( r.x < rt.width ) ? r.x : rt.width - WAVE_EFFECT_WIDTH;

			float dest_width = r.x - l.x;

			if ( dest_width > (lw + rw) )
			{
				float width = r.x - l.x - lw - rw;
				mImageWaveMiddle0->draw( CGPoint( l.x + lw, l.y ), 
					CGSize( (width> 0 ? width : 0 ), h ), NULL, COLOR_RECT_WHITE );
				mImageWaveLeft0->draw( CGPoint(l.x, l.y ),
					CGSize( lw, h ),NULL, COLOR_RECT_WHITE );
				mImageWaveRight0->draw( CGPoint(r.x - rw, l.y ),
					CGSize( lw, h ),NULL, COLOR_RECT_WHITE );
			}
			else if ( dest_width >= 10.0f )
			{
				float draw_width = ( float )( ( int )( dest_width * 0.5f ) );
				CGRect clip_rect_left(CGPoint(l.x, l.y ), CGSize(draw_width,h));
				CGRect clip_rect_right(CGPoint(l.x + draw_width, l.y ), CGSize(draw_width,h));
				mImageWaveLeft0->draw( CGPoint(l.x , l.y ),
					CGSize( lw, h ), &clip_rect_left, COLOR_RECT_WHITE );
				mImageWaveRight0->draw( CGPoint(r.x - rw, l.y ),
					CGSize( rw, h ), &clip_rect_right, COLOR_RECT_WHITE );
			}

			// ���⻷
			float falpha = mImageWaveTrans.getAlpha();
			if ( falpha > 1.0f )
				falpha = 1.0f;
			else if ( falpha <= 0.0f )
				falpha = 0.01f;

			KKColorRect cr( KKColor( 1.0, 1.0, 1.0, falpha ) );
			if ( mbEnableWaveEffect )
			{
				CGPoint l1( 0.f, 0.f );
				CGPoint r1( 0.f, 0.f );
				// �⻷��ʾ��λ��
				l1.y = r1.y = wave->y - hh1;		// ��ȥmImageWaveMiddle0��һ��߶� 23 * 0.5

				l1.x = l.x - 1;
				r1.x = r.x - 1;

				float dest_width1 = r1.x - l1.x;

				if ( dest_width1 > (lw1 + rw1) )
				{
					float width = r1.x - l1.x - lw1 - rw1;
					mImageWaveMiddle1->draw( CGPoint( l1.x + lw1, l1.y ), 
						CGSize( (width> 0 ? width : 0 ), h1 ), NULL, cr );
					mImageWaveLeft1->draw( CGPoint(l1.x, l1.y ),
						CGSize( lw1, h1 ),NULL, cr );
					mImageWaveRight1->draw( CGPoint(r1.x - rw1, l1.y ),
						CGSize( lw1, h1 ),NULL, cr );
				}
				else if ( dest_width1 >= 10.0f )
				{
					float draw_width = ( float )( ( int )( dest_width1 * 0.5f ) );
					CGRect clip_rect_left(CGPoint(l1.x, l1.y ), CGSize(draw_width,h1));
					CGRect clip_rect_right(CGPoint(l1.x + draw_width, l1.y ), CGSize(draw_width,h1));
					mImageWaveLeft0->draw( CGPoint(l1.x , l1.y ),
						CGSize( lw1, h1 ), &clip_rect_left, cr );
					mImageWaveRight0->draw( CGPoint(r1.x - rw1, l1.y ),
						CGSize( rw1, h1 ), &clip_rect_right, cr );
				}
			}
		}
	}
	else
	{
		static int h = ( int )mImageWave->getHeight();			// mImageWave�߶�
		static int hh = h / 2;									// mImageWaveһ��ĸ߶�

		//std::vector< _tGuiWaveInfo >::const_iterator i;
		VECTORGUIPITCHVECT::iterator i;//const_
		for( i = waves.begin(); i != waves.end(); ++i )
		{
			_tGuiWaveInfo* & wave = *i;//const 
			int left = wave->l;
			int right = wave->r;
			if ( left >= 0 || right >= 0 )
			{
				if ( left < 0 )
				{
					left = 0;
				}

				l.x = left;
				r.x = right;
				l.y = r.y = wave->y - hh;					// ��ȥmImageWave��һ��߶� 10 * 0.5

				float width = 0.0f;
				if ( r.x <= rt.width )
				{
					width = r.x - l.x;
				}
				else
				{
					width = rt.width - l.x;
				}
				mImageWave->draw( CGPoint( l.x, l.y ), CGSize( (width > 0 ? width : 0 ), h ), NULL );

				if ( l.x >= rt.width )
				{
					break;
				}
			}
		}
	}
}

//--------------------------------------------------------------------------
// �����α����λ��
void WaveRender::_locateCursor()
{
	static float h = ( float )mImageWave->getHeight();			// Image�߶�
	CGSize & sz = m_WindowSize;
	mLyricCursorPos.x = mLyricCursorInfo.x * sz.width;
	mLyricCursorPos.y = ( sz.height - 4*h ) * mLyricCursorInfo.y + 2*h;
}

//--------------------------------------------------------------------------
//�����α�
void WaveRender::_dealWithCursor(  const _tGuiLyricCursorInfo & ci  )
{
	int size = mVevCursors.size();

	static int h = ( int )mImageWaveLeft3->getHeight();						// mImageWaveLeft3�߶�
	static int hh = ( ( int )mImageWaveLeft2->getHeight() ) / 2;			// mImageWaveLeft2һ��ĸ߶�
	
	_tGuiLyricCursorInfo _ci( ci.x, ci.y, ci.b, ci.r );
	
	bool bfind = false;
	bool b = false;															// �Ƿ����ڱ�׼���ߵ�ĳ��������
	int ici = ( ( int )( ci.y / h ) ) * h;
	static _tGuiWaveInfo  li;

	//std::vector< _tGuiWaveInfo >::const_iterator i;
	VECTORGUIPITCHVECT::iterator i;//const_
	for( i = mVecWave.begin(); i != mVecWave.end(); ++i )
	{//�鿴�Ƿ����ڱ�׼���ߵ�ĳ�������ڣ�����ǣ�����YֵΪ��׼���ߵ�Yֵ��
		_tGuiWaveInfo* & wi = *i;//const 
		if ( ci.x >= wi->l && ci.x <= wi->r && wi->r - wi->l >= 10 )
		{
		
			bfind = true;
			int temp = ci.y - wi->y;
			if ( temp >= -mfKtvErr && temp <= mfKtvErr )
			{
				li = *wi;//////////////////////////////////////////////////////////////////////////
				ici = wi->y;
				b = true;
			}
		}

		if ( bfind )
		{
			break;
		}
	}

	_ci.y = ici;
	_ci.b = b;

	if ( size >= 2 )
	{
		_tGuiLyricCursorInfo & c = mVevCursors[size-1];
		_tGuiLyricCursorInfo & l = mVevCursors[size-2];

		if ( c.y == l.y && l.y == ici )
		{
			mVevCursors[size-1] = _ci;
		}
		else
		{
			if ( c.x != _ci.x )
			{
				if ( c.y == _ci.y )
				{
					mVevCursors.push_back( _ci );
				}
				else
				{
					if ( c.b == true && _ci.b == false )
					{
						if ( _ci.x > li.r )
						{
							_tGuiLyricCursorInfo & w = c;
							w.x = li.r;
							_tGuiLyricCursorInfo & z = _ci;
							z.x = li.r;
							mVevCursors.push_back( w );
							mVevCursors.push_back( z );
							mVevCursors.push_back( _ci );
						}
						else
						{
							_tGuiLyricCursorInfo & w = c;
							w.x = _ci.x;
							mVevCursors.push_back( w );
							mVevCursors.push_back( _ci );
						}
					}
					else
					{
						_tGuiLyricCursorInfo & w = c;
						w.x = _ci.x;
						mVevCursors.push_back( w );
						mVevCursors.push_back( _ci );
					}
					
				}
			}
		}
	}
	else if ( size >= 1 )
	{
		_tGuiLyricCursorInfo & c = mVevCursors[size-1];
		if ( c.x != _ci.x )
		{
			if ( c.y == _ci.y )
			{
				mVevCursors.push_back( _ci );
			}
			else
			{
				if ( c.b == true && _ci.b == false )
				{
					if ( _ci.x > li.r )
					{
						_tGuiLyricCursorInfo & w = c;
						w.x = li.r;
						_tGuiLyricCursorInfo & z = _ci;
						z.x = li.r;
						mVevCursors.push_back( w );
						mVevCursors.push_back( z );
						mVevCursors.push_back( _ci );
					}
					else
					{
						_tGuiLyricCursorInfo & w = c;
						w.x = _ci.x;
						mVevCursors.push_back( w );
						mVevCursors.push_back( _ci );
					}
				}
				else
				{
					_tGuiLyricCursorInfo & w = c;
					w.x = _ci.x;
					mVevCursors.push_back( w );
					mVevCursors.push_back( _ci );
				}
			}
		}
	}
	else
	{
		mVevCursors.push_back( _ci );
	}
}
