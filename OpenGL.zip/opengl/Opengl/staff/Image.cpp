//
//  Image.h
//
//  Created by ��� on 12-8-21.
//
//
#include "../stdafx.h"
#include "Image.h"
#include "Imageset.h"

Image::Image()
{

}

Image::Image(CGRect rect,Imageset* imgset)
{
	m_rect = rect;
	m_imgset = imgset;
}

Image::~Image()
{
    //SAFE_DELETE(m_imgset);
}

const int & Image::getWidth() const
{
	return m_rect.size.width;
}

const int & Image::getHeight() const
{
	return m_rect.size.height;
}

void Image::SetPoint(CGPoint point)
{
	m_offset = point;
}

void Image::SetRect(CGRect rect)
{
	m_rect = rect;
}
void Image::SetImageset(Imageset* imgset)
{
	if (imgset)
	{
		m_imgset = imgset;		
	}
}

void Image::draw(const CGRect& dest_rect,CGRect* pclip_rect,const KKColorRect& color_rect)
{
	if (m_imgset)
	{
		m_imgset->draw(m_rect , dest_rect , pclip_rect , color_rect );
	}   
}

void Image::draw(const CGPoint& dest_point,const CGSize& dest_size,CGRect* pclip_rect,const KKColorRect& color_rect)
{
	CGRect rect(dest_point,dest_size);
	draw(rect,pclip_rect,color_rect);
}

void Image::draw(const CGPoint& dest_point,CGRect* pclip_rect,const KKColorRect& color_rect)
{
	if (m_imgset)
	{
		CGRect dest_rect = CGRectMake(dest_point,m_rect.size);
		m_imgset->draw(m_rect , dest_rect , pclip_rect , color_rect );
	}   
}

/*
void Image::draw(CGPoint& dest_point,CGRect* pclip_rect)
{
	draw(dest_point,pclip_rect,COLOR_RECT_WHITE);//��ɫ��
}*/

/*
// called once every frame
-(void)render//:(CGFloat *)vetex andcolors:(CGFloat *)colors
{
	glVertexPointer(vertexSize, GL_FLOAT, 0, vertexes);
	glEnableClientState(GL_VERTEX_ARRAY);
	glColorPointer(colorSize, GL_FLOAT, 0, colors);
	glEnableClientState(GL_COLOR_ARRAY);
	////////////////////////////////////
    
	if (materialKey != NULL) {
		[[BBMaterialController sharedMaterialController] bindMaterial:materialKey];
        //���ò��ʿ������԰󶨲��ʡ�
        //GL_TEXTURE_COORD_ARRAY,uvCoordinates������һ��������ʾ��ν�����ͼ��ӳ�䵽��������֡�
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        //ȷ�������������顣
		glTexCoordPointer(2, GL_FLOAT, 0, uvCoordinates);
        //�����UV���ꡣ
	}
     ////////////////////////////////
    //NSLog(@"add is %i",funadd(10, 10));
    
    FT_Library library;
    FT_Face face;
    
    FT_Error error = FT_Init_FreeType( &library );
    
    error = FT_New_Face( library, "/Users/tiange01/Desktop/simhei.ttf", 0, &face );
    
    error = FT_Set_Char_Size(face, // handle to face object 
                             0, // char_width in 1/64th of points
                             16*64, // char_height in 1/64th of points 
                             300, // horizontal device resolution 
                             300 ); // vertical device resolution 
    
    error = FT_Set_Pixel_Sizes(face, // handle to face object 
                               0, // pixel_width 
                               16 ); // pixel_height 
    //while (<#condition#>) {
    
    const wchar_t *  charcode=L"��";
    FT_UInt glyph_index = FT_Get_Char_Index( face, *charcode );
    //}
    
    
    FT_Int32 load_flags = FT_LOAD_DEFAULT;
    error = FT_Load_Glyph(face, // handle to face object 
                          glyph_index, // glyph index 
                          load_flags ); // load flags, see below 
    
    //FT_Render_Mode render_mode = FT_RENDER_MODE_NORMAL;
    //error = FT_Render_Glyph( face->glyph, // glyph slot 
    //  render_mode ); // render mode 
    
    if (face->glyph->format != FT_GLYPH_FORMAT_BITMAP) {
        error = FT_Render_Glyph(face->glyph, FT_RENDER_MODE_NORMAL);
    }
    
    //error = FT_Set_Transform( face,  target face object
    // NULL,//&matrix, //pointer to 2x2 matrix
    //NULL);//&delta ); //pointer to 2d vector
    
    GLubyte *spriteData;
    
    size_t width,height;
    width = face->glyph->bitmap.width;
    height = face->glyph->bitmap.rows;
    FT_Bitmap *glyph_bitmap = &face->glyph->bitmap;
    
    
    spriteData = (GLubyte *) malloc(width * height * 4);
    memset(spriteData, 0, (width * height * 4));
    
    for (int i = 0; i < height; ++i)
    {
        unsigned char *src = glyph_bitmap->buffer + (i * glyph_bitmap->pitch);
        //switch (glyph_bitmap->pixel_mode)
        //{
        //   case FT_PIXEL_MODE_GRAY:
        // {
        
        //unsigned char *dst = reinterpret_cast<unsigned char*>(buffer);
        for (int j = 0; j < width; ++j)
        {
            // RGBA
            *spriteData++ = 0xFF;
            *spriteData++ = 0xFF;
            *spriteData++ = 0xFF;
            *spriteData++ = *src++;
        }
        //}
        //break;
        
        //case FT_PIXEL_MODE_MONO:
        //    for (int j = 0; j < glyph_bitmap->width; ++j)
        //       buffer [j] = (src [j / 8] & (0x80 >> (j & 7))) ? 0xFFFFFFFF : 0x00000000;
        //  break;
        
        //default:
        //   CEGUI_THROW(InvalidRequestException("Font::drawGlyphToBuffer: "
        //                                       "The glyph could not be drawn because the pixel mode is "
        //                                       "unsupported."));
        //   break;
        //}
        
        //buffer += buf_width;
    }
    
    GLuint _texture; // declared as un instance variable so its address never changes
    glGenTextures(1, &_texture);
    glBindTexture(GL_TEXTURE_2D, _texture);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, spriteData);
    free(spriteData);
    
    
    glEnable(GL_TEXTURE_2D); //��������
	glBindTexture(GL_TEXTURE_2D, _texture);
    uvCoordinates = (CGFloat *)malloc(8*sizeof(CGFloat));
    uvCoordinates[0] = 0;
	uvCoordinates[1] = 1;
	
	uvCoordinates[2] = 1;
	uvCoordinates[3] = 1;
	
	uvCoordinates[4] = 0;
	uvCoordinates[5] = 0;
    
	uvCoordinates[6] = 1;
	uvCoordinates[7] = 0;
    
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, uvCoordinates);
    
    free(uvCoordinates);
	//render
	glDrawArrays(renderStyle, 0, vertexCount);
    glDeleteTextures(1, &_texture);
}
*/

