//
//
//  Karaoke
//
//  Created by ���glp on 12-8-21.
//
//
#include "../stdafx.h"
//#include <sys/time.h>
#include "SceneMgr.h"
#include "../input/InputViewController.h"
//#include "EAGLView.h"
#include "SceneObject.h"
#include "ImgsetMgr.h"

SceneMgr SceneMgr::cls_sceneMgr;

SceneMgr::SceneMgr(bool bLoop):
													m_bLoop(bLoop),
													m_durationMS(0)
{
	m_sceneObjects.clear();
	m_objectsToAdd.clear();
	m_objectsToRemove.clear();
}

SceneMgr::~SceneMgr()
{
	//[self stopAnimation];
	// hjp
	//[sceneObjects release];
	ClearListObject(m_sceneObjects);
	//[objectsToAdd release];
	ClearListObject(m_objectsToAdd);
	//[objectsToRemove release];
	ClearListObject(m_objectsToRemove);
	//[openGLView release];
	//[animationTimer release];
	//[m_inputController release];
	SAFE_DELETE(m_inputController);//?�����¼���
	SAFE_DELETE(m_inputController);
	//[levelStartDate release];
}

void SceneMgr::ClearListObject(LISTSCENEOBJECT& listObject)
{
	if (!listObject.empty())
	{
		LISTSCENEOBJECT::iterator i;
		for (i=listObject.begin();i!=listObject.end();i++)
		{
			SAFE_DELETE(*i);
		}
	}
	listObject.clear();
}
// Singleton accessor.  this is how you should ALWAYS get a reference
// to the scene controller.  Never init your own. 
SceneMgr* SceneMgr::getSingleton()
{
   return &cls_sceneMgr;
}

bool SceneMgr::addObjectToAdd(SceneObject *object)
{
    object->m_active = TRUE;
    if (!object ->awake())
    {
		return false;
    }
    //[objectsToAdd addObject:object];
	m_objectsToAdd.push_back(object);
	return true;
}

void SceneMgr::addObjectToRemove(SceneObject *object)
{
    //[objectsToRemove addObject:object];
	m_objectsToRemove.push_back(object);
}

void SceneMgr::addObjectToScene()
{
	 if (!m_objectsToAdd.empty()) {
        /*[sceneObjects addObjectsFromArray:objectsToAdd];
        [objectsToAdd removeAllObjects];*/
		LISTSCENEOBJECT::iterator i;
		for (i=m_objectsToAdd.begin();i!=m_objectsToAdd.end();i++)
		{
			m_sceneObjects.push_back(*i);
		}
		m_objectsToAdd.clear();
    }
}

void SceneMgr::removeObjectFromScene()
{
   /* if (objectsToRemove == NULL) {
        objectsToRemove = [[NSMutableArray alloc] init];
        [objectsToRemove addObject:object];
    }*/
	if (!m_objectsToRemove.empty())
	{
		LISTSCENEOBJECT::iterator i;
		for (i=m_objectsToRemove.begin();i!=m_objectsToRemove.end();i++)
		{
			m_sceneObjects.remove(*i);
		}
		ClearListObject(m_objectsToRemove);
	}
}

// this is where we initialize all our scene objects
void SceneMgr::loadScene()
{
/*
	// this is where we store all our objects
	if (sceneObjects == NULL) sceneObjects = [[NSMutableArray alloc] init];
	[sceneObjects removeAllObjects];
	
	//Add a single scene object just for testing
	SceneObject * object = [[SceneObject alloc] init];
	[self addObjectToScene:object];
*/
// hjp
//	[object release];
    /*BBSpaceShip * ship = [[BBSpaceShip alloc] init];
    [ship awake];
	[self addObjectToScene:ship];
	[ship release];*/
}

//void SceneMgr::startScene()
//{
//	self.animationInterval = 1.0/60.0;
//	[self startAnimation];
//    // reset clock
//    startTimeInterval = CFAbsoluteTimeGetCurrent();
//}

void SceneMgr::gameLoop(ulong startTimeInterval)
{
	//writeLog("SceneMgr::gameLoop enter");
	if (m_bLoop)
	{
		 //�����κ��Ŷӵĳ�������
	   addObjectToScene();
	            
		curTimeInterval = timeGetTime();//CFAbsoluteTimeGetCurrent();
		unsigned int elapsed_ms = ( (unsigned int)( ( curTimeInterval - startTimeInterval )  ) - m_durationMS );//* 1000
		m_durationMS += elapsed_ms;
		/*char bufLog[256] = {0};
		sprintf(bufLog,"elapsed_ms : %d",elapsed_ms);
		writeLog(bufLog);*/
		/*NSNumber * ns_elapsed_ms = [[NSNumber alloc] initWithUnsignedInt:elapsed_ms];*/
	    
		/*
		static int last_duration_s = 0;
		int duration_s = (int)(durationSeconds);
		if ( duration_s != last_duration_s )
		{
			last_duration_s = duration_s;
			NSLog( @"duration_ms[%d].", duration_s );
		}
		*/
		
		realupdateModel(elapsed_ms);//ns_elapsed_ms

		// send our objects to the renderer
		renderScene();
	    
	    
		//ɾ���κ���Ҫɾ���Ķ���
	   removeObjectFromScene();
	}
}

void SceneMgr::realupdateModel(ulong ns_elapsed_ms)
{
	//writeLog("SceneMgr::realupdateModel enter");
	// simply call 'update' on all our scene objects
	//m_sceneObjects makeObjectsPerformSelector:@selector(update:) withObject: ns_elapsed_ms ];
	LISTSCENEOBJECT::const_iterator i;
	for (i=m_sceneObjects.begin();i!=m_sceneObjects.end();i++)
	{
		(*i)->realtime(ns_elapsed_ms);
		(*i)->update(ns_elapsed_ms);
	}
	// be sure to clear the events
	m_inputController->clearEvents();
}

void SceneMgr::endModel()
{
	LISTSCENEOBJECT::const_iterator i;
	for (i=m_sceneObjects.begin();i!=m_sceneObjects.end();i++)
	{
		(*i)->end();
	}
}

void SceneMgr::renderScene()
{
	// simply call 'render' on all our scene objects
	ImgsetMgr::getSingleton()-> renderAll();
}


// these methods are copied over from the EAGLView template

void SceneMgr::startAnimation()
{
	m_bLoop = true;
//    //������ʱ��
//	self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:animationInterval target:self selector:@selector(gameLoop) userInfo:NULL repeats:YES];
//    
//    //����һ�ַ�������ʾ���ӣ�Ӳ�������Ļص�������1��60����Ļˢ�µ�ʱ�����gameLoopһ��
//    //CADisplayLink *displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(gameLoop)];
//    //displayLink.FrameInterval = animationInterval;
//    //[displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
}

void SceneMgr::stopAnimation()
{
	m_bLoop = false;
	//self.animationTimer = NULL;
}

// - (void) SceneMgr::setAnimationTimer:(NSTimer *)newTimer {
// 	[animationTimer invalidate];
//     NSLog(@"set AnimationTimer");
// 	animationTimer = newTimer;
// }

// - (void) SceneMgr::setAnimationInterval:(NSTimeInterval)interval {	
// 	animationInterval = interval;
// 	if (animationTimer) {
// 		[self stopAnimation];
// 		[self startAnimation];
// 	}
// }




