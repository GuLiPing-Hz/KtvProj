//
//
//  Karaoke
//
//  Created by ���glp on 12-8-21.
//
//
#pragma once

#include <list>
#include <stdio.h>
#include <string.h>
#include <string>

#include "../Opengl.h"
class SceneObject;
class InputViewController;

typedef std::list<SceneObject*> LISTSCENEOBJECT;

class SceneMgr
{
public:
	SceneMgr(bool bLoop=true);
	~SceneMgr();

	static SceneMgr* getSingleton();
	void loadScene();
	//void startScene();
	void gameLoop(ulong startTimeInterval);
	void renderScene();
	//void setAnimationInterval(NSTimeInterval interval) ;
	//void setAnimationTimer(NSTimer *newTimer) ;
	void startAnimation() ;
	void stopAnimation() ;
	void realupdateModel(ulong  ns_elapsed_ms);
	void endModel();
	
	bool addObjectToAdd(SceneObject *object);
	void addObjectToRemove(SceneObject *object);
	

private:
	void addObjectToScene();
	void removeObjectFromScene();
	void ClearListObject(LISTSCENEOBJECT & listObject);
	
public:
	static SceneMgr cls_sceneMgr;
private:
	LISTSCENEOBJECT	m_sceneObjects;

	LISTSCENEOBJECT  m_objectsToAdd;
	LISTSCENEOBJECT  m_objectsToRemove;

	InputViewController * m_inputController;
	//EAGLView * openGLView;

	//NSTimer *animationTimer;
	//NSTimeInterval animationInterval;

	//NSTimeInterval deltaTime;
	//NSDate * levelStartDate;

	// ��ȡʱ��
	//CFTimeInterval          startTimeInterval;
	//CFTimeInterval          curTimeInterval;
	ulong								curTimeInterval;
	// ÿһ֡�ۼƵľ�ȷ�������ֵ
	unsigned int            m_durationMS;

	//����ѭ��
	bool		m_bLoop;
	CGSize m_windowsize;
};

