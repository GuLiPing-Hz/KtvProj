//
//  ImgsetMgr.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012�� 9158. All rights reserved.
//
#include "../stdafx.h"
#include "ImgsetMgr.h"
#include "Image.h"

ImgsetMgr ImgsetMgr::cls_ImgsetMgr;

ImgsetMgr::ImgsetMgr()//:m_windowsize(windowsize)
{
	m_Imagesets.clear();
}

ImgsetMgr::~ImgsetMgr()
{
	ClearMapImageset();
}

ImgsetMgr * ImgsetMgr::getSingleton()
{
    return &cls_ImgsetMgr;
}

Imageset * ImgsetMgr::getImageset(const std::string& imgset_name)
{
	wchar_t unicodeName[256] = {0};
	MultiByteToWideChar(CP_ACP,0,imgset_name.c_str(),-1,unicodeName,255);
	return getImageset(unicodeName);
}

Imageset * ImgsetMgr::getImageset(const std::wstring& imgset_name)
{
	if (m_Imagesets.empty())
	{
		return NULL;
	}
	MAPMUTABLEIMAGESET::const_iterator i;
	i=m_Imagesets.find(imgset_name);
	if (i!=m_Imagesets.end())
	{
		return i->second;
	}
	return NULL;
}

Image * ImgsetMgr::getImage(const std::string& imgset_name ,const std::string& img_name)
{
	wchar_t unicodeSetName[256] = {0};
	wchar_t unicodeName[256] = {0};
	MultiByteToWideChar(CP_ACP,0,imgset_name.c_str(),-1,unicodeSetName,255);
	MultiByteToWideChar(CP_ACP,0,img_name.c_str(),-1,unicodeName,255);
	return getImage(unicodeSetName,unicodeName);
}

Image * ImgsetMgr::getImage(const std::wstring& imgset_name ,const std::wstring& img_name)
{
    if (m_Imagesets.empty())
    {
		return NULL;
    }
	MAPMUTABLEIMAGESET::const_iterator i;
	i=m_Imagesets.find(imgset_name);
	if (i!=m_Imagesets.end())
	{
		Imageset * timgset = i->second;//////////////////////////////////////////////////////////////////////////
		return timgset->getImage(img_name);
	}
	return NULL;
    /*Imageset * imgset = [mImagesets valueForKey:imgset_name];
    return [imgset getImage:img_name];*/
}

Imageset * ImgsetMgr::addImageSet(const CGSize& winsize,const std::wstring& imgset_name)
{//ΪFreeType Font
	writeLog("ImgsetMgr::addImageSet ΪFreeType Font enter");
	if( imgset_name.size() != 0 )
	{
		MAPMUTABLEIMAGESET::iterator i;
		i = m_Imagesets.find(imgset_name);
		if (i!=m_Imagesets.end())
		{
			delete i->second;
			m_Imagesets.erase(i);//ȥ��ԭ���ġ�
		}
		Imageset * imgset = new Imageset(winsize);
		imgset->mImagesetName = "FreeTypeFont";
		m_Imagesets.insert(std::pair<std::wstring,Imageset*>(imgset_name,imgset));//add by glp
		return imgset;
	}
	return NULL;
}

Imageset * ImgsetMgr::addImageSet(const CGSize& winsize,const std::string& dataDir,const std::string& imgset_name)
{
    if( imgset_name.size() != 0 )
    {
        Imageset * imgset = new Imageset(winsize);
        if(!imgset->load(dataDir,imgset_name))
		{
			return NULL;
		}
		wchar_t unicodeImgset[256] = {0};//���ֲ�����255
		MultiByteToWideChar(CP_ACP,0,imgset_name.c_str(),-1,unicodeImgset,255);
		std::wstring wsImgset = unicodeImgset;
		MAPMUTABLEIMAGESET::iterator i;
		i = m_Imagesets.find(wsImgset);
		if (i!=m_Imagesets.end())
		{
			delete i->second;
			m_Imagesets.erase(i);//ȥ��ԭ���ġ�
		}
		m_Imagesets.insert(std::pair<std::wstring,Imageset*>(wsImgset,imgset));//add by glp
		return imgset;
    }
    return NULL;
}

void ImgsetMgr::renderAll()
{
    if (m_Imagesets.empty()) 
	{
        return;
    }
	MAPMUTABLEIMAGESET::iterator i;
    for ( i=m_Imagesets.begin();i!=m_Imagesets.end();i++) 
	{
        i->second->bindTexture();
        i->second->render();
    }
}

void ImgsetMgr::ClearMapImageset()
{
	if (!m_Imagesets.empty())
	{
		MAPMUTABLEIMAGESET::iterator i;
		for (i = m_Imagesets.begin();i!=m_Imagesets.end();i++)
		{
			SAFE_DELETE(i->second);
		}
	}
	m_Imagesets.clear();
}
