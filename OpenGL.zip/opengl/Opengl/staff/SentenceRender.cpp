//
//  SentenceRender.mm
//  Karaoke
//
//  Created by hujianping on 12-8-26.
//  Copyright (c) 2012�� 9158. All rights reserved.
//
#include "../stdafx.h"
#include "SentenceRender.h"
#include "ImgsetMgr.h"

const int COUNTDOWN = 2000;


//-----------------------------------------------------------------------------

SentenceRender::SentenceRender(CGSize& winsize):m_windowsize(winsize)
{ 
	Image * img = NULL;
	Imageset * imgset = ImgsetMgr::getSingleton()-> getImageset(L"renderer");
	//mNumberImages = [[NSMutableArray alloc] initWithCapacity:10];
	for ( int i = 0; i < 10; ++i )
	{
		//std::string temp = [[std::string alloc] initWithFormat:@"Number%d", i];
		char bufNumber[256] = {0};
		sprintf(bufNumber,"Number%d",i);
		img = imgset-> getImage(bufNumber);
		if ( img )
		{
			//[mNumberImages addObject:img];
			m_NumberImages.push_back(img);
		}
	}

	//mGradeImages = [[NSMutableArray alloc] initWithCapacity:5];
	if ( NULL != (img = imgset-> getImage("Miss") )) m_GradeImages.push_back(img);
	if ( NULL != (img = imgset-> getImage("Poor") )) m_GradeImages.push_back(img);
	if ( NULL != (img = imgset-> getImage("Good") )) m_GradeImages.push_back(img);
	if ( NULL != (img = imgset-> getImage("Great") )) m_GradeImages.push_back(img);
	if ( NULL != (img = imgset-> getImage("Perfect") )) m_GradeImages.push_back(img);

}

SentenceRender::~SentenceRender()
{
	m_NumberImages.clear();
	m_GradeImages.clear();
    //mNumberImages release;
	//[mGradeImages release];
}



//-----------------------------------------------------------------------------
void SentenceRender::invalidate()
{
    mbInvalidate = true;
    miCountDown = COUNTDOWN;
}

//-----------------------------------------------------------------------------
void SentenceRender::showSentenceLevel(_eSentenceGradeLevel sentence_level)
{
    meSentenceGradeLevel = sentence_level;
    invalidate();
}

//-----------------------------------------------------------------------------
void SentenceRender::showSentenceScore(int score)
{
    mnScore = score < 0 ? 0 : ( score > 2000 ? 2000 : score );
	invalidate();
}


//-----------------------------------------------------------------------------
void SentenceRender::update(unsigned int elapsed_ms)
{
    if ( mbInvalidate )
    {
        miCountDown -= elapsed_ms;
        if ( miCountDown < 0 )
        {
            mbInvalidate = false;
        }
    }
}

//-----------------------------------------------------------------------------
void SentenceRender::reset()
{
	meSentenceGradeLevel = SENTENCEGRADELEVEL_NONE;
	mnScore = 0;
    
    // hjp
    // renderer.png��Ӧ��Imageset�е�uvs vs cs ���Ѿ���WaveRender�����
    /*
	GeometryBuffer & geo = getGeometryBuffer();
	geo.reset();
    */
    // hjp
}

//-----------------------------------------------------------------------------
void SentenceRender::populateGeometryBuffer()
{
	//writeLog("SentenceRender::populateGeometryBuffer enter");
    if ( !mbInvalidate )
    {
        return;
    }
    
    if ( m_NumberImages.size() != 10 || m_GradeImages.size() != 5 )
    {
        return;
    }
    //////////////////////////////////////////////////////////////////////////
    // ��Ⱦ����
	float pos_x = m_windowsize.width;//1280.0f;//�����д�������320.0f
    float pos_y = 400.0f;//9.0f
    
    int score = mnScore;
    
	Image * img = NULL;
    do
    {
        int i = ( score ) % 10;
        img = m_NumberImages[i];//[mNumberImages objectAtIndex:i];
        if ( img )
        {
			//��������ұߣ��Ӹ�λ��ʼ��棬
            CGRect dest_rect = CGRectMake( pos_x - img->m_rect.size.width, pos_y, img->m_rect.size.width, img->m_rect.size.height );
            img-> draw( dest_rect , NULL , COLOR_RECT_WHITE);
            
            pos_x -= img->m_rect.size.width;//ÿ����һλ��x���������ƶ�
        }
        score /= 10;
	}
    while( score );
    //////////////////////////////////////////////////////////////////////////
    // ��Ⱦ�����ֵȼ�
    pos_x = m_windowsize.width/2.0f;//�����д�����126.0f
    pos_y = 407.0f;//16.0f
    int grade_level = ((int)meSentenceGradeLevel) - 1;
    if ( grade_level >= 0 && grade_level <= 4 )
    {
        img = m_GradeImages[grade_level];//[mGradeImages objectAtIndex: grade_level];
        if ( img )
        {
            CGRect dest_rect = CGRectMake( pos_x, pos_y, img->m_rect.size.width, img->m_rect.size.height );
            img-> draw( dest_rect , NULL , COLOR_RECT_WHITE);
        }
    }
}

