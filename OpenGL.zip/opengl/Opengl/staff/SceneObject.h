//
//  SceneObject.h
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//
#pragma once

#include "SceneMgr.h"
#include "../input/InputViewController.h"

class SceneObject 
{
public:
	SceneObject(BOOL active=FALSE);
	virtual ~SceneObject();

	virtual bool awake()=0;
	virtual void realtime(ulong ns_elapsed_ms) = 0;
	virtual void update(ulong ns_elapsed_ms)=0;
	virtual void end()=0;

public:
	BOOL                    m_active;
	CGRect                  m_meshBounds;
};

