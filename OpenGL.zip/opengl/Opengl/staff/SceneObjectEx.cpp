//
//  SceneObject.m
//  Karaoke
//
//  Created by xxx on 8/25/2012.
//  Copyright 2012 9158. All rights reserved.
//
#include "../stdafx.h"
#include "SceneObjectEx.h"
#include "SceneMgr.h"
#include "../input/InputViewController.h"
#include "ImgsetMgr.h"
#include "Image.h"

#include <windows.h>

// ���ߴ��ڳ�������
const int WAVEWND_WIDTH_TIMEMS = 5000;//2222;//5000;		// һ��5000����
const int WAVEWND_WIDTH_PIXELS = 1280;//320;//720;		// һ������720����
const int WAVEWND_HEIGHT_PIXELS = 87;//79;		// ���׵ĸ߶�40����
const int WAVEWND_HEIGHT_PIXELS_KTV = 87;//105;	// ���׵ĸ߶�40����
const int WAVEWND_LEFT_PIXELS = 80;//170;		// ��ߵ�����
const int CURSOR_WIDTH_PIXELS = 36;			// ������
const int WAVEWND_LEFT_TIMEMS = 1210;		// WAVEWND_WIDTH_TIMEMS * WAVEWND_LEFT_PIXELS / WAVEWND_WIDTH_PIXELS + 30;

const int WAVEWND_WIDTH_PIXELS_KTV = 320;//460;	// һ������632����(KTVģʽ)

const int SHOW_TIP_IMAGE_MSEC = 4000;		// 4000����~2000����	��ʾ��ʾͼ�꣨ͼ����˸��
const int SHOW_MOVE_IMAGE_MSEC = 2000;		// 2000����~0����		��ʾ��껬������
const int NEED_SHOW_MOVE_IMAGE_MSEC = 500;	// >= 1000����			��Ҫ��ʾ��껬������

// ����16�����������Ӣ���ַ�����
const int CHAR_WIDTH_CHS = 21;				// ����������ȸ߶�
const int CHAR_WIDTH_EN = 12;				// Ӣ��������ȸ߶�

SceneObjectEx::SceneObjectEx(const std::string& dataDir,const std::string& fileName ,CGSize& winsize,const DWORD& nChannels, const DWORD& nFrequency, const WORD& nBits,const std::string& textureName):
																		m_windowsize(winsize),
																		m_dataDir(dataDir),
																		mfileName(fileName),//������׺��
																		m_textureName(textureName),
																		lyric_render(NULL),
																		wave_render(NULL),
																		sentence_render(NULL),
																		m_WavRecorder(NULL),
																		mnCallbackRealtimeGradeCount(0),
																		mnCallbackSentenceGradeCount(0),
																		miLastElapsedCount(0),													
																		mbIsCallback(false),
																		mbIsMe(false),
																		mbKtvMode(false),
																		mbChangeMode(false),														
																		mfElapsedCount(0.0f),
																		miElapsedCount(0),
																		mErrCorrect(0),
																		mPreTime(0),
																		mCurTime(0),
																		mCurSingTime(0),
																		mCurSingStage(SINGSTAGE_PRELUDE),
																		mfKtvErr(0.0f),
																		mfGameErr(0.0f),
																		m_tmpcursor(NULL)
																		
{
	memset(&mCurGrade,0,sizeof(mCurGrade));
	memset(&mSongInfo,0,sizeof(mSongInfo));
	init();//init evalģ��

	if (ImgsetMgr::getSingleton()->addImageSet(winsize,dataDir,m_textureName))
	{
		lyric_render = new LyricRender(winsize);
		wave_render = new WaveRender(winsize);
		sentence_render = new SentenceRender(winsize);

		m_WavRecorder = new CWZ_WaveUnit;
		m_WavRecorder->SetWaveInConfig(nChannels,nFrequency,nBits);//���ü������������ʣ�λ
		//audio_module = new AudioModule(kBufferDurationSeconds ,sampleRate ,dBUpperLimit);

		//int time_step = (int)(kBufferDurationSeconds*1000);
		//eval_module = new eval(nFrequency ,dBUpperLimit ,time_step); //Magic:0.0f];

		mbInterpolation = true;
		// 	mGuiLyricVect = [[NSMutableArray alloc] initWithCapacity:128];
		// 	mGuiPitchVect = [[NSMutableArray alloc] initWithCapacity:128];
		// 	mGuiSentencelineVect = [[NSMutableArray alloc] initWithCapacity:128];
		// 	mParagraphVect = [[NSMutableArray alloc] initWithCapacity:128];
		mGuiLyricVect.clear();
		mGuiPitchVect.clear();
		mGuiSentencelineVect.clear();
		mParagraphVect.clear();

		m_tmpgui_lyric_list.clear();
		m_tmpgui_pitch_list.clear();
		//self.mfileName = mdmName;
	}
}


SceneObjectEx::~SceneObjectEx()
{
//     [mGuiLyricVect release];
	ClearListVectT(mGuiLyricVect);
//     [mGuiPitchVect release];
	ClearListVectT(mGuiPitchVect);
//     [mGuiSentencelineVect release];
	mGuiSentencelineVect.clear();
//     [mParagraphVect release];
	ClearListVectT(mParagraphVect);

	ClearListVectT(m_tmpgui_lyric_list);
	ClearListVectT(m_tmpgui_pitch_list);
	SAFE_DELETE(m_tmpcursor);

	SAFE_DELETE(lyric_render);
//     [lyric_render release];
	SAFE_DELETE(wave_render);
//     [wave_render release];
	SAFE_DELETE(sentence_render);
//     [sentence_render release];
	//SAFE_DELETE(audio_module);
	//SAFE_DELETE(m_WavRecorder);
//     [audio_module release];
	//SAFE_DELETE(eval_module);
    //[eval_module release];
	uninit();
}

/*
AQRecorder *SceneObjectEx::getAudioRecorder()
{
    return audio_module->getRecorder();
}

AQPlayer *SceneObjectEx::getAudioPlayer()
{
    return audio_module->getPlayer();
}*/



//-----------------------------------------------------------------------------
// �������ߺ͸��
void SceneObjectEx::genWaveAndLyric(_tSongInfo& song_info)
{   
	writeLog("SceneObjectEx::genWaveAndLyric enter");
// 	mGuiLyricVect->removeAllObjects();
	ClearListVectT(mGuiLyricVect);
// 	[mGuiPitchVect removeAllObjects];
	ClearListVectT(mGuiPitchVect);
// 	[mGuiSentencelineVect removeAllObjects];
	mGuiSentencelineVect.clear();
// 	[mParagraphVect removeAllObjects];
	ClearListVectT(mParagraphVect);
	
    
	unsigned int sentence_count = song_info.sentence_size;
	_tSentenceInfo * sentences = song_info.sentence_info;
    
	// ���ɸ�ʼ�λ����Ϣ��λ��Ϊȫ�ֵ�����ֵ��
	int pos = 0;
	
	for ( unsigned int i = 0; i < sentence_count; ++i )
	{
		const _tSentenceInfo & sentence = sentences[ i ];
		
		for ( unsigned int j = 0; j < sentence.word_size; ++j )
		{
			const _tWordInfo & word_info = sentence.word_list[ j ];
			if ( word_info.lyric_size )
			{
                //static NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
				_tGuiLyricInfo * gui_lyric_info = new _tGuiLyricInfo;//[[_tGuiLyricInfo alloc] init];
				wchar_t lyricBuf[50] = {0};
				/*if (word_info.lyric_size>255)
				{
					OutputDebugStringA("lyric_size error >255\n");
					memcpy(lyricBuf,word_info.lyric,255);
				}
				else
				{
					memcpy(lyricBuf,word_info.lyric,word_info.lyric_size);
				}*/
				static char szLyric[50] = { 0 };
				memcpy(szLyric,word_info.lyric,word_info.lyric_size);
				szLyric[word_info.lyric_size] = 0;

				MultiByteToWideChar(CP_ACP, 0, szLyric, -1, lyricBuf, 49);//һ������һ�����ֽڣ�Ӣ�Ĳ�����49
                gui_lyric_info->lyric	= lyricBuf;
				gui_lyric_info->pos		= word_info.begin_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
				// ���ͨ��ʵ����������ַ�λ����ǰһ���ַ��ص���У��
				if ( gui_lyric_info->pos < pos )
				{
					gui_lyric_info->pos = pos;
				}
				//[mGuiLyricVect addObject: gui_lyric_info];
				mGuiLyricVect.push_back(gui_lyric_info);
                
				// ������ǰһ���ַ��ص�
				pos = gui_lyric_info->pos + 1;
				for ( unsigned int k = 0; k < word_info.lyric_size; ++ k )
				{
					pos += ( word_info.lyric[ k ] > 0x00FF ) ? 21 : 12;
				}
                //[gui_lyric_info release];//////////////glp
			}
		}
	}
        
	// �������߾�β�߼�λ����Ϣ��λ��Ϊȫ�ֵ�����ֵ��
	for ( unsigned int i = 0; i < sentence_count; ++i )
	{
        _tGuiWaveInfo * gui_pitch = NULL;
		const _tSentenceInfo & sentence = sentences[ i ];
        
        for ( unsigned int j = 0; j < sentence.pitchgroup_size; ++j )
        {
            const _tPitchGroup & pitch_group = sentence.pitchgroup_list[j];
            
            for ( unsigned int k = 0; k < pitch_group.pitch_size; ++k )
            {
                gui_pitch = new _tGuiWaveInfo;//[[_tGuiWaveInfo alloc] init];
                
                const _tPitch & pitch_info = pitch_group.pitch_list[ k ];
                gui_pitch->l = pitch_info.begin_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
                gui_pitch->r = pitch_info.end_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
                gui_pitch->y = ( WAVEWND_HEIGHT_PIXELS - 18 ) * ( song_info.pitch_max - pitch_info.pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 400;//9
                mGuiPitchVect.push_back(gui_pitch);
				//[mGuiPitchVect addObject: gui_pitch];
                //[gui_pitch release];/////////glp
            }
        }
		
		// ������ߵĽ�βӦ���Ǿ��β
        int _sentenceline_pos = sentence.endMsec * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS;
        //NSNumber * nsnumber_sentenceline_pos = [[NSNumber alloc] initWithInt: _sentenceline_pos];
        int number_sentenceline_pos =  _sentenceline_pos;
		if ( gui_pitch != NULL && gui_pitch->r != _sentenceline_pos )
		{
			char logBuf[256] ={0};
			sprintf(logBuf,"sentence line position is error sentence index = [%d].\n", ( int )i);
			OutputDebugStringA( logBuf );
		}
		mGuiSentencelineVect.push_back(number_sentenceline_pos);
		//[mGuiSentencelineVect addObject: nsnumber_sentenceline_pos];
        //[nsnumber_sentenceline_pos release];/////////glp
	}
	char bufLog[256] = {0};
	sprintf(bufLog,"mGuiPitchVect size=%d",mGuiPitchVect.size());
	writeLog(bufLog);
	// ���ö���(��Ҫ��ǰ��ʾ��ʲ���ʾ)
	unsigned long end_msec = 0;			// ��һ�䣬�Ͼ����ʱ��Ϊ0���ڶ����Ͼ�ʱ��Ϊ��һ��Ľ���ʱ��
	for ( unsigned int i = 0; i < sentence_count; ++i )
	{
		const _tSentenceInfo & sentence = sentences[ i ];
		if ( sentence.beginMsec >= end_msec )
		{
			unsigned long duration = 0;		// ��ǰ������һ�������ʱ��
			duration = sentence.beginMsec - end_msec;
            
			if ( duration >= NEED_SHOW_MOVE_IMAGE_MSEC )
			{
				duration = duration / 500 * 500;
				if ( duration > SHOW_TIP_IMAGE_MSEC )
				{
					duration = SHOW_TIP_IMAGE_MSEC;
				}
                _tGuiParagraphInfo * paragraph_info = new _tGuiParagraphInfo;//[[_tGuiParagraphInfo alloc] init];
                paragraph_info->sentence_index = i;
                paragraph_info->duration = duration;
				mParagraphVect.push_back(paragraph_info);
				//[mParagraphVect addObject:paragraph_info];
                //[paragraph_info release];////////////glp
			}
		}
		else
		{
			char logBuf[256] = {0};
			sprintf(logBuf,"sentence time stamp is error,sentence index is [%d].\n", ( int )i);
			OutputDebugStringA( logBuf );
		}
		end_msec = sentence.endMsec;
	}
}

void SceneObjectEx::RealtimeGrade( const _tRealtimeGrade &  realtime_grade)
{
    if ( mnCallbackRealtimeGradeCount < 16 )
    {
        mCallbackRealtimeGrade[mnCallbackRealtimeGradeCount] = realtime_grade;
        mnCallbackRealtimeGradeCount++;
    }
    else
    {
        mnCallbackRealtimeGradeCount = 0;
        mCallbackRealtimeGrade[mnCallbackRealtimeGradeCount] = realtime_grade;
        mnCallbackRealtimeGradeCount++;
    }
}

void SceneObjectEx::SentenceGrade(const _tSentenceGrade &  sentence_grade)
{
    if ( mnCallbackSentenceGradeCount < 8 )
    {
        mCallbackSentenceGrade[mnCallbackSentenceGradeCount] = sentence_grade;
        mnCallbackSentenceGradeCount++;
    }
    else
    {
        mnCallbackSentenceGradeCount = 0;
        mCallbackSentenceGrade[mnCallbackSentenceGradeCount] = sentence_grade;
        mnCallbackSentenceGradeCount++;
    }
}

void SceneObjectEx::eventMainUpdate(unsigned int elapsed_ms)
{
	//writeLog("SceneObjectEx::eventMainUpdate enter");
    bool call_realtime_grade = false;
	// ��������Ƿ��ֵ
	if ( mbInterpolation )
	{
		//writeLog("SceneObjectEx::eventMainUpdate mbInterpolation is true");
		if ( !mbIsCallback )
		{// �������AVģ��ص�
            // hjp
			/*_tRealtimeGrade next_grade;
			// ���AVģ��ʵʱ���ֻص������д�����һ֡
			if ( TOP::box().av->peekTopRealtimeGrade( next_grade ) )
        	{
				call_realtime_grade = true;
			}
			else
			{// ���AVģ��ʵʱ���ֻص������в�������һ֡
				if ( mbIsMe )
				{// ����Լ������ϣ���ǰ����ʱ����ǰ����elapsed_tm
					call_realtime_grade = true;
				}
				else
				{// ��������ڣ�ͣס����ǰԤ�⡣
					//LOG_GAME( "CStateStageSing::eventMainUpdate real time grade queue is empty." );
				}
			}
            */
            // hjp
            call_realtime_grade = true;
			writeLog("SceneObjectEx::eventMainUpdate set call_realtime_grade true");
		}
	}
    
	if ( call_realtime_grade )
	{
		eventAvRealtimeGrade(elapsed_ms , mCurGrade , false);
	}
    /*
	if ( mbKtvMode && ( mbInterpolation || mbIsCallback ) )
	{
		// 1.������ʾ��˸ͼ�ꡢ����ͼ��
		unsigned int i = 0;
		unsigned int iParagraphCount = mParagraphVect.size();
		for ( i = 0; i < iParagraphCount; ++i )
		{
			std::pair< int, int > & paragraph = mParagraphVect[ i ];
			int & sentence_index = paragraph.first;
			int & duration = paragraph.second;
			if ( ( miCurSentence - 1 ) == sentence_index )
			{// �����Ҫ��ʾ��˸ͼ��򻬶�ͼ��
				int temp_msec = ( int )mCurSentenceLyric.beginMsec - ( int )mCurGrade.cur_tm;
				if ( temp_msec <= duration )
				{// �����Ҫ
					if ( temp_msec <= SHOW_MOVE_IMAGE_MSEC )
					{// ��ʾ����ͼ��
						float temp_pos = (float)( SHOW_MOVE_IMAGE_MSEC - temp_msec ) / SHOW_MOVE_IMAGE_MSEC;
						TOP::box().gui->getStage()->setLyricMovePos( temp_pos );
					}
                    / *
                     else if ( temp_msec < SHOW_TIP_IMAGE_MSEC )
                     {// ��ʾ��˸ͼ��
                     float temp_trans = (float)( 500 - temp_msec % 500 ) / 500.0f;
                     TOP::box().gui->getStage()->setLyricTipImageTrans( temp_trans );
                     }
                     * /
				}
				break;
			}
		}
        
		// 2.��ɫ���
		// ��ǰ�ݳ���������
		unsigned int nWordCount = mCurSentenceLyric.nWordCount;
        
		// ���Vect������
		unsigned int nGuiLyricCount = ( unsigned int )mCurGuiLyricVect.size();
        
		if ( miCurSentence >= 1 && nWordCount > 0 && nGuiLyricCount > 0 )
		{
			// ��ǰ����ʱ�䣨���룩
			float total_msec = mCurSentenceLyric.endMsec-mCurSentenceLyric.beginMsec;
            
			// ������׵�ʱ�����룩
			// ��ȥ75���루���������õ���˷�������������ֱ������ĵ�ʱ�䣩
			float left_msec = mCurGrade.cur_tm - mCurSentenceLyric.beginMsec - 75;
            
			// �ܳ��ȣ���λ�����أ�
			float total = 0.0f;
			bool first_sentence = ( ( ( miCurSentence - 1 ) % 2 ) == 0 );
			if ( first_sentence )
				total = mFirstLyricWidth;
			else
				total = mSecondLyricWidth;
            
			total += Gui::FONT24_SPACE * ( nWordCount - 1 );
            
			if ( total > 1.0f )
			{
				// ��ɫ�ĳ��ȣ���λ�����أ�
				float left = 0.0f;
				for ( i = 0; i < nWordCount && i < nGuiLyricCount; ++i )
				{
					WordInfo & word_info = mCurSentenceLyric.words[i];
					Gui::_tGuiLyricInfo & lyric_info = mCurGuiLyricVect[i];
					if ( mCurGrade.cur_tm > word_info.endMsec )
					{
						left += lyric_info.width;
						left += Gui::FONT24_SPACE;
					}
					else
					{
						if ( mCurGrade.cur_tm >= word_info.beginMsec)
						{
							float word_msec = word_info.endMsec-word_info.beginMsec;
							if ( word_msec < 1.0f )
								word_msec = 1.0f;
							
							long temp_msec = mCurGrade.cur_tm - word_info.beginMsec;
							if ( temp_msec < 0 )
								temp_msec = 0;
                            
							left += lyric_info.width * temp_msec / word_msec;
						}
						break;
					}
				}
                
				mCurRate = left / total;
				
				if ( first_sentence )
				{
					TOP::box().gui->getStage()->setFirstLyricStartPos( mCurRate );
				}
				else
				{
					TOP::box().gui->getStage()->setNextLyricStartPos( mCurRate );
				}
			}
            
			if ( total_msec > 1.0f && left_msec >= 0.0f )
			{
				if ( left_msec > total_msec )
					left_msec = total_msec;
                
				mMoveRate = left_msec / total_msec;
			}
			else
			{
				mMoveRate = 0.0f;
			}
			TOP::box().gui->getStage()->setMovePos( mMoveRate );
		}
	}
    */
    
	if ( mbIsCallback )
	{// AVģ��ص�����λ��־�����ظ�����eventAvRealtimeGrade����
		mbIsCallback = false;
	}
}

//-----------------------------------------------------------------------------
// av����Ƶʵʱ����
void SceneObjectEx::eventAvRealtimeGrade(unsigned int elasped_ms ,_tRealtimeGrade & grade ,bool is_callback/* = true*/)
{
	char bufLog[512] ={0};
	//sprintf(bufLog,"SceneObjectEx::eventAvRealtimeGrade enter elasped_ms=%d,Pgrade=%x",elasped_ms,&grade);
	//writeLog(bufLog);
	mbIsCallback = is_callback;
    
	miLastElapsedCount += elasped_ms;
    
    /*
    if ( ( miLastElapsedCount - miElapsedCount ) > 1000 )
    {
        miElapsedCount += 1000;
        NSLog(@"miElapsedCount[%d].", miElapsedCount / 1000);
    }
    */
	if ( false )//mbInterpolation
	{// ʹ�ò�ֵ
		// ʹ��֡��Ⱦ�е�ʱ����Ϊ��ֵ
		//writeLog("mbInterpolation is true");
		int cur_tm = ( int )mCurGrade.cur_tm;
		//////////////////////////////////////////////////////////////////////////
		/*sprintf(bufLog,"cur_tm = %d",cur_tm);
		writeLog(bufLog);*/
		cur_tm += elasped_ms;
        
		if ( mbIsCallback )
		{
			// У����ǰʱ��
			int temp = cur_tm - grade.cur_tm;
			//////////////////////////////////////////////////////////////////////////
			/*sprintf(bufLog,"temp = %d",temp);
			writeLog(bufLog);*/
			if ( temp < -2000 || temp > 2000)
			{
				cur_tm = grade.cur_tm;
			}
            
            mCurGrade = grade;
            mCurGrade.cur_tm = ( unsigned int )cur_tm;
		}
		else
		{
			mCurGrade = grade;
			mCurGrade.cur_tm = cur_tm;
		}
	}
	else
	{// ���ò�ֵ
		mCurGrade = grade;
	}
    
	mCurTime = miLastElapsedCount;//mCurGrade.cur_tm;
    mCurGrade.cur_tm = mCurTime;
	const _tSongInfo & song_info = mSongInfo;
    //sprintf(bufLog,"cur_tm = %d,song_tm = %d",mCurGrade.cur_tm,song_info.song_tm*1000);
	//writeLog(bufLog);
	// ��ʾ��������
	if ( mCurGrade.cur_tm <= song_info.song_tm*1000 && mCurGrade.cur_tm >= mPreTime )
	{
		// ���㲢��ʾ��������
		float progress = ( float )mCurGrade.cur_tm / ( float )(song_info.song_tm*1000);
		//TOP::box().gui->getStage()->showSongProgress( progress );
        
		// ��ʾ����ʱ��
		//TOP::box().gui->getStage()->setCurentPlayTime( mCurGrade.cur_tm );
        
		// ��ʾ����ʱ��
		int cur_tm = ( int )( mCurGrade.cur_tm / 1000.0f );
		//int second = cur_tm % 60;
		//int minute = cur_tm / 60;
		//std::string song_tm = boost::str( boost::format( "%02d:%02d" ) % minute % second );
		//TOP::box().gui->getStage()->showSongTime( song_tm );
        
		mPreTime = mCurGrade.cur_tm;
	}
    
	if ( mCurTime > song_info.begin_tm && mCurSingTime < song_info.end_tm )
	{
		mCurSingStage = SINGSTAGE_SING;
	}
	else if ( mCurTime > song_info.end_tm )
	{
		mCurSingStage = SINGSTAGE_FINALE;
	}
    
	if ( mbIsMe )
	{
		if ( mCurGrade.cur_tm > song_info.song_tm*1000 )
		{
			sprintf(bufLog,"my cur_tm error : [%d][%d]\n", (int)(mCurGrade.cur_tm), (int)(song_info.end_tm));
			writeLog( bufLog );
		}
	}
	
	if ( mCurGrade.cur_tm > song_info.song_tm*1000 || mCurGrade.cur_tm < mPreTime )
	{
		// LOG_GAME_ERR( "cur_tm error : " << (int)(mCurGrade.cur_tm) << (int)(song_info.end_tm) );
		return;
	}
    
	unsigned int word_count = 0;
	unsigned int pitch_count = 0;
    
	unsigned int sentence_count = song_info.sentence_size;
	_tSentenceInfo * sentences = song_info.sentence_info;
    
	// ��ʾ�ۼӾ����ֽ�����
	//TOP::box().gui->getStage()->showSentenceProgress( mCurGrade.accumulate_score / 1000.0f );
    
	// ��ǰ��ʱ�䣬ȷ���ڷָ����ϣ��ָ��ߵ����ҡ��ָ��ߵ�������Ѿ������ĸ�ʣ��ָ��ߵ��Ҳ���û�г����ĸ��
	// ����ı䷽������ô��Ҫ��ʱ���������ʾӦ����ǰ5����ʾ
    /*
	if ( mbKtvMode )
	{
		bool bScroll = false;
		if ( mbChangeMode )
		{
			bScroll = true;
		}
        
		unsigned int i = 0;
		// ��ʾ��ʵĵ�ǰʱ��
		unsigned long show_lyric_time = mCurGrade.cur_tm;
		for ( i = 0; i < mParagraphVect.size(); ++i )
		{
			std::pair< int, int > & paragraph = mParagraphVect[ i ];
			int & sentence_index = paragraph.first;
			int & duration = paragraph.second;
			if ( sentence_index == miCurSentence )
			{
				show_lyric_time += duration;			// ����Ƕ��䣬��Ҫ��ǰX����ʾ���
				break;
			}
		}
        
		// ���㵱ǰ���ŵľ�
		for ( i = miCurSentence; i < sentence_count; ++i )
		{
			const SentenceInfo & sentence = sentences[i];
			if ( show_lyric_time >= sentence.beginMsec && show_lyric_time <= sentence.endMsec )
			{
				if ( mCurSentenceLyric.beginMsec != sentence.beginMsec )
				{
					mCurSentenceLyric = sentence;
					miCurSentence = i + 1;
					if ( i + 1 < sentence_count )
					{
						mNextSentenceLyric = sentences[ i + 1 ];
					}
					else
					{
						memset( &mNextSentenceLyric, 0, sizeof(SentenceInfo) );
					}
					bScroll = true;
				}
				break;
			}
		}
        
		if ( mCurGrade.cur_tm > song_info.end_tm )
		{
			memset( &mCurSentenceLyric, 0, sizeof(SentenceInfo) );
			memset( &mNextSentenceLyric, 0, sizeof(SentenceInfo) );
		}
        
		if ( bScroll )
		{
			// ��ո���б�
			mCurGuiLyricVect.clear();
			mNextGuiLyricVect.clear();
            
			unsigned long pt_left	= mCurSentenceLyric.beginMsec;
			unsigned long pt_right	= mCurSentenceLyric.endMsec - mCurSentenceLyric.beginMsec;
            
            // ��ʾ��һ��(����)
			Gui::_tGuiLyricInfo gui_lyric_info;
            
			// ��һ����
			word_count = mCurSentenceLyric.nWordCount;
			for ( unsigned int i = 0; i < word_count; ++i )
			{
				const WordInfo & word_info = mCurSentenceLyric.words[ i ];
				if ( word_info.chars )
				{
					gui_lyric_info.lyric = Ci::CUtility::wc2CeguiString( word_info.chars );
					mCurGuiLyricVect.push_back( gui_lyric_info );
				}
			}
            
			// �ڶ�����
			word_count = mNextSentenceLyric.nWordCount;
			for ( unsigned int i = 0; i < word_count; ++i )
			{
				const WordInfo & word_info = mNextSentenceLyric.words[ i ];
				if ( word_info.chars )
				{
					gui_lyric_info.lyric = Ci::CUtility::wc2CeguiString( word_info.chars );
					mNextGuiLyricVect.push_back( gui_lyric_info );
				}
			}
            
			// ��ʲ�����
			bool current_is_first_sentence = ( ( ( miCurSentence - 1 ) % 2 ) == 0 );
			TOP::box().gui->getStage()->switchSentence( current_is_first_sentence );
            
			// �����ʾ���λ�ø�λ
			TOP::box().gui->getStage()->setLyricMovePos( 0.0f );
            
			if ( current_is_first_sentence )
			{
				mFirstLyricWidth = TOP::box().gui->getStage()->showFirstLyric( mCurGuiLyricVect, false );
				mSecondLyricWidth = TOP::box().gui->getStage()->showSecondLyric( mNextGuiLyricVect, true );
			}
			else
			{
				mFirstLyricWidth = TOP::box().gui->getStage()->showFirstLyric( mNextGuiLyricVect, false );
				mSecondLyricWidth = TOP::box().gui->getStage()->showSecondLyric( mCurGuiLyricVect, true );
			}
            
			// ��ʾ����
			Gui::_tGuiWaveInfo gui_pitch;
			std::vector< Gui::_tGuiWaveInfo > gui_pitch_list;
			unsigned int pitch_count = mCurSentenceLyric.nPitchCount;
			for ( unsigned int i = 0; i < pitch_count; ++i )
			{
				const PitchInfo & pitch_info = mCurSentenceLyric.pitches[ i ];
				if ( pt_right > 0.0f )
				{
					gui_pitch.l = ( pitch_info.beginMsec - pt_left ) * WAVEWND_WIDTH_PIXELS_KTV / pt_right;
					gui_pitch.r = ( pitch_info.endMsec - pt_left ) * WAVEWND_WIDTH_PIXELS_KTV / pt_right;
				}
				gui_pitch.y = ( WAVEWND_HEIGHT_PIXELS_KTV - 35 ) * abs( song_info.pitch_max - pitch_info.pitch ) / (float)( song_info.pitch_max - song_info.pitch_min ) + 11;
				gui_pitch_list.push_back( gui_pitch );
			}
            
			TOP::box().gui->getStage()->showWave( gui_pitch_list );
            
			TOP::box().gui->getStage()->clearLyricCursor();
		}
		// ��ʾ�ǹ���Чͼ��
		if ( mbIsCallback )
		{
			// ���㵱ǰ���֣������ж��Ƿ���Ҫ��ʾ�ǹ���Ч
			mfPitchRealGrade += grade.realtime_score;
		}
		unsigned int pitch_count = mCurSentenceLyric.nPitchCount;
		for ( unsigned int i = 0; i < pitch_count; ++i )
		{
			const PitchInfo & pitch_info = mCurSentenceLyric.pitches[ i ];
			int _left_tm = pitch_info.endMsec - _elapsed_tm;
			int _right_tm = pitch_info.endMsec + _elapsed_tm;
			if ( mCurTime >= _left_tm && mCurTime < _right_tm )
			{
				if ( mfPitchRealGrade > 0.0f )
				{
					TOP::box().gui->getStage()->enableStarEffect( i, true );
				}
				mfPitchRealGrade = 0.0f;
				break;
			}
		}
        
		// ��ʾ�α�
		float cur_pitch = mCurGrade.cur_pitch;
        
		Gui::_tGuiLyricCursorInfo cursor;
		cursor.r = Gui::_tGuiLyricCursorInfo::RANK_YELLOW;
		
		cursor.y = ( WAVEWND_HEIGHT_PIXELS_KTV - 35 ) * abs( song_info.pitch_max - cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 11;
		// cursor.y = ( song_info.pitch_max - mCurGrade.cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min );
		cursor.x = WAVEWND_WIDTH_PIXELS_KTV * mMoveRate;
        
		if ( cursor.x > WAVEWND_WIDTH_PIXELS_KTV )
		{
			cursor.x = WAVEWND_WIDTH_PIXELS_KTV;
		}
		TOP::box().gui->getStage()->showLyricCursor( cursor, mfKtvErr, mfGameErr );
	}
	else
    */
	{
		// ����ƫ��
		int offset = mCurGrade.cur_tm * WAVEWND_WIDTH_PIXELS / WAVEWND_WIDTH_TIMEMS - WAVEWND_LEFT_PIXELS;
		//sprintf(bufLog,"offset = %d",offset);
		//writeLog(bufLog);
		// ��ʾ���
        //NSMutableArray * gui_lyric_list = NULL;
		ClearListVectT(m_tmpgui_lyric_list);
		//for( _tGuiLyricInfo * i in mGuiLyricVect )
		LISTGUILYRICVECT::iterator iL;
		sprintf(bufLog,"mGuiLyricVect size = %d",mGuiLyricVect.size());
		writeLog(bufLog);
		for (iL=mGuiLyricVect.begin();iL!=mGuiLyricVect.end();iL++)
		{
			int pos = (*iL)->pos - offset;
			//sprintf(bufLog,"pos1=%d,pos2 = %d",pos+offset,pos);
			//writeLog(bufLog);
			if ( pos < -20 )
			{
				continue;
			}
            
			if ( pos > WAVEWND_WIDTH_PIXELS )
			{
				break;
			}
            
			_tGuiLyricInfo * temp = new _tGuiLyricInfo;//[[_tGuiLyricInfo alloc] init];
            temp->lyric = (*iL)->lyric;
            temp->width = (*iL)->width;

            temp->pos = pos;
           /* if ( NULL == gui_lyric_list )
            {
                gui_lyric_list = [[NSMutableArray alloc] init];
            }*/
			//[gui_lyric_list addObject: temp];
			m_tmpgui_lyric_list.push_back(temp);
		}
        
        //if ( NULL != gui_lyric_list )
		{
			//char szLog[4096] = { 0 };
			//sprintf( szLog, "gui_lyric_list.size=%d", m_tmpgui_lyric_list.size() );
			//writeLog( szLog );
            lyric_render->showFirstLyric(m_tmpgui_lyric_list , true);
        }
        
		// ��ʾ����
		//NSMutableArray * gui_pitch_list = NULL;
		ClearListVectT(m_tmpgui_pitch_list);
		//for( _tGuiWaveInfo * i in mGuiPitchVect )
		LISTGUIPITCHVECT::iterator iP;
		for (iP=mGuiPitchVect.begin();iP!=mGuiPitchVect.end();iP++)
		{
			int left = (*iP)->l - offset;
			int right = (*iP)->r - offset;
			if ( left > WAVEWND_WIDTH_PIXELS )
			{
				break;
			}
			if ( left >= 0 || right >= 0 )
			{
				if ( left < 0 )
				{
					left = 0;
				}
                
				_tGuiWaveInfo * temp = new _tGuiWaveInfo;//[[_tGuiWaveInfo alloc] init];
                temp->y = (*iP)->y;
				temp->l = left;
				temp->r = right;
                
               /* if ( NULL == gui_pitch_list )
                {
                    gui_pitch_list = [[NSMutableArray alloc] init];
                }*/
				//[gui_pitch_list addObject: temp];
				m_tmpgui_pitch_list.push_back(temp);
                //[temp release];
			}
		}
        
        //if ( NULL != gui_pitch_list )
        {
            wave_render->setLineGroup(m_tmpgui_pitch_list , true);
        }
		//[gui_lyric_list release];glp
		//��ʾ��β��
		//NSMutableArray * gui_sentenceline_list = NULL;
		LISTSENTENCELINEVECT gui_sentenceline_list;
		//for( NSNumber * i in mGuiSentencelineVect )
		LISTSENTENCELINEVECT::iterator iS;
		for (iS=mGuiSentencelineVect.begin();iS!=mGuiSentencelineVect.end();iS++)
		{
			int pos = *iS - offset;
			if ( pos > WAVEWND_WIDTH_PIXELS )
			{
				break;
			}
            
			if ( pos >= 0 )
			{
                //NSNumber * nsnumber_pos = [[NSNumber alloc] initWithInt: pos];
                
                /*if ( NULL == gui_sentenceline_list )
                {
                    gui_sentenceline_list = [[NSMutableArray alloc] init];
                }*/
				//[gui_sentenceline_list addObject: nsnumber_pos];
				gui_sentenceline_list.push_back(pos);
			}
		}
        //if ( NULL != gui_sentenceline_list )
		{
            wave_render->setSentenceLineList( gui_sentenceline_list , true);
        }
        //[gui_lyric_list release];
		// ��ʾ�α�
		float cur_pitch = mCurGrade.cur_pitch;
        
		float standard_pitch;
		for ( int i = 0; i < sentence_count; ++i )
		{
			const _tSentenceInfo & sentence = sentences[i];
			if ( mCurGrade.cur_tm >= sentence.beginMsec && mCurGrade.cur_tm <= sentence.endMsec )
			{
                for ( unsigned int j = 0; j < sentence.pitchgroup_size; ++j ) {
                    const _tPitchGroup & pitch_group = sentence.pitchgroup_list[j];
                    int pitch_count = pitch_group.pitch_size;
                    for (int j = 0; j < pitch_count; ++j )
                    {
                        if ( mCurGrade.cur_tm >= pitch_group.pitch_list[j].begin_tm && mCurGrade.cur_tm <= pitch_group.pitch_list[j].end_tm )
                        {
                            const _tPitch & pitch_info = pitch_group.pitch_list[j];
                            standard_pitch = pitch_info.pitch;
                            break;
                        }
                    }
                }
				break;
			}
		}
        
		if (!m_tmpcursor)
		{
			m_tmpcursor = new _tGuiLyricCursorInfo;//[[_tGuiLyricCursorInfo alloc] init];
		}
        m_tmpcursor->r = RANK_YELLOW;//(int)
        int standard_y = ( WAVEWND_HEIGHT_PIXELS - 18 ) * abs( song_info.pitch_max - standard_pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 9;
        //cursor.y = ( song_info.pitch_max - mCurGrade.cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min );
        m_tmpcursor->x = WAVEWND_LEFT_PIXELS - CURSOR_WIDTH_PIXELS;

        if ( cur_pitch >= song_info.pitch_min )
		{
            m_tmpcursor->y = ( WAVEWND_HEIGHT_PIXELS - 18 ) * abs( song_info.pitch_max - cur_pitch ) / ( song_info.pitch_max - song_info.pitch_min ) + 9;
        }
        else
        {
            m_tmpcursor->y = -1000;
        }
        
        wave_render ->setStandardY(standard_y);
        wave_render ->setLyricCursor(*m_tmpcursor , mfKtvErr , mfGameErr);
    }
    
	// ��λ��־λ
	if ( mbChangeMode )
	{
		mbChangeMode = false;
	}
}

//-----------------------------------------------------------------------------
// av����Ƶ��������
void SceneObjectEx::eventAvSentenceGrade (_tSentenceGrade & grade)
{
	writeLog("SceneObjectEx::eventAvSentenceGrade enter");
    _eSentenceGradeLevel sentence_level = grade.sentence_level;
    sentence_render ->showSentenceLevel( sentence_level);
    
    // ����ģ�飬�����ַ�����ʾ
    int sentence_score = ( int )grade.sentence_score;
    sentence_render ->showSentenceScore(sentence_score);
    
    // ����ģ�飬�����л�����
    static bool sentence_grade_good = true;
    static int sentence_grade_num = 0;
    bool cur_good = false;
    if ( grade.sentence_level > 1 )
        cur_good = true;
    if ( cur_good == sentence_grade_good )
    {
        sentence_grade_num ++;
    }
    else
    {
        sentence_grade_num	= 0;
        sentence_grade_good	= cur_good;
    }
    
    // �л��Ƿ���ʾ������Χ�⻷��Ч
    bool enable_waveeffect = sentence_grade_good && ( sentence_grade_num > 0 );
    wave_render ->enableWaveEffect(enable_waveeffect);
}

//-----------------------------------------------------------------------------
// ��ȡ���������и��(�ų��ظ�)
// ����Unicode����Ĳ��ظ��ĸ��
std::wstring & SceneObjectEx::getLyric(_tSongInfo& song_info)
{
    //NSMutableString * strLyric = [[NSMutableString alloc] init];
	static std::wstring strLyric;//
	strLyric.clear();

	MAPWCHARINT mapWord ;//= [[NSMutableDictionary alloc] initWithCapacity:256];
	for (unsigned int i = 0; i < song_info.sentence_size; i++)
	{
		for (unsigned int j = 0; j < song_info.sentence_info[i].word_size; j++)
		{
			const _tWordInfo & word_info = song_info.sentence_info[i].word_list[j];
            //NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
			char lyricBuf[256] = {0};
			if (word_info.lyric_size>255)
			{
				OutputDebugStringA("lyric_size error >255\n");
				memcpy(lyricBuf,word_info.lyric,255);
			}
			else
			{
				memcpy(lyricBuf,word_info.lyric,word_info.lyric_size);
			}
			wchar_t unicodeStr[256]= {0};
			MultiByteToWideChar(CP_ACP, 0, lyricBuf, -1, unicodeStr, 255);
			//[[std::string alloc] initWithBytes: word_info.lyric length:word_info.lyric_size encoding:enc];
            //std::string unicodeStr = [std::string stringWithCString:[asciiStr UTF8String] encoding:NSUnicodeStringEncoding];
            uint len = wcslen(unicodeStr);
			for ( unsigned int k = 0; k < len;k++)//unicodeStr.length; k++ )
			{
                //std::string word = [unicodeStr substringWithRange:NSMakeRange(k, 1)];
				wchar_t word = unicodeStr[k];
                //id w = [mapWord objectForKey:word];
				MAPWCHARINT::const_iterator w;
				w = mapWord.find(word);
				if ( w == mapWord.end() )
				{
                    //NSNumber * n = [[NSNumber alloc] initWithInt:1];
					//[mapWord setObject:n forKey:word];
					mapWord.insert(std::pair<wchar_t,int>(word,1));
                    //[n release];
					//[strLyric appendString:word];
					strLyric.push_back(word);
                    
				}
				else
				{
                    //NSNumber * n = (NSNumber*)w;
                    //NSNumber * n1 = [[NSNumber alloc] initWithInt:([n intValue] + 1)];
					
                    //[mapWord setObject:n1 forKey:word];
					int n = w->second+1;
					mapWord.insert(std::pair<wchar_t,int>(word,n));
				}
			}
            //[unicodeStr release];
		}
	}
	return strLyric;
    //[mapWord release];////////////glp
	//return [strLyric autorelease];
}

// called once when the object is first created.
bool SceneObjectEx::awake()
{
    /*
    FreeTypeFont * ftt = [[FreeTypeFont alloc] init];
    [ftt load: NULL LyricString:@"������"];
    CGPoint pt = CGPointMake( 0, 0 );
    KKColorRect color_rect(0xFFFF0000, 0xFFFF0000, 0xFFFF0000, 0xFFFF0000);
    [ftt drawText: @"������" OffsetPoint: pt ClipRect: NULL ColorRect: color_rect];
    [ftt render];
    return;
    */
    /*
    [[ImgsetMgr getSingleton] addImageSet:@"renderer"];
    CGRect dest_rect = CGRectMake( 0, 0, 26, 11 );
    //CGRect clip_rect = CGRectMake( 0, 0, 15, 50 );
    Image * img = [[[ImgsetMgr getSingleton] getImageset:@"renderer"] getImage:@"WaveBlueM"];
    
    [img draw: dest_rect ClipRect:NULL ColorRect:COLOR_RECT_WHITE];

    dest_rect.origin.x += 26;
    dest_rect.origin.y += 11;
    
    [img draw: dest_rect ClipRect:NULL ColorRect:COLOR_RECT_WHITE];
    
    
    [[[ImgsetMgr getSingleton] getImageset:@"renderer"] render];
    
    return;
    */
    
    //[audio_module awakeFromNib];
    //[audio_module initRecorder:eval_module CallbackObject: self];
    
//     NSString *basePath0 = [[NSBundle mainBundle] bundlePath];
//     NSRange range = [basePath0 rangeOfString:@"/KTV.app"];
//     NSString *basePath1 = [basePath0 substringWithRange:NSMakeRange(0, range.location)];
   // const char * basePath = [basePath1 UTF8String];
    
//    static char basePath[256] = "/Users/hujianping_NB/Downloads/projects/";
    
    //sprintf(MdmName, "%s/Documents/top100/mdm100/%s.mdm",[basePath1 UTF8String],[mfileName cStringUsingEncoding:NSUTF8StringEncoding]);
	
	char MdmName[256] = {0};
	sprintf(MdmName,"%s\\mdm\\%s.mdm",m_dataDir.c_str(),mfileName.c_str());
	if (!loadSongInfo( MdmName,mSongInfo))
	{
		return false;
	}
	
    // ��ʱ�ý���ʱ����档
    mSongInfo.song_tm = mSongInfo.end_tm / 1000.0f + 5.0f;
	std::wstring strLyric = getLyric(mSongInfo);
    genWaveAndLyric(mSongInfo);
	writeLog("genWaveAndLyric out");
    lyric_render->loadFont( m_windowsize,strLyric );
	writeLog("loadFont out");
    lyric_render-> setMode( false);

    wave_render-> setMode( false);
    
    char MpgName[256] = {0};
    sprintf(MpgName, "%s\\mpg\\%s.mpg",m_dataDir.c_str(),mfileName.c_str());
	//////////////////////////////////////////////////////////////////////////
//������¼��
	if (!OpenVideoFile(MpgName))//���ļ�
	{
		OutputDebugStringA("video open error\n");
		return false;
	}
	//��¼��
	if(!m_WavRecorder->RecordOpen())
	{
		OutputDebugStringA("recoder open error");
		return false;
	}
	//��ʼ¼��
	m_WavRecorder->RecordStart();
	//��ʼ����
	StartPlayer();
	return true;
    //[audio_module play:MpgName];//////////////////////////////////////////////////////////////////////////
    //[audio_module record];
}


void SceneObjectEx::realtime(ulong ns_elapsed_ms)
{
	writeLog("SceneObjectEx::realtime enter");
	//ʵʱ����
	float	fFrPitchLog = -1;
	float	fRealTimeDiff = -1; 
	//��ȡ����
	CWave	wave;

	//��ȡ���һ֡������
	int		iResult;
	int		nCount;
	std::vector<float> vBuffer;

	if (!m_WavRecorder)
	{
		return;
	}
	iResult = m_WavRecorder->GetWaveInTailByNumSamples( 551, wave );
	CWZ_WaveUnit waveUnit;
	waveUnit.GetWaveData(wave,vBuffer);
	nCount = (int)vBuffer.size();

	if (nCount>0)//&&pos>0
	{
		//if (MSE_bfDetectSingingVoice((TWZ_REAL*)(vBuffer.end()-551).operator->(),551,11025))
		if ( iResult == 551 )
		{
			//if (m_iAlgorithmSel==1)
			//{
			//ȡ����551����
			//��ȡʵʱ���ֽ��
			unsigned int sentence_index = -1;
			float pitch = 0.0f;
			float pitchdiff = 1000.0f;
			float realtime_score = 0.0f;
			int rank = 0;
			float accumulate_score = 0.0f;
			bool switch_sentence = false;
			int algorithm_type = 1;
			realtimeEval( (float*)(vBuffer.begin()).operator->(), 551, (uint)ns_elapsed_ms , pitch,pitchdiff, realtime_score, rank, sentence_index,
				 accumulate_score,switch_sentence,algorithm_type);

			_tRealtimeGrade realtimeGrade;

			realtimeGrade.cur_tm = (uint)ns_elapsed_ms;
			realtimeGrade.cur_pitch = pitch;
			realtimeGrade.sentence_index = sentence_index;
			realtimeGrade.realtime_score = realtime_score;
			realtimeGrade.accumulate_score = accumulate_score;

			RealtimeGrade(realtimeGrade);

			_tSentenceGrade sentenceGrade;
			sentenceGrade.sentence_score = accumulate_score;
			if ( switch_sentence )
			{
				if ( accumulate_score > 800 )
					sentenceGrade.sentence_level = SENTENCEGRADELEVEL_PERFECT;
				else if ( accumulate_score > 700 )
					sentenceGrade.sentence_level = SENTENCEGRADELEVEL_GREAT;
				else if ( accumulate_score > 600 )
					sentenceGrade.sentence_level = SENTENCEGRADELEVEL_GOOD;
				else if ( accumulate_score > 300 )
					sentenceGrade.sentence_level = SENTENCEGRADELEVEL_POOR;
				else
					sentenceGrade.sentence_level = SENTENCEGRADELEVEL_MISS;

				SentenceGrade(sentenceGrade);
			}
			if ( sentence_index != -1 )
			{
				sentenceGrade.sentence_index = sentence_index;
			}
		}
	}

}

// called once every frame
void SceneObjectEx::update(ulong  ns_elapsed_ms)
{
	writeLog("SceneObjectEx::update enter");
    //return;
    unsigned int elapsed_ms = (uint)ns_elapsed_ms;
    /*
    if ( elapsed_ms > 17 || elapsed_ms < 16 )
    {
        NSLog( @"elapsed_ms[%d]", elapsed_ms );
    }
    */
    if ( mnCallbackRealtimeGradeCount > 0 )
	{
        _tRealtimeGrade & realtime_grade = mCallbackRealtimeGrade[mnCallbackRealtimeGradeCount-1];
        eventAvRealtimeGrade(elapsed_ms , realtime_grade ,true);
        mnCallbackRealtimeGradeCount--;
    }
    
    eventMainUpdate( elapsed_ms);

    if ( mnCallbackSentenceGradeCount > 0 )
	{
        _tSentenceGrade & sentence_grade = mCallbackSentenceGrade[mnCallbackSentenceGradeCount-1];
        eventAvSentenceGrade( sentence_grade);
        mnCallbackSentenceGradeCount--;
    }
    
    //���ڵ���ʱ����ʱ�䡣
	if (sentence_render)
	{
		sentence_render-> update(elapsed_ms);
		sentence_render-> populateGeometryBuffer();
	}
	if (wave_render)
	{
		wave_render-> populateGeometryBuffer();
	}
    if (lyric_render)
    {
		lyric_render-> populateGeometryBuffer();
    }
    
}

void SceneObjectEx::end()
{
	StopPlayer();
	if (m_WavRecorder)
	{
		m_WavRecorder->RecordStop();
		char recoderFile[256] ={0};
		sprintf(recoderFile,"%s\\recoder\\tmpRecoder.wav",m_dataDir.c_str());
		if(DeleteFile(recoderFile)==0)
		{
			OutputDebugStringA("delete recoder file failed\n");
		}
		m_WavRecorder->SaveMonoWavFileFromWaveIn(recoderFile);
		m_WavRecorder->RecordClose();
		//MSE_RealTimeEvalSave();
	}
	
}

/*
void SceneObjectEx::CreatePath(std::string strPath)
{
	//����һ��Ŀ¼��strPath��
	//strPath����Ϊһ��·�������ܰ����ļ�����

	CString strTemp=strPath;

	int nIndex=strPath.find(":\\",0);
	if(nIndex != -1)//�ҵ���
	{
		//����·��

		int nBegain=nIndex+1;
		int ntt=strPath.Find("\\",3);
		while((nBegain = strPath.Find("\\",nBegain+1)) != -1)
		{
			CString strTemp=strPath.Left(nBegain);
			if(!CreateDirectory(strTemp,NULL))
			{
				DWORD dError=GetLastError();
				if(dError == ERROR_ALREADY_EXISTS)
				{
					int n=0;
				}
				else if(dError == ERROR_PATH_NOT_FOUND)
				{
					int n=1;
				}
			}
		}

		CreateDirectory(strPath,NULL);
	}

	//����Ƿ�Ϊ����·��
	nIndex=strPath.Find("\\\\",0);
	if(nIndex == 0)//����ʼλ��
	{
		//������·��
		int nBegain=nIndex+1;
		while((nBegain = strPath.Find("\\",nBegain+2)) != -1)
		{
			CString strTemp=strPath.Left(nBegain);
			if(!CreateDirectory(strTemp,NULL))
			{
				DWORD dError=GetLastError();
				if(dError == ERROR_ALREADY_EXISTS)
				{
					int n=0;
				}
				else if(dError == ERROR_PATH_NOT_FOUND)
				{
					int n=1;
				}
			}
		}
	}
}*/
